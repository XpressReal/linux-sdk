#include <QCoreApplication>
#include <QStringList>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QTextCodec>
#include <QDateTime>
#include <QDebug>
#include <QThread>
#include <QTimer>
#include <stdlib.h>
#include <time.h>
#include <fcntl.h>
#include "rtkgst.h"

#define HEADER      "StressTest: "
#define HEADER_ERR  "StressTest: [ERR] "
QString absFilePath = "";
bool isTesting = false;
QtMessageHandler defMsgHandler;
RtkGst rtkGs;
int g_pipefd[2];
QTimer *progressTimer;


QString currentHeader()
{
    return QDateTime::currentDateTime().toString("[yy/MM/dd hh:mm:ss.zzz] ");
}

void stressTest_seek()
{
    MediaInfo *info = rtkGst->get_media_info (absFilePath.toStdString());
    const int interval_seek = 300;
    const int interval_check = 250;
    int interval = 0;
    bool first_round = true;


    rtkGst->rtk_gst_play_new (absFilePath, NULL, false, 0, 0, 1920, 1080, true);

    isTesting = true;
    progressTimer->start(interval_check);
    QThread::sleep(3);
    while (isTesting)
    {
        if (first_round || interval > 1000)
        {
            srand(time(NULL));
            first_round = false;
            interval -= 1000;
        }
        int x = rand();
        double rate = ((double)(x % 90))/100.0;
        rtkGst->rtk_gst_seek_by_slider(rate);
        QThread::msleep(interval_seek);
        interval += interval_seek;
    }
    progressTimer->stop();
    rtkGst->rtk_gst_play_free();
}

static void updateProgress()
{
    auto [position, duration] = rtkGst->rtk_gst_getPlaybackPositionDuration();

    if (isTesting != true)
        return;
    if (duration > 0)
    {
        qDebug() << QString().sprintf("%s%s %d / %d",
                        currentHeader().toStdString().c_str(), HEADER,
                        position, duration);
    }

    char buffer[100];
    int bytesRead;
    if ((bytesRead = read(g_pipefd[0], buffer, sizeof(buffer) - 1)) != -1) {
        if (bytesRead > 0) {
            buffer[bytesRead] = '\0';
            qDebug() << "pipe read: " << buffer;

            if (strcmp(buffer, "GST_MESSAGE_EOS") == 0)
            {
                isTesting = false;
                rtkGst->rtk_gst_play_free();
                progressTimer->stop();
            }
        }
    }
}

void init()
{
    rtkGst->set_debug(true);
    progressTimer = new QTimer(NULL);
    QObject::connect(progressTimer, &QTimer::timeout, NULL, &updateProgress);
}

void finalize()
{
    qWarning() << QString().sprintf("%s%s %s",
                    currentHeader().toStdString().c_str(), HEADER,
                    __FUNCTION__);
    if(isTesting)
    {
        isTesting = false;
        sleep (3);
    }
    rtkGst->rtk_gst_play_free();
    progressTimer->stop();
    delete(progressTimer);
    progressTimer = NULL;
}

static void sig_handler(int sig)
{
    switch(sig)
    {
    case SIGSEGV:   // crash
    case SIGKILL:   // kill command
    case SIGTERM:
    case SIGINT:    // ctrl+c
    case SIGTSTP:   // ctrl+z
//    case SIGILL:
//    case SIGABRT:
//    case SIGBUS:
//    case SIGHUP:
        qDebug() << QString().asprintf("%s() with signal=%d", __func__, sig);
        finalize();
        exit(1);
        break;
    }
}

void myMsgHandler(QtMsgType type, const QMessageLogContext &log, const QString &msg)
{
    static bool lock = false;
    static bool initLog = true;

    if (lock)
        return;
    lock = true;

    QString str = QString("[%1] %2")
                  .arg(QDateTime::currentDateTime().toString("yy/MM/dd HH:mm:ss.zzz"))
                  .arg(msg);

    // Qt Gui Application
    if(defMsgHandler != NULL)
    {
        defMsgHandler(type, log, str);
    }
    else
    {
        fprintf(stderr, "%s\n", str.toLatin1().constData());
    }

    // sysLog.logInfo(msg);
    lock = false;
}

int main(int argc, char *argv[])
{
    // in Qt Console Application, defMsgHandler is null
    // in Qt Gui Application, defMsgHandler is NOT null
    defMsgHandler = qInstallMessageHandler(myMsgHandler);

    QCoreApplication app(argc, argv);

    // In order to display correct file name with other languages, ex: Chinese for zh-cn or zh-tw
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));

    struct sigaction newact;
    newact.sa_handler = (__sighandler_t)sig_handler;
    sigemptyset(&newact.sa_mask);
    newact.sa_flags = 0;
    sigaction(SIGSEGV, &newact, NULL);
    sigaction(SIGKILL, &newact, NULL);
    sigaction(SIGTERM, &newact, NULL);
    sigaction(SIGINT, &newact, NULL);
    sigaction(SIGTSTP, &newact, NULL);
//    sigaction(SIGILL, &newact, NULL);
//    sigaction(SIGABRT, &newact, NULL);
//    sigaction(SIGBUS, &newact, NULL);
//    sigaction(SIGHUP, &newact, NULL);

    // Upper part is failed, add these to set signal
    signal(SIGINT, sig_handler);
    signal(SIGTERM, sig_handler);
    signal(SIGTSTP, sig_handler);
    signal(SIGSEGV, sig_handler);

    if (argc == 2)
    {
        QString filePath = QString(argv[1]);
        QFile file(filePath);
        if (file.exists() != true)
        {
            qWarning() << QString().sprintf("%s%s File does not exist: %s",
                            currentHeader().toStdString().c_str(), HEADER_ERR,
                            filePath.toStdString().c_str());
            return 1;
        }
        QFileInfo fileInfo(filePath);
        absFilePath = fileInfo.absoluteFilePath();
    }
    else
    {
        qWarning() << QString().sprintf("%s%s Wrong parameters, argc: %d",
                        currentHeader().toStdString().c_str(), HEADER_ERR,
                        argc);
        return 1;
    }

    if (pipe(g_pipefd) == -1) {
        perror("pipe");
    } else {
        int flags = fcntl(g_pipefd[0], F_GETFL, 0);
        fcntl(g_pipefd[0], F_SETFL, flags | O_NONBLOCK);
    }

    init();
    stressTest_seek();
    finalize();
    return 0;
}
