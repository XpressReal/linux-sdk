/**
 * @file gridinfo.cpp
 * @author Realtek Semiconductor Corp.
 * @date Aug 2017
 * @brief The extension of QRect
 */

#include "gridinfo.h"
#include "config.h"

GridInfo::GridInfo()
{
    GridInfo(0,0,0,0, 0, false);
}

GridInfo::GridInfo(int x, int y, int width, int height,
                   int border, bool visible)
{
    setGridInfo(x, y, width, height, border, visible);
}

void GridInfo::setGridInfo(int x, int y, int width, int height,
                           int border, bool visible)
{
    this->setX(x);
    this->setY(y);
    this->setWidth(width);
    this->setHeight(height);
    this->border = border;
    this->visible = visible;
}

void GridInfo::copy(GridInfo *from)
{
    this->setRect(from->x(), from->y(), from->width(), from->height());
    this->border = from->border;
    this->visible = from->visible;
}

void GridInfo::swap(GridInfo *from)
{
    GridInfo *temp = new GridInfo();
    temp->copy(this);
    this->copy(from);
    from->copy(temp);
}

int GridInfo::borderSize()
{
    return border;
}

bool GridInfo::isVisible()
{
    return this->visible;
}
