/**
 * @file rtksim.h
 * @author Realtek Semiconductor Corp.
 * @date Nov 2017
 * @brief The interface of Realtek library for QT_ENV_ONLY
 */

#ifndef RTKSIM_H
#define RTKSIM_H

#include "define.h"
#include <QString>
#include <QPixmap>

#define CH_MAX  32

#if QT_ENV_ONLY != 1
#if RTSP_AV
extern "C" {
#include "rtkcontrol.h"
#include "rtkrtspav.h"
//#include "rtkplayer.h"
}
#elif RTSP_GST
extern "C" {
#include "rtkcontrol.h"
#include "rtkrtsp.h"
#include "rtkplayer.h"
}
#endif
#else
#include <QThread>
#include <QMutex>
#include <QTime>

/******************************* rtktypes.h **********************************/
/**
 * @brief Return code.
 */
typedef enum
{
  RTK_SUCCESS = 0,
  RTK_ERR_FAILURE = -1,
  RTK_ERR_INVALID_OPERATION = -2,
  RTK_ERR_INVALID_PARAM = -3,
  RTK_ERR_INSUFFICIENT_RESOURCE = -4,
  RTK_ERR_INVALID_STREAM = -5,
  RTK_ERR_DECODER_NOT_FOUND = -6,
} RtkReturn_e;

/******************************* rtkcontrol.h ********************************/

#define MAX_INSTANCE 32

/**
 * @brief window identifier
 *
 * A window identifier (wnd) indicates a display window which shows media
 * streams originated from a channel.
 */
typedef int WindowId;

/**
 * @brief channel identifier
 *
 * A channel identifier (ch) indicates a media channel which is used to, for
 * example, decode media stream. To show the decoded stream in a display window,
 * a channel has to be bound to a window.
 */
typedef int ChannelId;

/**
 * @brief Input Stream type.
 */
typedef enum {
    INPUT_STREAM_FILE,
    INPUT_STREAM_LIVE,
} InputStreamType_e;

/**
 * @brief A structure describing the position and size of a window.
 *
 * The x and y describe the position of the window’s upper-left
 * corner. The width and height describe the window size.
 */
typedef struct {
    unsigned int x;
    unsigned int y;
    unsigned int width;
    unsigned int height;
    InputStreamType_e inputType;
#if 0
    pid_t pid;
#endif
} WindowParams_t;

/**
 * @brief A structure describing the position and size of a window.
 *
 * The width and height describe the window size.
 */
typedef struct {
    unsigned int width;
    unsigned int height;
} Resolution_t;

/**
 * @brief Audio codec.
 */
typedef enum {
    AUDIO_NONE = -1,
    AUDIO_AUTO,
    AUDIO_AAC,
    AUDIO_PCMU,
    AUDIO_PCMA,
    AUDIO_AMRNB,
    AUDIO_G726,
} AudioCodec_e;

/**
 * @brief Video codec.
 */
typedef enum {
    VIDEO_NONE = -1,
    VIDEO_AUTO,
    VIDEO_H264,
    VIDEO_H265,
    VIDEO_MJPEG,
    VIDEO_MPEG4,
} VideoCodec_e;

/**
 * @brief A structure describing the parameters of a media channel.
 */
typedef struct {
    unsigned int width;
    unsigned int height;
    AudioCodec_e aud_codec;
    int aud_samplerate;
    int aud_bitrate;
    int aud_channels;
    VideoCodec_e vid_codec;
    int vid_framerate;
    int vid_bitrate;
} ChannelParams_t;

/**
 * @brief A structure describing the parameters of a media channel.
 */
typedef struct {
    int ionBufFd;
    int ionBufHdl;
    unsigned int width;
    unsigned int height;
    unsigned int size;
    unsigned char *ionBufVirt;
}SnapshotBuffer_t;

/**
 * @brief HDMI resolution.
 */
typedef enum {
    HDMI_AUTO,
    HDMI_720P_50,
    HDMI_720P_60,
    HDMI_1080P_30,
    HDMI_1080P_50,
    HDMI_1080P_60,
    HDMI_1080I_50,
    HDMI_1080I_60,
    HDMI_4K_25,
    HDMI_4K_30,
    HDMI_4K_60,
    HDMI_NONE,
} HDMIMode_e;

/**
 * @brief DP resolution.
 */
typedef enum {
    DP_AUTO,
    DP_720P_60,
    DP_1080P_60,
    DP_4K_30,
    DP_NONE,
} DPMode_e;

/**
 * @brief Channel state.
 */
typedef enum {
    CH_STATE_PLAY,
    CH_STATE_PAUSE, // for file play pause, TBD
    CH_STATE_STOP,
} ChannelState_e;

/**
 * @brief Video Frame Buffer resolution.
 */
typedef enum
{
    FRAME_BUFFER_1920x1088,
    FRAME_BUFFER_3840x2160,
} FrameBufferSize_e;

typedef struct debugInfo
{
    unsigned long long bufferWrtieCnt;
    unsigned long long sizeZeroCnt;
    unsigned long long writeErrorCnt;
    unsigned long long connectErrorCnt;
    char enPrint;
    QDateTime   bufferStart;
}debugInfo;

extern int debuglevel;

/**
 * @brief A function to initialize service communication.
 *
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_serv_initialize(void);

/**
 * @brief A function to terminate service communication.
 *
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_serv_terminate(void);

/**
 * @brief A function to force terminate service communication.
 *
 * @return 0 on success, a negative error code on failure
 * @note This is used for special case. Don't use this to terminate at normal case!
 */
RtkReturn_e rtk_serv_force_terminate(void);

/**
 * @brief A function to create a window.
 *
 * @param x X axis of the position (the leftmost axis indicates 0)
 * @param y Y axis of the position (the topmost axis indicates 0)
 * @param width window width
 * @param height window height
  * @param inputType input source type is live or file
 * @return window identifier on success, a negative value on failure
 */
WindowId rtk_disp_create(unsigned int x, unsigned int y,
             unsigned int width, unsigned int height, InputStreamType_e inputType);

/**
 * @brief A function to destroy a window.
 *
 * @param wnd window identifier
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_destroy(WindowId wnd);

/**
 * @brief A function to get window parameters.
 *
 * @param wnd window identifier
 * @param param a structure containing the window parameters be returned
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_params(WindowId wnd, WindowParams_t * param);

/**
 * @brief A function to get decoded (source) window parameters.
 *
 * @param wnd window identifier
 * @param param a structure containing the resolution parameters be returned
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_srcSize(WindowId wnd, Resolution_t * param);

/**
 * @brief A function to change window position and size.
 *
 * @param wnd window identifier
 * @param x X axis of the position (the leftmost axis indicates 0)
 * @param y Y axis of the position (the topmost axis indicates 0)
 * @param width window width
 * @param height window height
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_resize(WindowId wnd, unsigned int x, unsigned int y,
            unsigned int width, unsigned int height);

/**
 * @brief A function to swap window position and size.
 *
 * @param wndA window identifier
 * @param wndB window identifier
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_swap(WindowId wndA, WindowId wndB);


/**
 * @brief A function to show the cropped area in a window.
 *
 * @param wnd window identifier
 * @param crop_x X axis of the cropped area
 * @param crop_y Y axis of the cropped area
 * @param crop_w width of the cropped area
 * @param crop_h height of the cropped area
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_crop(WindowId wnd, unsigned int crop_x, unsigned int crop_y,
          unsigned int crop_w, unsigned int crop_h);

/**
 * @brief A function to set window blank.
 *
 * @param enable TRUE to set blank
 * @param num number of window identifiers. A variable number of arguments
 * indicates the window identifiers.
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_blank(bool enable, int num, ...);

/**
 * @brief A function to check if blank window.
 *
 * @param wnd window identifier
 * @param enabled blank or not
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_blank(WindowId wnd, bool * enabled);

/**
 * @brief A function to freeze the window.(Keeps the current frame on the screen and lost the next frames)
 *
 * @param enable TRUE to freeze
 * @param num number of window identifiers. A variable number of arguments
 * indicates the window identifiers.
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_freeze(bool enable, int num, ...);

/**
 * @brief A function to check if window freezed.
 *
 * @param wnd window identifier
 * @param enabled freeze or not
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_freeze(WindowId wnd, bool * enabled);

/**
 * @brief A function to set output resolution.
 *
 * @param mode output resoultion
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_output(HDMIMode_e hdmiMode, DPMode_e dpMode);

/**
 * @brief A function to get output setting.
 *
 * @param mode the output mode be returned
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_output(HDMIMode_e * mode, DPMode_e * dpMode);

/**
 * @brief A function to change display frame rate of a channel
 *
 * @param ch channel identifier
 * @param fps frame per second (0~30, 0 for original fps)
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_outputFrameRate(ChannelId ch, unsigned int fps);

/**
 * @brief A function to set brightness.
 *
 * @param brightness the brightness value to be set [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_brightness(unsigned char brightness);

/**
 * @brief A function to get brightness.
 *
 * @param brightness the brightness value to be get [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_brightness(unsigned char * brightness);

/**
 * @brief A function to set contrast.
 *
 * @param contrast the contrast value to be set [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_contrast(unsigned char contrast);

/**
 * @brief A function to get contrast.
 *
 * @param contrast the contrast value to be get [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_contrast(unsigned char * contrast);

/**
 * @brief A function to set hue.
 *
 * @param hue the hue value to be set [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_hue(unsigned char hue);

/**
 * @brief A function to get hue.
 *
 * @param hue the hue value to be get [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_hue(unsigned char * hue);

/**
 * @brief A function to set saturation.
 *
 * @param saturation the saturation value to be set [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_saturation(unsigned char saturation);

/**
 * @brief A function to get saturation.
 *
 * @param saturation the saturation value to be get [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_saturation(unsigned char * saturation);

/**
 * @brief A function to set sharpness.
 *
 * @param sharpness the sharpness value to be set [0~31, default 0]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_sharpness(unsigned char sharpness);

/**
 * @brief A function to get sharpness.
 *
 * @param sharpness the sharpness value to be get [0~31, default 0]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_sharpness(unsigned char * sharpness);

/**
 * @brief A function to debug.
 *
 * @param cmd the debug cmd
 * @param value the debug value
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_debug(unsigned int cmd, unsigned int value, char * path);

/**
 * @brief A function to set one channel's brightness.
 *
 * @param wnd the window ID indicates which window to set
 * @param brightness the brightness value to be set [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_channel_brightness(WindowId wnd, unsigned int brightness);

/**
 * @brief A function to get one channel's brightness.
 *
 * @param wnd the window ID indicates which window to get
 * @param brightness the brightness value to be get [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_channel_brightness(WindowId wnd, unsigned int * brightness);

/**
 * @brief A function to set one channel's contrast.
 *
 * @param wnd the window ID indicates which window to set
 * @param contrast the contrast value to be set [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_channel_contrast(WindowId wnd, unsigned int contrast);

/**
 * @brief A function to get one channel's contrast.
 *
 * @param wnd the window ID indicates which window to get
 * @param contrast the contrast value to be get [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_channel_contrast(WindowId wnd, unsigned int * contrast);

/**
 * @brief A function to set one channel's hue.
 *
 * @param wnd the window ID indicates which window to set
 * @param hue the hue value to be set [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_channel_hue(WindowId wnd, unsigned int hue);

/**
 * @brief A function to get one channel's hue.
 *
 * @param wnd the window ID indicates which window to get
 * @param hue the hue value to be get [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_channel_hue(WindowId wnd, unsigned int * hue);

/**
 * @brief A function to set one channel's saturation.
 *
 * @param wnd the window ID indicates which window to set
 * @param saturation the saturation value to be set [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_channel_saturation(WindowId wnd, unsigned int saturation);

/**
 * @brief A function to get one channel's saturation.
 *
 * @param wnd the window ID indicates which window to get
 * @param saturation the saturation value to be get [0~64, default 32]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_channel_saturation(WindowId wnd, unsigned int * saturation);

/**
 * @brief A function to set one channel's sharpness.
 *
 * @param wnd the window ID indicates which window to set
 * @param sharpness the sharpness value to be set [0~31, default 0]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_channel_sharpness(WindowId wnd, unsigned int sharpness);

/**
 * @brief A function to get one channel's sharpness.
 *
 * @param wnd the window ID indicates which window to get
 * @param sharpness the sharpness value to be get [0~31, default 0]
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_channel_sharpness(WindowId wnd, unsigned int * sharpness);

/**
 * @brief A function to set background color.
 *
 * @param r the R in RGB color to set
 * @param r the G of RGB color to set
 * @param r the B of RGB color to set
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_bgcolor(unsigned char r, unsigned char g, unsigned char b);

/**
 * @brief A function to set video frame buffer resolution.
 *
 * @param fbSize the video frame buffer resoltion to set
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_set_videoFB_Resolution(FrameBufferSize_e fbSize);

/**
 * @brief A function to get video frame buffer resolution.
 *
 * @param fbSize the video frame buffer resoltion to get
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_disp_get_videoFB_Resolution(FrameBufferSize_e * fbSize);

/**
 * @brief A function to add decoding channel for video only.
 *
 * @param width video width, value -1 for automatic detection
 * @param height video height, value -1 for automatic detection
 * @return channel identifier on success, a negative value on failure
 */
ChannelId rtk_dec_add_channel_video(unsigned int width, unsigned int height);

/**
 * @brief A function to set channel parameters for video.
 *
 * @param ch channel identifier
 * @param param a structure containing the channel parameters
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_set_channel_video (ChannelId ch, ChannelParams_t * param);

/**
 * @brief A function to remove decoding channel.
 *
 * @param ch channel identifier
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_remove_channel(ChannelId ch);

/**
 * @brief A function to get channel parameters.
 *
 * @param ch channel identifier
 * @param param a structure containing the channel parameters be returned
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_get_params(ChannelId ch, ChannelParams_t * param);

/**
 * @brief A function to bind a channel to a window.
 *
 * A channel has to be bound to a window for playing the stream in a display
 * window.
 *
 * @param ch channel identifier
 * @param wnd window identifier
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_bind(ChannelId ch, WindowId wnd);

/**
 * @brief A function to set play state of a channel.
 *
 * @param state channel state
 * @param ch channel identifier
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_set_play(ChannelState_e state, ChannelId ch);

/**
 * @brief A function to get play state of a channel.
 *
 * @param ch channel identifier
 * @param state the channel state be returned
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_get_play(ChannelId ch, ChannelState_e * state);

/**
 * @brief A function to change display frame rate of a channel
 *
 * @param ch channel identifier
 * @param fps frame per second (0~30, 0 for original fps)
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_fps(ChannelId ch, unsigned int fps);

/**
 * @brief A function to play audio of a channel.
 *
 * @param ch channel identifier
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_start_audio(ChannelId ch);

/**
 * @brief A function to stop playing audio of a channel.
 *
 * @param ch channel identifier
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_stop_audio(ChannelId ch);

/**
 * @brief A function to set audio of a channel mute.
 *
 * @param enable TRUE to set mute
 * @param ch channel identifier
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_set_mute(bool enable, ChannelId ch);

/**
 * @brief A function to set audio volume of a channel.
 *
 * @param volume to set audio volume : 0~10.0f
 * @param ch channel identifier
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_set_volume(double volume, ChannelId ch);

/**
 * @brief A function to get audio volume of a channel.
 *
 * @param the channel volume be returned
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_get_volume(ChannelId ch, double *volume);

/**
 * @brief A function to increase audio volume of a channel.
 *
 * @param ch channel identifier
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_increase_volume(ChannelId ch);

/**
 * @brief A function to decrease audio volume of a channel.
 *
 * @param ch channel identifier
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_decrease_volume(ChannelId ch);

/**
 * @brief A function to flush decoder input & output buffer of a channel.
 *
 * @param ch channel identifier
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_dec_flush(ChannelId ch);

/**
 * @brief A function to take a snapshot of the whole display.
 *
 * @param filename the location of the snapshot JPEG image file
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_snapshot_display(const char *filename);

/**
 * @brief A function to take a snapshot of the partial display.
 *
 * @param
 * @return 0 on success, a negative error code on failure, >0 for buffer size(width*height*4)
 */
RtkReturn_e rtk_snapshot_display_wnd_ARGB(WindowId wnd, void **buffer);

/**
 * @brief A function to take a snapshot of the partial display.
 *
 * @param
 * @return 0 on success, a negative error code on failure, >0 for buffer size(width*height*4)
 */
RtkReturn_e rtk_get_window_image(WindowId wnd, SnapshotBuffer_t *point);

/**
 * @brief A function to free the buffer of snapshot window.
 *
 * @param
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_free_window_image(SnapshotBuffer_t point);

/**
 * @brief A function to get IPC status.
 *
 * @param ch channel identifier
 * @param bufferWriteCnt the amount that rtk_buffer_send is called
 * @param sizeZeroCnt the amount that the size of rtk_buffer_send is zero
 * @param connectErrCnt the amount of the socket connection error
 * @param writeErrCnt the amount of the socket write error
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_ipc_debug_getInfo(ChannelId ch, unsigned long long * bufferWriteCnt,
                                  unsigned long long * sizeZeroCnt,
                                  unsigned long long * connectErrCnt,
                                  unsigned long long * writeErrCnt);

/**
 * @brief A function to print IPC status.
 *
 * @param ch channel identifier
 * @param fEn print or not
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_ipc_debug_printInfo(ChannelId ch, char fEn);

/**
 * @brief A function to reset IPC status.
 *
 * @param ch channel identifier
 * @return 0 on success, a negative error code on failure
 */
RtkReturn_e rtk_ipc_debug_reset(ChannelId ch);

/**
 * @brief A function to send stream or frame to a channel.
 *
 * @param ch channel identifier
 * @param data the pointer to data.
 * @param size size of data
 * @param ptsMs time stamp, -1 means framerate controlled by application layer
 * @param timeoutMs mode of sending streams, 0 for non-block mode, -1 for block mode
 * @return the number of bytes written on success, a negative value on failure
 */
int rtk_buffer_send(ChannelId ch, void *data, int size, unsigned int ptsMs, unsigned int timeoutMs);

#if RTSP_AV
/******************************* rtkrtspav.h ********************************/
/**
 * @brief RTSP client identifier
 *
 * A RTSP client identifier (ch) indicates a client which is used to do
 * connection to a RTSP address, and receive the video/audio frame data.
 */
typedef int RtspClientId;

#define REC_VERSION		0x00
#define URL_LENGTH		256
#define CLIENT_MAX      64
typedef struct
{
    unsigned char tag[4];
    double totalTime;	// unit: 1 sec
    int length;
    char version;
    unsigned char flag;
    char gui_ch;
    char v_ch;
    char a_ch;
    short int year;
    unsigned char month;
    unsigned char day;
    double time;  // time from 0:00:00.000, unit: 1 sec
    int wnd_x;
    int wnd_y;
    int wnd_width;
    int wnd_height;
    unsigned short v_codec_type;
    unsigned short a_codec_type;
    int v_frame_width;
    int v_frame_height;
    char url[URL_LENGTH];	// rtsp address
} RecHeaderInfo;

typedef struct
{
    int index;        // the index of clientList[]
    RecHeaderInfo info;
//    AVFormatContext *formatctx;
    int v_stream_idx; // video stream index
    int a_stream_idx; // audio stream index
//    AVPacket packet;
    bool bRunThread;
    bool bPktTimeout;
    bool bDisplay;    // if rtk_buffer_send() to display
    bool bSound;
    bool bRec;
    pthread_t thread;
    pthread_mutex_t mutex;
    struct timeval timeRcv;
} _RtkRtspFClient;

int rtk_rtsp_av_initialize();
int rtk_rtsp_av_terminate();
RtspClientId rtk_rtsp_av_client_new(const char *url);
void rtk_rtsp_av_client_free(RtspClientId cid);
void rtk_rtsp_av_player_play(RtspClientId cid, int v_ch, int a_ch);
void rtk_rtsp_av_player_stop(RtspClientId cid);
void rtk_rtsp_av_rec_set_info(RtspClientId cid,
                            int gui_ch, int v_ch, int a_ch,
                            int wnd_x, int wnd_y, int wnd_width, int wnd_height);
void rtk_rtsp_av_rec_start(RtspClientId cid, const char *path, int duration);
void rtk_rtsp_av_rec_stop(RtspClientId cid);
void rtk_rtsp_av_rec_change(RtspClientId cid, const char *path, int duration);

#elif RTSP_GST
/******************************* rtkrtsp.h ********************************/
typedef struct _RtspClient RtspClient;

typedef enum
{
  MUX_MPEGTS,
  ES_VIDEO,
  ES_H264,
  ES_H265,
} Stream;

typedef struct
{
  RtspClient *client;
} RtspPlayer;

/* RTSP player */
RtspPlayer *rtsp_player_new (const char *url, int ch);
void rtsp_player_free (RtspPlayer *player);
void rtsp_player_play (RtspPlayer *player);
void rtsp_player_stop (RtspPlayer *player); // also do rtsp_player_rec_stop() first if already recording
void rtsp_player_set_stream (RtspPlayer * player, Stream stream);
void rtsp_player_rec_start (RtspPlayer * player, const char *path, uint duration);
void rtsp_player_rec_stop (RtspPlayer * player);
void rtsp_player_rec_change (RtspPlayer * player, const char *path, uint duration);
void rtsp_client_set_latency (RtspClient *self, uint latency);

/******************************* rtkplayer.h *******************************/
#if 0
typedef struct {
    unsigned int width;
    unsigned int height;
    int/*AudioCodec_e*/ aud_codec;
    int aud_samplerate;
    int aud_bitrate;
    int aud_channels;
    int/*VideoCodec_e*/ vid_codec;
    int vid_framerate;
    int vid_bitrate;
} PlayerChannelParams_t/*ChannelParams_t*/;
#endif

int/*RtkReturn_e*/ rtk_player_initialize(void);
int/*ChannelId*/ rtk_player_add_channel_video();
int/*ChannelId*/ rtk_player_add_channel_audio();
int/*ChannelId*/ rtk_player_add_channel_av();
int/*RtkReturn_e*/ rtk_player_add_idx_channel_video(int/*ChannelId*/ availableCh);
int/*RtkReturn_e*/ rtk_player_add_idx_channel_audio(int/*ChannelId*/ availableCh);
int/*RtkReturn_e*/ rtk_player_add_idx_channel_av(int/*ChannelId*/ availableCh);
#if 0
int/*RtkReturn_e*/ rtk_player_set_channel_video(int/*ChannelId*/ ch, PlayerChannelParams_t * param);
int/*RtkReturn_e*/ rtk_player_set_channel_audio(int/*ChannelId*/ ch, PlayerChannelParams_t * param);
#endif
int/*RtkReturn_e*/ rtk_player_remove_channel(int/*ChannelId*/ ch);
#if 0
int/*RtkReturn_e*/ rtk_player_bind(int/*ChannelId*/ ch, int/*WindowId*/ wnd);
#else
int/*RtkReturn_e*/ rtk_player_bind(int/*ChannelId*/ ch, int/*WindowId*/ wnd, int x, int y, int width, int height);
#endif
int/*RtkReturn_e*/ rtk_player_set_play(int/*ChannelState_e*/ state, int/*ChannelId*/ ch);
int/*RtkReturn_e*/ rtk_player_seek(int/*ChannelId*/ ch, int time);
int/*RtkReturn_e*/ rtk_player_set_speed(int/*ChannelId*/ ch, double rate);
int/*RtkReturn_e*/ rtk_player_set_fps(int/*ChannelId*/ ch, unsigned int fps);
int/*RtkReturn_e*/ rtk_player_open(int/*ChannelId*/ ch, const char *filename);
int/*RtkReturn_e*/ rtk_player_start_audio(int/*ChannelId*/ ch);
int/*RtkReturn_e*/ rtk_player_stop_audio(int/*ChannelId*/ ch);
int/*RtkReturn_e*/ rtk_player_set_mute(bool enable, int/*ChannelId*/ ch);
int/*RtkReturn_e*/ rtk_player_get_volume(int/*ChannelId*/ ch, double *volume);
int/*RtkReturn_e*/ rtk_player_set_volume(double volume, int/*ChannelId*/ ch);
int/*RtkReturn_e*/ rtk_player_increase_volume(int/*ChannelId*/ ch);
int/*RtkReturn_e*/ rtk_player_decrease_volume(int/*ChannelId*/ ch);
int/*RtkReturn_e*/ rtk_player_query_time(int/*ChannelId*/ ch, uint64_t *pCurrent);
bool rtk_player_get_available(int ch);
int/*RtkReturn_e*/ rtk_player_flush(int/*ChannelId*/ ch);
int/*RtkReturn_e*/ rtk_player_set_iFrame_only_mode(int/*ChannelId*/ ch, bool enable);

#endif

/******************************* simulation *******************************/
class RtkSimWnd
{
public:
    WindowId    wnd;
    WindowParams_t  wndParam;
    ChannelId   ch;

    bool    bBlank;
    bool    bFreeze;
    Resolution_t res;
    unsigned int crop_x, crop_y, crop_w, crop_h;

    unsigned int brightness, contrast, hue, saturation, sharpness;


    RtkSimWnd();
    void copyWndParam(WindowParams_t *wndParam);
};

class RtkSimCh
{
public:
    bool bAdded;
    ChannelParams_t chParam;
    ChannelState_e state;

    double       dec_speed;
    unsigned int dec_fps;
    unsigned int output_fps;
    bool         mute;
    double       volume;

    debugInfo   dbgInfo;

    RtkSimCh();
};

#if RTSP_AV
#elif RTSP_GST
class RtkSimData
{
public:
    RtspPlayer *pPlayer;
    QString     absRecFilePath;
    int         ts_idx;
    int         duration;   // millisecond
    QTime       *pTime;

    RtkSimData()
    {
        pPlayer = new RtspPlayer();
        ts_idx = 0;
        duration = 0;
        pTime = NULL;
    }
    ~RtkSimData()
    {
        if(pPlayer != NULL)
        {
            free(pPlayer);
            pPlayer = NULL;
        }
        if(pTime != NULL)
        {
            free(pTime);
            pTime = NULL;
        }
    }
};
#endif

class RtkSim : public QThread
{
    Q_OBJECT

public:
    bool ch_buffwrite[CH_MAX];
    int ch_next_idx;
    RtkSimCh rtkSimCh[CH_MAX];

    FrameBufferSize_e fbSize;
    unsigned char brightness, contrast, hue, saturation, sharpness;
    HDMIMode_e hdmiMode;
    DPMode_e dpMode;
    QList<RtkSimWnd *> rtkSimWndList;
#if RTSP_AV
#elif RTSP_GST
    QList<RtkSimData *> rtkSimDataList;
#endif
    QMutex mutex;

    RtkSim();
    RtkSimCh *getRtkSimChByRtkSimWnd(int ch);
#if RTSP_AV
#elif RTSP_GST
    void setStart();
    void run();
    void setStop();
    void finalize();
    void rec_start(RtkSimData *pRtkSimData, QString path, uint duration);
    void rec_stop(RtkSimData *pRtkSimData);
    void rec_timeup(RtkSimData *pRtkSimData);
    void rec_createFile(RtkSimData *pRtkSimData);
#endif

private:
    bool    bRun;
    int     pollingTime;
};

extern RtkSim *rtkSim;
#endif  // QT_ENV_ONLY == 1

#endif // RTKSIM_H
