/**
 * @file viewprocess.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The main display operation of IPC or playback per each channel
 */

#include "viewprocess.h"
#include "gui/mainwidget.h"

ViewProcess *viewProcess = NULL;

ViewProcess::ViewProcess()
{
    viewProcess = this;
    this->bUpdateIpcFrame = false;
    this->bUpdateFileFrame = false;
//    this->bSetFrameBufferSize = true;
    this->bSetBrightness = true;
    this->bSetContrast = true;
    this->bSetHue = true;
    this->bSetSaturation = true;
    this->bSetSharpness = true;

    bRun = false;
    this->ipc_grid_num = Config::style.ipcGridNum;
    this->ipc_grid_idx = 0;
    this->ipc_zoomin_idx = 0;
    this->ipc_viewMode = ViewProcess::ViewMode_Grid;
    this->file_grid_num = Config::style.fileGridNum;
    this->file_grid_idx = 0;
    this->file_zoomin_idx = 0;
    this->file_viewMode = ViewProcess::ViewMode_Hide;

    initIpcViewInfo();
    initFileViewInfo();

    slideShowTimer = new QTimer(this);
    set_slideshow_interval();
    connect(slideShowTimer, SIGNAL(timeout()), this, SLOT(timer_update_slideshow()));

    updateFrameTimer = new QTimer(this);
    updateFrameTimer->setInterval(30);
    connect(updateFrameTimer, SIGNAL(timeout()), this, SLOT(timer_update_frame()));

    updateStatusTimer = new QTimer(this);
    updateStatusTimer->setInterval(500);
    connect(updateStatusTimer, SIGNAL(timeout()), this, SLOT(timer_update_ipc_status()));

    ipcRecSegmentTimer = new QTimer(this);
    ipcRecSegmentTimer->setInterval(Config::sys.recSegmentPollingTime);
    connect(ipcRecSegmentTimer, SIGNAL(timeout()), this, SLOT(timer_rec_segment()));

    for(int i=0; i<CHANNEL_MAX; i++)
    {
        ipc_gridReal[i].type = GridReal::GridType_IPC;
        ipc_gridReal[i].channelIndex = i;
        ipc_array_idx[i] = i;
        file_gridReal[i].type = GridReal::GridType_File;
        if(i<Config::sys.fileChannelMax)
        {
            file_gridReal[i].channelIndex = i;
        }
    }

#if QT_ENV_ONLY == 1
    QList<QColor> colorList =
    {
        QColor::fromRgb(0, 170, 127), QColor::fromRgb(170, 170, 255),
        QColor::fromRgb(255, 170, 0), QColor::fromRgb(255, 255, 0),
        QColor::fromRgb(0, 170, 255), QColor::fromRgb(255, 170, 255),
        QColor::fromRgb(170, 85, 0), QColor::fromRgb(255, 0, 255),
        QColor::fromRgb(85, 0, 0), QColor::fromRgb(255, 0, 0),
        QColor::fromRgb(85, 0, 127), QColor::fromRgb(170, 170, 127),
        QColor::fromRgb(255, 255, 255),  QColor::fromRgb(0, 255, 0),
        QColor::fromRgb(0, 0, 127), QColor::fromRgb(85, 255, 255),

        QColor::fromRgb(0, 170, 127), QColor::fromRgb(170, 170, 255),
        QColor::fromRgb(255, 170, 0), QColor::fromRgb(255, 255, 0),
        QColor::fromRgb(0, 170, 255), QColor::fromRgb(255, 170, 255),
        QColor::fromRgb(170, 85, 0), QColor::fromRgb(255, 0, 255),
        QColor::fromRgb(85, 0, 0), QColor::fromRgb(255, 0, 0),
        QColor::fromRgb(85, 0, 127), QColor::fromRgb(170, 170, 127),
        QColor::fromRgb(255, 255, 255),  QColor::fromRgb(0, 255, 0),
        QColor::fromRgb(0, 0, 127), QColor::fromRgb(85, 255, 255),
    };
    for(int i=0; i<CHANNEL_MAX && i<colorList.count(); i++)
    {
        ipc_gridReal[i].bgColor = colorList.at(i);
    }
#endif
}

ViewProcess::~ViewProcess()
{
    if(ipcRecSegmentTimer != NULL)
    {
        delete(ipcRecSegmentTimer);
        ipcRecSegmentTimer = NULL;
    }
    if(updateFrameTimer != NULL)
    {
        delete(updateFrameTimer);
        updateFrameTimer = NULL;
    }
    if(updateStatusTimer != NULL)
    {
        delete(updateStatusTimer);
        updateStatusTimer = NULL;
    }
    if(slideShowTimer != NULL)
    {
        delete(slideShowTimer);
        slideShowTimer = NULL;
    }
}

void ViewProcess::initIpcViewInfo()
{
    int i, x, y, w, h;

    // grid_0
    view_ipc_grid0.gridNum = 0;

    // grid_1
    view_ipc_grid1.gridNum = 1;
    view_ipc_grid1.setGridInfo(0, 0, 0, _4K_WIDTH_, _4k_HEIGHT_, 0, true);    // full screen without frame size

    // grid_4
    view_ipc_grid4.gridNum = 4;
    w=_4K_WIDTH_/2;
    h=_4k_HEIGHT_/2;
    for(i=0; i<4&&i<CHANNEL_MAX; i++)
    {
        x = i%2;
        y = i/2;
        view_ipc_grid4.setGridInfo(i, x*w, y*h, w, h, Config::style.ipcBorderSize, true);
    }

    // grid_8
    view_ipc_grid8.gridNum = 8;
    w=_4K_WIDTH_/4;
    h=_4k_HEIGHT_/4;
    view_ipc_grid8.setGridInfo (0, 0, 0, w*3, h*3,  Config::style.ipcBorderSize, true);
    view_ipc_grid8.setGridInfo (1, w*3, 0, w, h,    Config::style.ipcBorderSize, true);
    view_ipc_grid8.setGridInfo (2, w*3, h*1, w, h,  Config::style.ipcBorderSize, true);
    view_ipc_grid8.setGridInfo (3, w*3, h*2, w, h,  Config::style.ipcBorderSize, true);
    view_ipc_grid8.setGridInfo (4, w*3, h*3, w, h,  Config::style.ipcBorderSize, true);
    view_ipc_grid8.setGridInfo (5, w*2, h*3, w, h,  Config::style.ipcBorderSize, true);
    view_ipc_grid8.setGridInfo (6, w*1, h*3, w, h,  Config::style.ipcBorderSize, true);
    view_ipc_grid8.setGridInfo (7, 0, h*3, w, h,    Config::style.ipcBorderSize, true);

    // grid_9
    view_ipc_grid9.gridNum = 9;
    w=_4K_WIDTH_/3;
    h=_4k_HEIGHT_/3;
    for(i=0; i<9&&i<CHANNEL_MAX; i++)
    {
        x = i%3;
        y = i/3;
        view_ipc_grid9.setGridInfo(i, x*w, y*h, w, h, Config::style.ipcBorderSize, true);
    }

    // grid_16
    view_ipc_grid16.gridNum = 16;
    w=_4K_WIDTH_/4;
    h=_4k_HEIGHT_/4;
    for(i=0; i<16&&i<CHANNEL_MAX; i++)
    {
        x = i%4;
        y = i/4;
        view_ipc_grid16.setGridInfo(i, x*w, y*h, w, h, Config::style.ipcBorderSize, true);
    }

#if 0
    // grid_17
    view_ipc_grid17.gridNum = 17;
    w=_4K_WIDTH_/5;
    h=_4k_HEIGHT_/5;
    view_ipc_grid17.setGridInfo ( 0, 0, 0, w*3, h*3, Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo ( 1, w*3, 0, w, h,   Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo ( 2, w*3, h*1, w, h, Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo ( 3, w*3, h*2, w, h, Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo ( 4, w*3, h*3, w, h, Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo ( 5, w*2, h*3, w, h, Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo ( 6, w*1, h*3, w, h, Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo ( 7, 0, h*3, w, h,   Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo ( 8, w*4, 0, w, h,   Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo ( 9, w*4, h*1, w, h, Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo (10, w*4, h*2, w, h, Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo (11, w*4, h*3, w, h, Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo (12, w*3, h*4, w, h, Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo (13, w*2, h*4, w, h, Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo (14, w*1, h*4, w, h, Config::style.ipcBorderSize, true);
    view_ipc_grid17.setGridInfo (15, 0, h*4, w, h,   Config::style.ipcBorderSize, true);
#endif

    // grid_32
    int xShift = 0;
    view_ipc_grid32.gridNum = 32;
    view_ipc_grid32.setGridInfo(0, xShift+0, 0, 1088, 616, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(1, xShift+1088, 0, 1088, 616, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(2, xShift+2176, 0, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(3, xShift+2720, 0, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(4, xShift+3264, 0, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(5, xShift+2176, 308, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(6, xShift+2720, 308, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(7, xShift+3264, 308, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(8, xShift+0, 616, 1088, 616, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(9, xShift+1088, 616, 1632, 924, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(10, xShift+2720, 616, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(11, xShift+3264, 616, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(12, xShift+2720, 924, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(13, xShift+3264, 924, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(14, xShift+0, 1232, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(15, xShift+544, 1232, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(16, xShift+2720, 1232, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(17, xShift+3264, 1232, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(18, xShift+0, 1540, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(19, xShift+544, 1540, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(20, xShift+1088, 1540, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(21, xShift+1632, 1540, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(22, xShift+2176, 1540, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(23, xShift+2720, 1540, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(24, xShift+3264, 1540, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(25, xShift+0, 1848, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(26, xShift+544, 1848, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(27, xShift+1088, 1848, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(28, xShift+1632, 1848, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(29, xShift+2176, 1848, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(30, xShift+2720, 1848, 544, 308, Config::style.ipcBorderSize, true);
    view_ipc_grid32.setGridInfo(31, xShift+3264, 1848, 544, 308, Config::style.ipcBorderSize, true);

    // grid_36
    view_ipc_grid36.gridNum = 36;
    w=_4K_WIDTH_/6;
    h=_4k_HEIGHT_/6;
    for(i=0; i<36&&i<CHANNEL_MAX; i++)
    {
        x = i%6;
        y = i/6;
        view_ipc_grid36.setGridInfo(i, x*w, y*h, w, h, Config::style.ipcBorderSize, true);
    }

    // grid_1_set
    view_ipc_grid1_set.gridNum = 1;
    view_ipc_grid1_set.setGridInfo(0, 912*2, 326*2, 608*2, 342*2, 0, true);    // for ViewMode_Set
}

void ViewProcess::initFileViewInfo()
{
    int i, x, y, w, h;
    double ratio = 1.0 / Config::sys.ratioOSD;

    // grid_0
    view_file_grid0.gridNum = 0;

    // grid_1
    view_file_grid1.gridNum = 1;
    view_file_grid1.setGridInfo(0,
                                ratio*Config::sys.playbackX,
                                ratio*Config::sys.playbackTopDownBorder,
                                ratio*Config::sys.playbackWidth,
                                ratio*Config::sys.playbackHeight, 0, true);

    // grid_4
    view_file_grid4.gridNum = 4;
    w=ratio*Config::sys.playbackWidth/2;
    h=ratio*Config::sys.playbackHeight/2;
    for(i=0; i<4&&i<CHANNEL_MAX; i++)
    {
        x = i%2;
        y = i/2;
        view_file_grid4.setGridInfo(i,
                                    ratio*Config::sys.playbackX+x*w,
                                    ratio*Config::sys.playbackTopDownBorder+y*h,
                                    w, h, Config::style.fileBorderSize, true);
    }

    // grid_9
    view_file_grid9.gridNum = 9;
    w=ratio*Config::sys.playbackWidth/3;
    h=ratio*Config::sys.playbackHeight/3;
    for(i=0; i<9&&i<CHANNEL_MAX; i++)
    {
        x = i%3;
        y = i/3;
        view_file_grid9.setGridInfo(i,
                                    ratio*Config::sys.playbackX+x*w,
                                    ratio*Config::sys.playbackTopDownBorder+y*h,
                                    w, h, Config::style.fileBorderSize, true);
    }
}

void ViewProcess::setStart()
{
    update_ipc_recSegment();
    set_slideshow_interval();
    updateFrameTimer->start();
    updateStatusTimer->start();
    ipcRecSegmentTimer->start();
    this->start();
}

void ViewProcess::run()
{
    bRun = true;
    while(bRun)
    {
        this->msleep(Config::sys.viewProcessPoolingTime);
//        if(bSetFrameBufferSize)
//        {
//            set_framebuffersize();
//        }
        if(bSetBrightness | bSetContrast | bSetHue | bSetSaturation | bSetSharpness)
        {
            set_system_image();
        }
        if(bIpcDetect)
        {
            if(ipcDetect->isVisible())
            {
                ipcDetect->initValue();
            }
            bIpcDetect = false;
        }
        mutex.lock();
        {
            run_rec_stop();
            run_stop();
            run_get_source();
            run_set_image();
            run_set_seek();     // if do seek, speed will be reset to 1x now
            run_set_speed();    // after seek
            run_set_mute();
            run_set_volume();
            run_apply_view();
            run_start();
            run_rec_start();
        }
        mutex.unlock();
    }
}

void ViewProcess::run_start()
{
    int i, idx;
    QList<int> listIpcStart;

    // start ipc
    listIpcStart.clear();
    for (idx=0; idx<CHANNEL_MAX; idx++)
    {
        if (!ipc_gridReal[idx].bNeedStart)
            continue;

        ipc_gridReal[idx].status = GridReal::GridStatus_SETUP;
        if(rtkApi->ipcStart(idx))
        {
            listIpcStart.append(idx);
        }
    }
    if(listIpcStart.count() > 0)
    {
        // sleep for building connect before rtsp player play
        rtkApi->msleep(Config::sys.setPlayerConnectTime);
    }
    for(i=0; i< listIpcStart.count(); i++)
    {
        idx = listIpcStart.at(i);

        // start rtsp player play
        rtkApi->ipcPlayStart(idx);

        if(ipc_gridReal[idx].infoCurr.width() == 0 && ipc_gridReal[idx].infoCurr.height() == 0)
        {
            ipc_gridReal[idx].status = GridReal::GridStatus_IPC_HIDE;
        }
        else
        {
            ipc_gridReal[idx].status = GridReal::GridStatus_PLAY;
        }
        ipc_gridReal[idx].bNeedStart = false;
        ipc_gridReal[idx].setSrcDefault();
        ipc_gridReal[idx].setImage(true);
        ipc_gridReal[idx].setCropDefault(false);// unncessary to do crop before get real source
    }

    // start file
    for (idx=0; idx<CHANNEL_MAX; idx++)
    {
        if (!file_gridReal[idx].bNeedStart)
            continue;
        file_gridReal[idx].status = GridReal::GridStatus_SETUP;
        if (rtkApi->fileStart(idx, file_gridReal[idx].absFilePath))
        {
            if(file_gridReal[idx].infoCurr.width() == 0 && file_gridReal[idx].infoCurr.height() == 0)
            {
                file_gridReal[idx].status = GridReal::GridStatus_FILE_PAUSE;
            }
            else
            {
                file_gridReal[idx].status = GridReal::GridStatus_PLAY;
            }
            file_gridReal[idx].status = GridReal::GridStatus_PLAY;
            file_gridReal[idx].bNeedStart = false;
            file_gridReal[idx].setSrcDefault();
//            file_gridReal[idx].setImage(true);
            file_gridReal[idx].setCropDefault(false);// unncessary to do crop before get real source
        }
    }
}

void ViewProcess::run_stop()
{
    int i, idx, chIdx;
    QList<int> listIpcStop, listFileStop, listFileBlank;
    QList<int> listIdx, listChIdx;
    QList<WindowId> listWndId;
    bool bFileSeamless = false;

    // stop ipc
    listIpcStop.clear();
    for (idx=0; idx<CHANNEL_MAX; idx++)
    {
        chIdx = ipc_gridReal[idx].channelIndex;
        if (ipc_gridReal[idx].bNeedStart && ipc_gridReal[idx].bNeedStop)
        {
            if (ipc_gridReal[idx].timeNeedStart <
                ipc_gridReal[idx].timeNeedStop)
            {
                ipc_gridReal[idx].bNeedStart = false;
            }
        }
        if (ipc_gridReal[idx].bNeedStop ||
            (ipc_gridReal[idx].bNeedStart &&
             (ipc_gridReal[idx].status == GridReal::GridStatus_PLAY ||
             ipc_gridReal[idx].status == GridReal::GridStatus_IPC_HIDE)))
        {
            listIpcStop.append(idx);
            listIdx.append(idx);
            listChIdx.append(chIdx);
            listWndId.append(ipc_gridReal[idx].wndId);
        }
    }
    if(listIpcStop.count() > 0)
    {
        if(Config::sys.seamless == false)
        {
            rtkApi->qt_rtk_disp_set_blank(STR_IPC, &listIdx, &listChIdx, true, &listWndId);
            // wait for blank
            rtkApi->msleep(Config::sys.setBlankTime);
        }
    }
    for(i=0; i< listIpcStop.count(); i++)
    {
        idx = listIpcStop.at(i);
        if (rtkApi->ipcStop(idx, ipc_gridReal[idx].bSeamless))
        {
            ipc_gridReal[idx].status = GridReal::GridStatus_NONE;
            ipc_gridReal[idx].bNeedStop = false;
            ipc_gridReal[idx].setSrcDefault();
            ipc_gridReal[idx].setImage(false);
            ipc_gridReal[idx].setCropDefault(false);

            ipc_gridReal[idx].bAlreadyRec = false;
            ipc_gridReal[idx].bNeedRecStop = false;
            ipc_gridReal[idx].timeNeedRecStop = QDateTime::currentDateTime();   // update
        }
    }

    // stop file
    listFileStop.clear();
    listFileBlank.clear();
    for (idx=0; idx<CHANNEL_MAX; idx++)
    {
        chIdx = file_gridReal[idx].channelIndex;
        if (file_gridReal[idx].bNeedStart && file_gridReal[idx].bNeedStop)
        {
            if (file_gridReal[idx].timeNeedStart <
                file_gridReal[idx].timeNeedStop)
            {
                file_gridReal[idx].bNeedStart = false;
            }
        }
        if (file_gridReal[idx].bNeedStop ||
            (file_gridReal[idx].bNeedStart &&
             (file_gridReal[idx].status == GridReal::GridStatus_PLAY ||
             file_gridReal[idx].status == GridReal::GridStatus_FILE_PAUSE)))
        {
            listFileStop.append(idx);

            if(file_gridReal[idx].bNeedStop &&
               file_gridReal[idx].bNeedStart != true &&
               file_gridReal[idx].wndId > WindowId_Invalid) // [20180427:Brian] Fix bug NAS-370: avoid set blank with wndId=-1
            {
                listIdx.append(idx);
                listChIdx.append(chIdx);
                listWndId.append(file_gridReal[idx].wndId);
                listFileBlank.append(idx);

                if (file_gridReal[idx].bSeamless)
                    bFileSeamless = true;
            }
        }
    }
    if(listFileBlank.count() > 0)
    {
        if(Config::sys.seamless == false)
        {
            rtkApi->qt_rtk_disp_set_blank(STR_FILE, &listIdx, &listChIdx, true, &listWndId);
            // wait for blank
            rtkApi->msleep(Config::sys.setBlankTime);
        }
        else if(Config::sys.seamless == true && bFileSeamless == false)
        {
            /* set balnk for closing playback */
            rtkApi->qt_rtk_disp_set_blank(STR_IPC, -1, -1, true, -1);
        }
    }
    for(i=0; i< listFileStop.count(); i++)
    {
        idx = listFileStop.at(i);
        if (rtkApi->fileStop(idx, file_gridReal[idx].bSeamless))
        {
            file_gridReal[idx].status = GridReal::GridStatus_NONE;
            file_gridReal[idx].bNeedStop = false;
            file_gridReal[idx].setSrcDefault();
//            file_gridReal[idx].setImage(false);
            file_gridReal[idx].setCropDefault(false);
        }
    }
    if(listFileBlank.count() > 0)
    {
        if(Config::sys.seamless == true && bFileSeamless == false)
        {
            /* set balnk for closing playback */
            rtkApi->qt_rtk_disp_set_blank(STR_IPC, -1, -1, false, -1);
        }
    }
}

void ViewProcess::run_rec_start()
{
    // start ipc rec
    for (int idx=0; idx<CHANNEL_MAX; idx++)
    {
        if (ipc_gridReal[idx].bNeedRecStart != true)
            continue;
        if (ipc_gridReal[idx].bNeedRecStop)
        {
            if(ipc_gridReal[idx].timeNeedRecStart < ipc_gridReal[idx].timeNeedRecStop)
            {
                ipc_gridReal[idx].bNeedRecStart = false;
            }
            else
            {
                // do rec start later, after rec stop
            }
            continue;
        }
        if (ipc_gridReal[idx].status != GridReal::GridStatus_PLAY &&
            ipc_gridReal[idx].status != GridReal::GridStatus_IPC_HIDE)
            continue;
#if RTSP_AV
        if (ipc_gridReal[idx].cid <= ClientId_Invalid)
            continue;
#elif RTSP_GST
        if (ipc_gridReal[idx].rtspPlayer == NULL)
            continue;
#endif
        QString absRecDirNew;
        QDateTime current;
        if (ipc_createNewAbsRecDir(idx, &absRecDirNew, &current))
        {
            if (ipc_gridReal[idx].bAlreadyRec)
            {
                rtkApi->ipcRecChange(idx, absRecDirNew, Config::sys.hlsDuration);
            }
            else
            {
                rtkApi->ipcRecStart(idx, absRecDirNew, Config::sys.hlsDuration);
            }
            ipc_gridReal[idx].bAlreadyRec = true;
            ipc_gridReal[idx].bNeedRecStart = false;
            ipc_gridReal[idx].absRecDir = absRecDirNew;
            ipc_gridReal[idx].timeNeedRecStart = current;   // update
            ipc_gridReal[idx].timeRecStart = current;       // update
        }
    }
}

void ViewProcess::run_rec_stop()
{
    int idx;

    // TBD check if recording time is up
    for (idx=0; idx<CHANNEL_MAX; idx++)
    {
        // bNeedStart = true;
    }

    // stop ipc rec
    for (idx=0; idx<CHANNEL_MAX; idx++)
    {
        if (ipc_gridReal[idx].bNeedRecStop != true)
            continue;

        if (ipc_gridReal[idx].bNeedRecStart && ipc_gridReal[idx].bNeedRecStop)
        {
            if (ipc_gridReal[idx].timeNeedRecStart <
                ipc_gridReal[idx].timeNeedRecStop)
            {
                ipc_gridReal[idx].bNeedRecStart = false;
            }
        }
#if RTSP_AV
        if (ipc_gridReal[idx].cid <= ClientId_Invalid)
            continue;
#elif RTSP_GST
        if (ipc_gridReal[idx].rtspPlayer == NULL)
            continue;
#endif

        if (ipc_gridReal[idx].bAlreadyRec)
        {
            rtkApi->ipcRecStop(idx);
        }
        ipc_gridReal[idx].bAlreadyRec = false;
        ipc_gridReal[idx].bNeedRecStop = false;
        ipc_gridReal[idx].timeNeedRecStop = QDateTime::currentDateTime();   // update
    }
}

void ViewProcess::run_get_source()
{
    int idx;
    QRect rect;
    bool bSet;

    // get ipc source
    for (idx=0; idx<CHANNEL_MAX; idx++)
    {
        if (ipc_gridReal[idx].status == GridReal::GridStatus_PLAY &&
            ipc_gridReal[idx].ifGetSrc() == false)
        {
            ipc_gridReal[idx].timeoutNeedSrc -= Config::sys.viewProcessPoolingTime;
            if(ipc_gridReal[idx].timeoutNeedSrc > 0)
                continue;

            // Check if already new frames put to decoder and display
            bSet = false;
            if(ipc_gridReal[idx].channelId > ChannelId_Invalid)
            {
                bSet = (ipc_gridReal[idx].ipcState == PING_FAIL_BUT_NEW_FRAME ||
                        ipc_gridReal[idx].ipcState == PING_OK_AND_NEW_FRAME);
            }
            if(!bSet)
            {
                ipc_gridReal[idx].timeoutNeedSrc = Config::sys.getSourcePollingTime;
                continue;
            }

            if (rtkApi->ipcGetSourceRect(idx, &rect))
            {
                ipc_gridReal[idx].setSrc(rect);
                ipc_gridReal[idx].setCrop(rect, false); // uncrop before getting src
            }
            else
            {
                ipc_gridReal[idx].timeoutNeedSrc = Config::sys.getSourcePollingTime;
            }
        }
    }

    // get file source
    for (idx=0; idx<CHANNEL_MAX; idx++)
    {
        if (file_gridReal[idx].status == GridReal::GridStatus_PLAY &&
            file_gridReal[idx].ifGetSrc() == false)
        {
            file_gridReal[idx].timeoutNeedSrc -= Config::sys.viewProcessPoolingTime;
            if(file_gridReal[idx].timeoutNeedSrc > 0)
                continue;
            if (rtkApi->fileGetSourceRect(idx, &rect))
            {
                file_gridReal[idx].setSrc(rect);
                file_gridReal[idx].setCrop(rect, false); // uncrop before getting src
            }
            else
            {
                file_gridReal[idx].timeoutNeedSrc = Config::sys.getSourcePollingTime;
            }
        }
    }
}

void ViewProcess::run_set_image()
{
    int idx, chIdx;
    bool bSet, bRetry;
    uint value;

    // ipc image
    for (idx=0; idx<CHANNEL_MAX; idx++)
    {
        if (ipc_gridReal[idx].status == GridReal::GridStatus_PLAY &&
            ipc_gridReal[idx].ifSetImage())
        {
            bRetry = false;
            chIdx = ipc_gridReal[idx].channelIndex;

            ipc_gridReal[idx].timeoutNeedSrc -= Config::sys.viewProcessPoolingTime;
            if(ipc_gridReal[idx].timeoutNeedSrc > 0)
                continue;

            // Check if already new frames put to decoder and display
            bSet = false;
            if(ipc_gridReal[idx].channelId > ChannelId_Invalid)
            {
                bSet = (ipc_gridReal[idx].ipcState == PING_FAIL_BUT_NEW_FRAME ||
                        ipc_gridReal[idx].ipcState == PING_OK_AND_NEW_FRAME);
            }
            if(!bSet)
            {
                ipc_gridReal[idx].timeoutNeedSrc = Config::sys.getSourcePollingTime;
                continue;
            }

            bSet = true;
            if(rtkApi->qt_rtk_disp_get_channel_brightness(STR_IPC, idx, chIdx, ipc_gridReal[idx].wndId, &value))
            {
                bSet = (value != Config::ipc.ch[chIdx].brightness);
            }
            if(bSet)
            {
                if(rtkApi->qt_rtk_disp_set_channel_brightness(
                            STR_IPC, idx, chIdx, ipc_gridReal[idx].wndId, Config::ipc.ch[chIdx].brightness) != true)
                {
                    bRetry = true;
                }
            }

            bSet = true;
            if(rtkApi->qt_rtk_disp_get_channel_contrast(STR_IPC, idx, chIdx, ipc_gridReal[idx].wndId, &value))
            {
                bSet = (value != Config::ipc.ch[chIdx].contrast);
            }
            if(bSet)
            {
                if(rtkApi->qt_rtk_disp_set_channel_contrast(
                            STR_IPC, idx, chIdx, ipc_gridReal[idx].wndId, Config::ipc.ch[chIdx].contrast) != true)
                {
                    bRetry = true;
                }
            }

            bSet = true;
            if(rtkApi->qt_rtk_disp_get_channel_hue(STR_IPC, idx, chIdx, ipc_gridReal[idx].wndId, &value))
            {
                bSet = (value != Config::ipc.ch[chIdx].hue);
            }
            if(bSet)
            {
                if(rtkApi->qt_rtk_disp_set_channel_hue(
                            STR_IPC, idx, chIdx, ipc_gridReal[idx].wndId, Config::ipc.ch[chIdx].hue) != true)
                {
                    bRetry = true;
                }
            }

            bSet = true;
            if(rtkApi->qt_rtk_disp_get_channel_saturation(STR_IPC, idx, chIdx, ipc_gridReal[idx].wndId, &value))
            {
                bSet = (value != Config::ipc.ch[chIdx].saturation);
            }
            if(bSet)
            {
                if(rtkApi->qt_rtk_disp_set_channel_saturation(
                            STR_IPC, idx, chIdx, ipc_gridReal[idx].wndId, Config::ipc.ch[chIdx].saturation) != true)
                {
                    bRetry = true;
                }
            }

            bSet = true;
            if(rtkApi->qt_rtk_disp_get_channel_sharpness(STR_IPC, idx, chIdx, ipc_gridReal[idx].wndId, &value))
            {
                bSet = (value != Config::ipc.ch[chIdx].sharpness);
            }
            if(bSet)
            {
                if(rtkApi->qt_rtk_disp_set_channel_sharpness(
                            STR_IPC, idx, chIdx, ipc_gridReal[idx].wndId, Config::ipc.ch[chIdx].sharpness) != true)
                {
                    bRetry = true;
                }
            }

            if(!bRetry)
            {
                ipc_gridReal[idx].setImage(false);
            }
            else
            {
                ipc_gridReal[idx].timeoutNeedSrc = Config::sys.getSourcePollingTime;
            }
        }
    }
}

void ViewProcess::run_set_speed()
{
    // set file speed
    for (int idx=0; idx<CHANNEL_MAX; idx++)
    {
        if (file_gridReal[idx].status == GridReal::GridStatus_PLAY &&
            file_gridReal[idx].bNeedSpeed)
        {
            file_gridReal[idx].timeoutNeedSpeed -= Config::sys.viewProcessPoolingTime;
            if(file_gridReal[idx].timeoutNeedSpeed > 0)
                continue;
            if (rtkApi->fileSetSpeed(idx, file_gridReal[idx].speed))
            {
                file_gridReal[idx].bNeedSpeed = false;
            }
            else
            {
                file_gridReal[idx].timeoutNeedSpeed = Config::sys.setSpeedPollingTime;
            }
        }
    }
}

void ViewProcess::run_set_seek()
{
    // set file seek
    for (int idx=0; idx<CHANNEL_MAX; idx++)
    {
        if (file_gridReal[idx].status == GridReal::GridStatus_PLAY &&
            file_gridReal[idx].bNeedSeek)
        {
            if (rtkApi->fileSetPlayTime(idx, file_gridReal[idx].seekTime))
            {
                file_gridReal[idx].bNeedSeek = false;
            }
        }
    }
}

void ViewProcess::run_set_mute()
{
    int idx, chIdx;
    // set file mute
    for (idx=0; idx<CHANNEL_MAX; idx++)
    {
        if (file_gridReal[idx].status == GridReal::GridStatus_PLAY &&
            file_gridReal[idx].bNeedMute)
        {
            chIdx = file_gridReal[idx].channelIndex;
            rtkApi->qt_rtk_player_set_mute(STR_FILE, idx, chIdx,
                                           file_gridReal[idx].channelId,
                                           file_gridReal[idx].mute);
            // [20180808:Brian] Fix bug NAS-442
            // no matter success or failed for there may be no audio stream in the file
            file_gridReal[idx].bNeedMute = false;
        }
    }
}

void ViewProcess::run_set_volume()
{
    int idx, chIdx;
    double volume;
    double ratio = 10;  // volume range 0~100 => 0~10
    // set file mute
    for (idx=0; idx<CHANNEL_MAX; idx++)
    {
        if (file_gridReal[idx].status == GridReal::GridStatus_PLAY &&
            file_gridReal[idx].bNeedVolume)
        {
            chIdx = file_gridReal[idx].channelIndex;
            if (rtkApi->qt_rtk_player_get_volume(STR_FILE, idx, chIdx,
                                                 file_gridReal[idx].channelId,
                                                 &volume))
            {
                if ((volume*ratio) == file_gridReal[idx].volume)
                {
                    file_gridReal[idx].bNeedVolume = false;
                    continue;
                }
            }
            rtkApi->qt_rtk_player_set_volume(STR_FILE, idx, chIdx,
                                            file_gridReal[idx].channelId,
                                            file_gridReal[idx].volume/ratio);
            // [20180808:Brian] Fix bug NAS-442
            // no matter success or failed for there may be no audio stream in the file
            file_gridReal[idx].bNeedVolume = false;
        }
    }
}

void ViewProcess::run_apply_view()
{
#if QT_ENV_ONLY == 1
    int idx;
    for(idx=0; idx<CHANNEL_MAX; idx++)
    {
        update_color(&ipc_gridReal[idx].bgColor);
        update_ipc_frame(idx);
    }
    for(idx=0; idx<CHANNEL_MAX; idx++)
    {
        update_color(&file_gridReal[idx].bgColor);
        update_file_frame(idx);
    }
#endif
    if (ipc_viewMode == ViewMode_Hide)
    {
        rtkApi->apply_view_ipc();   // [20171215:Brian] Fix bug: set blank first if necessary
        rtkApi->apply_view_file();
    }
    else
    {
        rtkApi->apply_view_file();  // [20171215:Brian] Fix bug: set blank first if necessary
        rtkApi->apply_view_ipc();
    }
}

bool ViewProcess::ipc_createNewAbsRecDir(int idx, QString *pAbsRecDir, QDateTime *pCurrent)
{
    bool bMkPath;
    QDateTime current = QDateTime::currentDateTime();
    int chIdx = ipc_gridReal[idx].channelIndex;
    QString hlsDirPath = Config::absoluteHlsDirPath +
                        (Config::absoluteHlsDirPath.endsWith("/") ? "" : "/");
    QString absRecDir = QString("%1%2/%3")
                            .arg(hlsDirPath)
                            .arg(HLS_SUBDIR(chIdx))
#if 0
                            .arg(current.toString(STR_HLSDIR_DATETIME_MS));
#else
                            .arg(current.toString(STR_HLSDIR_DATETIME));
#endif

    if(pAbsRecDir == NULL || pCurrent == NULL)
        return false;

    bMkPath = QDir().mkpath(absRecDir);
    if (bMkPath)
    {
        *pAbsRecDir = absRecDir;
        *pCurrent = current;
        if(DBG(_DBG_RTKAPI_))
        {
            qDebug() << STR_IPC << idx
                     << QString("absRecDir=%1").arg(absRecDir);
        }
    }
    else
    {
        QDir dir(absRecDir);
        dir.removeRecursively();
    }
    return bMkPath;
}

bool ViewProcess::isValidIpv4Ip(QString strIp)
{
    // check format
    QRegularExpression re("^(\\d+).(\\d+).(\\d+).(\\d+)$");
    QRegularExpressionMatch match=re.match(strIp);
    if(match.hasMatch() == false)
    {
//        qDebug() << __func__ << "format mismatch";
        return false;
    }

    // check value
    int ip[4];
    ip[0] = match.captured(1).toInt();
    ip[1] = match.captured(2).toInt();
    ip[2] = match.captured(3).toInt();
    ip[3] = match.captured(4).toInt();
//    qDebug() << __func__ << ip[0] << ip[1] << ip[2] << ip[3];
    if (ip[0] < 0 || ip[0] > 255 ||
        ip[1] < 0 || ip[1] > 255 ||
        ip[2] < 0 || ip[2] > 255 ||
        ip[3] < 0 || ip[3] > 255)
    {
//        qDebug() << __func__ << "value mismatch";
        return false;
    }
    return true;
}

void ViewProcess::setStop()
{
    bRun = false;
    ipcRecSegmentTimer->stop();
    updateStatusTimer->stop();
    updateFrameTimer->stop();
    slideShowTimer->stop();
}

void ViewProcess::finalize()
{
    bRun = false;
    while (viewProcess->isRunning())
    {
        msleep(200);
    }
}

QList<GridInfo*> *ViewProcess::getIpcGridInfoList(int grid_num)
{
    QList<ViewInfo *>list = {&view_ipc_grid0, &view_ipc_grid1, &view_ipc_grid4,
                             &view_ipc_grid8, &view_ipc_grid9,
                             &view_ipc_grid16, /*&view_ipc_grid17,*/
                             &view_ipc_grid32, &view_ipc_grid36};
    for (int i=0; i<list.count(); i++)
    {
        if (grid_num == list.at(i)->gridNum)
            return (list.at(i)->gridInfoList);
    }
    return (view_ipc_grid9.gridInfoList);
}

QList<GridInfo*> *ViewProcess::getFileGridInfoList(int grid_num)
{
    QList<ViewInfo *>list = {&view_file_grid0, &view_file_grid1,
                             &view_file_grid4, &view_file_grid9};
    for (int i=0; i<list.count(); i++)
    {
        if (grid_num == list.at(i)->gridNum)
            return (list.at(i)->gridInfoList);
    }
    return (view_file_grid1.gridInfoList);
}

void ViewProcess::set_ipc_grid_num(int grid_num)
{
//    qDebug() << __func__ << grid_num;
    this->ipc_grid_num = grid_num;
    ipc_grid_idx = 0;
    if(grid_num <= 1)
    {
        for (int i=0; i<CHANNEL_MAX; i++)
        {
            if (ipc_gridReal[i].status != GridReal::GridStatus_NONE)
            {
                ipc_grid_idx = i;
                break;
            }
        }
    }
    update_view_ipc();
}

void ViewProcess::set_file_grid_num(int grid_num, int idx)
{
//    qDebug() << __func__ << grid_num;
    this->file_grid_num = grid_num;
    if(idx >= 0 && idx < Config::sys.ipcChannelMax)
    {
        this->file_grid_idx = idx;
    }
    update_view_file();
}

int ViewProcess::get_ipc_grid_num()
{
    return this->ipc_grid_num;
}

int ViewProcess::get_file_grid_num()
{
    return this->file_grid_num;
}

void ViewProcess::timer_update_slideshow()
{
    //qDebug() << __func__;
    ipc_next_selected(true);
}

void ViewProcess::timer_update_frame()
{
    for(int i=0; i<CHANNEL_MAX; i++)
    {
        mainWidget->ipcFrame[i]->updateComponent();
        mainWidget->ipcFrame[i]->updateStyleSheet();
        mainWidget->ipcFrame[i]->updateGeometry();
        playback->fileFrame[i]->updateComponent();
        playback->fileFrame[i]->updateStyleSheet();
        playback->fileFrame[i]->updateGeometry();
    }
}

void ViewProcess::timer_update_ipc_status()
{
    int chIdx;
    bool bRec;
    QString str, strRec;

    mutex.lock();
    QDateTime current = QDateTime::currentDateTime();
    for(int i=0; i<CHANNEL_MAX; i++)
    {
        bRec = ((ipc_gridReal[i].status == GridReal::GridStatus_PLAY ||
                ipc_gridReal[i].status == GridReal::GridStatus_IPC_HIDE) &&
                ipc_gridReal[i].bAlreadyRec);
        if (bRec != mainWidget->ipcFrame[i]->isBtnRecActived())
        {
            mainWidget->ipcFrame[i]->setBtnRecActived(bRec);
        }
        if (ipcAdd->isVisible() || setStorage->isVisible())
        {
            chIdx = ipc_gridReal[i].channelIndex;
            if(chIdx < 0 || chIdx >= Config::sys.ipcChannelMax)
                continue;

            if(bRec)
            {
                strRec = STR_REC;
                qint64 diffT = ipc_gridReal[i].timeRecStart.secsTo(current);
                strRec = strRec + " " + Config::strTime(diffT);
            }
            else
            {
                strRec = "";
            }
            switch(ipc_gridReal[i].status)
            {
            case GridReal::GridStatus_SETUP:
                str = STR_SETUP;
                break;
            case GridReal::GridStatus_IPC_HIDE:
                if(strRec.length()>0)
                {
                    str = strRec + ", " + STR_HIDE;
                }
                else
                {
                    str = STR_HIDE;
                }
                break;
            case GridReal::GridStatus_PLAY:
                if(strRec.length()>0)
                {
                    str = strRec;
                }
                else
                {
                    str = STR_CONNECT;
                }
                break;
            case GridReal::GridStatus_NONE:
            default:
                str = STR_DISCONNECT;
                break;
            }
            QString strStyleSheet = bRec ?
                        "color: rgb(255, 120, 120); font: 20px \"Arial\";" :
                        "color: rgb(102, 109, 109); font: 20px \"Arial\";" ;
            if (ipcConnect->isVisible())
            {
                if (ipcConnect->lStatusList->at(chIdx)->text() != str)
                    ipcConnect->lStatusList->at(chIdx)->setText(str);
                if (ipcConnect->lStatusList->at(chIdx)->styleSheet() != strStyleSheet)
                    ipcConnect->lStatusList->at(chIdx)->setStyleSheet(strStyleSheet);
            }
            if (ipcDetect->isVisible())
            {
// TBD
            }
            if (setStorage->isVisible())
            {
                if (setStorage->lStatusList->at(chIdx)->text() != str)
                    setStorage->lStatusList->at(chIdx)->setText(str);
                if (setStorage->lStatusList->at(chIdx)->styleSheet() != strStyleSheet)
                    setStorage->lStatusList->at(chIdx)->setStyleSheet(strStyleSheet);
            }
        }
    }
    mutex.unlock();
}

void ViewProcess::timer_rec_segment()
{
    if(QDir(Config::absoluteHlsDirPath).exists() != true)
        return;

    for(int idx=0; idx<CHANNEL_MAX; idx++)
    {
        if ((ipc_gridReal[idx].status == GridReal::GridStatus_PLAY ||
            ipc_gridReal[idx].status == GridReal::GridStatus_IPC_HIDE) &&
            ipc_gridReal[idx].bAlreadyRec &&
            ipc_gridReal[idx].bNeedRecStart == false &&
            ipc_gridReal[idx].bNeedRecStop == false)
        {
            ipc_gridReal[idx].recElapsed += Config::sys.recSegmentPollingTime;
            if(ipc_gridReal[idx].recElapsed >= ipc_gridReal[idx].recSegmentTime)
            {
                QString absRecDirNew;
                QDateTime current;
                if (ipc_createNewAbsRecDir(idx, &absRecDirNew, &current))
                {
                    rtkApi->ipcRecChange(idx, absRecDirNew, Config::sys.hlsDuration);
                    ipc_gridReal[idx].absRecDir = absRecDirNew;
                    ipc_gridReal[idx].recElapsed = 0;
                }
            }
        }
    }
}

void ViewProcess::ipc_next_selected(bool bOnlyConnect)
{
    if (ipc_viewMode != ViewMode_Grid)
        return;
    if(ipc_grid_num == 1)
    {
        int idx = ipc_grid_idx;
        for (int i=1; i<CHANNEL_MAX; i++)
        {
            idx = (ipc_grid_idx + i) % CHANNEL_MAX;
            if (ipc_gridReal[idx].status != GridReal::GridStatus_NONE)
            {
                ipc_grid_idx = idx;
                update_view_ipc();
                break;
            }
        }
    }
    else
    {
        int go = 0;
        int idx;
        int firstCandidateIdx;
        int candidateIdx = ipc_grid_idx;
        while(go < CHANNEL_MAX)
        {
            idx = ((candidateIdx + ipc_grid_num) % CHANNEL_MAX);
            idx = (idx / ipc_grid_num) * ipc_grid_num;
            if(go <= 0)
            {
                firstCandidateIdx = idx;
            }
            candidateIdx = idx;
            for (int i=0; i<ipc_grid_num && idx<CHANNEL_MAX; i++, idx++)
            {
                go ++;
                if((!bOnlyConnect &&
                    ipc_gridReal[idx].channelIndex >= 0 &&
                    ipc_gridReal[idx].channelIndex < Config::sys.ipcChannelMax) ||
                   ipc_gridReal[idx].status != GridReal::GridStatus_NONE)
                {
                    ipc_grid_idx = candidateIdx;
                    update_view_ipc();
                    return;
                }
            }
        }
        ipc_grid_idx = firstCandidateIdx;
        update_view_ipc();
    }
}

void ViewProcess::ipc_prev_selected(bool bOnlyConnect)
{
    if (ipc_viewMode != ViewMode_Grid)
        return;
    if(ipc_grid_num == 1)
    {
        int idx = ipc_grid_idx;
        for (int i=1; i<CHANNEL_MAX; i++)
        {
            idx = (ipc_grid_idx + CHANNEL_MAX - i) % CHANNEL_MAX;
            if (ipc_gridReal[idx].status != GridReal::GridStatus_NONE)
            {
                ipc_grid_idx = idx;
                update_view_ipc();
                break;
            }
        }
    }
    else
    {
        int go = 0;
        int idx;
        int firstCandidateIdx;
        int candidateIdx = ipc_grid_idx;
        while(go < CHANNEL_MAX)
        {
            idx = ((candidateIdx + CHANNEL_MAX - 1/*ipc_grid_num*/) % CHANNEL_MAX);
            idx = (idx / ipc_grid_num) * ipc_grid_num;
            if(go <= 0)
            {
                firstCandidateIdx = idx;
            }
            candidateIdx = idx;
            for (int i=0; i<ipc_grid_num && idx<CHANNEL_MAX; i++, idx++)
            {
                go ++;
                if((!bOnlyConnect &&
                    ipc_gridReal[idx].channelIndex >= 0 &&
                    ipc_gridReal[idx].channelIndex < Config::sys.ipcChannelMax) ||
                   ipc_gridReal[idx].status != GridReal::GridStatus_NONE)
                {
                    ipc_grid_idx = candidateIdx;
                    update_view_ipc();
                    return;
                }
            }
        }
        ipc_grid_idx = firstCandidateIdx;
        update_view_ipc();
    }
}

void ViewProcess::ipc_slideshow_selected(bool)
{
    if (ipc_viewMode != ViewMode_Grid)
        return;

    if (mainMenu->tbSlideshow->getActived())
    {
//        qDebug() << "start slideshow";
        slideShowTimer->start();
    }
    else
    {
//        qDebug() << "stop slideshow";
        slideShowTimer->stop();
    }
}

void ViewProcess::update_ipc_recSegment()
{
    for(int idx=0; idx<CHANNEL_MAX; idx++)
    {
        int chIdx = ipc_gridReal[idx].channelIndex;
        if(chIdx < 0 || chIdx >= Config::sys.ipcChannelMax)
            continue;
        ipc_gridReal[idx].recSegmentTime = Config::ipc.ch[chIdx].segmentTime * 60 * 1000;
    }
}

#if QT_ENV_ONLY == 1
void ViewProcess::update_color(QColor *color)
{
    int r, g, b;
    color->getRgb(&r, &g, &b);
    r = r + (rand() % 5 - 2);
    g = g + (rand() % 5 - 2);
    b = b + (rand() % 5 - 2);
    if(r > 255) r=255;
    if(g > 255) g=255;
    if(b > 255) b=255;
    if(r < 0) r=0;
    if(g < 0) g=0;
    if(b < 0) b=0;
    *color = QColor::fromRgb(r,g,b);
}
#endif

void ViewProcess::update_view_ipc()
{
    int start_idx;
    int idx, i;
    QList<GridInfo *> *list;

    switch(ipc_viewMode)
    {
    case ViewMode_Grid:
        list = getIpcGridInfoList(ipc_grid_num);
        start_idx = ipc_grid_idx;
        break;
    case ViewMode_ZoomIn:
        list = view_ipc_grid1.gridInfoList;
        start_idx = ipc_zoomin_idx;
        break;
    case ViewMode_Hide:
        list = view_ipc_grid0.gridInfoList;
        start_idx = 0;
        break;
    case ViewMode_Set:
        list = view_ipc_grid1_set.gridInfoList;
        start_idx = ipc_set_idx;
        break;
    default:
        qDebug() << __func__ << "ipc viewMode mismatch !";
        return;
    }

    if (list->count() < CHANNEL_MAX)
    {
        qDebug() << __func__ << "current grid info list < CHANNEL_MAX";
    }

    mutex.lock();
    {
        if(ipc_viewMode == ViewMode_Grid)
        {
            GridInfo gridDefault;
            idx = start_idx;
            for (i=0; i<idx; i++)
            {
                view_ipc.gridInfoList->at(i)->copy(&gridDefault);
            }
            for (i=0; i<CHANNEL_MAX && idx<CHANNEL_MAX; i++, idx++)
            {
                view_ipc.gridInfoList->at(idx)->copy(list->at(i));
            }
            bUpdateIpcFrame = true;
        }
        else
        {
            idx = start_idx % CHANNEL_MAX;
            for (i=0; i<CHANNEL_MAX; i++, idx=((idx+1)%CHANNEL_MAX))
            {
                view_ipc.gridInfoList->at(idx)->copy(list->at(i));
            }
            bUpdateIpcFrame = true;
        }
    }
    mutex.unlock();
}

void ViewProcess::update_view_file()
{
    int start_idx;
    int idx, i;
    QList<GridInfo *> *list;

    switch(file_viewMode)
    {
    case ViewMode_Grid:
        list = getFileGridInfoList(file_grid_num);
        start_idx = file_grid_idx;
        break;
    case ViewMode_ZoomIn:
        list = view_file_grid1.gridInfoList;
        start_idx = file_zoomin_idx;
        break;
    case ViewMode_Hide:
        list = view_file_grid0.gridInfoList;
        start_idx = 0;
        break;
    default:
        qDebug() << __func__ << "file viewMode mismatch !";
        return;
    }

    if (list->count() < CHANNEL_MAX)
    {
        qDebug() << __func__ << "current grid info list < CHANNEL_MAX";
    }
    if (start_idx > Config::sys.fileChannelMax)
    {
        qDebug() << __func__ <<  "start_idx > Config::sys.fileChannelMax";
    }

    mutex.lock();
    {
        idx = start_idx % CHANNEL_MAX;
        for (i=0; i<CHANNEL_MAX; i++, idx=((idx+1)%CHANNEL_MAX))
        {
            view_file.gridInfoList->at(idx)->copy(list->at(i));
        }
        bUpdateFileFrame = true;
    }
    mutex.unlock();
}

void ViewProcess::update_ipc_frame(int idx)
{
    RFrame *ipcFrame = mainWidget->ipcFrame[idx];
    GridInfo *view = view_ipc.gridInfoList->at(idx);
    GridReal *gridIpc = &ipc_gridReal[idx];
#if QT_ENV_ONLY == 1
    if (ipc_gridReal[idx].status == GridReal::GridStatus_PLAY)
    {
        int r, g, b;
        ipc_gridReal[idx].bgColor.getRgb(&r, &g, &b);
        ipcFrame->setBackground(r, g, b, 255);
    }
    else
    {
        ipcFrame->setBackground(255, 255, 255, 0);   // transparent
    }
#endif
    ipcFrame->setBorderSize(view->borderSize());
    ipcFrame->prepareUpdateComponent();
    ipcFrame->prepareStyleSheet();
    ipcFrame->setChText(HLS_SUBDIR(gridIpc->channelIndex));
}

void ViewProcess::update_file_frame(int idx)
{
    RFrame *fileFrame = playback->fileFrame[idx];
    GridInfo *view = view_file.gridInfoList->at(idx);
    GridReal *gridFile = &file_gridReal[idx];
#if QT_ENV_ONLY == 1
    if (file_gridReal[idx].status == GridReal::GridStatus_PLAY)
    {
        int r, g, b;
        file_gridReal[idx].bgColor.getRgb(&r, &g, &b);
        fileFrame->setBackground(r, g, b, 255);
    }
    else
    {
        fileFrame->setBackground(255, 255, 255, 0);   // transparent
    }
#endif
    fileFrame->setBorderSize(view->borderSize());
    fileFrame->prepareUpdateComponent();
    fileFrame->prepareStyleSheet();
    fileFrame->setChText(HLS_SUBDIR(gridFile->channelIndex));
}

ViewProcess::ViewMode_E ViewProcess::ipc_getViewMode()
{
    return ipc_viewMode;
}

ViewProcess::ViewMode_E ViewProcess::file_getViewMode()
{
    return file_viewMode;
}

int ViewProcess::get_ipc_array_idx(int channel_idx)
{
    return ipc_array_idx[channel_idx];
}

void ViewProcess::ipc_start(int idx, QString rtsp_cmd)
{
    if(ipc_gridReal[idx].rtspCmd != rtsp_cmd)
    {
        if(ipc_gridReal[idx].status == GridReal::GridStatus_PLAY ||
           ipc_gridReal[idx].status == GridReal::GridStatus_IPC_HIDE)
        {
            ipc_stop(idx, Config::sys.seamless);
        }
    }
    msleep(2);
    qDebug() << idx << __func__ << "channel" << ipc_gridReal[idx].channelIndex;
    mutex.lock();
    {
        if(ipc_gridReal[idx].rtspCmd != rtsp_cmd ||
           ipc_gridReal[idx].bIpValid == false)
        {
            // simple:   "rtsp://192.168.0.168/profile1"
            // full:     "rtsp://usrname:passwd@192.168.0.90:1234/stream01"
            QString temp = rtsp_cmd.split("://").at(1);
            temp = temp.split("/").at(0);
            if(temp.indexOf("@") >= 0)
            {
                temp = temp.split("@").at(1);
            }
            temp = temp.split(":").at(0);
            ipc_gridReal[idx].ip = temp;
            ipc_gridReal[idx].bIpValid = isValidIpv4Ip(temp);
        }
        ipc_gridReal[idx].rtspCmd = rtsp_cmd;
        ipc_gridReal[idx].bNeedStart = true;
        ipc_gridReal[idx].timeNeedStart = QDateTime::currentDateTime();
        bUpdateIpcFrame = true;
    }
    mutex.unlock();
}

void ViewProcess::ipc_stop(int idx, bool bSeamless)
{
    qDebug() << idx << __func__ << "channel" << ipc_gridReal[idx].channelIndex;
    mutex.lock();
    {
        ipc_gridReal[idx].bNeedStop = true;
        ipc_gridReal[idx].timeNeedStop = QDateTime::currentDateTime();
        ipc_gridReal[idx].bSeamless = bSeamless;
    }
    mutex.unlock();
    if(ipc_gridReal[idx].bAlreadyRec || ipc_gridReal[idx].bNeedRecStart)
    {
        ipc_rec_stop(idx);
    }
}

void ViewProcess::ipc_rec_start(int idx)
{
    qDebug() << idx << __func__ << "channel" << ipc_gridReal[idx].channelIndex;
    mutex.lock();
    {
        ipc_gridReal[idx].bNeedRecStart = true;
        ipc_gridReal[idx].timeNeedRecStart = QDateTime::currentDateTime();
        //ipc_gridReal[idx].absRecDir = ;   // update later
    }
    mutex.unlock();
}

void ViewProcess::ipc_rec_stop(int idx)
{
    qDebug() << idx << __func__ << "channel" << ipc_gridReal[idx].channelIndex;
    mutex.lock();
    {
        ipc_gridReal[idx].bNeedRecStop = true;
        ipc_gridReal[idx].timeNeedRecStop = QDateTime::currentDateTime();
    }
    mutex.unlock();
}

void ViewProcess::file_start(int idx, QString abs_file_path, int seekTime,
                             bool mute, double volume)
{
    qDebug() << idx << __func__ << "channel" << file_gridReal[idx].channelIndex
             << "seekTime" << seekTime;
    mutex.lock();
    {
        if(file_gridReal[idx].absFilePath != abs_file_path)
        {
            if(file_gridReal[idx].status == GridReal::GridStatus_PLAY ||
               file_gridReal[idx].status == GridReal::GridStatus_FILE_PAUSE)
            {
                file_gridReal[idx].bNeedStop = true;
                file_gridReal[idx].timeNeedStop = QDateTime::currentDateTime();
                msleep(2);
            }
        }
        file_gridReal[idx].absFilePath = abs_file_path;
        file_gridReal[idx].bNeedStart = true;
        file_gridReal[idx].timeNeedStart = QDateTime::currentDateTime();
        if(seekTime > 0)
        {
            file_gridReal[idx].bNeedSeek = true;
            file_gridReal[idx].seekTime = seekTime;
        }
        else
        {
            file_gridReal[idx].bNeedSeek = false;
            file_gridReal[idx].seekTime = 0;
        }
        file_gridReal[idx].bNeedMute = true;
        file_gridReal[idx].mute = mute;
        if(mute == false)
        {
            file_gridReal[idx].bNeedVolume = true;
            file_gridReal[idx].volume = volume;
        }
        bUpdateFileFrame = true;
    }
    mutex.unlock();
}

void ViewProcess::file_stop(int idx, bool bSeamless)
{
    qDebug() << idx << __func__ << "channel" << file_gridReal[idx].channelIndex;
    mutex.lock();
    {
        file_gridReal[idx].bNeedStop = true;
        file_gridReal[idx].timeNeedStop = QDateTime::currentDateTime();
        file_gridReal[idx].bSeamless = bSeamless;
    }
    mutex.unlock();
}

bool ViewProcess::ipc_swap(int idx_a, int idx_b)
{
    if (ipc_viewMode != ViewMode_Grid)
        return false;
    if (idx_a < 0 || idx_a >= CHANNEL_MAX)
        return false;
    if (idx_b < 0 || idx_b >= CHANNEL_MAX)
        return false;

    mutex.lock();
    {
        if(DBG(_DBG_RTKAPI_))
        {
            qDebug() << STR_IPC << idx_a << idx_b << __func__;
        }
        ipc_gridReal[idx_a].swap(&ipc_gridReal[idx_b]);
        if(ipc_gridReal[idx_a].status == GridReal::GridStatus_PLAY &&
           ipc_gridReal[idx_b].status == GridReal::GridStatus_PLAY)
        {
            // directly swap the locations of two wndId
            if (rtkApi->ipcSwapWndId(idx_a, idx_b))
            {
                ipc_gridReal[idx_a].infoCurr.swap(&ipc_gridReal[idx_b].infoCurr);
            }
        }
        bUpdateIpcFrame = true;

        int channelIdx_a = ipc_gridReal[idx_a].channelIndex;
        int channelIdx_b = ipc_gridReal[idx_b].channelIndex;
        int temp = ipc_array_idx[channelIdx_a];
        ipc_array_idx[channelIdx_a] = ipc_array_idx[channelIdx_b];
        ipc_array_idx[channelIdx_b] = temp;
    }
    mutex.unlock();
    return true;
}

bool ViewProcess::file_swap(int idx_a, int idx_b)
{
    if (file_viewMode != ViewMode_Grid)
        return false;
    if (idx_a < 0 || idx_a >= CHANNEL_MAX)
        return false;
    if (idx_b < 0 || idx_b >= CHANNEL_MAX)
        return false;

    mutex.lock();
    {
        if(DBG(_DBG_RTKAPI_))
        {
            qDebug() << STR_FILE << idx_a << idx_b << __func__;
        }
        file_gridReal[idx_a].swap(&file_gridReal[idx_b]);
        if(file_gridReal[idx_a].status == GridReal::GridStatus_PLAY &&
           file_gridReal[idx_b].status == GridReal::GridStatus_PLAY)
        {
            // directly swap the locations of two wndId
            if (rtkApi->fileSwapWndId(idx_a, idx_b))
            {
                file_gridReal[idx_a].infoCurr.swap(&file_gridReal[idx_b].infoCurr);
            }
        }
        bUpdateFileFrame = true;
#if 0
        int channelIdx_a = file_gridReal[idx_a].channelIndex;
        int channelIdx_b = file_gridReal[idx_b].channelIndex;
        int temp = file_array_idx[channelIdx_a];
        file_array_idx[channelIdx_a] = file_array_idx[channelIdx_b];
        file_array_idx[channelIdx_b] = temp;
#endif
    }
    mutex.unlock();
    return true;
}

bool ViewProcess::ipc_setViewMode(ViewMode_E newMode, int idx)
{
    if (idx < 0 || idx > CHANNEL_MAX)
        return false;
    if (idx == CHANNEL_MAX &&
        newMode != ViewMode_Hide &&
        newMode != ViewMode_Grid)
        return false;

    switch(newMode)
    {
    case ViewMode_ZoomIn:
        if(DBG(_DBG_RTKAPI_))
        {
            qDebug() << __func__ << idx << strViewMode(newMode);
        }
        mutex.lock();
        {
            ipc_viewMode = ViewMode_ZoomIn;
            ipc_zoomin_idx = idx;
        }
        mutex.unlock();
        update_view_ipc();
        mainMenu->setZoominOption(true);
        break;
    case ViewMode_Grid:
        if(DBG(_DBG_RTKAPI_))
        {
            qDebug() << __func__ << strViewMode(newMode);
        }
        mutex.lock();
        {
            ipc_viewMode = ViewMode_Grid;
            if(idx < CHANNEL_MAX)
            {
                if (ipc_gridReal[idx].ifGetSrc())
                {
                    QRect src = ipc_gridReal[idx].getSrc();
                    ipc_gridReal[idx].setCrop(src.x(),src.y(),src.width(),src.height(),
                                              true); // need to be changed for zoom out
                }
                else
                {
                    ipc_gridReal[idx].setSrcDefault();
                    ipc_gridReal[idx].setCropDefault(false);
                }
            }
//            ipc_grid_idx = idx;
        }
        mutex.unlock();
        update_view_ipc();
        mainMenu->setZoominOption(false);
        break;
    case ViewMode_Set:
        if(DBG(_DBG_RTKAPI_))
        {
            qDebug() << __func__ << idx << strViewMode(newMode);
        }
        mutex.lock();
        {
            ipc_viewMode = ViewMode_Set;
            ipc_set_idx = idx;
        }
        mutex.unlock();
        update_view_ipc();
        mainMenu->setZoominOption(true);
        break;
    case ViewMode_Hide:
    default:
        if(DBG(_DBG_RTKAPI_))
        {
            qDebug() << __func__ << strViewMode(newMode);
        }
        mutex.lock();
        {
            ipc_viewMode = ViewMode_Hide;
        }
        mutex.unlock();
        update_view_ipc();
        mainMenu->setZoominOption(true);
        break;
    }
    return true;
}

bool ViewProcess::file_setViewMode(ViewMode_E newMode, int idx)
{
    if (idx < 0 || idx > CHANNEL_MAX)
        return false;
    if (idx == CHANNEL_MAX &&
        newMode != ViewMode_Hide &&
        newMode != ViewMode_Grid)
        return false;

    switch(newMode)
    {
    case ViewMode_ZoomIn:
        if(DBG(_DBG_RTKAPI_))
        {
            qDebug() << __func__ << idx << strViewMode(newMode);
        }
        mutex.lock();
        {
            file_viewMode = ViewMode_ZoomIn;
            file_zoomin_idx = idx;
        }
        mutex.unlock();
        update_view_file();
        playback->setZoominOption(true);
        break;
    case ViewMode_Grid:
        if(DBG(_DBG_RTKAPI_))
        {
            qDebug() << __func__ << strViewMode(newMode);
        }
        mutex.lock();
        {
            file_viewMode = ViewMode_Grid;
            if(idx < CHANNEL_MAX)
            {
                if (file_gridReal[idx].ifGetSrc())
                {
                    QRect src = file_gridReal[idx].getSrc();
                    file_gridReal[idx].setCrop(src.x(),src.y(),src.width(),src.height(),
                                               true); // need to be changed for zoom out
                }
                else
                {
                    file_gridReal[idx].setSrcDefault();
                    file_gridReal[idx].setCropDefault(false);
                }
            }
        }
        mutex.unlock();
        update_view_file();
        playback->setZoominOption(false);
//        file_grid_idx = idx;
        break;
    case ViewMode_Set:
    case ViewMode_Hide:
    default:
        if(DBG(_DBG_RTKAPI_))
        {
            qDebug() << __func__ << strViewMode(newMode);
        }
        mutex.lock();
        {
            file_viewMode = ViewMode_Hide;
        }
        mutex.unlock();
        update_view_file();
        playback->setZoominOption(true);
        break;
    }
    return true;
}

bool ViewProcess::ipc_zoomin(int idx, QRect rect)
{
    if (idx < 0 || idx >= CHANNEL_MAX)
        return false;
    qDebug() << __func__ << idx;

    mutex.lock();
    {
        this->ipc_viewMode = ViewMode_ZoomIn;
        ipc_zoomin_idx = idx;
    }
    mutex.unlock();
    update_view_ipc();
    mutex.lock();
    {
        ipc_gridReal[idx].setCrop(rect, true);
    }
    mutex.unlock();
    mainMenu->setZoominOption(true);
    return true;
}

bool ViewProcess::file_zoomin(int idx, QRect rect)
{
    if (idx < 0 || idx >= CHANNEL_MAX)
        return false;
    qDebug() << __func__ << idx;

    mutex.lock();
    {
        this->file_viewMode = ViewMode_ZoomIn;
        file_zoomin_idx = idx;
    }
    mutex.unlock();
    update_view_file();
    mutex.lock();
    {
        file_gridReal[idx].setCrop(rect, true);
    }
    mutex.unlock();
    playback->setZoominOption(true);
    return true;
}

QString ViewProcess::strViewMode(ViewMode_E mode)
{
    QString str;
    if (mode == ViewMode_Grid)
        str = "Grid";
    else if (mode == ViewMode_ZoomIn)
        str = "Zoomin";
    else if (mode == ViewMode_Set)
        str = "Set";
    else if (mode == ViewMode_Hide)
        str = "Hide";
    else
        str = "Unknown";
    return str;
}

void ViewProcess::set_system_image()
{
    uint value;

    if(bSetBrightness)
    {
        if(rtkApi->qt_rtk_disp_get_brightness(&value))
        {
            bSetBrightness = (value != Config::setting.brightness);
        }
        if(bSetBrightness)
        {
            bSetBrightness = !(rtkApi->qt_rtk_disp_set_brightness(Config::setting.brightness));
        }
    }

    if(bSetContrast)
    {
        if(rtkApi->qt_rtk_disp_get_contrast(&value))
        {
            bSetContrast = (value != Config::setting.contrast);
        }
        if(bSetContrast)
        {
            bSetContrast = !(rtkApi->qt_rtk_disp_set_contrast(Config::setting.contrast));
        }
    }

    if(bSetHue)
    {
        if(rtkApi->qt_rtk_disp_get_hue(&value))
        {
            bSetHue = (value != Config::setting.hue);
        }
        if(bSetHue)
        {
            bSetHue = !(rtkApi->qt_rtk_disp_set_hue(Config::setting.hue));
        }
    }

    if(bSetSaturation)
    {
        if(rtkApi->qt_rtk_disp_get_saturation(&value))
        {
            bSetSaturation = (value != Config::setting.saturation);
        }
        if(bSetSaturation)
        {
            bSetSaturation = !(rtkApi->qt_rtk_disp_set_saturation(Config::setting.saturation));
        }
    }

    if(bSetSharpness)
    {
        if(rtkApi->qt_rtk_disp_get_sharpness(&value))
        {
            bSetSharpness = (value != Config::setting.sharpness);
        }
        if(bSetSharpness)
        {
            bSetSharpness = !(rtkApi->qt_rtk_disp_set_sharpness(Config::setting.sharpness));
        }
    }
}

void ViewProcess::set_slideshow_interval()
{
    slideShowTimer->setInterval(Config::setting.slideshowInterval * 1000);
}

//void ViewProcess::set_framebuffersize()
//{
//    if(bSetFrameBufferSize)
//    {
//        FrameBufferSize_e fbSize;
//        if(rtkApi->qt_rtk_disp_get_videoFB_Resolution(&fbSize))
//        {
//            bSetFrameBufferSize = (fbSize != Config::sys.frameBufferSizeIndex);
//        }
//        if(bSetFrameBufferSize)
//        {
//            switch (Config::sys.frameBufferSizeIndex) {
//            case 1:
//                fbSize = FRAME_BUFFER_3840x2160;
//                break;
//            case 0:
//            default:
//                fbSize = FRAME_BUFFER_1920x1088;
//                break;
//            }
//            bSetFrameBufferSize = !(rtkApi->qt_rtk_disp_set_videoFB_Resolution(fbSize));
//        }
//    }
//}
