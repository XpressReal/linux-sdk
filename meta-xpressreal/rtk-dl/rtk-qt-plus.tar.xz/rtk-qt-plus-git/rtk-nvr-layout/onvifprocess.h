/**
 * @file onvifprocess.h
 * @author Realtek Semiconductor Corp.
 * @date May 2018
 * @brief The process to operate ONVIF procedure
 */

#ifndef ONVIFROCESS_H
#define ONVIFROCESS_H

#include <QThread>
#include <QMutex>
#include <QTimer>
#include <QDateTime>
#include "define.h"
#include "config.h"

class OnvifProcess : public QThread
{
    Q_OBJECT

public:

    OnvifProcess();
    ~OnvifProcess();

    void setStart();
    void run();
    void setStop();
    void finalize();

    bool isValidIpv4Ip(QString strIp);

private:
    QList<long long> pollingMsec;
    bool bRun;

private slots:
};

extern OnvifProcess *onvifProcess;

#endif // ONVIFROCESS_H
