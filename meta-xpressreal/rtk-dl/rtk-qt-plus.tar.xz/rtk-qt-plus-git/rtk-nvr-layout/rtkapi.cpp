/**
 * @file rtkapi.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The interface/api to use Realtek library
 */

#include <QImage>
#include "rtkapi.h"
#include "gui/mainwidget.h"

RtkApi *rtkApi = NULL;

RtkApi::RtkApi()
{
    rtkApi = this;
#if AUTO_SEARCH_AVAILABLE_CHANNEL
    for(int i=0; i<MAX_INSTANCE; i++)
    {
        availableCh[i] = true;
    }
#endif
}

RtkApi::~RtkApi()
{

}

QString RtkApi::msgRtkReturn(RtkReturn_e rtkReturn)
{
    QString str;
    switch(rtkReturn)
    {
    case RTK_SUCCESS:               str = "Setting Done !";         break;
    case RTK_ERR_FAILURE:           str = "Setting Failed !";       break;
    case RTK_ERR_INVALID_OPERATION: str = "Invalid Operation !";    break;
    case RTK_ERR_INVALID_PARAM:     str = "Invalid Parameters !";   break;
    case RTK_ERR_INSUFFICIENT_RESOURCE: str = "Insufficient Setting !"; break;
    case RTK_ERR_INVALID_STREAM:    str = "Invalid Stream !";           break;
    case RTK_ERR_DECODER_NOT_FOUND: str = "Decoder Not Found !";    break;
    default:    str = "Unknown Failed !";break;
    }
    return str;
}

QString RtkApi::dbgStrRtkReturn(int rtkReturn)
{
    if (rtkReturn == RTK_SUCCESS)
        return QString("");
    QString str;
    switch(rtkReturn)
    {
    case RTK_ERR_FAILURE:           str = "failure";            break;
    case RTK_ERR_INVALID_OPERATION: str = "invalid_op";         break;
    case RTK_ERR_INVALID_PARAM:     str = "invalid_param";      break;
    case RTK_ERR_INSUFFICIENT_RESOURCE: str = "insuffcnt_resrc";break;
    case RTK_ERR_INVALID_STREAM:    str = "invalid_stream";     break;
    case RTK_ERR_DECODER_NOT_FOUND: str = "decoder_not_found";  break;
    default:    str = "unknown"; break;
    }
    return QString(" => fail %1:%2").arg(rtkReturn).arg(str);
}

QString RtkApi::dbgStrFrameBufferSize(FrameBufferSize_e size)
{
    QString str;
    switch(size)
    {
    case FRAME_BUFFER_3840x2160:    str = "3840x2160";  break;
    case FRAME_BUFFER_1920x1088:    str = "1920x1088";  break;
    default:    str = "unknown"; break;
    }
    return QString("%1:%2").arg(size).arg(str);
}

#if RTSP_AV
#elif RTSP_GST
QString RtkApi::dbgStrStream(Stream stream)
{
    QString str;
    switch(stream)
    {
    case MUX_MPEGTS:    str = "MUX_MPEGTS"; break;
    case ES_VIDEO:      str = "ES_VIDEO";   break;
    case ES_H264:       str = "ES_H264";    break;
    case ES_H265:       str = "ES_H265";    break;
    default:            str = "unknown";    break;
    }
    return QString("%1:%2").arg(stream).arg(str);
}
#endif
/*-------------------- qdebug api ----------------*/
bool RtkApi::qt_rtk_serv_initialize()
{
    int rtkReturn = rtk_serv_initialize();
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_serv_initialize() %1")
                    .arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn >= RTK_SUCCESS);
}

bool RtkApi::qt_rtk_serv_terminate()
{
    int rtkReturn = rtk_serv_terminate();
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_serv_terminate() %1")
                    .arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn >= RTK_SUCCESS);
}

bool RtkApi::qt_rtk_serv_force_terminate()
{
    int rtkReturn = rtk_serv_force_terminate();
    qDebug() << QString("rtk_serv_force_terminate() %1")
                .arg(dbgStrRtkReturn(rtkReturn));
    return (rtkReturn >= RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_get_blank(QString head, int idx, int chIdx,
                                   WindowId wndId, bool *enable)
{
    int rtkReturn = rtk_disp_get_blank(wndId,  enable);
    QString strBool = *enable ? "true" : "false";
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        if(rtkReturn < RTK_SUCCESS)
        {
            qDebug() << head << idx << chIdx
                     << QString("rtk_disp_get_blank() wndId=%1%2")
                        .arg(wndId).arg(dbgStrRtkReturn(rtkReturn));
        }
        else
        {
            qDebug() << head << idx << chIdx
                     << QString("rtk_disp_get_blank() wndId=%1 => enable=%2")
                        .arg(wndId).arg(strBool);
        }
    }
    return (rtkReturn >= RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_blank(QString head, int idx, int chIdx,
                                  bool enable, WindowId wndId)
{
    int rtkReturn = rtk_disp_set_blank(enable, 1, wndId);
    QString strBool = enable ? "true" : "false";
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_set_blank(%1) wndId=%2%3")
                    .arg(strBool).arg(wndId).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn >= RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_blank(QString head, QList<int> *idxList, QList<int> *chIdxList,
                                    bool enable, QList<WindowId> *wndIdList)
{
    int i, rtkReturn;
    QString strBool = enable ? "true" : "false";
    if (wndIdList->count() <= 0)
    {
        qDebug() << head << "N" << "N"
                 << QString("rtk_disp_set_blank(%1) num=%2")
                    .arg(strBool).arg(wndIdList->count());
        return true;
    }
    switch(wndIdList->count())
    {
    case 1:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0));
        break;
    case 2:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1));
        break;
    case 3:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2));
        break;
    case 4:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2), wndIdList->at(3));
        break;
    case 5:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2), wndIdList->at(3),
                                       wndIdList->at(4));
        break;
    case 6:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2), wndIdList->at(3),
                                       wndIdList->at(4), wndIdList->at(5));
        break;
    case 7:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2), wndIdList->at(3),
                                       wndIdList->at(4), wndIdList->at(5), wndIdList->at(6));
        break;
    case 8:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2), wndIdList->at(3),
                                       wndIdList->at(4), wndIdList->at(5), wndIdList->at(6),
                                       wndIdList->at(7));
        break;
    case 9:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2), wndIdList->at(3),
                                       wndIdList->at(4), wndIdList->at(5), wndIdList->at(6),
                                       wndIdList->at(7), wndIdList->at(8));
        break;
    case 10:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2), wndIdList->at(3),
                                       wndIdList->at(4), wndIdList->at(5), wndIdList->at(6),
                                       wndIdList->at(7), wndIdList->at(8), wndIdList->at(9));
        break;
    case 11:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2), wndIdList->at(3),
                                       wndIdList->at(4), wndIdList->at(5), wndIdList->at(6),
                                       wndIdList->at(7), wndIdList->at(8), wndIdList->at(9),
                                       wndIdList->at(10));
        break;
    case 12:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2), wndIdList->at(3),
                                       wndIdList->at(4), wndIdList->at(5), wndIdList->at(6),
                                       wndIdList->at(7), wndIdList->at(8), wndIdList->at(9),
                                       wndIdList->at(10),wndIdList->at(11));
        break;
    case 13:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2), wndIdList->at(3),
                                       wndIdList->at(4), wndIdList->at(5), wndIdList->at(6),
                                       wndIdList->at(7), wndIdList->at(8), wndIdList->at(9),
                                       wndIdList->at(10),wndIdList->at(11),wndIdList->at(12));
        break;
    case 14:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2), wndIdList->at(3),
                                       wndIdList->at(4), wndIdList->at(5), wndIdList->at(6),
                                       wndIdList->at(7), wndIdList->at(8), wndIdList->at(9),
                                       wndIdList->at(10),wndIdList->at(11),wndIdList->at(12),
                                       wndIdList->at(13));
        break;
    case 15:
        rtkReturn = rtk_disp_set_blank(enable, wndIdList->count(), wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2), wndIdList->at(3),
                                       wndIdList->at(4), wndIdList->at(5), wndIdList->at(6),
                                       wndIdList->at(7), wndIdList->at(8), wndIdList->at(9),
                                       wndIdList->at(10),wndIdList->at(11),wndIdList->at(12),
                                       wndIdList->at(13),wndIdList->at(14));
        break;
    case 16:
    default:
        rtkReturn = rtk_disp_set_blank(enable, 16, wndIdList->at(0),
                                       wndIdList->at(1), wndIdList->at(2), wndIdList->at(3),
                                       wndIdList->at(4), wndIdList->at(5), wndIdList->at(6),
                                       wndIdList->at(7), wndIdList->at(8), wndIdList->at(9),
                                       wndIdList->at(10),wndIdList->at(11),wndIdList->at(12),
                                       wndIdList->at(13),wndIdList->at(14),wndIdList->at(15));
        break;
    }
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << "N" << "N"
                 << QString("rtk_disp_set_blank(%1) num=%2%3")
                    .arg(strBool).arg(wndIdList->count()).arg(dbgStrRtkReturn(rtkReturn));
        QString strIdx =    "Idx   = ";
        QString strChIdx =  "chIdx = ";
        QString strWndId =  "wndId = ";
        for(i=0; i<wndIdList->count(); i++)
        {
            if(i<idxList->count())
            {
                strIdx.append(QString().asprintf("%2d, ", idxList->at(i)));
            }
            if(i<chIdxList->count())
            {
                strChIdx.append(QString().asprintf("%2d, ", chIdxList->at(i)));
            }
            strWndId.append(QString().asprintf("%2d, ", wndIdList->at(i)));
        }
        qDebug() << strIdx;
        qDebug() << strChIdx;
        qDebug() << strWndId;
    }
    return (rtkReturn >= RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_freeze(QString head, int idx, int chIdx,
                                  bool enable, WindowId wndId)
{
    int rtkReturn = rtk_disp_set_freeze(enable, 1, wndId);
    QString strBool = enable ? "true" : "false";
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_set_freeze(%1) wndId=%2%3")
                    .arg(strBool).arg(wndId).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn >= RTK_SUCCESS);
}

WindowId RtkApi::qt_rtk_disp_create(QString head, int idx, int chIdx,
                                 uint x, uint y, uint w, uint h,
                                 InputStreamType_e inputType)
{
    WindowId wndId = rtk_disp_create(x, y, w, h, inputType);
    if (wndId <= WindowId_Invalid)
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_create() x=%1, y=%2, w=%3, h=%4%5")
                            .arg(x).arg(y).arg(w).arg(h)
                            .arg(dbgStrRtkReturn(wndId));
    }
    else
    {
        if(DBG(_DBG_RTKAPI_))
            qDebug() << head << idx << chIdx
                     << QString("rtk_disp_create() x=%1, y=%2, w=%3, h=%4 => wndId=%5")
                                .arg(x).arg(y).arg(w).arg(h).arg(wndId);
    }
    return wndId;
}

bool RtkApi::qt_rtk_disp_resize(QString head, int idx, int chIdx,
                       WindowId wndId, uint x, uint y, uint w, uint h)
{
    int rtkReturn = rtk_disp_resize(wndId, x, y, w, h);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_resize() wndId=%1, x=%2, y=%3, w=%4, h=%5%6")
                        .arg(wndId).arg(x).arg(y).arg(w).arg(h)
                        .arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_crop(QString head, int idx, int chIdx,
                             WindowId wndId, uint crop_x, uint crop_y,
                             uint crop_w, uint crop_h)
{
    int rtkReturn = rtk_disp_crop(wndId, crop_x, crop_y, crop_w, crop_h);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_crop() wndId=%1, x=%2, y=%3, w=%4, h=%5%6")
                            .arg(wndId).arg(crop_x).arg(crop_y)
                            .arg(crop_w).arg(crop_h).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_swap(QString head, int idx_a, int idx_b, int wndId_a, int wndId_b)
{
    int rtkReturn = rtk_disp_swap(wndId_a, wndId_b);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx_a << idx_b
                 << QString("rtk_disp_swap() wndId_a=%1, wndId_b=%2%3")
                    .arg(wndId_a).arg(wndId_b).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_destroy(QString head, int idx, int chIdx, WindowId wndId)
{
    int rtkReturn = rtk_disp_destroy(wndId);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_destroy() wndId=%1%2")
                    .arg(wndId).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_output(HDMIMode_e hdmiMode, DPMode_e dpMode, RtkReturn_e *rtnValue)
{
    RtkReturn_e rtkReturn = rtk_disp_set_output(hdmiMode, dpMode);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_set_output() hdmi=%1:%2 dp=%3:%4%5")
                        .arg(hdmiMode).arg(opt_ValToStr(optHdmiMode, hdmiMode))
                        .arg(dpMode).arg(opt_ValToStr(optDpMode, dpMode))
                        .arg(dbgStrRtkReturn(rtkReturn));
    }
    if(rtnValue != NULL)
    {
        *rtnValue = rtkReturn;
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_get_output(HDMIMode_e *pHdmiMode, DPMode_e *pDpMode)
{
    if (pHdmiMode==NULL || pDpMode==NULL)
        return false;
    int rtkReturn = rtk_disp_get_output(pHdmiMode, pDpMode);
    if (rtkReturn < RTK_SUCCESS)
    {
        qDebug() << QString("rtk_disp_get_output()%1")
                        .arg(dbgStrRtkReturn(rtkReturn));
    }
    else
    {
        if (DBG(_DBG_RTKAPI_))
            qDebug() << QString("rtk_disp_get_output() hdmi=%1:%2 dp=%3:%4")
                            .arg(*pHdmiMode).arg(opt_ValToStr(optHdmiMode, *pHdmiMode))
                            .arg(*pDpMode).arg(opt_ValToStr(optDpMode, *pDpMode));
    }
    return (rtkReturn >= RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_outputFrameRate(QString head, int idx, int chIdx, ChannelId channelId, unsigned int fps)
{
    int rtkReturn = rtk_disp_set_outputFrameRate(channelId, fps);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_set_outputFrameRate() channelId=%1 fps=%2%3")
                    .arg(channelId).arg(fps).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_brightness(unsigned int brightness)
{
    int rtkReturn = rtk_disp_set_brightness(brightness);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_set_brightness() brightness=%1%2")
                    .arg(brightness).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_get_brightness(unsigned int *brightness)
{
    uchar value;
    int rtkReturn = rtk_disp_get_brightness(&value);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_get_brightness() brightness=%2%3")
                    .arg(value).arg(dbgStrRtkReturn(rtkReturn));
    }
    if(rtkReturn == RTK_SUCCESS)
    {
        *brightness = value;
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_contrast(unsigned int contrast)
{
    int rtkReturn = rtk_disp_set_contrast(contrast);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_set_contrast() contrast=%1%2")
                    .arg(contrast).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_get_contrast(unsigned int *contrast)
{
    uchar value;
    int rtkReturn = rtk_disp_get_contrast(&value);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_get_contrast() contrast=%2%3")
                    .arg(value).arg(dbgStrRtkReturn(rtkReturn));
    }
    if(rtkReturn == RTK_SUCCESS)
    {
        *contrast = value;
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_hue(unsigned int hue)
{
    int rtkReturn = rtk_disp_set_hue(hue);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_set_hue() hue=%1%2")
                    .arg(hue).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_get_hue(unsigned int *hue)
{
    uchar value;
    int rtkReturn = rtk_disp_get_hue(&value);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_get_hue() hue=%2%3")
                    .arg(value).arg(dbgStrRtkReturn(rtkReturn));
    }
    if(rtkReturn == RTK_SUCCESS)
    {
        *hue = value;
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_saturation(unsigned int saturation)
{
    int rtkReturn = rtk_disp_set_saturation(saturation);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_set_saturation() saturation=%1%2")
                    .arg(saturation).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_get_saturation(unsigned int *saturation)
{
    uchar value;
    int rtkReturn = rtk_disp_get_saturation(&value);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_get_saturation() saturation=%2%3")
                    .arg(value).arg(dbgStrRtkReturn(rtkReturn));
    }
    if(rtkReturn == RTK_SUCCESS)
    {
        *saturation = value;
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_sharpness(unsigned int sharpness)
{
    int rtkReturn = rtk_disp_set_sharpness(sharpness);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_set_sharpness() sharpness=%1%2")
                    .arg(sharpness).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_get_sharpness(unsigned int *sharpness)
{
    uchar value;
    int rtkReturn = rtk_disp_get_sharpness(&value);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_get_sharpness() sharpness=%2%3")
                    .arg(value).arg(dbgStrRtkReturn(rtkReturn));
    }
    if(rtkReturn == RTK_SUCCESS)
    {
        *sharpness = value;
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_channel_brightness(QString head, int idx, int chIdx, WindowId wndId, unsigned int brightness)
{
    int rtkReturn = rtk_disp_set_channel_brightness(wndId, brightness);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_set_channel_brightness() wndId=%1 brightness=%2%3")
                    .arg(wndId).arg(brightness).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_get_channel_brightness(QString head, int idx, int chIdx, WindowId wndId, unsigned int *brightness)
{
    int rtkReturn = rtk_disp_get_channel_brightness(wndId, brightness);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_get_channel_brightness() wndId=%1 brightness=%2%3")
                    .arg(wndId).arg(*brightness).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_channel_contrast(QString head, int idx, int chIdx, WindowId wndId, unsigned int contrast)
{
    int rtkReturn = rtk_disp_set_channel_contrast(wndId, contrast);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_set_channel_contrast() wndId=%1 contrast=%2%3")
                    .arg(wndId).arg(contrast).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_get_channel_contrast(QString head, int idx, int chIdx, WindowId wndId, unsigned int *contrast)
{
    int rtkReturn = rtk_disp_get_channel_contrast(wndId, contrast);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_get_channel_contrast() wndId=%1 contrast=%2%3")
                    .arg(wndId).arg(*contrast).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_channel_hue(QString head, int idx, int chIdx, WindowId wndId, unsigned int hue)
{
    int rtkReturn = rtk_disp_set_channel_hue(wndId, hue);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_set_channel_hue() wndId=%1 hue=%2%3")
                    .arg(wndId).arg(hue).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_get_channel_hue(QString head, int idx, int chIdx, WindowId wndId, unsigned int *hue)
{
    int rtkReturn = rtk_disp_get_channel_hue(wndId, hue);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_get_channel_hue() wndId=%1 hue=%2%3")
                    .arg(wndId).arg(*hue).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_channel_saturation(QString head, int idx, int chIdx, WindowId wndId, unsigned int saturation)
{
    int rtkReturn = rtk_disp_set_channel_saturation(wndId, saturation);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_set_channel_saturation() wndId=%1 saturation=%2%3")
                    .arg(wndId).arg(saturation).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_get_channel_saturation(QString head, int idx, int chIdx, WindowId wndId, unsigned int *saturation)
{
    int rtkReturn = rtk_disp_get_channel_saturation(wndId, saturation);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_get_channel_saturation() wndId=%1 saturation=%2%3")
                    .arg(wndId).arg(*saturation).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_channel_sharpness(QString head, int idx, int chIdx, WindowId wndId, unsigned int sharpness)
{
    int rtkReturn = rtk_disp_set_channel_sharpness(wndId, sharpness);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_set_channel_sharpness() wndId=%1 sharpness=%2%3")
                    .arg(wndId).arg(sharpness).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_get_channel_sharpness(QString head, int idx, int chIdx, WindowId wndId, unsigned int *sharpness)
{
    int rtkReturn = rtk_disp_get_channel_sharpness(wndId, sharpness);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_get_channel_sharpness() wndId=%1 sharpness=%2%3")
                    .arg(wndId).arg(*sharpness).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_bgcolor(uchar r, uchar g, uchar b, RtkReturn_e *rtnValue)
{
    RtkReturn_e rtkReturn = rtk_disp_set_bgcolor(r, g, b);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_set_bgcolor() r=%1 g=%2 b=%3%4")
                    .arg(QString().asprintf("0x%02x", r))
                    .arg(QString().asprintf("0x%02x", g))
                    .arg(QString().asprintf("0x%02x", b))
                    .arg(dbgStrRtkReturn(rtkReturn));
    }
    if(rtnValue != NULL)
    {
        *rtnValue = rtkReturn;
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_set_videoFB_Resolution(FrameBufferSize_e fbSize, RtkReturn_e *rtnValue)
{
    RtkReturn_e rtkReturn = rtk_disp_set_videoFB_Resolution(fbSize);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_set_videoFB_Resolution() fbSize=%1%2")
                    .arg(dbgStrFrameBufferSize(fbSize)).arg(dbgStrRtkReturn(rtkReturn));
    }
    if(rtnValue != NULL)
    {
        *rtnValue = rtkReturn;
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_disp_get_videoFB_Resolution(FrameBufferSize_e *fbSize)
{
    int rtkReturn = rtk_disp_get_videoFB_Resolution(fbSize);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_disp_get_videoFB_Resolution() fbSize=%1%2")
                    .arg(dbgStrFrameBufferSize(*fbSize)).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

ChannelId RtkApi::qt_rtk_dec_add_channel_video(QString head, int idx, int chIdx)
{
    int width = -1;
    int height = -1;
    ChannelId channelId = rtk_dec_add_channel_video(-1, -1);
    if (channelId <= ChannelId_Invalid)
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_dec_add_channel_video() w=%1, h=%2 => fail channelId=%3")
                            .arg(width).arg(height).arg(channelId);
    }
    else
    {
        if(DBG(_DBG_RTKAPI_))
            qDebug() << head << idx << chIdx
                     << QString("rtk_dec_add_channel_video() w=%1, h=%2 => channelId=%3")
                            .arg(width).arg(height).arg(channelId);
#if AUTO_SEARCH_AVAILABLE_CHANNEL
        availableCh[channelId] = false;
#endif
    }
    return channelId;
}

bool RtkApi::qt_rtk_dec_set_channel_video (QString head, int idx, int chIdx,
                                           ChannelId channelId, VideoCodec_e vid_codec)
{
    ChannelParams_t param;
//    if(qt_rtk_dec_get_params(head, idx, chIdx, channelId, &param) != true)
//    {
//        return false;
//    }
    param.vid_codec = vid_codec;
    int rtkReturn = rtk_dec_set_channel_video(channelId, &param);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_dec_set_channel_video() channelId=%1 vid_codec=%2:%3%4")
                        .arg(channelId)
                        .arg(param.vid_codec)
                        .arg(opt_ValToStr(optVideoCodec, param.vid_codec))
                        .arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_dec_bind(QString head, int idx, int chIdx,
                                    ChannelId channelId, WindowId wndId)
{
    int rtkReturn = rtk_dec_bind(channelId, wndId);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_dec_bind() channelId=%1, wndId=%2%3")
                    .arg(channelId).arg(wndId).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_dec_set_play(QString head, int idx, int chIdx,
                        ChannelState_e newState, ChannelId channelId)
{
    int rtkReturn = rtk_dec_set_play(newState, channelId);
    QString strState;
    if (newState == CH_STATE_PAUSE)
        strState = "PAUSE";
    else if (newState == CH_STATE_PLAY)
        strState = "PLAY";
    else if (newState == CH_STATE_STOP)
        strState = "STOP";
    else
        strState = "Unknown";
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_dec_set_play(%1) channelId=%2%3")
                    .arg(strState).arg(channelId).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_dec_remove_channel(QString head, int idx, int chIdx,
                                      ChannelId channelId)
{
    int rtkReturn = rtk_dec_remove_channel(channelId);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_dec_remove_channel() channelId=%1%2")
                    .arg(channelId).arg(dbgStrRtkReturn(rtkReturn));
    }
#if AUTO_SEARCH_AVAILABLE_CHANNEL
    if (rtkReturn == RTK_SUCCESS)
    {
        availableCh[channelId] = true;
    }
#endif
    return (rtkReturn == RTK_SUCCESS);
}

//bool RtkApi::qt_rtk_dec_get_params(QString head, int idx, int chIdx,
//                                   ChannelId channelId, ChannelParams_t *param)
//{
//    int rtkReturn = rtk_dec_get_params(channelId, param);
//    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
//    {
//        qDebug() << head << idx << chIdx
//                 << QString("rtk_dec_get_params() channelId=%1%2")
//                    .arg(channelId).arg(dbgStrRtkReturn(rtkReturn));
//    }
//    return (rtkReturn == RTK_SUCCESS);
//}

bool RtkApi::qt_rtk_ipc_debug_getInfo(QString head, int idx, int chIdx, ChannelId channelId,
                                      unsigned long long * bufferWriteCnt, unsigned long long * sizeZeroCnt,
                                      unsigned long long * connectErrCnt, unsigned long long * writeErrCnt)
{
    int rtkReturn = rtk_ipc_debug_getInfo(channelId, bufferWriteCnt, sizeZeroCnt, connectErrCnt, writeErrCnt);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_ipc_debug_getInfo() channelId=%1%2")
                    .arg(channelId).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_ipc_debug_getInfo(ChannelId channelId,
                                      unsigned long long * bufferWriteCnt, unsigned long long * sizeZeroCnt,
                                      unsigned long long * connectErrCnt, unsigned long long * writeErrCnt,
                                      bool ifMsg)
{
    int rtkReturn = rtk_ipc_debug_getInfo(channelId, bufferWriteCnt, sizeZeroCnt, connectErrCnt, writeErrCnt);
    if(ifMsg)
    {
        if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
        {
            qDebug() << QString("rtk_ipc_debug_getInfo() channelId=%1%2")
                        .arg(channelId).arg(dbgStrRtkReturn(rtkReturn));
        }
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_ipc_debug_reset(QString head, int idx, int chIdx, ChannelId channelId)
{
    int rtkReturn = rtk_ipc_debug_reset(channelId);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_ipc_debug_reset() channelId=%1%2")
                    .arg(channelId).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_ipc_debug_reset(ChannelId channelId)
{
    int rtkReturn = rtk_ipc_debug_reset(channelId);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_ipc_debug_reset() channelId=%1%2")
                    .arg(channelId).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}

bool RtkApi::qt_rtk_player_initialize()
{
#if RTSP_GST
    int rtkReturn = rtk_player_initialize();
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_player_initialize() %1")
                    .arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn >= RTK_SUCCESS);
#else
    return true;
#endif
}

#if AUTO_SEARCH_AVAILABLE_CHANNEL
ChannelId RtkApi::qt_rtk_player_get_available_channel()
{
    for(int i=0; i<MAX_INSTANCE; i++)
    {
        if(availableCh[i] == true)
        {
            if(rtk_player_get_available(i))
            {
                return i;
            }
        }
    }
    return ChannelId_Invalid;
}
#endif

ChannelId RtkApi::qt_rtk_player_add_channel_video(QString head, int idx, int chIdx)
{
#if RTSP_GST
#if AUTO_SEARCH_AVAILABLE_CHANNEL
    ChannelId channelId = qt_rtk_player_get_available_channel();
    if(channelId <= ChannelId_Invalid)
    {
        qDebug() << head << idx << chIdx
                 << QString("qt_rtk_player_availabel_channel() => fail channelId=%3")
                            .arg(channelId);
        return channelId;
    }
    int rtkReturn = rtk_player_add_idx_channel_video(channelId);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_add_idx_channel_video() channelId=%1%2")
                    .arg(channelId).arg(dbgStrRtkReturn(rtkReturn));
    }
    if (rtkReturn == RTK_SUCCESS)
    {
        availableCh[channelId] = false;
        return channelId;
    }
    return rtkReturn;
#else
    ChannelId channelId = rtk_player_add_channel_video();
    if (channelId <= ChannelId_Invalid)
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_add_channel_video() => fail channelId=%3")
                            .arg(channelId);
    }
    else
    {
        if(DBG(_DBG_RTKAPI_))
            qDebug() << head << idx << chIdx
                     << QString("rtk_player_add_channel_video() => channelId=%3")
                                .arg(channelId);
    }
    return channelId;
#endif
#else
    return (RTK_SUCCESS);
#endif
}

ChannelId RtkApi::qt_rtk_player_add_channel_av(QString head, int idx, int chIdx)
{
#if RTSP_GST
#if AUTO_SEARCH_AVAILABLE_CHANNEL
    ChannelId channelId = qt_rtk_player_get_available_channel();
    if(channelId <= ChannelId_Invalid)
    {
        qDebug() << head << idx << chIdx
                 << QString("qt_rtk_player_availabel_channel() => fail channelId=%3")
                            .arg(channelId);
        return channelId;
    }
    int rtkReturn = rtk_player_add_idx_channel_av(channelId);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_add_idx_channel_av() channelId=%1%2")
                    .arg(channelId).arg(dbgStrRtkReturn(rtkReturn));
    }
    if (rtkReturn == RTK_SUCCESS)
    {
        availableCh[channelId] = false;
        return channelId;
    }
    return rtkReturn;
#else
    ChannelId channelId = rtk_player_add_channel_av();
    if (channelId <= ChannelId_Invalid)
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_add_channel_av() => fail channelId=%3")
                            .arg(channelId);
    }
    else
    {
        if(DBG(_DBG_RTKAPI_))
            qDebug() << head << idx << chIdx
                     << QString("rtk_player_add_channel_av() => channelId=%3")
                                .arg(channelId);
    }
    return channelId;
#endif
#else
    return (RTK_SUCCESS);
#endif
}

#if 0
bool RtkApi::qt_rtk_player_set_channel_video (QString head, int idx, int chIdx,
                                           ChannelId channelId, VideoCodec_e vid_codec)
{
    PlayerChannelParams_t param;
//    if(qt_rtk_player_get_params(head, idx, chIdx, channelId, &param) != true)
//    {
//        return false;
//    }
    param.vid_codec = vid_codec;
    param.width = 3840;
    param.height = 2160;
    int rtkReturn = rtk_player_set_channel_video(channelId, &param);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_set_channel_video() channelId=%1 vid_codec=%2:%3%4")
                        .arg(channelId)
                        .arg(param.vid_codec)
                        .arg(opt_ValToStr(optVideoCodec, param.vid_codec))
                        .arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
}
#endif

bool RtkApi::qt_rtk_player_bind(QString head, int idx, int chIdx,
                                ChannelId channelId, WindowId wndId,
                                int x, int y, int width, int height)
{
#if RTSP_GST
    int rtkReturn = rtk_player_bind(channelId, wndId, x, y, width, height);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
#if 0
                 << QString("rtk_player_bind() channelId=%1, wndId=%2%3")
                    .arg(channelId).arg(wndId).arg(dbgStrRtkReturn(rtkReturn));
#else
                 << QString("rtk_player_bind() channelId=%1, wndId=%2, x=%3, y=%4, w=%5, h=%6%7")
                    .arg(channelId).arg(wndId).arg(x).arg(y).arg(width).arg(height)
                    .arg(dbgStrRtkReturn(rtkReturn));
#endif
    }
    return (rtkReturn == RTK_SUCCESS);
#else
    return true;
#endif
}

bool RtkApi::qt_rtk_player_open(QString head, int idx, int chIdx,
                            ChannelId channelId, QString absFilePath)
{
#if RTSP_GST
    int rtkReturn = rtk_player_open(channelId, absFilePath.toStdString().c_str());
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_open() channelId=%1%2 %3")
                    .arg(channelId).arg(dbgStrRtkReturn(rtkReturn)).arg(absFilePath);
    }
    return (rtkReturn == RTK_SUCCESS);
#else
    return true;
#endif
}

bool RtkApi::qt_rtk_player_set_play(QString head, int idx, int chIdx,
                        ChannelState_e newState, ChannelId channelId)
{
#if RTSP_GST
    int rtkReturn = rtk_player_set_play(newState, channelId);
    QString strState;
    if (newState == CH_STATE_PAUSE)
        strState = "PAUSE";
    else if (newState == CH_STATE_PLAY)
        strState = "PLAY";
    else if (newState == CH_STATE_STOP)
        strState = "STOP";
    else
        strState = "Unknown";
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_set_play(%1) channelId=%2%3")
                    .arg(strState).arg(channelId).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
#else
    return true;
#endif
}

bool RtkApi::qt_rtk_player_remove_channel(QString head, int idx, int chIdx,
                                      ChannelId channelId)
{
#if RTSP_GST
    int rtkReturn = rtk_player_remove_channel(channelId);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_remove_channel() channelId=%1%2")
                    .arg(channelId).arg(dbgStrRtkReturn(rtkReturn));
    }
#if AUTO_SEARCH_AVAILABLE_CHANNEL
    if (rtkReturn == RTK_SUCCESS)
    {
        availableCh[channelId] = true;
    }
#endif
    return (rtkReturn == RTK_SUCCESS);
#else
    return true;
#endif
}

bool RtkApi::qt_rtk_player_start_audio(QString head, int idx, int chIdx, ChannelId channelId)
{
#if RTSP_GST
    int rtkReturn = rtk_player_start_audio(channelId);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_start_audio() channelId=%1%2")
                    .arg(channelId).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
#else
    return true;
#endif
}

bool RtkApi::qt_rtk_player_stop_audio(QString head, int idx, int chIdx, ChannelId channelId)
{
#if RTSP_GST
    int rtkReturn = rtk_player_stop_audio(channelId);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_stop_audio() channelId=%1%2")
                    .arg(channelId).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
#else
    return true;
#endif
}

bool RtkApi::qt_rtk_player_set_mute(QString head, int idx, int chIdx, ChannelId channelId, bool enable)
{
#if RTSP_GST
    int rtkReturn = rtk_player_set_mute(enable, channelId);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_set_mute() channelId=%1, enable=%2%3")
                    .arg(channelId).arg(enable).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn == RTK_SUCCESS);
#else
    return true;
#endif
}

bool RtkApi::qt_rtk_player_get_volume(QString head, int idx, int chIdx, ChannelId channelId, double *volume)
{
#if RTSP_GST
    if(volume == NULL)
        return false;
    int rtkReturn = rtk_player_get_volume(channelId, volume);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString().asprintf("rtk_player_get_volume() channelId=%d, volume=%.3f%s",
                                      channelId, *volume,
                                      dbgStrRtkReturn(rtkReturn).toStdString().c_str());
    }
    return (rtkReturn == RTK_SUCCESS);
#else
    return true;
#endif
}

bool RtkApi::qt_rtk_player_set_volume(QString head, int idx, int chIdx, ChannelId channelId, double volume)
{
#if RTSP_GST
    int rtkReturn = rtk_player_set_volume(volume, channelId);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString().asprintf("rtk_player_set_volume() channelId=%d, volume=%.3f%s",
                                      channelId, volume,
                                      dbgStrRtkReturn(rtkReturn).toStdString().c_str());
    }
    return (rtkReturn == RTK_SUCCESS);
#else
    return true;
#endif
}

#if RTSP_AV
bool RtkApi::qt_rtk_rtsp_av_initialize()
{
    int rtkReturn = rtk_rtsp_av_initialize();
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
        {
        qDebug() << QString("rtk_rtsp_av_initialize() %1")
                    .arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn >= RTK_SUCCESS);
}

bool RtkApi::qt_rtk_rtsp_av_terminate()
{
    int rtkReturn = rtk_rtsp_av_terminate();
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("rtk_rtsp_av_terminate() %1")
                    .arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn >= RTK_SUCCESS);
}

RtspClientId RtkApi::qt_rtk_rtsp_av_client_new(QString head, int idx, int chIdx, QString rtspCmd)
{
    RtspClientId cid = rtk_rtsp_av_client_new(rtspCmd.toStdString().c_str());
    if (cid <= ClientId_Invalid)
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_rtsp_av_client_new() => fail cid=%1")
                            .arg(cid);
        cid = ClientId_Invalid;
    }
    else
    {
        if(DBG(_DBG_RTKAPI_))
            qDebug() << head << idx << chIdx
                     << QString("rtk_rtsp_av_client_new() => cid=%1")
                                .arg(cid);
    }
    return cid;
}

void RtkApi::qt_rtk_rtsp_av_client_free(QString head, int idx, int chIdx, RtspClientId cid)
{
    rtk_rtsp_av_client_free(cid);
    if (DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_rtsp_av_client_free() cid=%1").arg(cid);
    }
}

void RtkApi::qt_rtk_rtsp_av_player_play(QString head, int idx, int chIdx,
                             RtspClientId cid, int v_ch, int a_ch)
{
    rtk_rtsp_av_player_play(cid, v_ch, a_ch);
    if(DBG(_DBG_RTKAPI_))
        qDebug() << head << idx << chIdx
                 << QString("rtk_rtsp_av_player_play() cid=%1, v_ch=%2, a_ch=%3")
                           .arg(cid).arg(v_ch).arg(a_ch);
}

void RtkApi::qt_rtk_rtsp_av_player_stop(QString head, int idx, int chIdx,
                                    RtspClientId cid)
{
    rtk_rtsp_av_player_stop (cid);
    if(DBG(_DBG_RTKAPI_))
        qDebug() << head << idx << chIdx
                 << QString("rtk_rtsp_av_player_stop() cid=%1").arg(cid);
}

void RtkApi::qt_rtk_rtsp_av_rec_set_info(QString head, int idx, int chIdx,
                              RtspClientId cid, int v_ch, int a_ch,
                              int wnd_x, int wnd_y, int wnd_width, int wnd_height)
{
    rtk_rtsp_av_rec_set_info (cid, chIdx, v_ch, a_ch,
                           wnd_x, wnd_y, wnd_width, wnd_height);
    if(DBG(_DBG_RTKAPI_))
        qDebug() << head << idx << chIdx
                 << QString().asprintf("rtk_rtsp_av_rec_set_info() cid=%d, gui_ch=%d, v_ch=%d, a_ch=%d, wnd_x=%d, wnd_y=%d, wnd_width=%d, wnd_height=%d",
                                      cid, chIdx, v_ch, a_ch,
                                      wnd_x, wnd_y, wnd_width, wnd_height);
}

void RtkApi::qt_rtk_rtsp_av_rec_start(QString head, int idx, int chIdx, RtspClientId cid, QString absDirPath, int duration)
{

}

void RtkApi::qt_rtk_rtsp_av_rec_stop(QString head, int idx, int chIdx, RtspClientId cid)
{

}

void RtkApi::qt_rtk_rtsp_av_rec_change(QString head, int idx, int chIdx, RtspClientId cid, QString absDirPath, int duration)
{

}
#elif RTSP_GST
void RtkApi::qt_rtsp_client_set_latency (QString head, int idx, int chIdx, RtspClient* client, uint latency)
{
    rtsp_client_set_latency(client, latency);
    if(DBG(_DBG_RTKAPI_))
        qDebug() << head << idx << chIdx
                 << QString("rtsp_client_set_latency(%1)").arg(Config::sys.setRtspLatency);
}

RtspPlayer *RtkApi::qt_rtsp_player_new (QString head, int idx, int chIdx, QString rtspCmd, int channelId)
{
    RtspPlayer *rtspPlayer = rtsp_player_new(rtspCmd.toStdString().c_str(), channelId);
    if (rtspPlayer == NULL)
    {
        qDebug() << head << idx << chIdx
                 << QString("rtsp_player_new() channelId=%1 => fail rtspPlayer=%2")
                            .arg(channelId).arg(rtspCmd);
    }
    else
    {
        if(DBG(_DBG_RTKAPI_))
            qDebug() << head << idx << chIdx
                     << QString().asprintf("rtsp_player_new() channelId=%d => rtspPlayer=%p",
                                          channelId, (void *)rtspPlayer);
    }
    return rtspPlayer;
}

void RtkApi::qt_rtsp_player_play (QString head, int idx, int chIdx, RtspPlayer* rtspPlayer)
{
    rtsp_player_play(rtspPlayer);
    if(DBG(_DBG_RTKAPI_))
        qDebug() << head << idx << chIdx
                 << QString().asprintf("rtsp_player_play() rtspPlayer=%p", (void *)rtspPlayer);
}

void RtkApi::qt_rtsp_player_stop (QString head, int idx, int chIdx, RtspPlayer* rtspPlayer)
{
    rtsp_player_stop (rtspPlayer);
    if(DBG(_DBG_RTKAPI_))
        qDebug() << head << idx << chIdx
                 << QString().asprintf("rtsp_player_stop() rtspPlayer=%p", (void *)rtspPlayer);
}

void RtkApi::qt_rtsp_player_free (QString head, int idx, int chIdx, RtspPlayer* rtspPlayer)
{
    rtsp_player_free (rtspPlayer);
    if(DBG(_DBG_RTKAPI_))
        qDebug() << head << idx << chIdx
                 << QString().asprintf("rtsp_player_free() rtspPlayer=%p", (void *)rtspPlayer);
}

void RtkApi::qt_rtsp_player_set_stream (QString head, int idx, int chIdx, RtspPlayer *rtspPlayer, Stream stream)
{
    rtsp_player_set_stream (rtspPlayer, stream);
    if(DBG(_DBG_RTKAPI_))
        qDebug() << head << idx << chIdx
                 << QString().asprintf("rtsp_player_set_stream() rtspPlayer=%p, stream=%s",
                                      (void *)rtspPlayer, dbgStrStream(stream).toStdString().c_str());
}

void RtkApi::qt_rtsp_player_rec_start (QString head, int idx, int chIdx, RtspPlayer* rtspPlayer, QString absDirPath, uint duration)
{
    rtsp_player_rec_start(rtspPlayer, absDirPath.toStdString().c_str(), duration);
    if(DBG(_DBG_RTKAPI_))
        qDebug() << head << idx << chIdx
                 << QString().asprintf("rtsp_player_rec_start() rtspPlayer=%p duration=%d %s",
                                      (void *)rtspPlayer, duration, absDirPath.toStdString().c_str());
}

void RtkApi::qt_rtsp_player_rec_stop (QString head, int idx, int chIdx, RtspPlayer* rtspPlayer)
{
    rtsp_player_rec_stop(rtspPlayer);
    if(DBG(_DBG_RTKAPI_))
        qDebug() << head << idx << chIdx
                 << QString().asprintf("rtsp_player_rec_stop() rtspPlayer=%p", (void *)rtspPlayer);
}

void RtkApi::qt_rtsp_player_rec_change (QString head, int idx, int chIdx, RtspPlayer* rtspPlayer, QString absDirPath, uint duration)
{
    rtsp_player_rec_change(rtspPlayer, absDirPath.toStdString().c_str(), duration);
    if(DBG(_DBG_RTKAPI_))
        qDebug() << head << idx << chIdx
                 << QString().asprintf("rtsp_player_rec_change() rtspPlayer=%p duration=%d %s",
                                      (void *)rtspPlayer, duration, absDirPath.toStdString().c_str());
}
#endif
/*-------------------- qdebug api end-------------*/

bool RtkApi::setup()
{
    /* Initialize */
    if (qt_rtk_serv_initialize() == false)
    {
        if(qt_rtk_serv_force_terminate() == false)
        {
            return false;
        }
        if(qt_rtk_serv_initialize() == false)
        {
            return false;
        }
    }
#if RTSP_AV
    if (qt_rtk_rtsp_av_initialize() == false)
    {
        if(qt_rtk_rtsp_av_terminate() == false)
        {
            return false;
        }
        if(qt_rtk_rtsp_av_initialize() == false)
        {
            return false;
        }
    }
#endif
    qt_rtk_player_initialize();
    return true;
}

void RtkApi::msleep(int msec)
{
    QThread::msleep(msec);
    if(DBG(_DBG_RTKAPI_))
    {
        qDebug() << QString("sleep %1ms").arg(msec);
    }
}

void RtkApi::finalize()
{
    if(DBG(_DBG_RTKAPI_))
        qDebug() << "RtkApi::finalize()";
    for (int idx=0; idx<CHANNEL_MAX; idx++)
    {
        ipcStop(idx, false);
    }
    for (int idx=0; idx<CHANNEL_MAX; idx++)
    {
        fileStop(idx, false);
    }
    this->msleep(Config::sys.terminateDelay);
#if RTSP_AV
    qt_rtk_rtsp_av_terminate();
#endif
    qt_rtk_serv_terminate();
}

bool RtkApi::apply_view_ipc()
{
//    if(DBG(_DBG_RTKAPI_))
//        qDebug() << __func__;
    QString head = STR_IPC;
    int i, chIdx, change, err;
    GridReal *grid;
    GridInfo *info, *view;
    QList<int> listIdx, listChIdx;
    QList<WindowId> listWndId;
    int osdX, osdY, osdW, osdH;
    int fbX, fbY, fbW, fbH;

    // update widget & border first
    for (i=0; i<CHANNEL_MAX; i++)
    {
        grid = &viewProcess->ipc_gridReal[i];
        view = viewProcess->view_ipc.gridInfoList->at(i);
        osdX = Config::sys.ratioOSD*view->x();
        osdY = Config::sys.ratioOSD*view->y();
        osdW = Config::sys.ratioOSD*view->width();
        osdH = Config::sys.ratioOSD*view->height();
        if (viewProcess->bUpdateIpcFrame)
        {
            viewProcess->update_ipc_frame(i);
        }
        RFrame *frame = mainWidget->ipcFrame[i];
        if (frame->x() == osdX &&
            frame->y() == osdY &&
            frame->width() == osdW &&
            frame->height() == osdH)
            continue;
        if(DBG(_DBG_RTKAPI_))
            qDebug() << head << i
                     << QString("frame->prepareGeometry(%1, %2, %3, %4)")
                        .arg(osdX).arg(osdY).arg(osdW).arg(osdH);
        frame->prepareGeometry(osdX, osdY, osdW, osdH);
        // info->copy(view); /* update later */
    }
    viewProcess->bUpdateIpcFrame = false;

    // set blank first for changed grid
    for (i=0; i<CHANNEL_MAX; i++)
    {
        grid = &viewProcess->ipc_gridReal[i];
        chIdx = grid->channelIndex;
        info = &grid->infoCurr;
        view = viewProcess->view_ipc.gridInfoList->at(i);
        fbX = Config::sys.ratioVFB*view->x();
        fbY = Config::sys.ratioVFB*view->y();
        fbW = Config::sys.ratioVFB*view->width();
        fbH = Config::sys.ratioVFB*view->height();

        if (grid->wndId <= WindowId_Invalid)
            continue;
        if (info->x() == fbX &&
            info->y() == fbY &&
            info->width() == fbW &&
            info->height() == fbH)
            continue;

        if(Config::sys.seamless &&
           grid->status == GridReal::GridStatus_NONE)
        {
            // do not blank
        }
        else if (grid->status == GridReal::GridStatus_NONE)
        {
        }
        else
        {
            listIdx.append(i);
            listChIdx.append(chIdx);
            listWndId.append(grid->wndId);
        }
    }
    if (listIdx.count() > 0)
    {
        if (qt_rtk_disp_set_blank(head, &listIdx, &listChIdx, true, &listWndId))
        {
            this->msleep(Config::sys.setBlankTime);
        }
    }

    // resize
    change = 0;
    listIdx.clear();
    listChIdx.clear();
    listWndId.clear();
    for (i=0; i<CHANNEL_MAX; i++)
    {
        grid = &viewProcess->ipc_gridReal[i];
        chIdx = grid->channelIndex;
        info = &grid->infoCurr;
        view = viewProcess->view_ipc.gridInfoList->at(i);
        fbX = Config::sys.ratioVFB*view->x();
        fbY = Config::sys.ratioVFB*view->y();
        fbW = Config::sys.ratioVFB*view->width();
        fbH = Config::sys.ratioVFB*view->height();

        if (info->x() == fbX &&
            info->y() == fbY &&
            info->width() == fbW &&
            info->height() == fbH &&
            grid->ifCrop() == false)
            continue;

        err = 0;
        if (info->width() != 0 && info->height() !=0 &&
            (fbW == 0 || fbH == 0))
        {
            if (grid->wndId > WindowId_Invalid)
            {
                if(grid->channelId > ChannelId_Invalid) // resize when there is video frame
                {
                    if (qt_rtk_disp_resize(head, i, chIdx, grid->wndId,
                                           fbX, fbY, fbW, fbH) == false)
                    {
                        err ++;
                    }
                }
                else
                {
                    err ++;
                }
                if (grid->status == GridReal::GridStatus_PLAY)
                {
#if SLOW_DOWN_OUTPUT_FRAME_RATE //[2018/07/04:Brian] DHC bug, does not output 1 frame per 1 sec
                    if(qt_rtk_disp_set_outputFrameRate(head, i, chIdx, grid->channelId, 1) == false)
                    {
                        err ++;
                    }
                    else
#endif
                    {
                        grid->status = GridReal::GridStatus_IPC_HIDE;
                    }
                }
            }
        }
        else if ((info->width() == 0 || info->height() ==0) &&
                 fbW != 0 && fbH != 0)
        {
            if (grid->wndId > WindowId_Invalid)
            {
                if(grid->channelId > ChannelId_Invalid) // resize when there is video frame
                {
                    if (qt_rtk_disp_resize(head, i, chIdx, grid->wndId,
                                           fbX, fbY, fbW, fbH) == false)
                    {
                        err ++;
                    }
                    if (grid->ifCrop())
                    {
                        if (qt_rtk_disp_crop(head, i, chIdx, grid->wndId,
                                             grid->crop_x(), grid->crop_y(),
                                             grid->crop_width(), grid->crop_height()))
                        {
                            grid->unmark_crop();
                        }
                    }
                }
                else
                {
                    err ++;
                }
                if (grid->status == GridReal::GridStatus_IPC_HIDE)
                {
#if SLOW_DOWN_OUTPUT_FRAME_RATE
                    if(qt_rtk_disp_set_outputFrameRate(head, i, chIdx, grid->channelId, 0) == false)
                    {
                        err ++;
                    }
                    else
#endif
                    {
                        grid->status = GridReal::GridStatus_PLAY;
                        change ++;
                    }
                }

                if(Config::sys.seamless &&
                   grid->status == GridReal::GridStatus_NONE)
                {
                    // do not blank
                }
                else if (grid->status == GridReal::GridStatus_NONE)
                {
                }
                else
                {
                    listIdx.append(i);
                    listChIdx.append(chIdx);
                    listWndId.append(grid->wndId);
                }
            }
        }
        else
        {
            if (grid->wndId > WindowId_Invalid)
            {
                if(grid->channelId > ChannelId_Invalid) // resize when there is video frame
                {
                    if (qt_rtk_disp_resize(head, i, chIdx, grid->wndId,
                                           fbX, fbY, fbW, fbH) == false)
                    {
                        err ++;
                    }
                    if (grid->ifCrop())
                    {
                        if (qt_rtk_disp_crop(head, i, chIdx, grid->wndId,
                                             grid->crop_x(), grid->crop_y(),
                                             grid->crop_width(), grid->crop_height()))
                        {
                            grid->unmark_crop();
                        }
                    }
                }
                else
                {
                    err ++;
                }

                if(Config::sys.seamless &&
                   grid->status == GridReal::GridStatus_NONE)
                {
                    // do not blank
                }
                else if (grid->status == GridReal::GridStatus_NONE)
                {
                }
                else
                {
                    listIdx.append(i);
                    listChIdx.append(chIdx);
                    listWndId.append(grid->wndId);
                }
            }
        }
        if (err <= 0)
        {
            info->setGridInfo(fbX, fbY, fbW, fbH, view->borderSize(), view->isVisible());
        }
    }
    if (listIdx.count() > 0)
    {
        qt_rtk_disp_set_blank(head, &listIdx, &listChIdx, false, &listWndId);
    }
    if (change > 0)
    {
        this->msleep(Config::sys.setBlankTime);
    }
    return true;
}

bool RtkApi::apply_view_file()
{
//    if(DBG(_DBG_RTKAPI_))
//        qDebug() << __func__;
    QString head = STR_FILE;
    int i, chIdx, change, err;
    GridReal *grid;
    GridInfo *info, *view;
    QList<int> listIdx, listChIdx;
    QList<WindowId> listWndId;
    int osdX, osdY, osdW, osdH;
    int fbX, fbY, fbW, fbH;

    // update widget & border first
    for (i=0; i<CHANNEL_MAX; i++)
    {
        grid = &viewProcess->file_gridReal[i];
        view = viewProcess->view_file.gridInfoList->at(i);
        osdX = Config::sys.ratioOSD*view->x();
        osdY = Config::sys.ratioOSD*view->y();
        osdW = Config::sys.ratioOSD*view->width();
        osdH = Config::sys.ratioOSD*view->height();
        if (viewProcess->bUpdateFileFrame)
        {
            viewProcess->update_file_frame(i);
        }
        RFrame *frame = playback->fileFrame[i];
        if (frame->x() == osdX &&
            frame->y() == osdY &&
            frame->width() == osdW &&
            frame->height() == osdH)
            continue;
        if(DBG(_DBG_RTKAPI_))
            qDebug() << head << i
                     << QString("frame->prepareGeometry(%1, %2, %3, %4)")
                        .arg(osdX).arg(osdY).arg(osdW).arg(osdH);
        frame->prepareGeometry(osdX, osdY, osdW, osdH);
        // info->copy(view); /* update later */
    }
    viewProcess->bUpdateFileFrame = false;

    // set blank first for changed grid
    change = 0;
    for (i=0; i<CHANNEL_MAX; i++)
    {
        grid = &viewProcess->file_gridReal[i];
        chIdx = grid->channelIndex;
        info = &grid->infoCurr;
        view = viewProcess->view_file.gridInfoList->at(i);
        fbX = Config::sys.ratioVFB*view->x();
        fbY = Config::sys.ratioVFB*view->y();
        fbW = Config::sys.ratioVFB*view->width();
        fbH = Config::sys.ratioVFB*view->height();
        if (grid->wndId <= WindowId_Invalid)
            continue;
        if (info->x() == fbX &&
            info->y() == fbY &&
            info->width() == fbW &&
            info->height() == fbH)
            continue;

        if(Config::sys.seamless &&
           grid->status == GridReal::GridStatus_NONE)
        {
            // do not blank
        }
        else if (grid->status == GridReal::GridStatus_NONE)
        {
        }
        else
        {
            listIdx.append(i);
            listChIdx.append(chIdx);
            listWndId.append(grid->wndId);
        }
    }
    if (listIdx.count() > 0)
    {
        if (qt_rtk_disp_set_blank(head, &listIdx, &listChIdx, true, &listWndId))
        {
            this->msleep(Config::sys.setBlankTime);
        }
    }

    // resize
    change = 0;
    listIdx.clear();
    listChIdx.clear();
    listWndId.clear();
    for (i=0; i<CHANNEL_MAX; i++)
    {
        grid = &viewProcess->file_gridReal[i];
        info = &grid->infoCurr;
        view = viewProcess->view_file.gridInfoList->at(i);
        fbX = Config::sys.ratioVFB*view->x();
        fbY = Config::sys.ratioVFB*view->y();
        fbW = Config::sys.ratioVFB*view->width();
        fbH = Config::sys.ratioVFB*view->height();

        if (info->x() == fbX &&
            info->y() == fbY &&
            info->width() == fbW &&
            info->height() == fbH &&
            grid->ifCrop() == false)
            continue;

        err = 0;
        if (info->width() != 0 && info->height() != 0 &&
            (fbW == 0 || fbH == 0))
        {
            if (grid->wndId > WindowId_Invalid)
            {
                if(grid->channelId > ChannelId_Invalid) // resize when there is video frame
                {
                    if (qt_rtk_disp_resize(head, i, chIdx, grid->wndId,
                                           fbX, fbY, fbW, fbH) == false)
                    {
                        err ++;
                    }
                }
                else
                {
                    err ++;
                }
                if (grid->status == GridReal::GridStatus_PLAY)
                {
//                    if(qt_rtk_disp_set_outputFrameRate(head, i, grid->channelId, 1) == false) //bug:NAS-275
                    if (qt_rtk_player_set_play(head, i, chIdx, CH_STATE_PAUSE, grid->channelId) == false)
                    {
                        err ++;
                    }
                    else
                    {
                        grid->status = GridReal::GridStatus_FILE_PAUSE;
                    }
                }
            }
        }
        else if ((info->width() == 0 || info->height() == 0) &&
                 fbW != 0 && fbH != 0)
        {
            if (grid->wndId > WindowId_Invalid)
            {
                if(grid->channelId > ChannelId_Invalid) // resize when there is video frame
                {
                    if (qt_rtk_disp_resize(head, i, chIdx, grid->wndId,
                                           fbX, fbY, fbW, fbH) == false)
                    {
                        err ++;
                    }
                    if (grid->ifCrop())
                    {
                        if (qt_rtk_disp_crop(head, i, chIdx, grid->wndId,
                                             grid->crop_x(), grid->crop_y(),
                                             grid->crop_width(), grid->crop_height()))
                        {
                            grid->unmark_crop();
                        }
                    }
                }
                else
                {
                    err ++;
                }
                if (grid->status == GridReal::GridStatus_FILE_PAUSE)
                {
//                    if(qt_rtk_disp_set_outputFrameRate(head, i, grid->channelId, 0) == false) //bug:NAS-275
                    if (qt_rtk_player_set_play(head, i, chIdx, CH_STATE_PLAY, grid->channelId) == false)
                    {
                        err ++;
                    }
                    else
                    {
                        grid->status = GridReal::GridStatus_PLAY;
                        change ++;
                    }
                }
                if(Config::sys.seamless &&
                   grid->status == GridReal::GridStatus_NONE)
                {
                    // do not blank
                }
                else if (grid->status == GridReal::GridStatus_NONE)
                {
                }
                else
                {
                    listIdx.append(i);
                    listChIdx.append(chIdx);
                    listWndId.append(grid->wndId);
                }
            }
        }
        else
        {
            if (grid->wndId > WindowId_Invalid)
            {
                if(grid->channelId > ChannelId_Invalid) // resize when there is video frame
                {
                    if (qt_rtk_disp_resize(head, i, chIdx, grid->wndId,
                                           fbX, fbY, fbW, fbH) == false)
                    {
                        err ++;
                    }
                    if (grid->ifCrop())
                    {
                        if (qt_rtk_disp_crop(head, i, chIdx, grid->wndId,
                                             grid->crop_x(), grid->crop_y(),
                                             grid->crop_width(), grid->crop_height()))
                        {
                            grid->unmark_crop();
                        }
                    }
                }
                else
                {
                    err ++;
                }
                if(Config::sys.seamless &&
                   grid->status == GridReal::GridStatus_NONE)
                {
                    // do not blank
                }
                else if (grid->status == GridReal::GridStatus_NONE)
                {
                }
                else
                {
                    listIdx.append(i);
                    listChIdx.append(chIdx);
                    listWndId.append(grid->wndId);
                }
            }
        }
        if (listIdx.count() > 0)
        {
            qt_rtk_disp_set_blank(head, &listIdx, &listChIdx, false, &listWndId);
        }
        if (err <= 0)
        {
            info->setGridInfo(fbX, fbY, fbW, fbH, view->borderSize(), view->isVisible());
        }
    }
    if (change > 0)
    {
        this->msleep(Config::sys.setBlankTime);
    }
    return true;
}

bool RtkApi::ipcStart(int idx)
{
    if(DBG(_DBG_RTKAPI_))
        qDebug() << idx << __func__;
    QString head = STR_IPC;
    WindowId        wndId;
    ChannelId       channelId;
#if RTSP_AV
    RtspClientId    cid;
#elif RTSP_GST
    RtspPlayer      *rtspPlayer;
#endif
    bool            needBind = false;

    GridReal *grid = &(viewProcess->ipc_gridReal[idx]);
    GridInfo *view = viewProcess->view_ipc.gridInfoList->at(idx);
    int chIdx = grid->channelIndex;

    if (grid->wndId <= WindowId_Invalid)
    {
        int fbX = Config::sys.ratioVFB*view->x();
        int fbY = Config::sys.ratioVFB*view->y();
        int fbW = Config::sys.ratioVFB*view->width();
        int fbH = Config::sys.ratioVFB*view->height();
        wndId = qt_rtk_disp_create(head, idx, chIdx,
                                   fbX, fbY, fbW, fbH, INPUT_STREAM_LIVE);
        if (wndId <= WindowId_Invalid)
        {
            return false;
        }
        else
        {
            grid->wndId = wndId;
            grid->infoCurr.setGridInfo(fbX, fbY, fbW, fbH, view->borderSize(), view->isVisible());
        }
        needBind = true;
    }
    if (grid->channelId <= ChannelId_Invalid)
    {
        channelId = qt_rtk_dec_add_channel_video(head, idx, chIdx);
        if (channelId <= ChannelId_Invalid)
        {
            return false;
        }
        else
        {
            grid->channelId = channelId;
        }
        needBind = true;
    }
    if (needBind || grid->needBind)
    {
        int codec = opt_StrToVal(optVideoCodec, Config::ipc.ch[idx].codec);
        if(codec == (int)OPT_ERROR)
        {
            return false;
        }
        if(qt_rtk_dec_set_channel_video(head, idx, chIdx, grid->channelId,
                                        (VideoCodec_e)codec) != true)
        {
            return false;
        }
        grid->needBind = (qt_rtk_dec_bind(head, idx, chIdx, grid->channelId, grid->wndId) == false);
        if (grid->needBind)
        {
            return false;
        }
    }
#if RTSP_AV
    if (grid->cid <= ClientId_Invalid)
    {
        cid = qt_rtk_rtsp_av_client_new(head, idx, chIdx, grid->rtspCmd);
        if (cid <= ClientId_Invalid)
        {
            return false;
        }
        else
        {
            grid->cid = cid;

            int fbX = Config::sys.ratioVFB*view->x();
            int fbY = Config::sys.ratioVFB*view->y();
            int fbW = Config::sys.ratioVFB*view->width();
            int fbH = Config::sys.ratioVFB*view->height();
            qt_rtk_rtsp_av_rec_set_info(head, idx, chIdx,
                                     grid->cid, grid->channelId, ChannelId_Invalid,
                                     fbX, fbY, fbW, fbH);
//            qt_rtsp_client_set_latency(head, idx, chIdx, grid->rtspPlayer->client, Config::sys.setRtspLatency);
// TBD
        }
    }
#elif RTSP_GST
    if (grid->rtspPlayer == NULL)
    {
        rtspPlayer = qt_rtsp_player_new(head, idx, chIdx, grid->rtspCmd, grid->channelId);
        if (rtspPlayer == NULL)
        {
            return false;
        }
        else
        {
            grid->rtspPlayer = rtspPlayer;
            qt_rtsp_client_set_latency(head, idx, chIdx, grid->rtspPlayer->client, Config::sys.setRtspLatency);
        }
    }
#endif

    /* Start to play */
    qt_rtk_dec_set_play(head, idx, chIdx, CH_STATE_PLAY, grid->channelId);

    /*
    qt_rtk_disp_set_blank(head, i, chIdx, false, grid->wndId);
    */
    return true;
}

bool RtkApi::ipcStop(int idx, bool bSeamless)
{
    QString head = STR_IPC;
    GridReal *grid = &(viewProcess->ipc_gridReal[idx]);
    int chIdx = grid->channelIndex;

    if(chIdx < 0 || chIdx >= CHANNEL_MAX)
        return false;
    if(DBG(_DBG_RTKAPI_))
        qDebug() << idx << __func__;

    if (grid->wndId > WindowId_Invalid)
    {
        if(bSeamless == false)
        {
            qt_rtk_disp_set_blank(head, idx, chIdx, true, grid->wndId);
            this->msleep(Config::sys.setBlankTime);

            qt_rtk_disp_destroy(head, idx, chIdx, grid->wndId);
            grid->wndId = WindowId_Invalid;
            grid->needBind = true;
        }
        else
        {
            qt_rtk_disp_set_freeze(head, idx, chIdx, true, grid->wndId);
        }
    }
#if RTSP_AV
    if (grid->cid > ClientId_Invalid)
    {
        /* stop playing */
        qt_rtk_rtsp_av_player_stop (head, idx, chIdx, grid->cid);

        /* free */
        qt_rtk_rtsp_av_client_free (head, idx, chIdx, grid->cid);
        grid->cid = ClientId_Invalid;
    }
#elif RTSP_GST
    if (grid->rtspPlayer != NULL)
    {
        /* stop playing */
        qt_rtsp_player_stop (head, idx, chIdx, grid->rtspPlayer);

        /* free */
        qt_rtsp_player_free (head, idx, chIdx, grid->rtspPlayer);
        grid->rtspPlayer = NULL;
    }
#endif
    if (grid->channelId > ChannelId_Invalid)
    {
        /* stop playing & remove channel */
        qt_rtk_dec_set_play(head, idx, chIdx, CH_STATE_STOP, grid->channelId);
        qt_rtk_dec_remove_channel(head, idx, chIdx, grid->channelId);
        grid->channelId = ChannelId_Invalid;
        grid->needBind = true;
    }
    return true;
}

void RtkApi::ipcPlayStart(int idx)
{
    QString head = STR_IPC;
    GridReal *grid = &(viewProcess->ipc_gridReal[idx]);
    int chIdx = grid->channelIndex;
#if RTSP_AV
    qt_rtk_rtsp_av_player_play(head, idx, chIdx, grid->cid, grid->channelId, ChannelId_Invalid);
#elif RTSP_GST
    int codec = opt_StrToVal(optVideoCodec, Config::ipc.ch[chIdx].codec);
    if(codec == (int)OPT_ERROR)
    {
        return ;
    }
    Stream stream;
    switch(codec)
    {
    case VIDEO_H264:        stream = ES_H264;       break;
    case VIDEO_H265:        stream = ES_H265;       break;
    case VIDEO_MJPEG:       stream = MUX_MPEGTS;    break;
    case VIDEO_MPEG4:       stream = MUX_MPEGTS;    break;
    default:                stream = ES_H264;       break;
    }
    qt_rtsp_player_set_stream(head, idx, chIdx, grid->rtspPlayer, stream);
    qt_rtsp_player_play(head, idx, chIdx, grid->rtspPlayer);
#endif
}

void RtkApi::ipcRecStart(int idx, QString absDirPath, uint duration)
{
    GridReal *grid = &(viewProcess->ipc_gridReal[idx]);
    int chIdx = grid->channelIndex;
#if RTSP_AV
    qt_rtk_rtsp_av_rec_start(STR_IPC, idx, chIdx, grid->cid, absDirPath, duration);
#elif RTSP_GST
    qt_rtsp_player_rec_start(STR_IPC, idx, chIdx, grid->rtspPlayer, absDirPath, duration);
#endif
}

void RtkApi::ipcRecChange(int idx, QString absDirPath, uint duration)
{
    GridReal *grid = &(viewProcess->ipc_gridReal[idx]);
    int chIdx = grid->channelIndex;
#if RTSP_AV
    qt_rtk_rtsp_av_rec_change(STR_IPC, idx, chIdx, grid->cid, absDirPath, duration);
#elif RTSP_GST
    qt_rtsp_player_rec_change(STR_IPC, idx, chIdx, grid->rtspPlayer, absDirPath, duration);
#endif
}

void RtkApi::ipcRecStop(int idx)
{
    GridReal *grid = &(viewProcess->ipc_gridReal[idx]);
    int chIdx = grid->channelIndex;
#if RTSP_AV
    qt_rtk_rtsp_av_rec_stop(STR_IPC, idx, chIdx, grid->cid);
#elif RTSP_GST
    qt_rtsp_player_rec_stop(STR_IPC, idx, chIdx, grid->rtspPlayer);
#endif
}

bool RtkApi::fileStart(int idx, QString absFilePath)
{
    if(DBG(_DBG_RTKAPI_))
        qDebug() << idx << __func__;
    QString head = STR_FILE;
    WindowId        wndId;
    ChannelId       channelId;
    bool            needBind = false;

    GridReal *grid = &(viewProcess->file_gridReal[idx]);
    int chIdx = grid->channelIndex;
    GridInfo *view = viewProcess->view_file.gridInfoList->at(idx);

    int fbX = Config::sys.ratioVFB*view->x();
    int fbY = Config::sys.ratioVFB*view->y();
    int fbW = Config::sys.ratioVFB*view->width();
    int fbH = Config::sys.ratioVFB*view->height();
    if (grid->wndId <= WindowId_Invalid)
    {
        // input type: INPUT_STREAM_FILE, not INPUT_STREAM_LIVE
        wndId = qt_rtk_disp_create(head, idx, chIdx,
                                   fbX, fbY, fbW, fbH, INPUT_STREAM_FILE);
        if (wndId <= WindowId_Invalid)
        {
            return false;
        }
        else
        {
            grid->wndId = wndId;
            grid->infoCurr.setGridInfo(fbX, fbY, fbW, fbH, view->borderSize(), view->isVisible());
        }
        needBind = true;
    }
    if (grid->channelId <= ChannelId_Invalid)
    {
        channelId = qt_rtk_player_add_channel_av(head, idx, chIdx);
        if (channelId <= ChannelId_Invalid)
        {
            return false;
        }
        else
        {
            grid->channelId = channelId;
        }
        needBind = true;
    }
    if (needBind || grid->needBind)
    {
#if 0
        grid->needBind = (qt_rtk_player_bind(head, idx, chIdx, grid->channelId, grid->wndId) == false);
#else
        grid->needBind = (qt_rtk_player_bind(head, idx, chIdx, grid->channelId, grid->wndId,
                                            fbX, fbY, fbW, fbH) == false);
#endif
        if (grid->needBind)
        {
            return false;
        }
    }
    if (grid->absFilePath != absFilePath &&
        grid->bAlreadyFilePlay)
    {
        /* stop playing */
        qt_rtk_player_set_play(head, idx, chIdx, CH_STATE_STOP, grid->channelId);
        grid->absFilePath = AbsFilePath_NULL;
        grid->bAlreadyFilePlay = false;
    }
    if (grid->bAlreadyFilePlay == false)
    {
        grid->absFilePath = AbsFilePath_NULL;
        if (qt_rtk_player_open(head, idx, chIdx, grid->channelId, absFilePath) == false)
        {
            return false;
        }
        else
        {
            grid->absFilePath = absFilePath;
            grid->bAlreadyFilePlay = true;
        }
    }

    /* Start to play */
    qt_rtk_player_set_play(head, idx, chIdx, CH_STATE_PLAY, grid->channelId);

    /* Start play audio */
    /* no matter success or failed for there may be no voice stream in the file */
    qt_rtk_player_start_audio(head, idx, chIdx, grid->channelId);

    /*
    bool enable = false;
    if(qt_rtk_disp_get_blank(head, idx, chIdx, grid->wndId, &enable) != true)
    {
        enable = true;
    }
    if(enable)
    {
        qt_rtk_disp_set_blank(head, idx, chIdx, false, grid->wndId);
    }
    */

    return true;
}

bool RtkApi::fileStop(int idx, bool bSeamless)
{
    QString head = STR_FILE;
    GridReal *grid = &(viewProcess->file_gridReal[idx]);
    int chIdx = grid->channelIndex;

    if(chIdx < 0 || chIdx >= CHANNEL_MAX)
        return false;
    if(DBG(_DBG_RTKAPI_))
        qDebug() << idx << __func__;

    /*
    if (grid->wndId > WindowId_Invalid)
    {
        if(grid->bNeedStart != true)
        {
            qt_rtk_disp_set_blank(head, idx, chIdx, true, grid->wndId);
            this->msleep(Config::sys.setBlankTime);
        }
    }
    */
    if(bSeamless == true)
    {
        qt_rtk_disp_set_freeze(head, idx, chIdx, true, grid->wndId);
    }

    if (grid->channelId > ChannelId_Invalid)
    {
        /* Stop play audio */
        // [20180808:Brian] Fix bug NAS-442
        // no matter success or failed for there may be no audio stream in the file
        qt_rtk_player_stop_audio(head, idx, chIdx, grid->channelId);

        /* stop playing */
        qt_rtk_player_set_play(head, idx, chIdx, CH_STATE_STOP, grid->channelId);
    }

    if(bSeamless == false)
    {
        if (grid->wndId > WindowId_Invalid)
        {
            qt_rtk_disp_destroy(head, idx, chIdx, grid->wndId);
            grid->wndId = WindowId_Invalid;
            grid->needBind = true;
        }
    }
    if (grid->channelId > ChannelId_Invalid)
    {
        grid->bAlreadyFilePlay = false;
        grid->absFilePath = AbsFilePath_NULL;

        /* remove channel */
        qt_rtk_player_remove_channel(head, idx, chIdx, grid->channelId);

        grid->channelId = ChannelId_Invalid;
        grid->needBind = true;
    }
    return true;
}

bool RtkApi::ipcSwapWndId(int idx_a, int idx_b)
{
    QString head = STR_IPC;
    GridReal *grid_a = &(viewProcess->ipc_gridReal[idx_a]);
    GridReal *grid_b = &(viewProcess->ipc_gridReal[idx_b]);
    return qt_rtk_disp_swap(head, idx_a, idx_b, grid_a->wndId, grid_b->wndId);
}

bool RtkApi::fileSwapWndId(int idx_a, int idx_b)
{
    QString head = STR_FILE;
    GridReal *grid_a = &(viewProcess->file_gridReal[idx_a]);
    GridReal *grid_b = &(viewProcess->file_gridReal[idx_b]);
    return qt_rtk_disp_swap(head, idx_a, idx_b, grid_a->wndId, grid_b->wndId);
}

bool RtkApi::ipcGetSourceRect(int idx, QRect *rect)
{
    GridReal *grid = &(viewProcess->ipc_gridReal[idx]);
    int chIdx = grid->channelIndex;
    return getSourceRect(STR_IPC, idx, chIdx, grid->wndId, rect);
}

bool RtkApi::fileGetSourceRect(int idx, QRect *rect)
{
    GridReal *grid = &(viewProcess->file_gridReal[idx]);
    int chIdx = grid->channelIndex;
    return getSourceRect(STR_FILE, idx, chIdx, grid->wndId, rect);
}

bool RtkApi::getSourceRect(QString head, int idx, int chIdx, int wndId, QRect *rect)
{
    if(DBG(_DBG_RTKAPI_))
        qDebug() << head << idx << __func__;
    int rtkReturn;
    Resolution_t res;

    rtkReturn = rtk_disp_get_srcSize (wndId, &res);
    if (rtkReturn < RTK_SUCCESS)
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_disp_get_srcSize()%1").arg(dbgStrRtkReturn(rtkReturn));
        return false;
    }
    else
    {
        if(DBG(_DBG_RTKAPI_))
            qDebug() << head << idx << chIdx
                     << QString("rtk_disp_get_srcSize() => w=%1, h=%2").arg(res.width).arg(res.height);
    }
    rect->setX(0);
    rect->setY(0);
    rect->setWidth(res.width);
    rect->setHeight(res.height);
    return true;
}

bool RtkApi::ipcGetSnapshot(int idx, QPixmap *pixmap)
{
    GridReal *grid = &(viewProcess->ipc_gridReal[idx]);
    int chIdx = grid->channelIndex;
    if(Config::sys.seamless &&
       grid->wndId > WindowId_Invalid &&
       grid->channelId <= ChannelId_Invalid)    // [20180809:Brian] Fix bug NAS-449
    {
        qDebug() << STR_IPC << idx << chIdx << __func__
                 << QString("wndId=%1, chId=%2, seamless=%3 fail")
                            .arg(grid->wndId).arg(grid->channelId)
                            .arg(Config::sys.seamless);
        return false;
    }
    return getSnapshot(STR_IPC, idx, chIdx,
                       grid->infoCurr.width(),
                       grid->infoCurr.height(),
                       grid->wndId,
                       pixmap);
}

bool RtkApi::fileGetSnapshot(int idx, QPixmap *pixmap)
{
    GridReal *grid = &(viewProcess->file_gridReal[idx]);
    int chIdx = grid->channelIndex;
    if(Config::sys.seamless &&
       grid->wndId > WindowId_Invalid &&
       grid->channelId <= ChannelId_Invalid)    // [20180809:Brian] Fix bug NAS-449
    {
        qDebug() << STR_FILE << idx << chIdx << __func__
                 << QString("wndId=%1, chId=%2, seamless=%3 fail")
                            .arg(grid->wndId).arg(grid->channelId)
                            .arg(Config::sys.seamless);
        return false;
    }
    return getSnapshot(STR_FILE, idx, chIdx,
                       grid->infoCurr.width(),
                       grid->infoCurr.height(),
                       grid->wndId,
                       pixmap);
}

bool RtkApi::getSnapshot(QString head, int idx, int chIdx, int widthFB, int heightFB, int wndId, QPixmap *pixmapOSD)
{
    SnapshotBuffer_t bufSnapshot;

    int rtkReturn;
    uchar *data = 0;

    if (wndId <= WindowId_Invalid ||
        widthFB <= 0 || heightFB <= 0)
    {
        qDebug() << head << idx << chIdx << __func__
                 << QString("wndId=%1, w=%2, h=%3, pixmap.w=%4, pixmap.h=%5, fail")
                            .arg(wndId).arg(widthFB).arg(heightFB)
                            .arg(pixmapOSD->width()).arg(pixmapOSD->height());
        return false;
    }

    bufSnapshot.ionBufVirt = 0;
    rtkReturn = rtk_get_window_image(wndId, &bufSnapshot);
    if (rtkReturn < RTK_SUCCESS)
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_get_window_image() wndId=%1%2").arg(wndId).arg(dbgStrRtkReturn(rtkReturn));
        return false;
    }
    else
    {
        if (bufSnapshot.width != (unsigned int)widthFB ||
            bufSnapshot.height != (unsigned int)heightFB ||
            ((unsigned int)(widthFB * heightFB * 4) > bufSnapshot.size))
            // the true size may bigger than width*height*4 for alignment
        {
            qDebug() << head << idx << chIdx
                     << QString().asprintf("rtk_get_window_image() wndId=%d, "
                                          "wFB %d <=> buf.w %d, "
                                          "hFB %d <=> buf.h %d, "
                                          "size=%d <=> buf.size=%d, "
                                          "fail",
                                            wndId,
                                            widthFB, bufSnapshot.width,
                                            heightFB, bufSnapshot.height,
                                            widthFB*heightFB*4, bufSnapshot.size);
            rtkReturn = rtk_free_window_image(bufSnapshot);
            return false;
        }
        else
        {
            if(DBG(_DBG_RTKAPI_))
                qDebug() << head << idx << chIdx
                         << QString().asprintf("rtk_get_window_image() wndId=%d, wOSD=%d, hOSD=%d, wFB=%d, hFB=%d, size=%d, data_ptr=%p",
                                              wndId,
                                              pixmapOSD->width(),
                                              pixmapOSD->height(),
                                              bufSnapshot.width,
                                              bufSnapshot.height,
                                              bufSnapshot.size,
                                              bufSnapshot.ionBufVirt);
        }
    }

    data = bufSnapshot.ionBufVirt;
    if(pixmapOSD->width() == widthFB &&
       pixmapOSD->height() == heightFB)
    {
        QImage imageOSD = pixmapOSD->toImage();
        copySnapshot(true, widthFB, heightFB, &imageOSD, data);
        *pixmapOSD = pixmapOSD->fromImage(imageOSD);
    }
    else // need resize
    {
        QImage imageOSD = pixmapOSD->toImage();
#if 0   //[2018/07/04:Brian] Fix bug NAS-404
        int bgColorR = (int)Config::setting.bgColorR;
        int bgColorG = (int)Config::setting.bgColorG;
        int bgColorB = (int)Config::setting.bgColorB;
#else
        int bgColorR = 0x00;
        int bgColorG = 0x00;
        int bgColorB = 0x00;
#endif
        int r, g, b, a;
        QColor color;
        QRgb argb;
        QImage imageFB = QImage(widthFB, heightFB, QImage::Format_ARGB32);
        copySnapshot(false, widthFB, heightFB, &imageFB, data);
        QImage imageScaled = imageFB.scaled(pixmapOSD->width(), pixmapOSD->height());
        for(int x=0; x<pixmapOSD->width(); x++)
        {
            for(int y=0; y<pixmapOSD->height(); y++)
            {
                color = QColor(imageOSD.pixel(x, y));
                if (color.red() != bgColorR ||
                    color.green() != bgColorG ||
                    color.blue() != bgColorB)
                {
                    r = color.red();
                    g = color.green();
                    b = color.blue();
                    a = 0x00FF;
                    argb = qRgba((int)r,  //red
                                 (int)g,  //green
                                 (int)b,  //blue
                                 (int)a); //alpha
                    imageScaled.setPixel (x, y, argb);
                }
            }
        }
        *pixmapOSD = pixmapOSD->fromImage(imageScaled);
    }

    rtkReturn = rtk_free_window_image(bufSnapshot);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx
                 << QString("rtk_free_window_image()%1").arg(dbgStrRtkReturn(rtkReturn));
    }
    return true;
}

void RtkApi::copySnapshot(bool keepOSD, int width, int height, QImage *image, uchar *data)
{
#if 0   //[2018/07/04:Brian] Fix bug NAS-404
    int bgColorR = (int)Config::setting.bgColorR;
    int bgColorG = (int)Config::setting.bgColorG;
    int bgColorB = (int)Config::setting.bgColorB;
#else
    int bgColorR = 0x00;
    int bgColorG = 0x00;
    int bgColorB = 0x00;
#endif
    int r, g, b, a;
    QColor color;
    QRgb argb;
#if 1
    for (int y=0; y<height; y++)
    {
        for (int x=0; x<width; x++)
        {
            color = QColor(image->pixel(x, y));
            if (keepOSD &&
                (color.red() != bgColorR ||
                 color.green() != bgColorG ||
                 color.blue() != bgColorB))
            {
                r = color.red();
                g = color.green();
                b = color.blue();
                a = 0x00FF;
            }
            else
            {
                int index = (y*width+x)*4;
                r = (int)*(data+index+2);
                g = (int)*(data+index+1);
                b = (int)*(data+index+0);
                a = (int)*(data+index+3);
//                if (x == y)
//                {
//                    qDebug() << QString().sprintf("x=%d, y=%d, idx:%d => addr:%p, r=%d, g=%d, b=%d, a=%d",
//                                                  x, y, index, (data+index),
//                                                  r, g, b, a);
//                }

            }
            argb = qRgba((int)r,  //red
                         (int)g,  //green
                         (int)b,  //blue
                         (int)a); //alpha
            image->setPixel (x, y, argb);
        }
    }
#else
    qDebug() << __func__ << "create image";
    int bytes_per_line = width * 4;
    image = new QImage((uchar *)data, width, height, bytes_per_line,
                        QImage::Format_ARGB32, NULL);
#endif
}

bool RtkApi::fileGetPlayTime(int idx, uint64_t *pCurrent)
{
    QString head = STR_FILE;
#if 0
    int rtkReturn;
#endif
    GridReal *grid = &(viewProcess->file_gridReal[idx]);
    int chIdx = grid->channelIndex;
    if (pCurrent == NULL ||
        grid->channelId == ChannelId_Invalid ||
        (grid->status != GridReal::GridStatus_FILE_PAUSE &&
         grid->status != GridReal::GridStatus_PLAY))
    {
        qDebug() << head << idx << chIdx << __func__ << "status fail";
        return false;
    }

#if 0
    rtkReturn = rtk_player_query_time(grid->channelId, pCurrent);
    if (rtkReturn < RTK_SUCCESS)
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_query_time() channelId=%1%2")
                    .arg(grid->channelId).arg(dbgStrRtkReturn(rtkReturn));
    }
    else
    {
        if (DBG(_DBG_RTKAPI_))
            qDebug() << head << idx << chIdx
                     << QString().sprintf("rtk_player_query_time() channelId=%d, current=%lld",
                                        grid->channelId, *pCurrent);
    }
    return (rtkReturn >= RTK_SUCCESS);
#else
    return false;
#endif
}

bool RtkApi::fileSetPlayTime(int idx, int time)
{
#if RTSP_GST
    QString head = STR_FILE;
    GridReal *grid = &(viewProcess->file_gridReal[idx]);
    int chIdx = grid->channelIndex;
    int rtkReturn;

    if (grid->channelId == ChannelId_Invalid ||
        (grid->status != GridReal::GridStatus_FILE_PAUSE &&
         grid->status != GridReal::GridStatus_PLAY))
    {
        qDebug() << head << idx << chIdx << __func__ << "status fail";
        return false;
    }
    rtkReturn = rtk_player_seek(grid->channelId, time);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_seek() time=%1 secs %2")
                    .arg(time).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn >= RTK_SUCCESS);
#else
    return true;
#endif
}

bool RtkApi::fileSetSpeed(int idx, double speed)
{
#if RTSP_GST
    QString head = STR_FILE;
    GridReal *grid = &(viewProcess->file_gridReal[idx]);
    int chIdx = grid->channelIndex;
    int rtkReturn;

    if (grid->channelId == ChannelId_Invalid ||
        (grid->status != GridReal::GridStatus_FILE_PAUSE &&
         grid->status != GridReal::GridStatus_PLAY))
    {
        qDebug() << head << idx << chIdx << __func__ << "status fail";
        return false;
    }
    rtkReturn = rtk_player_set_speed(grid->channelId, speed);
    if (rtkReturn < RTK_SUCCESS || DBG(_DBG_RTKAPI_))
    {
        qDebug() << head << idx << chIdx
                 << QString("rtk_player_set_speed() speed=%1%2")
                   .arg(speed).arg(dbgStrRtkReturn(rtkReturn));
    }
    return (rtkReturn >= RTK_SUCCESS);
#else
    return true;
#endif
}
