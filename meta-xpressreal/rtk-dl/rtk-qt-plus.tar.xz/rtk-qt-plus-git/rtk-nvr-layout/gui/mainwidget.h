/**
 * @file mainwidget.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The main background widget page of GUI
 */

#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QComboBox>
#include "define.h"
#include "config.h"
#include "option.h"
#include "keypad.h"
#include "keyboard.h"
#include "rcheckbox.h"
#include "rframe.h"
#include "rdialog.h"
#include "mainlogin.h"
#include "mainmenu.h"
#include "ipcadd.h"
#include "playback.h"
#include "videodebug.h"
#include "facedetect.h"
#include "info.h"
#include "statistics.h"
#include "ipc.h"
#include "setting.h"
#include "storage.h"
#include "system.h"
#include "viewinfo.h"
#include "viewprocess.h"
#include "monitorprocess.h"
#include "hlsprocess.h"
#include "onvifprocess.h"
#include "rtkapi.h"

namespace Ui {
class MainWidget;
}

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    RFrame *ipcFrame[CHANNEL_MAX];
    QTimer *bootTimer;

    explicit MainWidget(QWidget *parent = 0);
    ~MainWidget();

    bool setup();
    void finalize();

private:
    Ui::MainWidget *ui;
    QList<QWidget *>widgetList;

    void showIdxWidgetOnly(QWidget *idxWidget);
    void setComponentStyleSheet();

private slots:
    void playback_selected(bool);
    void ctrl_selected(bool);
    void add_selected(bool);
    void setting_selected(bool);
    void info_selected(bool);
    void videoDebug_selected(bool);
    void power_selected(bool);
    void boot_applay();

protected:
    void mouseMoveEvent(QMouseEvent *);
    void mousePressEvent(QMouseEvent *);
    QWidget* getVisibleWidget(QMouseEvent *);
    QWidget* getClickedWidget(QMouseEvent *);
};

extern MainWidget *mainWidget;
extern MainMenu *mainMenu;
extern MainLogin *mainLogin;
extern IpcAdd *ipcAdd;
extern IpcConnect *ipcConnect;
extern IpcDetect *ipcDetect;
extern Playback *playback;
extern Setting *setting;
extern Ipc *ipc;
extern Storage *setStorage;
extern System *setSystem;
extern Info *info;
extern Alarm *infoAlarm;
extern Statistics *infoStatistics;
extern VideoDebug *videoDebug;
extern FaceDetect *faceDetect;
extern Keypad *keypad;
extern Keyboard *keyboard;
extern RDialog *dialog;

extern QList<QLabel*> *labelList;
extern QList<QLineEdit*> *editList;
extern QList<QLineEdit*> *readOnlyList;
extern QList<QComboBox*> *optionList;
extern QList<RCheckBox*> *checkList;
extern QList<QToolButton*> *actionList;
#endif // MAINWIDGET_H
