/**
 * @file rcalendarwidget.h
 * @author Realtek Semiconductor Corp.
 * @date Dec 2017
 * @brief The widget page of calendar operation
 */

#ifndef RCALENDARWIDGET_H
#define RCALENDARWIDGET_H

#include <QWidget>
#include <QList>
#include <QSpinBox>
#include <QToolButton>
#include <QDate>
#include "keypad.h"

namespace Ui {
class RCalendarWidget;
}

class RCalendarWidget : public QWidget
{
    Q_OBJECT

public:

    typedef struct
    {
        bool    bThisMonth;
        bool    bAlreadyRecData;
        int     day;
        QToolButton *btnDay;
    } BtnDayInfo;

    QSpinBox    *sbYear, *sbMonth;
    QString strSelectedColor;

    explicit RCalendarWidget(QWidget *parent = 0);
    ~RCalendarWidget();

    void initStyleSheet(bool ifAlwaysShow, bool ifCheckRecData);
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    bool getDate(int year, int month, int day, int *date); // 0:Sunday, 1:Mon. to 6:Sat.
    void selectCurrentDate();
    QDate getDateSelected();
    QDate getMonthShow();
    QString strDateSelected(bool ifWeek);
    int yearSelected();
    int monthSelected();
    int daySelected();
    bool regetCalendar();

private:
    Ui::RCalendarWidget *ui;
    QList<BtnDayInfo *> _btnDayInfoList;
    QDate dateMax, dateMin, dateSelect, monthShow;
    QString strBackgroundColor;
    bool ifCheckRecData;

    void objCheckRange();
    void objYearSetRange();
    void objYearMonthSetConnect(bool);
    bool updateCalender(int year, int month);

protected:
    bool eventFilter(QObject *o, QEvent *e);
    void showEvent(QShowEvent *event);

signals:
    void closeClicked();
    void dayClicked();

private slots:
    void btnCloseClicked(bool);
    void objMonthPrev(bool);
    void objMonthNext(bool);
    void objYearMonthValueChanged();
    bool objYearMonthAdd(int addYears, int addMonths);
};

#endif // RCALENDARWIDGET_H
