/**
 * @file mainmenu.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page of GUI main menu after login
 */

#ifndef MAINMENU_H
#define MAINMENU_H

#include <QWidget>
#include "rtoolbutton.h"

namespace Ui {
class MainMenu;
}

class MainMenu : public QWidget
{
    Q_OBJECT

public:
    explicit MainMenu(QWidget *parent = 0);
    ~MainMenu();
    RToolButton *tbSlideshow;
    void setup();
    void setZoominOption(bool enable);

private:
    Ui::MainMenu *ui;

    void ipc_grid_selected(RToolButton *btn);
    void enableSlideshowOption(bool enable);
    void enableGridOption(bool enable);

private slots:
    void ipc_grid1_selected(bool);
    void ipc_grid4_selected(bool);
    void ipc_grid8_selected(bool);
    void ipc_grid9_selected(bool);
    void ipc_grid16_selected(bool);
    void ipc_grid32_selected(bool);
    void ipc_grid36_selected(bool);

protected:
    void showEvent(QShowEvent *);
};

#endif // MAINMENU_H
