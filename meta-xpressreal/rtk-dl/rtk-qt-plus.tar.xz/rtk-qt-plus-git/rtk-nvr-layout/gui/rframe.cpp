/**
 * @file rframe.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The frame for each IPC or playback per channel
 */

#include "rframe.h"
#include "mainwidget.h"
#define ZOOM_RATIO_DEF  1.0

RFrame::RFrame(QWidget *parent, bool enableZoomin, bool enableDrag,
               bool enableRec, bool enableSound, int id) :
    QFrame(parent)
{
    this->id = id;
    this->setMouseTracking(true);
    this->setAcceptDrops(true);

    tagCh = new QLabel(this);
    tagCh->setAlignment(Qt::AlignVCenter | Qt::AlignHCenter);

    tagZoom = new QLabel(this);
    tagZoom->setAlignment(Qt::AlignVCenter | Qt::AlignHCenter);
    showZoomText(false, ZOOM_RATIO_DEF);

    btnRec = new RToolButton(this);
    btnRec->setIcons(QIcon(":/images/record-off_normal.png"),
                     QIcon(":/images/record-off_hover.png"),
                     QIcon(":/images/record-on_normal.png"),
                     QIcon(":/images/record-on_hover.png"),
                     true);
    btnRec->setVisible(enableRec);
    connect(btnRec, SIGNAL(clicked(bool)), this, SLOT(rec_selected(bool)));

    btnSound = new RToolButton(this);
    btnSound->setIcons(QIcon(":/images/sound-off_normal.png"),
                     QIcon(":/images/sound-off_hover.png"),
                     QIcon(":/images/sound-on_normal.png"),
                     QIcon(":/images/sound-on_hover.png"),
                     true);
    btnSound->setVisible(enableSound);
    connect(btnSound, SIGNAL(clicked(bool)), this, SLOT(rec_selected(bool)));

#if QT_ENV_ONLY == 1
    r = g = b = 255;
    a = 0;
#endif
    borderSize = Config::style.ipcBorderSize;
    this->enableRec = enableRec;
    this->enableSound = enableSound;
    this->enableZoomin = enableZoomin;
    this->enableDrag = enableDrag;
    bDragProcess = false;
    currDragId = RFrame_Id_Invalid;
    gridReal = NULL;

    bUpdateComponent = false;
    bUpdateStyleSheet = false;
    bUpdateGeometry = false;

    zoomZone = new QFrame(this);
    zoomZone->setFrameShape(QFrame::Box);
    zoomZone->setFrameShadow(QFrame::Plain);
    zoomZone->setStyleSheet(QString("border:%1px solid %2;"
                                    "background-color: %3;")
                            .arg(Config::style.ipcBorderSize)
                            .arg(Config::style.borderZoomColor)
                            .arg(Config::style.maskZoomColor));
    zoomZone->setVisible(false);
}

RFrame::~RFrame()
{
    delete(zoomZone);
    delete(btnSound);
    delete(btnRec);
    delete(tagZoom);
    delete(tagCh);
}

void RFrame::setBorderSize(int size)
{
    this->borderSize = size;
}

#if QT_ENV_ONLY == 1
void RFrame::setBackground(int r, int g, int b, int a)
{
    this->r = r;
    this->g = g;
    this->b = b;
    this->a = a;
}
#endif

void RFrame::prepareUpdateComponent()
{
    mutex.lock();
    bUpdateComponent = true;
    mutex.unlock();
}

void RFrame::updateComponent()
{
    bool bVisible = (gridReal->channelIndex >= 0 &&
                     gridReal->channelIndex < Config::sys.ipcChannelMax);
    mutex.lock();
    setTagVisible(bVisible);
    setBtnRecVisible(enableRec & bVisible);
//    setBtnVoiceVisible(bVisible);
    bUpdateComponent = false;
    mutex.unlock();
}

void RFrame::prepareStyleSheet(QString appendStr)
{
//    qDebug() << __func__ << this->id;
    QString borderColor = (bDragProcess  && (currDragId != this->id)) ?
                            Config::style.borderDragColor : Config::style.borderColor;
    mutex.lock();
    bUpdateStyleSheet = true;
#if QT_ENV_ONLY == 1
    strStyleSheet =
                QString("border: %1px solid %2;"
                        "background-color: rgba(%3, %4, %5, %6);"
                        "%7")
                .arg(borderSize).arg(borderColor)
                .arg(r).arg(g).arg(b).arg(a)
                .arg(appendStr);
#else
    strStyleSheet =
                QString("border: %1px solid %2;"
                        "%3")
                .arg(borderSize).arg(borderColor)
                .arg(appendStr);
#endif
    mutex.unlock();
}

void RFrame::updateStyleSheet()
{
    if(!bUpdateStyleSheet)
        return;
//    qDebug() << __func__ << this->id << strStyleSheet;
    mutex.lock();
    this->setStyleSheet(strStyleSheet);
    bUpdateStyleSheet = false;
    mutex.unlock();
}

void RFrame::updateGeometry()
{
    if(!bUpdateGeometry)
        return;
//    qDebug() << __func__ << this->id;
    mutex.lock();
    this->setGeometry(geometry);
    bUpdateGeometry = false;
    mutex.unlock();
}

void RFrame::prepareGeometry(int x, int y, int w, int h)
{
    mutex.lock();
    bUpdateGeometry = true;
    geometry.setX(x);
    geometry.setY(y);
    geometry.setWidth(w);
    geometry.setHeight(h);
    mutex.unlock();
}

void RFrame::setGeometry(const QRect &rect)
{
    QFrame::setGeometry(rect);

    int tagChWidth, tagChHeight, tagFontSize;
    if(rect.width() >= Config::sys.width)
    {
        tagChWidth = 56;
        tagChHeight = 44;
        tagFontSize = 24;
    }
    else if(rect.width() >= 384)
    {
        tagChWidth = 40;
        tagChHeight = 32;
        tagFontSize = 16;
    }
    else
    {
        tagChWidth = 32;
        tagChHeight = 24;
        tagFontSize = 14;
    }
    tagCh->setGeometry(0, 0, tagChWidth, tagChHeight);
    tagZoom->setGeometry(0, 0, tagChWidth, tagChHeight);
    btnRec->setGeometry(0, 0, tagChHeight, tagChHeight);
    btnRec->setIconSize(QSize(tagChHeight, tagChHeight));
    btnSound->setGeometry(0, 0, tagChHeight, tagChHeight);
    btnSound->setIconSize(QSize(tagChHeight, tagChHeight));

    QString bgPath;
    if (Config::style.tagAlignment == TagAlign_BOTTOM_RIGHT ||
        Config::style.tagAlignment == TagAlign_TOP_RIGHT)
    {
        bgPath = (rect.width() >= Config::sys.width) ?
                    ":/images/bg-channel_right.png" :
                    ":/images/bg-channel_right_32px.png";
    }
    else
    {
        bgPath = (rect.width() >= Config::sys.width) ?
                    ":/images/bg-channel_left.png" :
                    ":/images/bg-channel_left_32px.png";
    }
#if 0
    QPixmap p = QPixmap(bgPath).scaled(
                    QSize(tagChW, newH), Qt::KeepAspectRatio, Qt::SmoothTransformation);
    p.save("scaled-bg.png");
    tagCh->setPixmap(p);
#else
    tagCh->setStyleSheet(QString(
//                            "padding:2px;"
                            "border:0px;"    // transparent for Linux
                            "color: %1;"
                            "background: url(\"%2\") transparent top center no-repeat;"
                            "font: bold %3px \"Arial\";")
                       .arg(Config::style.tagFontColor)
                       .arg(bgPath)
                       .arg(tagFontSize)
                       );
    tagZoom->setStyleSheet(QString(
//                            "padding:2px;"
                            "border:0px;"    // transparent for Linux
                            "color: %1;"
                            "background: url(\"%2\") transparent top center no-repeat;"
                            "font: bold %3px \"Arial\";")
                       .arg(Config::style.borderDragColor)
                       .arg(bgPath)
                       .arg(tagFontSize-4)
                       );
#endif

    int interval = 0;
    switch(Config::style.tagAlignment)
    {
    case TagAlign_TOP_LEFT:
        tagCh->setGeometry(borderSize,
                         borderSize,
                         tagCh->width(),
                         tagCh->height());
        btnRec->setGeometry(tagCh->x()+tagCh->width()+interval,
                            borderSize,
                            btnRec->width(),
                            btnRec->height());
        btnSound->setGeometry(tagCh->x()+tagCh->width()+interval+btnRec->width()+interval,
                            borderSize,
                            btnSound->width(),
                            btnSound->height());
        tagZoom->setGeometry(borderSize,
                         borderSize + tagCh->height(),
                         tagCh->width(),
                         tagCh->height());
        break;
    case TagAlign_TOP_RIGHT:
        tagCh->setGeometry(rect.width()-borderSize-tagCh->width(),
                         borderSize,
                         tagCh->width(),
                         tagCh->height());
        btnRec->setGeometry(tagCh->x()-interval-btnRec->width(),
                         borderSize,
                         btnRec->width(),
                         btnRec->height());
        btnSound->setGeometry(tagCh->x()-interval-btnRec->width()-interval-btnSound->width(),
                         borderSize,
                         btnSound->width(),
                         btnSound->height());
        tagZoom->setGeometry(tagCh->x(),
                         borderSize + tagCh->height(),
                         tagCh->width(),
                         tagCh->height());
        break;
    case TagAlign_BOTTOM_LEFT:
        tagCh->setGeometry(borderSize,
                         rect.height()-borderSize-tagCh->height(),
                         tagCh->width(),
                         tagCh->height());
        btnRec->setGeometry(tagCh->x()+tagCh->width()+interval,
                         rect.height()-borderSize-tagCh->height(),
                         btnRec->width(),
                         btnRec->height());
        btnSound->setGeometry(tagCh->x()+tagCh->width()+interval+btnRec->width()+interval,
                         rect.height()-borderSize-tagCh->height(),
                         btnSound->width(),
                         btnSound->height());
        tagZoom->setGeometry(borderSize,
                         tagCh->y()-tagCh->height(),
                         tagCh->width(),
                         tagCh->height());
        break;
    case TagAlign_BOTTOM_RIGHT:
    default:
        tagCh->setGeometry(rect.width()-borderSize-tagCh->width(),
                         rect.height()-borderSize-tagCh->height(),
                         tagCh->width(),
                         tagCh->height());
        btnRec->setGeometry(tagCh->x()-interval-btnRec->width(),
                         tagCh->y(),
                         btnRec->width(),
                         btnRec->height());
        btnSound->setGeometry(tagCh->x()-interval-btnRec->width()-interval-btnSound->width(),
                         tagCh->y(),
                         btnRec->width(),
                         btnRec->height());
        tagZoom->setGeometry(tagCh->x(),
                         tagCh->y()-tagCh->height(),
                         tagCh->width(),
                         tagCh->height());
        break;
    }
}

void RFrame::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void RFrame::setChText(QString text)
{
    tagCh->setText(text);
}

QString RFrame::getChText()
{
    return tagCh->text();
}

void RFrame::showZoomText(bool visible, double zoomRatio)
{
    if(zoomRatio <= ZOOM_RATIO_DEF)
    {
        tagZoom->setText(QString().asprintf("%dx", (int)ZOOM_RATIO_DEF));
    }
    else if(zoomRatio >= 10)
    {
        tagZoom->setText(QString().asprintf("%dx", (int)zoomRatio));
    }
    else
    {
        tagZoom->setText(QString().asprintf("%0.1fx", zoomRatio));
    }
    tagZoom->setVisible(visible);
}

bool RFrame::isTagVisible()
{
    return tagCh->isVisible();
}

void RFrame::setTagVisible(bool visible)
{
    tagCh->setVisible(visible);
}

bool RFrame::isBtnRecVisible()
{
    return btnRec->isVisible();
}

void RFrame::setBtnRecVisible(bool visible)
{
    btnRec->setVisible(visible);
}

bool RFrame::isBtnRecActived()
{
    return btnRec->getActived();
}

void RFrame::setBtnRecActived(bool active)
{
    btnRec->setActive(active, false);
}

bool RFrame::isBtnVoiceVisible()
{
    return btnSound->isVisible();
}

void RFrame::setBtnVoiceVisible(bool visible)
{
    btnSound->setVisible(visible);
}

void RFrame::setGridReal(GridReal *grid)
{
    this->gridReal = grid;
}

GridReal* RFrame::getGridReal()
{
    return this->gridReal;
}

bool RFrame::isMaxSize()
{
    bool bTrue = false;
    if (gridReal->type == GridReal::GridType_IPC)
    {
        bTrue = ((this->x() == 0) &&
                (this->y() == 0) &&
                (this->width() >= Config::sys.width) &&
                (this->height() >= Config::sys.height));
    }
    else if (gridReal->type == GridReal::GridType_File)
    {
        bTrue = ((this->x() == Config::sys.playbackX) &&
                (this->y() == Config::sys.playbackTopDownBorder) &&
                (this->width() >= Config::sys.playbackWidth) &&
                (this->height() >= Config::sys.playbackHeight));
    }
    return bTrue;
}

void RFrame::showZoomZone(QPoint p)
{
    int x0 = qMin(dragStartPosition.x(), p.x());
    int y0 = qMin(dragStartPosition.y(), p.y());
    int x1 = qMax(dragStartPosition.x(), p.x());
    int y1 = qMax(dragStartPosition.y(), p.y());
    zoomZone->setGeometry(x0, y0, (x1-x0), (y1-y0));
    if(zoomZone->isHidden())
    {
        zoomZone->setVisible(true);
        zoomZone->raise();
    }
}

int RFrame::getIdFromMime(const QMimeData *mime)
{
    if (!mime->hasText())
        return RFrame_Id_Invalid;
    QString text = mime->text();
    if (!text.startsWith(RFrame_MimeDataHead))
        return RFrame_Id_Invalid;
    QString value = text.split("=").at(1);
    bool ok;
    int indexId = value.toInt(&ok);
    if (!ok || indexId <= RFrame_Id_Invalid)
    {
        return RFrame_Id_Invalid;
    }
    return indexId;
}

void RFrame::mousePressEvent(QMouseEvent *event)
{
    /* do QFrame::mousePressEvent(event) to trigger mainWidget->mousePressEvent first */
    QFrame::mousePressEvent(event);

//    qDebug() << "RFrame" << __func__ << this->id;
    if (event->button() == Qt::LeftButton)
    {
        dragStartPosition = event->pos();
//        qDebug() << dragStartPosition.x() << dragStartPosition.y();
    }
}

void RFrame::mouseMoveEvent(QMouseEvent *event)
{
    if (!(event->buttons() == Qt::LeftButton))
        return;
    if (gridReal == NULL)
        return;
//    qDebug() << "RFrame" << __func__ << this->id;

    if(isMaxSize() == false &&
       ((gridReal->type == GridReal::GridType_IPC &&
       viewProcess->ipc_getViewMode() == ViewProcess::ViewMode_Grid) ||
       (gridReal->type == GridReal::GridType_File &&
       viewProcess->file_getViewMode() == ViewProcess::ViewMode_Grid))
       )
    {
        if(enableDrag)
        {
            framePixmap = mainWidget->grab(QRect(this->x(), this->y(),
                                                 this->width(), this->height()));
            if(gridReal->type == GridReal::GridType_IPC)
                rtkApi->ipcGetSnapshot(this->id, &framePixmap);
            else if(gridReal->type == GridReal::GridType_File)
                rtkApi->fileGetSnapshot(this->id, &framePixmap);

            QDrag *drag = new QDrag(this);
            QMimeData *mimeData = new QMimeData;
            mimeData->setText(QString("%1%2").arg(RFrame_MimeDataHead).arg(this->id));
            drag->setMimeData(mimeData);
            drag->setPixmap(framePixmap);

            Qt::DropAction dropAction = drag->exec(Qt::CopyAction | Qt::MoveAction);
            Q_UNUSED(dropAction);
        }
    }
    else if (enableZoomin)
    {
        if (gridReal->status == GridReal::GridStatus_PLAY)
        {
            if (gridReal->crop_width() > Config::sys.widthBase ||
                gridReal->crop_height() > Config::sys.heightBase)
            {
                bDragProcess = true;
                currDragId = this->id;
                showZoomZone(event->pos());
            }
        }
    }
}

void RFrame::mouseReleaseEvent(QMouseEvent *event)
{
    QFrame::mouseReleaseEvent(event);

//    qDebug() << "RFrame" << __func__ << this->id;
    if (event->button() == Qt::LeftButton &&
        enableZoomin)
    {
        if(bDragProcess && currDragId == this->id)
        {
            bDragProcess = false;
            currDragId = RFrame_Id_Invalid;
            if (this->zoomZone->isVisible())
            {
                this->zoomZone->setVisible(false);
            }
            if (gridReal != NULL)
            {
                if (gridReal->status == GridReal::GridStatus_PLAY)
                {
                    QRect rect;
                    if (transformToRect(dragStartPosition, event->pos(), &rect))
                    {
                        if (gridReal->type == GridReal::GridType_IPC)
                        {
                            viewProcess->ipc_zoomin(this->id, rect);
                            if(Config::sys.faceDetectEnable)
                            {
                                if(faceDetect->isVisible())
                                {
                                    faceDetect->setVisible(false);
                                }
                            }
                        }
                        else if (gridReal->type == GridReal::GridType_File)
                            viewProcess->file_zoomin(this->id, rect);
                    }
                }
            }
        }
    }
}

void RFrame::dragEnterEvent(QDragEnterEvent *event)
{
//    qDebug() << "RFrame" << __func__ << this->id;

    bDragProcess = true;

    currDragId = getIdFromMime(event->mimeData());
    if (currDragId > RFrame_Id_Invalid)
    {
        prepareStyleSheet();
    }

    event->acceptProposedAction();
    QFrame::dragEnterEvent(event);
}

void RFrame::dragLeaveEvent(QDragLeaveEvent *event)
{
    /* no mimeData() for this event */
//    qDebug() << "RFrame" << __func__ << this->id;

    bDragProcess = false;
    currDragId = RFrame_Id_Invalid;
    prepareStyleSheet();
    if(zoomZone->isVisible())
    {
        zoomZone->setVisible(false);
    }

    QFrame::dragLeaveEvent(event);
}

void RFrame::dragMoveEvent(QDragMoveEvent *event)
{
//    qDebug() << "RFrame" << __func__ << this->id;
    currDragId = getIdFromMime(event->mimeData());
    if (currDragId > RFrame_Id_Invalid &&
        enableZoomin)
    {
        if (currDragId == this->id)
        {
            if (gridReal != NULL)
            {
                if (gridReal->status == GridReal::GridStatus_PLAY)
                {
                    // plot rect
                    showZoomZone(event->pos());
                }
            }
        }
    }
    QFrame::dragMoveEvent(event);
}

void RFrame::dropEvent(QDropEvent *event)
{
    bDragProcess = false;

    currDragId = getIdFromMime(event->mimeData());
    if (currDragId > RFrame_Id_Invalid)
    {
        if (currDragId == this->id)
        {
            if (this->zoomZone->isVisible())
            {
                this->zoomZone->setVisible(false);
            }
            if (enableZoomin && gridReal != NULL)
            {
                if (gridReal->status == GridReal::GridStatus_PLAY)
                {
                    QRect rect;
                    if (transformToRect(dragStartPosition, event->pos(), &rect))
                    {
                        if (gridReal->type == GridReal::GridType_IPC)
                        {
                            viewProcess->ipc_zoomin(this->id, rect);
                        }
                        else if (gridReal->type == GridReal::GridType_File)
                        {
                            viewProcess->file_zoomin(this->id, rect);
                        }
                    }
                }
            }
        }
        else
        {
            if (enableDrag)
            {
                prepareStyleSheet();
                if (gridReal->type == GridReal::GridType_IPC)
                {
                    viewProcess->ipc_swap(currDragId, this->id);
                }
                else if (gridReal->type == GridReal::GridType_File)
                {
                    viewProcess->file_swap(currDragId, this->id);
                }
            }
        }
    }
    QFrame::dropEvent(event);
}

void RFrame::mouseDoubleClickEvent(QMouseEvent *event)
{
    QFrame::mouseDoubleClickEvent(event);

    if (!(event->buttons() & Qt::LeftButton))
        return;

//    qDebug() << "RFrame" << __func__ << this->id;
    if (enableZoomin && gridReal != NULL)
    {
        switch (gridReal->type)
        {
        case GridReal::GridType_IPC:
            switch (viewProcess->ipc_getViewMode())
            {
            case ViewProcess::ViewMode_Grid:
                if (gridReal->status != GridReal::GridStatus_NONE)
                {
                    viewProcess->ipc_setViewMode(ViewProcess::ViewMode_ZoomIn, this->id);
                    showZoomText(true, ZOOM_RATIO_DEF);
                    if(Config::sys.faceDetectEnable)
                    {
                        faceDetect->setGridReal(& viewProcess->ipc_gridReal[this->id]);
                        faceDetect->raise();
                        faceDetect->setVisible(true);
                        qDebug() << "faceDetect->setVisible(true)";
                    }
                }
                break;
            case ViewProcess::ViewMode_ZoomIn:
                viewProcess->ipc_setViewMode(ViewProcess::ViewMode_Grid, this->id);
                showZoomText(false, ZOOM_RATIO_DEF);
                if(Config::sys.faceDetectEnable)
                {
                    faceDetect->setVisible(false);
                    qDebug() << "faceDetect->setVisible(false)";
                }
                break;
            case ViewProcess::ViewMode_Set:
                break;
            case ViewProcess::ViewMode_Hide:
            default:
                viewProcess->ipc_setViewMode(ViewProcess::ViewMode_Hide, this->id);
                break;
            }
            break;
        case GridReal::GridType_File:
            switch (viewProcess->file_getViewMode())
            {
            case ViewProcess::ViewMode_Grid:
                if (gridReal->status != GridReal::GridStatus_NONE)
                {
                    viewProcess->file_setViewMode(ViewProcess::ViewMode_ZoomIn, this->id);
                    showZoomText(true, ZOOM_RATIO_DEF);
                }
                break;
            case ViewProcess::ViewMode_ZoomIn:
                viewProcess->file_setViewMode(ViewProcess::ViewMode_Grid, this->id);
                showZoomText(false, ZOOM_RATIO_DEF);
                break;
            case ViewProcess::ViewMode_Set:
                break;
            case ViewProcess::ViewMode_Hide:
            default:
                viewProcess->file_setViewMode(ViewProcess::ViewMode_Hide, this->id);
                break;
            }
            break;
        }
    }
}

bool RFrame::transformToRect(QPoint pos_0, QPoint pos_1, QRect *pRect)
{
    QRect src, crop;

    qDebug() << __func__ << this->id;
    if (gridReal == NULL)
    {
        qDebug() << "gridReal == NULL";
        return false;
    }
    if (gridReal->status != GridReal::GridStatus_PLAY)
    {
        qDebug() << "status != LIVE";
        return false;
    }
    if (gridReal->ifGetSrc() != true)
    {
        qDebug() << "ifGetSrc() fail";
        return false;
    }

    int x0 = qMin(pos_0.x(), pos_1.x());
    int y0 = qMin(pos_0.y(), pos_1.y());
    int x1 = qMax(pos_0.x(), pos_1.x());
    int y1 = qMax(pos_0.y(), pos_1.y());
    if((x0-2*borderSize) <= 0)
        x0 = 0;
    if((x1+2*borderSize) >= this->width())
        x1 = this->width();
    if((y0-2*borderSize) <= 0)
        y0 = 0;
    if((y1+2*borderSize) >= this->height())
        y1 = this->height();
    int w = x1 - x0 + 1;
    int h = y1 - y0 + 1;

    src = gridReal->getSrc();
    crop = gridReal->getCrop();
    if(crop.left() < src.left())
        crop.setLeft(src.left());
    if(crop.right() > src.right())
        crop.setRight(src.right());
    if(crop.top() < src.top())
        crop.setTop(src.top());
    if(crop.bottom() > src.bottom())
        crop.setBottom(src.bottom());

    if(crop.width() <= Config::sys.widthBase &&
       crop.height() <= Config::sys.heightBase)
    {
        pRect->setRect(crop.x(), crop.y(), crop.width(), crop.height());
    }
    else
    {
        double wRatio = (double)crop.width() / (double)this->width();
        double hRatio = (double)crop.height() / (double)this->height();
        int xCenterMirror = crop.x() + (wRatio * (0.0+(double)x0+(double)x1) / 2);
        int yCenterMirror = crop.y() + (hRatio * (0.0+(double)y0+(double)y1) / 2);
        double wMirror = (wRatio * (0.0+(double)w));
        double hMirror = (hRatio * (0.0+(double)h));
        int ratio;
        if (wMirror/Config::sys.widthBase >= hMirror/Config::sys.heightBase)
        {
            ratio = (wMirror/Config::sys.widthBase + 1);
        }
        else
        {
            ratio = (hMirror/Config::sys.heightBase + 1);
        }
        int wReal = ratio * Config::sys.widthBase;
        int hReal = ratio * Config::sys.heightBase;
        int xReal = xCenterMirror - wReal/2;
        int yReal = yCenterMirror - hReal/2;
        if (xReal % x_pos_align > 0)
        {
            if (xReal % x_pos_align >= x_pos_align/2)
                xReal += (x_pos_align - xReal % x_pos_align);
            else
                xReal -= xReal % x_pos_align;
        }
        if (xReal < crop.left()) xReal = crop.left();
        if (yReal < crop.top()) yReal = crop.top();
        if (xReal + wReal - 1 > crop.right())
            xReal = crop.right() - wReal + 1;
        if (yReal + hReal - 1 > crop.bottom())
            yReal = crop.bottom() - hReal + 1;
        pRect->setX(xReal);
        pRect->setY(yReal);
        pRect->setWidth(wReal);
        pRect->setHeight(hReal);
//        qDebug() << "ratio=" << ratio;
    }
//    qDebug() << x0 << y0 << w << h;
//    qDebug() << pRect->x() << pRect->y() << pRect->width() << pRect->height();
    showZoomText(true, ((0.0 + src.width()) / pRect->width()));
    return true;
}

void RFrame::rec_selected(bool)
{
    if (setStorage == NULL)
        return;
    setStorage->doIdxRec(id, btnRec->getActived());
}

void RFrame::sound_selected(bool)
{
}
