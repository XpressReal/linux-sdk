/**
 * @file rcalendarwidget.cpp
 * @author Realtek Semiconductor Corp.
 * @date Dec 2017
 * @brief The widget page of calendar operation
 */

#include "rcalendarwidget.h"
#include "ui_rcalendarwidget.h"
#include "mainwidget.h"
#include <QDate>
#include <QDebug>

#define LIGHT_BG_COLOR  0

RCalendarWidget::RCalendarWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RCalendarWidget)
{
    ui->setupUi(this);
    sbYear = ui->sbYear;
    sbMonth = ui->sbMonth;
    ui->sbYear->setVisible(false);
    ui->sbMonth->setVisible(false);

    ui->tbClose->setAutoRaise(true);
    ui->tbClose->raise();
    ui->tbClose->setIcons(QIcon(":/images/playback_close_normal.png"),
                         QIcon(":/images/playback_close_hover.png"),
                         QIcon(":/images/playback_close_normal.png"),
                         QIcon(":/images/playback_close_hover.png"),
                         false);

    QList<QToolButton *> btnList = {
                    ui->btn_0_0, ui->btn_1_0, ui->btn_2_0, ui->btn_3_0, ui->btn_4_0, ui->btn_5_0, ui->btn_6_0,
                    ui->btn_0_1, ui->btn_1_1, ui->btn_2_1, ui->btn_3_1, ui->btn_4_1, ui->btn_5_1, ui->btn_6_1,
                    ui->btn_0_2, ui->btn_1_2, ui->btn_2_2, ui->btn_3_2, ui->btn_4_2, ui->btn_5_2, ui->btn_6_2,
                    ui->btn_0_3, ui->btn_1_3, ui->btn_2_3, ui->btn_3_3, ui->btn_4_3, ui->btn_5_3, ui->btn_6_3,
                    ui->btn_0_4, ui->btn_1_4, ui->btn_2_4, ui->btn_3_4, ui->btn_4_4, ui->btn_5_4, ui->btn_6_4,
                    ui->btn_0_5, ui->btn_1_5, ui->btn_2_5, ui->btn_3_5, ui->btn_4_5, ui->btn_5_5, ui->btn_6_5};
    for(int i=0; i<btnList.count(); i++)
    {
        BtnDayInfo *btnDayInfo = new BtnDayInfo();
        btnDayInfo->btnDay = btnList.at(i);
        btnDayInfo->btnDay->setAutoRaise(true);
        btnDayInfo->btnDay->setToolButtonStyle(Qt::ToolButtonTextOnly);
        btnDayInfo->btnDay->installEventFilter(this);
        btnDayInfo->bAlreadyRecData = false;
        btnDayInfo->bThisMonth = false;
        btnDayInfo->day = 0;
        _btnDayInfoList.append(btnDayInfo);
    }

    strBackgroundColor = "rgb(25, 32, 36);";
    strSelectedColor = "rgb(224, 255, 24)";
    initStyleSheet(false, true);

    QObject::connect(ui->tbClose, SIGNAL(clicked(bool)), this, SLOT(btnCloseClicked(bool)));
    QObject::connect(ui->btn_prev, SIGNAL(clicked(bool)), this, SLOT(objMonthPrev(bool)));
    QObject::connect(ui->btn_next, SIGNAL(clicked(bool)), this, SLOT(objMonthNext(bool)));

    dateSelect = QDate::currentDate();
    monthShow = QDate::currentDate();
    objYearSetRange();
    ui->cbYear->setCurrentText(QString().asprintf("%04d", monthShow.year()));
    ui->cbMonth->setCurrentText(QString().asprintf("%02d", monthShow.month()));
//    ui->sbYear->setValue(dateSelect.year());
//    ui->sbMonth->setValue(dateSelect.month());
//    updateCalender(dateSelect.year(), dateSelect.month());
    objYearMonthSetConnect(true);
}

void RCalendarWidget::initStyleSheet(bool ifAlwaysShow, bool ifCheckRecData)
{
    this->ifCheckRecData = ifCheckRecData;
    ui->tbClose->setHidden(ifAlwaysShow);

    ui->wBg->setStyleSheet(QString("background-color: %1").arg(strBackgroundColor));
    ui->lCalendar->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE);
    ui->tbClose->setStyleSheet("background-color: rgb(53, 57, 60);");
    QList<QComboBox *> cbList = {ui->cbYear, ui->cbMonth};
    for(int i=0; i<cbList.count(); i++)
    {
        cbList.at(i)->setMaxVisibleItems(cbList.at(i)->count());
        cbList.at(i)->setStyleSheet(QString(
                                    "background-color: %1"
                                    "font: bold 16px \"Arial Black\";"
                                    "color: rgb(117, 117, 117);"
                                    )
                                    .arg(strBackgroundColor));
    }

    QList<QToolButton *> selectList = {ui->btn_next, ui->btn_prev};
    for(int i=0; i<selectList.count(); i++)
    {
        selectList.at(i)->setAutoRaise(true);
        selectList.at(i)->setStyleSheet(
                    QString(
                        "QToolButton{"
                            "background-color: %1"
                            "%2"
                            "color: rgb(117, 117, 117);"
                            "}"
                        "QToolButton:hover{"
                            "background-color: %1"
                            "%2"
                            "color: rgb(255, 255, 255);"
                            "}"
                        )
                        .arg(strBackgroundColor)
                        .arg("font: bold 24px \"Arial Black\";"));
    }

    QList<QLabel *> labelList = {
                     ui->lSun, ui->lMon, ui->lTus, ui->lWed, ui->lThr, ui->lFri, ui->lSat
                     };
    for(int i=0; i<labelList.count(); i++)
    {
        labelList.at(i)->setStyleSheet(
                    "color: rgb(117, 117, 117);"
                    "font: bold 14px \"Arial Black\";");
    }
}

RCalendarWidget::~RCalendarWidget()
{
    delete ui;
}

bool RCalendarWidget::eventFilter(QObject *o, QEvent *e)
{
    if(e->type() == QEvent::MouseButtonRelease)
    {
        for(int i=0; i<_btnDayInfoList.count(); i++)
        {
            QObject *obj = _btnDayInfoList.at(i)->btnDay;
            if(obj == o)
            {
                if(_btnDayInfoList.at(i)->btnDay->text().length() > 0)
                {
//                    qDebug() << i << _btnDayInfoList.at(i)->day;
                    dateSelect.setDate(ui->cbYear->currentText().toInt(),
                                       ui->cbMonth->currentText().toInt(),
//                                       ui->sbYear->value(),
//                                       ui->sbMonth->value(),
                                       _btnDayInfoList.at(i)->day);
                    updateCalender(ui->cbYear->currentText().toInt(),
                                   ui->cbMonth->currentText().toInt());
//                                     ui->sbYear->value(),
//                                     ui->sbMonth->value());
                    emit(dayClicked());
                }
                break;
            }
        }
    }
    return QObject::eventFilter(o, e);
}

void RCalendarWidget::showEvent(QShowEvent *event)
{
    regetCalendar();
    Q_UNUSED(event);
}

void RCalendarWidget::btnCloseClicked(bool)
{
    this->setVisible(false);
    emit(closeClicked());
}

void RCalendarWidget::objMonthPrev(bool)
{
    objYearMonthAdd(0, -1);
}

void RCalendarWidget::objMonthNext(bool)
{
    objYearMonthAdd(0, 1);
}

void RCalendarWidget::objYearMonthValueChanged()
{
    objCheckRange();
//    updateCalender(ui->sbYear->value(), ui->sbMonth->value());
    updateCalender(ui->cbYear->currentText().toInt(), ui->cbMonth->currentText().toInt());
}

void RCalendarWidget::objCheckRange()
{
//    if (ui->sbYear->value() >= dateMax.year() &&
//        ui->sbMonth->value() == dateMax.month())
    if (ui->cbYear->currentText().toInt() >= dateMax.year() &&
        ui->cbMonth->currentText().toInt() == dateMax.month())
    {
        ui->btn_next->setVisible(false);
    }
    else
    {
        ui->btn_next->setVisible(true);
    }
//    if (ui->sbYear->value() <= dateMin.year() &&
//        ui->sbMonth->value() == dateMin.month())
    if (ui->cbYear->currentText().toInt() <= dateMin.year() &&
        ui->cbMonth->currentText().toInt() == dateMin.month())
    {
        ui->btn_prev->setVisible(false);
    }
    else
    {
        ui->btn_prev->setVisible(true);
    }
}

bool RCalendarWidget::objYearMonthAdd(int addYears, int addMonths)
{
//    QDate date = QDate(ui->sbYear->value(), ui->sbMonth->value(), 1);
    QDate date = QDate(ui->cbYear->currentText().toInt(), ui->cbMonth->currentText().toInt(), 1);
    date = date.addYears(addYears);
    date = date.addMonths(addMonths);
    if (date.year() > dateMax.year())
        return false;
    if (date.year() < dateMin.year())
        return false;

//    qDebug() << date.year() << date.month();
//    if (ui->sbYear->value() != date.year())
//        ui->sbYear->setValue(date.year());
    if (ui->cbYear->currentText().toInt() != date.year())
        ui->cbYear->setCurrentText(QString().asprintf("%04d", date.year()));
//    if (ui->sbMonth->value() != date.month())
//        ui->sbMonth->setValue(date.month());
    if (ui->cbMonth->currentText().toInt() != date.month())
        ui->cbMonth->setCurrentText(QString().asprintf("%02d",date.month()));

    objCheckRange();
    return updateCalender(date.year(), date.month());
}

void RCalendarWidget::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);
    ui->wBg->setGeometry(0, 0, rect.width(), rect.height());
    ui->tbClose->setGeometry(rect.width()-ui->tbClose->width(), 0,
                             ui->tbClose->width(),
                             ui->tbClose->height());
    ui->lCalendar->setGeometry(0, 0, rect.width(), 36);
    int x = qMax((rect.width()-ui->wAlign->width())/2, 0);
//    int y = qMax((rect.height()-ui->wAlign->height())/2, 0);
    ui->wAlign->setGeometry(x, 36, ui->wAlign->width(), ui->wAlign->height());
}

void RCalendarWidget::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

bool RCalendarWidget::getDate(int year, int month, int day, int *date)
{
    QDate qdate = QDate(year, month, day);
    int dayOfWeek = qdate.dayOfWeek();  // 1=Monday to 7=Sunday
    if (dayOfWeek <= 0)
    {
        return false;
    }
    if (dayOfWeek >= 7)
    {
        *date = 0;  // 0=Sunday
    }
    else
    {
        *date = dayOfWeek;  // 1=Monday to 6=Saturday
    }
    return true;
}

void RCalendarWidget::selectCurrentDate()
{
    dateSelect = QDate::currentDate();
}

QDate RCalendarWidget::getDateSelected()
{
    return dateSelect;
}

QDate RCalendarWidget::getMonthShow()
{
    return monthShow;
}

QString RCalendarWidget::strDateSelected(bool ifWeek)
{
    const QList<QString> dateList = {"",
                               "Monday", "Tusday", "Wednesday",
                               "Thursday", "Friday", "Saturday",
                               "Sunday"};
    QString str = dateSelect.toString(Config::strQDateFormat());
    if(ifWeek)
    {
        str += "  " + dateList.at(dateSelect.dayOfWeek());
    }
    return str;
}

int RCalendarWidget::yearSelected()
{
    return dateSelect.year();
}

int RCalendarWidget::monthSelected()
{
    return dateSelect.month();
}

int RCalendarWidget::daySelected()
{
    return dateSelect.day();
}

void RCalendarWidget::objYearSetRange()
{
    QDate currentDate = QDate::currentDate();
    int maxYear = currentDate.year()+3;
    int minYear = 2016;
    dateMax.setDate(maxYear, 12, 31);
    dateMin.setDate(minYear, 1, 1);
//    ui->sbYear->setMaximum(maxYear);
//    ui->sbYear->setMinimum(minYear);
    ui->cbYear->clear();
    for (int i=dateMin.year(); i<=dateMax.year(); i++)
    {
        ui->cbYear->addItem(QString("%1").arg(i));
    }
}

void RCalendarWidget::objYearMonthSetConnect(bool connect)
{
    if (connect)
    {
//        QObject::connect(ui->sbYear, SIGNAL(valueChanged(QString)), this, SLOT(objYearMonthValueChanged()));
//        QObject::connect(ui->sbMonth,SIGNAL(valueChanged(QString)), this, SLOT(objYearMonthValueChanged()));
        QObject::connect(ui->cbYear, SIGNAL(currentIndexChanged(int)), this, SLOT(objYearMonthValueChanged()));
        QObject::connect(ui->cbMonth, SIGNAL(currentIndexChanged(int)), this, SLOT(objYearMonthValueChanged()));
    }
    else
    {
//        QObject::disconnect(ui->sbYear, SIGNAL(valueChanged(QString)), this, SLOT(objYearMonthValueChanged()));
//        QObject::disconnect(ui->sbMonth,SIGNAL(valueChanged(QString)), this, SLOT(objYearMonthValueChanged()));
        QObject::disconnect(ui->cbYear, SIGNAL(currentIndexChanged(int)), this, SLOT(objYearMonthValueChanged()));
        QObject::disconnect(ui->cbMonth, SIGNAL(currentIndexChanged(int)), this, SLOT(objYearMonthValueChanged()));
    }
}

bool RCalendarWidget::regetCalendar()
{
    return updateCalender(monthShow.year(), monthShow.month());
}

bool RCalendarWidget::updateCalender(int year, int month)
{
    int date;
//    qDebug() << __func__ << year << month << "1";
    if (getDate(year, month, 1, &date) == false)
        return false;

    monthShow.setDate(year, month, 1);
//    qDebug() << date;
    QDate dateCurr = QDate::currentDate();
    for(int i=0; i<_btnDayInfoList.count(); i++)
    {
        BtnDayInfo *btnDayInfo = _btnDayInfoList.at(i);
        int tempDate;
        bool bSameMonth = getDate(year, month, 1+(i-date), &tempDate);
        btnDayInfo->day = 1+(i-date);
        btnDayInfo->bThisMonth = bSameMonth;
        if(ifCheckRecData)
        {
            btnDayInfo->bAlreadyRecData = (hlsProcess->getHashDateMask(QDate(year, month, btnDayInfo->day)) > 0);
        }
        else
        {
            btnDayInfo->bAlreadyRecData = false;
        }
        if (bSameMonth == false)
        {
            btnDayInfo->btnDay->setText("");
            btnDayInfo->btnDay->setEnabled(false);
            btnDayInfo->btnDay->setStyleSheet(QString("background-color: %1").arg(strBackgroundColor));
        }
        else
        {
            bool bSelected = (dateSelect.year() == year &&
                              dateSelect.month() == month &&
                              dateSelect.day() == btnDayInfo->day);
            bool bCurrDate = (dateCurr.year() == year &&
                              dateCurr.month() == month &&
                              dateCurr.day() == btnDayInfo->day);
            btnDayInfo->btnDay->setText(QString("%1").arg(btnDayInfo->day));
            btnDayInfo->btnDay->setEnabled(true);
            btnDayInfo->btnDay->setStyleSheet(QString(
                                    "QToolButton{"
#if LIGHT_BG_COLOR
                                        "border:4px solid;" // border
#else
                                        "border:2px solid;" // border
#endif
                                        "%1"    // border-color
                                        "%2"    // color
                                        "background-color: %4;"
                                        "%5"    // font
                                        "border-radius:%6px;"
                                        "}"
                                    "QToolButton:hover{"
#if LIGHT_BG_COLOR
                                        "border:4px solid;" // border
#else
                                        "border:2px solid;" // border
#endif
                                        "%1"    // border-color
                                        "%3"    // color
                                        "background-color: rgb(53, 57, 60);"
                                        "%5"    // font
                                        "border-radius:%6px;"
                                        "}")
#if LIGHT_BG_COLOR
                                    .arg(bCurrDate ? "border-color: rgb(24,26,28);" :
#else
                                    .arg(bCurrDate ? "border-color: rgb(84,84,84);" :
#endif
                                                     "border-color: transparent;")
                                    .arg(bSelected ? "color: rgb(0, 0, 0);" :
                                             (btnDayInfo->bAlreadyRecData ?
                                             "color: rgb(250, 250, 250);" :
                                             "color: rgb(84, 84, 84);"))
                                    .arg(btnDayInfo->bAlreadyRecData ?
                                             "color: rgb(250, 250, 250);" :
                                             "color: rgb(84, 84, 84);")
                                    .arg(bSelected ?
                                         strSelectedColor : strBackgroundColor)
                                    .arg("font: bold 14px \"Arial Black\";")
                                    .arg(btnDayInfo->btnDay->height()/2));
        }
    }

    objYearMonthSetConnect(false);
//    ui->sbYear->setValue(year);
//    ui->sbMonth->setValue(month);
    ui->cbYear->setCurrentText(QString().asprintf("%04d",year));
    ui->cbMonth->setCurrentText(QString().asprintf("%02d",month));
    objYearMonthSetConnect(true);
    return true;
}
