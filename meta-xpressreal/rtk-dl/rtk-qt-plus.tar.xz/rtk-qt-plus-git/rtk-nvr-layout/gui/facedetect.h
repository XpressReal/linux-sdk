/**
 * @file facedetect.cpp
 * @author Realtek Semiconductor Corp.
 * @date Apri 2018
 * @brief The widget page to set face detect
 */

#ifndef FACEDETECT_H
#define FACEDETECT_H

#include <QWidget>
#include "rlineedit.h"
#include "define.h"
#include "gridreal.h"

namespace Ui {
class FaceDetect;
}

class FaceDetect : public QWidget
{
    Q_OBJECT

public:
    explicit FaceDetect(QWidget *parent = 0);
    ~FaceDetect();
    QString strName;

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);
    void setGridReal(GridReal *gridReal);

private:
    Ui::FaceDetect *ui;
    int parent_absolute_offset_x, parent_absolute_offset_y;
    GridReal *gridReal;

    void initValue();

private slots:
    void set_clicked(bool);

protected:
    void showEvent(QShowEvent *event);
    void hideEvent(QShowEvent *event);
};

#endif // FACEDETECT_H
