/**
 * @file info.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page to show info
 */

#include "info.h"
#include "ui_info.h"
#include "mainwidget.h"

Info::Info(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Info)
{
    ui->setupUi(this);

    this->alarm = ui->alarm;
    this->statistics = ui->statistics;
//    this->setStyleSheet("background-color: rgb(20, 25, 28);");
    ui->lTitle->setStyleSheet(STYLESHEET_TITLE_1);
    ui->wOption->setStyleSheet("background-color: rgb(0, 5, 0);");
    ui->wContent->setStyleSheet("background-color: rgb(20, 25, 28);");

    ui->tbAlarm->setStyleSheet("color: rgb(179, 179, 179);");
    ui->tbStatistics->setStyleSheet("color: rgb(179, 179, 179);");
//    ui->tbAlarm->setToolTip("Alarm");
//    ui->tbStatistics->setToolTip("Statistics");

    connect(ui->tbAlarm,   SIGNAL(clicked(bool)), this, SLOT(setAlarm(bool)));
    connect(ui->tbStatistics,  SIGNAL(clicked(bool)), this, SLOT(setStatus(bool)));
}

Info::~Info()
{
    delete ui;
}

void Info::setup()
{
    alarm->setup();
    statistics->setup();
    setAlarm(true);
}

void Info::setGeometry(const QRect &rect)
{
    const int margin = 120;
    int width = rect.width()-margin;
    if (width < 0)
        width = 0;

    QWidget::setGeometry(rect);
    ui->wOption->setGeometry(0, 0, margin, rect.height());
    ui->wContent->setGeometry(margin,0,width,rect.height());

    ui->alarm->setParentAbsoluteOffset(rect.x()+margin, rect.y());
    ui->statistics->setParentAbsoluteOffset(rect.x()+margin, rect.y());

    ui->alarm->setGeometry(0, 0, width, rect.height());
    ui->statistics->setGeometry(0, 0, width, rect.height());
}

void Info::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void Info::setOption(QToolButton *btn)
{
    QToolButton *btnOpt[] = {ui->tbAlarm, ui->tbStatistics, NULL};
    QWidget *widget[] = {ui->alarm, ui->statistics, NULL};
    int i=0;
    while (btnOpt[i] != NULL)
    {
        if(btnOpt[i] == btn)
        {
            btnOpt[i]->setStyleSheet("QToolButton{"
                                        "background-color: rgba(158, 184, 184, 0.2);"
                                        "color: rgb(179, 179, 179);"
                                        "font: bold 20px \"Arial\";"
                                        "}"
                                     "QToolButton:hover{"
                                        "background-color: rgba(158, 184, 184, 0.2);"
                                        "color: rgb(179, 179, 179);"
                                        "font: bold 20px \"Arial\";"
                                        "}"
                                    );
            widget[i]->setVisible(true);
            widget[i]->raise();
        }
        else
        {
            btnOpt[i]->setStyleSheet("QToolButton{"
                                        "background-color: rgb(0, 5, 0);"
                                        "color: rgb(179, 179, 179);"
                                        "font: bold 20px \"Arial\";"
                                        "}"
                                     "QToolButton:hover{"
                                        "background-color: rgba(158, 184, 184, 0.2);"
                                        "color: rgb(179, 179, 179);"
                                        "font: bold 20px \"Arial\";"
                                        "}"
                                    );
            widget[i]->setVisible(false);
        }
        i++;
    }
}

void Info::setAlarm(bool)
{
    setOption(ui->tbAlarm);
}

void Info::setStatus(bool)
{
    setOption(ui->tbStatistics);
}
