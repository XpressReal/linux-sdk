/**
 * @file ipcadd.h
 * @author Realtek Semiconductor Corp.
 * @date May 2018
 * @brief The widget page to add IP camera
 */

#ifndef IPCADD_H
#define IPCADD_H

#include <QWidget>
#include <QToolButton>
#include "ipcconnect.h"
#include "ipcdetect.h"

namespace Ui {
class IpcAdd;
}

class IpcAdd : public QWidget
{
    Q_OBJECT

public:
    IpcConnect *ipcConnect;
    IpcDetect *ipcDetect;

    explicit IpcAdd(QWidget *parent = 0);
    ~IpcAdd();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);

private:
    Ui::IpcAdd *ui;

    void setOption(QToolButton *btn);

private slots:
    void setIpcConnect(bool);
    void setIpcDetect(bool);
};

#endif // IPCADD_H
