/**
 * @file mainlogin.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page to login
 */

#include "mainlogin.h"
#include "ui_mainlogin.h"
#include "mainwidget.h"
#include <QDebug>

MainLogin::MainLogin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainLogin)
{
    ui->setupUi(this);
    ui->wBg->setGeometry(0, 0, 490, 460);
/*
    {   // setPlaceholderText
        ui->lName->hide();
        ui->leUserName->setPlaceholderText("User Name");
        ui->leUserName->setGeometry(80,110,340,30);

        ui->lPassword->hide();
        ui->lePassword->setPlaceholderText("Password");
        ui->lePassword->setGeometry(80,170,340,30);
    }
*/
    ui->lTitle->setStyleSheet("color: rgb(176, 176, 176);"
                              "font: bold 36px \"Arial Black\";");
    QList<QLabel *>labelList = {ui->lName, ui->lPassword};
    for(int i=0; i<labelList.count(); i++)
    {
        labelList.at(i)->setStyleSheet("color: rgb(176, 176, 176);"
                                       "font: 16px \"Arial\";");
    }
    QList<QLineEdit *>editList = {ui->leUserName, ui->lePassword};
    for(int i=0; i<editList.count(); i++)
    {
        editList.at(i)->setStyleSheet("background: rgb(69,77,77);"
                                      "color: rgb(115, 121, 121);"
                                      "font: bold 24px \"Arial Black\";");
    }
    ui->checkRemember->setText("Remeber me");
    ui->checkRemember->setChecked(true);
    ui->checkRemember->label->setStyleSheet("background:transparent;"
                                "color: rgb(176, 176, 176);"
                                "font: 16px \"Arial\";");

    ui->checkShow->setText("Show password");
    ui->checkShow->setChecked(false);
    ui->checkShow->label->setStyleSheet("background:transparent;"
                                "color: rgb(176, 176, 176);"
                                "font: 16px \"Arial\";");

    ui->btn_forgot->setStyleSheet("background:transparent;"
                                  "color: rgb(176, 176, 176);"
                                  "font: 16px \"Arial\";"
                                  "border:0px;");
    ui->btn_signin->setStyleSheet("background-color: rgb(169, 204, 125);"
                                  "font: bold 24px \"Arial\";"
                                  "border-radius:6px;");
    ui->btn_cancel->setStyleSheet("background-color: rgb(176, 176, 176);"
                                  "font: bold 24px \"Arial\";"
                                  "border-radius:6px;");

    ui->leUserName->setText("admin");
    ui->btn_forgot->setVisible(false);
    connect(ui->checkShow, SIGNAL(clicked(bool)), this, SLOT(showPassword(bool)));
    connect(ui->btn_signin, SIGNAL(clicked(bool)), this, SLOT(signin(void)));
    connect(ui->btn_cancel, SIGNAL(clicked(bool)), this, SLOT(cancel(void)));
}

MainLogin::~MainLogin()
{
    delete ui;
}

void MainLogin::mousePressEvent(QMouseEvent *e)
{
    if (e->button() == Qt::LeftButton)
    {
        _mousePressed = true;
        _mousePosition = e->pos();
    }
}

void MainLogin::mouseMoveEvent(QMouseEvent *e)
{
    if (_mousePressed)
    {
        QPoint point = mapToParent(e->pos() - _mousePosition);
        move(point);
        ui->leUserName->setParentAbsoluteOffset(point.x(), point.y());
        ui->lePassword->setParentAbsoluteOffset(point.x(), point.y());
        dialog->move(point);
    }
}

void MainLogin::mouseReleaseEvent(QMouseEvent *e)
{
    if (e->button() == Qt::LeftButton)
    {
        _mousePressed = false;
        _mousePosition = QPoint();
    }
}

void MainLogin::installEventFilterForKeyboard(QObject *obj)
{
    ui->leUserName->installEventFilter(obj);
    ui->lePassword->installEventFilter(obj);
}

void MainLogin::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);
    ui->leUserName->setParentAbsoluteOffset(rect.x(), rect.y());
    ui->lePassword->setParentAbsoluteOffset(rect.x(), rect.y());
}

void MainLogin::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void MainLogin::showEvent(QShowEvent *e)
{
    ui->checkRemember->setChecked(Config::sys.autoLogin);
    Q_UNUSED(e);
}

void MainLogin::showPassword(bool)
{
    ui->lePassword->setEchoMode(
                ui->checkShow->isChecked() ? QLineEdit::Normal : QLineEdit::Password);
}

void MainLogin::signin()
{
//    qDebug() << "UserName" << ui->leUserName->text().toLocal8Bit().data();
//    qDebug() << "Password" << ui->lePassword->text().toLocal8Bit().data();
    if (Config::sys.autoLogin)
    {
        this->hide();
    }
    else
    {
        if (ui->leUserName->text() == "admin" &&
            ui->lePassword->text() == "real")
        {
            if(Config::sys.autoLogin != ui->checkRemember->isChecked())
            {
                Config::sys.autoLogin = ui->checkRemember->isChecked();
                Config::saveDefaultProfile();
            }
            this->hide();
        }
        else
        {
            dialog->showError(tr("Error username or password !"));
        }
    }
}

void MainLogin::cancel()
{
    if (ui->checkRemember->isChecked() != true)
    {
        ui->leUserName->setText("");
        ui->lePassword->setText("");
    }
}
