/**
 * @file alarm.h
 * @author Realtek Semiconductor Corp.
 * @date May 2018
 * @brief The widget page to show alarm
 */

#ifndef ALARM_H
#define ALARM_H

#include <QWidget>
#include <QList>
#include <QLabel>
#include <QGridLayout>
#include "rtablayer.h"
#include "define.h"

namespace Ui {
class Alarm;
}

class Alarm : public QWidget
{
    Q_OBJECT

public:
    explicit Alarm(QWidget *parent = 0);
    ~Alarm();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setParentAbsoluteOffset(int x, int y);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);

private:
    Ui::Alarm *ui;
    RTabLayer *tlAlarm;
    int parent_absolute_offset_x, parent_absolute_offset_y;

    void initValue();

private slots:

protected:
//    void showEvent(QShowEvent *event);
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // ALARM_H
