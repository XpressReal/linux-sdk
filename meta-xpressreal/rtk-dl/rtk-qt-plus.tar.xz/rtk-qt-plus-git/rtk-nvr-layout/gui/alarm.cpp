/**
 * @file alarm.cpp
 * @author Realtek Semiconductor Corp.
 * @date May 2018
 * @brief The widget page to show alarm
 */

#include "alarm.h"
#include "ui_alarm.h"
#include "mainwidget.h"

Alarm::Alarm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Alarm)
{
    ui->setupUi(this);

    QList<QToolButton *> btnLayer1 = {ui->tbCurrent, ui->tbHistory, ui->tbSetting};
    tlAlarm = new RTabLayer(this);
    tlAlarm->init(btnLayer1, ui->stkLayer1, TABLAYER_LAYER_1);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;

    ui->lAlarm->setStyleSheet(STYLESHEET_TITLE_2);
    ui->pgManagement->installEventFilter(this);
    ui->pgExport->installEventFilter(this);
}

Alarm::~Alarm()
{
    delete tlAlarm;
    delete ui;
}

void Alarm::setup()
{
    initValue();
    tlAlarm->clickTabIndex(0);
}

void Alarm::initValue()
{
}

void Alarm::setGeometry(const QRect &rect)
{
//    qDebug() << __func__ << "(const QRect &rect)";
    QWidget::setGeometry(rect);

}

void Alarm::setGeometry(int x, int y, int w, int h)
{
//    qDebug() << __func__ << "(int x, int y, int w, int h)";
    this->setGeometry(QRect(x, y, w, h));
}

void Alarm::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

void Alarm::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    Q_UNUSED(keyboard);
    Q_UNUSED(keypad);
}

bool Alarm::eventFilter(QObject *o, QEvent *e)
{
    if(e->type() == QEvent::Show)
    {
    }
    return QObject::eventFilter(o, e);
}
