/**
 * @file ipcconnect.cpp
 * @author Realtek Semiconductor Corp.
 * @date May 2018
 * @brief The widget page to connect IPC
 */

#include "ipcconnect.h"
#include "ui_ipcconnect.h"
#include "mainwidget.h"

IpcConnect::IpcConnect(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::IpcConnect)
{
    ui->setupUi(this);

//    QList<QToolButton *> btnLayer1 = {ui->tbCurrent, ui->tbHistory, ui->tbSetting};
//    tlIpcConnect = new RTabLayer(this);
//    tlIpcConnect->init(btnLayer1, ui->stkLayer1, TABLAYER_LAYER_1);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;

    ui->lIpcConnect->setStyleSheet(STYLESHEET_TITLE_2);
//    ui->pgManagement->installEventFilter(this);
//    ui->pgExport->installEventFilter(this);

    lChannelList = new QList<QLabel*>();
    lStatusList = new QList<QLabel*>();
    edList = new QList<RLineEdit*>();
    comboBoxList = new QList<QComboBox*>();
    checkBoxList = new QList<RCheckBox*>();
    ui->widgetEdit->setStyleSheet("border:10px solid rgb(179, 179, 179);");
    ui->widgetEdit->setVisible(false);

    {   // Connect table initialization
        QLabel *lb;
        RLineEdit *edit;
        QComboBox *combo;
        RCheckBox *check;
        int i;
        QStringList horHeadList, verHeadList;

        ui->tableConnect->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);

        // Connect header
        for(i=0; i<CHANNEL_MAX; i++)
        {
            verHeadList.append(HLS_SUBDIR(i));
        }
        horHeadList << "Channel" << "Status" << "RTSP Command" << "Codec" << "Set";
        ui->tableConnect->setColumnCount(horHeadList.count());
        ui->tableConnect->setRowCount(verHeadList.count());
        ui->tableConnect->setHorizontalHeaderLabels(horHeadList);
        ui->tableConnect->horizontalHeader()->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE);
        ui->tableConnect->horizontalHeader()->setFixedHeight(TABLE_ITEM_HEIGHT);
        ui->tableConnect->verticalHeader()->setVisible(false);

        ui->tableConnect->setColumnWidth(0, 100);
        ui->tableConnect->setColumnWidth(1, 210);
        ui->tableConnect->setColumnWidth(2, 460);
        ui->tableConnect->setColumnWidth(3, 110);
        ui->tableConnect->setColumnWidth(4, 130);
        for(i=0; i<ui->tableConnect->rowCount(); i++)
        {
            ui->tableConnect->setRowHeight(i, TABLE_ITEM_HEIGHT);
        }

        // Connect item
        for(i=0; i<CHANNEL_MAX; i++)
        {
            lb = new QLabel();
            lb->setAlignment(Qt::AlignCenter | Qt::AlignVCenter);
            lb->setText(verHeadList.at(i));
            this->lChannelList->append(lb);
            ui->tableConnect->setCellWidget(i, 0, (QWidget*)lb);

            lb = new QLabel();
            lb->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            lb->setText("Disconnect");
            this->lStatusList->append(lb);
            ui->tableConnect->setCellWidget(i, 1, (QWidget*)lb);

            edit = new RLineEdit(this);
            this->edList->append(edit);
            ui->tableConnect->setCellWidget(i, 2, (QWidget*)edit);

            combo = new QComboBox();
            opt_AddOpt(combo, optVideoCodec, {});
            combo->setStyleSheet(STYLESHEET_COMBOBOX);
            this->comboBoxList->append(combo);
            ui->tableConnect->setCellWidget(i, 3, (QWidget*)combo);

            check = new RCheckBox();
            check->setText("Connect");
            this->checkBoxList->append(check);
            ui->tableConnect->setCellWidget(i, 4, (QWidget*)check);
        }
    }

    ui->chKnownIpc->setText("Known IPC");
    ui->chUserDefine->setText("User define");
    ui->leChannel->setVisible(false);

    connect(ui->chKnownIpc, SIGNAL(clicked(bool)), this, SLOT(knownIpc_clicked(bool)));
    connect(ui->chUserDefine, SIGNAL(clicked(bool)), this, SLOT(usrDefine_clicked(bool)));
    connect(ui->cbIp, SIGNAL(currentIndexChanged(int)), this, SLOT(ip_index_changed(int)));
    connect(ui->tbConnectcSet, SIGNAL(clicked(bool)), this, SLOT(set_clicked(bool)));
    connect(ui->tbRtspCancel,SIGNAL(clicked(bool)), this, SLOT(rtsp_cancel_clicked(bool)));
    connect(ui->tbRtspSet,SIGNAL(clicked(bool)), this, SLOT(rtsp_set_clicked(bool)));
}

IpcConnect::~IpcConnect()
{
    foreach(RCheckBox *check, *checkBoxList)
    {
        delete check;
    }
    delete checkBoxList;
    foreach(QComboBox *cb, *comboBoxList)
    {
        delete cb;
    }
    delete comboBoxList;
    foreach(RLineEdit *ed, *edList)
    {
        delete ed;
    }
    delete edList;
    foreach(QLabel *lb, *lStatusList)
    {
        delete lb;
    }
    delete lStatusList;
    foreach(QLabel *lb, *lChannelList)
    {
        delete lb;
    }
    delete lChannelList;
//    delete tlIpcConnect;
    delete ui;
}

void IpcConnect::setup()
{
    int i;
    for (i=0; i<CHANNEL_MAX; i++)
    {
        labelList->append(this->lChannelList->at(i));
        labelList->append(this->lStatusList->at(i));
        editList->append(this->edList->at(i));
        checkList->append(this->checkBoxList->at(i));
        if(Config::sys.onvifEnable)
        {
            edList->at(i)->installEventFilter(this);
        }
    }
    labelList->append({ui->lChannel, ui->lRTSP, ui->lProfile});
    editList->append(ui->leUserDefine);
    actionList->append({ui->tbConnectcSet, ui->tbRtspSet, ui->tbRtspCancel});

    ui->cbIp->setStyleSheet(STYLESHEET_COMBOBOX);
    ui->cbProfile->setStyleSheet(STYLESHEET_COMBOBOX);

    int min = std::min(CHANNEL_MAX, Config::sys.ipcChannelMax);
    int max = std::max(CHANNEL_MAX, Config::sys.ipcChannelMax);
    for (i=max-1; i>=min; i--)
    {
        ui->tableConnect->setRowHidden(i, true);
    }

    initValue();
}

void IpcConnect::initValue()
{
    for (int chIdx=0; chIdx<Config::sys.ipcChannelMax; chIdx++)
    {
        edList->at(chIdx)->setText(Config::ipc.ch[chIdx].rtspCmd);
        comboBoxList->at(chIdx)->setCurrentText(Config::ipc.ch[chIdx].codec);
        checkBoxList->at(chIdx)->setChecked(Config::ipc.ch[chIdx].ifConnect);
    }
}

void IpcConnect::setGeometry(const QRect &rect)
{
//    qDebug() << __func__ << "(const QRect &rect)";
    QWidget::setGeometry(rect);
    ui->widgetEdit->setGeometry((rect.width()-ui->widgetEdit->width())/2,
                                (rect.height()-ui->widgetEdit->height())/2,
                                ui->widgetEdit->width(),
                                ui->widgetEdit->height());
    foreach(RLineEdit *edit, *edList)
    {
        edit->setParentAbsoluteOffset(parent_absolute_offset_x+ui->tableConnect->x(),
                                      parent_absolute_offset_y+ui->tableConnect->y()+TABLE_ITEM_HEIGHT);
    }
    ui->leUserDefine->setParentAbsoluteOffset(parent_absolute_offset_x + ui->widgetEdit->x(),
                                              parent_absolute_offset_y + ui->widgetEdit->y());
}

void IpcConnect::setGeometry(int x, int y, int w, int h)
{
//    qDebug() << __func__ << "(int x, int y, int w, int h)";
    this->setGeometry(QRect(x, y, w, h));
}

void IpcConnect::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

void IpcConnect::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    if(Config::sys.onvifEnable == false)
    {
        foreach(RLineEdit *edit, *edList)
        {
            edit->installEventFilter(keyboard);
        }
    }
    ui->leUserDefine->installEventFilter(keyboard);
    Q_UNUSED(keypad);
}

bool IpcConnect::eventFilter(QObject *o, QEvent *e)
{
    if(e->type() == QEvent::MouseButtonPress)
    {
        if(Config::sys.onvifEnable)
        {
            int chIdx = -1;
            for(int i=0; i<Config::sys.ipcChannelMax; i++)
            {
                if(o == this->edList->at(i))
                {
                    chIdx = i;
                    break;
                }
            }
            if(chIdx >= 0)
            {
                ui->widgetEdit->setVisible(true);
                initWidgetEdit(chIdx);
            }

        }
    }
    return QObject::eventFilter(o, e);
}

void IpcConnect::showEvent(QShowEvent *)
{
    if(ui->widgetEdit->isVisible())
    {
        ui->widgetEdit->setVisible(false);
    }
}

void IpcConnect::initWidgetEdit(int chIdx)
{
    QStringList ipList;

//    qDebug() << __func__;

    ui->lChannel->setText("Channel " + HLS_SUBDIR(chIdx) + " RTSP Command");
    ui->leChannel->setText(lChannelList->at(chIdx)->text());
    ui->leUserDefine->setText(edList->at(chIdx)->text());

    ui->chKnownIpc->setChecked(false);
    ui->chUserDefine->setChecked(true);
    ui->cbIp->clear();
    if(ipList.count() > 0)
    {
        ui->cbIp->addItems(ipList);
        ui->cbIp->setCurrentIndex(0);   // trigger ip_index_changed(0)
    }
    else
    {
        ui->cbProfile->clear();
    }
    ui->cbIp->setStyleSheet(STYLESHEET_COMBOBOX);
}

void IpcConnect::knownIpc_clicked(bool)
{
    if(ui->chUserDefine->isChecked() == ui->chKnownIpc->isChecked())
        ui->chUserDefine->setChecked(!ui->chKnownIpc->isChecked());
}

void IpcConnect::usrDefine_clicked(bool)
{
    if(ui->chKnownIpc->isChecked() == ui->chUserDefine->isChecked())
        ui->chKnownIpc->setChecked(!ui->chUserDefine->isChecked());
}

void IpcConnect::ip_index_changed(int)
{
    QString strIp = ui->cbIp->currentText();
    ui->cbProfile->clear();

    ui->cbProfile->setStyleSheet(STYLESHEET_COMBOBOX);
}

void IpcConnect::rtsp_cancel_clicked(bool)
{
    ui->widgetEdit->setHidden(true);
}

void IpcConnect::rtsp_set_clicked(bool)
{
    int chIdx = -1;
    for (int i=0; i<lChannelList->count(); i++)
    {
        if(lChannelList->at(i)->text() == ui->leChannel->text())
        {
            chIdx = i;
            break;
        }
    }
    if(chIdx < 0)
    {
        dialog->showError(QString("Unknown %1 !").arg(ui->leChannel->text()));
        return;
    }
    if(ui->chUserDefine->isChecked())
    {
        edList->at(chIdx)->setText(ui->leUserDefine->text());
    }
    else
    {
    }
    ui->widgetEdit->setVisible(false);
}

void IpcConnect::set_clicked(bool)
{
    set_apply(true, true);
}

void IpcConnect::set_apply(bool ifDialog, bool ifSave)
{
    int chIdx, i;
    GridReal::GridStatus_E status;
    IPC_CH_S   *ipc_ch;
    bool bNeedDir;
    QList<bool> codecChangedList;

    bNeedDir = false;
    for(chIdx=0; chIdx<Config::sys.ipcChannelMax; chIdx++)
    {
        if (Config::ipc.ch[chIdx].ifStorage &&
            checkBoxList->at(chIdx)->isChecked())
        {
            bNeedDir = true;
        }
        codecChangedList.append(Config::ipc.ch[chIdx].codec != comboBoxList->at(chIdx)->currentText());
    }
    if(bNeedDir)
    {
        if (!hlsProcess->checkAndMkDir(Config::absoluteHlsDirPath))
        {
            return;
        }
    }

    if(ifSave)
    {
        for(chIdx=0; chIdx<Config::sys.ipcChannelMax; chIdx++)
        {
            Config::ipc.ch[chIdx].ifConnect = checkBoxList->at(chIdx)->isChecked();
            Config::ipc.ch[chIdx].codec = comboBoxList->at(chIdx)->currentText();
            Config::ipc.ch[chIdx].rtspCmd = this->edList->at(chIdx)->text();
        }
        Config::saveDefaultProfile();
    }

    // stop first, then add
    for(i=0; i<Config::sys.ipcChannelMax; i++)
    {
        chIdx = viewProcess->ipc_gridReal[i].channelIndex;
        status = viewProcess->ipc_gridReal[i].status;
        ipc_ch = &Config::ipc.ch[chIdx];
        if (status != GridReal::GridStatus_NONE &&
            (ipc_ch->ifConnect == false || codecChangedList.at(i)))
        {
            viewProcess->ipc_stop(i, Config::sys.seamless);
        }
    }

    // then add
    for(i=0; i<Config::sys.ipcChannelMax; i++)
    {
        chIdx = viewProcess->ipc_gridReal[i].channelIndex;
        status = viewProcess->ipc_gridReal[i].status;
        ipc_ch = &Config::ipc.ch[chIdx];
        if (ipc_ch->ifConnect == true)
        {
            if (status != GridReal::GridStatus_PLAY ||
                ipc_ch->rtspCmd != viewProcess->ipc_gridReal[i].rtspCmd ||
                codecChangedList.at(i))
            {
                viewProcess->ipc_start(i, ipc_ch->rtspCmd);
                if (ipc_ch->ifStorage)
                {
                    viewProcess->ipc_rec_start(i);
                }
            }
        }
    }

    if(ifDialog)
    {
        dialog->showInfo(STR_SETTING_APPLY);
    }
}
