/**
 * @file system.h
 * @author Realtek Semiconductor Corp.
 * @date Dec 2017
 * @brief The widget page to do system setting
 */

#ifndef SYSTEM_H
#define SYSTEM_H

#include <QWidget>
#include "rtablayer.h"
#include "rslider.h"

namespace Ui {
class System;
}

class System : public QWidget
{
    Q_OBJECT

public:
    RSlider *rsBrightness, *rsContrast, *rsHue, *rsSaturation, *rsSharpness;

    explicit System(QWidget *parent = 0);
    ~System();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setParentAbsoluteOffset(int x, int y);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);

private:
    Ui::System *ui;
    RTabLayer *tlSystem, *tlDatetime, *tlDisplay;
    int parent_absolute_offset_x, parent_absolute_offset_y;
    QTimer *imgBrightnessTimer, *imgContrastTimer, *imgHueTimer, *imgSaturationTimer,
            *imgSharpnessTimer, *imgBgColorRTimer, *imgBgColorGTimer, *imgBgColorBTimer;

    void initValue(bool fromStatus);
    void getDisplayImage(bool fromStatus);
    void getFb(bool fromStatus);
    void getBackground(bool fromStatus);
    void getOutput(bool fromStatus);
    void updateTimeSymbol();
    void bgColor_set(bool ifDialog);
    void fb_set();
    void output_set(bool ifDialog);
    void admin_set(bool ifDialog);

private slots:
    void calendar_day_clicked();
    void calendar_clicked(bool);
    void current_set_clicked(bool);
    void format_set_clicked(bool);
    void image_reset_clicked(bool);
    void output_set_clicked(bool);
    void bgColor_set_clicked(bool);
    void fb_set_clicked(bool);
    void admin_set_clicked(bool);
    void brightness_value_changed(int);
    void contrast_value_changed(int);
    void hue_value_changed(int);
    void saturation_value_changed(int);
    void sharpness_value_changed(int);
    void bgColor_value_changed(int);
    void apply_brightness();
    void apply_contrast();
    void apply_hue();
    void apply_saturation();
    void apply_sharpness();
    void preview_bgColor();

protected:
//    void showEvent(QShowEvent *);
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // SYSTEM_H
