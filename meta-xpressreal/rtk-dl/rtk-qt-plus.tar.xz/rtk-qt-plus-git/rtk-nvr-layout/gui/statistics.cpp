/**
 * @file statistics.cpp
 * @author Realtek Semiconductor Corp.
 * @date May 2018
 * @brief The widget page to do statistics report
 */

#include "statistics.h"
#include "ui_statistics.h"
#include "mainwidget.h"
#include "rtksim.h"

Statistics::Statistics(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Statistics)
{
    ui->setupUi(this);

    QList<QToolButton *> btnLayer1 = {ui->tbDisplay, ui->tbSupplicant};
    tlStatistics = new RTabLayer(this);
    tlStatistics->init(btnLayer1, ui->stkLayer1, TABLAYER_LAYER_1);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;

    ui->lStatistics->setStyleSheet(STYLESHEET_TITLE_2);
    ui->pgDisplay->installEventFilter(this);
    ui->pgSupplicant->installEventFilter(this);

    lbDispList = new QList<QLabel*>();
    lbSuppList = new QList<QLabel*>();
    tbResetDispList = new QList<QToolButton*>();
    tbResetSuppList = new QList<QToolButton*>();
    ui->checkAutoRefresh->setText("Auto refresh with interval ");
    ui->cbRefreshInterval->addItems({"0.1", "0.5", "1", "2", "3", "5", "10"});
    ui->cbRefreshInterval->setCurrentIndex(2);

    refreshTimer = new QTimer(this);

    connect(refreshTimer,   SIGNAL(timeout()), this, SLOT(getDispStatistics()));
    connect(ui->cbRefreshInterval,  SIGNAL(currentIndexChanged(int)), this, SLOT(refresh_interval_changed(int)));
    connect(ui->checkAutoRefresh,   SIGNAL(clicked(bool)), this, SLOT(refresh_action(bool)));
    connect(ui->tbDispRefreshSet, SIGNAL(pressed()), this, SLOT(getDispStatistics()));
    connect(ui->tbSuppRefreshSet, SIGNAL(pressed()), this, SLOT(getSuppStatistics()));
}

Statistics::~Statistics()
{
    delete refreshTimer;
    foreach(QLabel *lb, *lbDispList)
    {
        delete lb;
    }
    delete lbDispList;
    foreach(QToolButton *tb, *tbResetDispList)
    {
        delete tb;
    }
    delete tbResetDispList;
    foreach(QLabel *lb, *lbSuppList)
    {
        delete lb;
    }
    delete lbSuppList;
    foreach(QToolButton *tb, *tbResetSuppList)
    {
        delete tb;
    }
    delete tbResetSuppList;
    delete tlStatistics;
    delete ui;
}

void Statistics::setup()
{
    QLabel *lb;
    QToolButton *tb;
    QStringList dispHorHeadList, dispVerHeadList, suppHorHeadList, suppVerHeadList;
    int i, j;

    ui->tableDisplay->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
    ui->tableSupplicant->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
//    ui->tableDisplay->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE);

    // Display header
    for(i=0; i<Config::sys.ipcChannelMax; i++)
    {
        dispVerHeadList.append("Channel " + HLS_SUBDIR(i));
    }
    dispHorHeadList << "Channel" << "WndId" << "ChId" << "Blank" << "BufferWrtie" << "Size\r\nZero" << "Connect\r\nError" << "Write\r\nError" << "Reset";
    ui->tableDisplay->setColumnCount(dispHorHeadList.count());
    ui->tableDisplay->setRowCount(dispVerHeadList.count());
    ui->tableDisplay->setHorizontalHeaderLabels(dispHorHeadList);
    ui->tableDisplay->horizontalHeader()->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE);
    ui->tableDisplay->verticalHeader()->setVisible(false);

    ui->tableDisplay->setColumnWidth(0, 120);
    ui->tableDisplay->setColumnWidth(1, 80);
    ui->tableDisplay->setColumnWidth(2, 70);
    ui->tableDisplay->setColumnWidth(3, 70);
    ui->tableDisplay->setColumnWidth(4, 200);
    ui->tableDisplay->setColumnWidth(5, 100);
    ui->tableDisplay->setColumnWidth(6, 100);
    ui->tableDisplay->setColumnWidth(7, 100);
    ui->tableDisplay->setColumnWidth(8, 120);
    for(i=0; i<ui->tableDisplay->rowCount(); i++)
    {
        ui->tableDisplay->setRowHeight(i, TABLE_ITEM_HEIGHT);
    }

    // Display item
    for(i=0; i<Config::sys.ipcChannelMax; i++)
    {
        for(j=0; j<dispHorHeadList.count()-1; j++)
        {
            lb = new QLabel();
            if(j<4)
            {
                if(j==0)
                {
                    lb->setText(dispVerHeadList.at(i));
                }
                lb->setAlignment(Qt::AlignCenter | Qt::AlignVCenter);
            }
            else
            {
                lb->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            }
            lb->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE_BG \
                              "font: bold 16px \"Arial Black\";"      \
                              "color: rgb(255, 255, 255);"
                              "padding:2px;");
            lbDispList->append(lb);
            ui->tableDisplay->setCellWidget(i, j, (QWidget*)lb);
        }
        tb = new QToolButton();
        tb->setText("Reset " + HLS_SUBDIR(i));
        tb->installEventFilter(this);
        tbResetDispList->append(tb);
        actionList->append(tb);
        ui->tableDisplay->setCellWidget(i, dispHorHeadList.count()-1, (QWidget*)tb);
        connect(tb, SIGNAL(clicked(bool)), this, SLOT(btn_disp_reset_clicked(bool)));
    }

    // Supplicant header
    for(i=0; i<CH_MAX; i++)
    {
        suppVerHeadList.append(QString().asprintf("ChId %02d", i));
    }
    suppHorHeadList << "ChId" << "BufferWrtie" << "Size\r\nZero" << "Connect\r\nError" << "Write\r\nError" << "Reset";
    ui->tableSupplicant->setColumnCount(suppHorHeadList.count());
    ui->tableSupplicant->setRowCount(suppVerHeadList.count());
    ui->tableSupplicant->setHorizontalHeaderLabels(suppHorHeadList);
    ui->tableSupplicant->setVerticalHeaderLabels(suppVerHeadList);
    ui->tableSupplicant->horizontalHeader()->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE);
    ui->tableSupplicant->verticalHeader()->setVisible(false);

    ui->tableSupplicant->setColumnWidth(0, 90);
    ui->tableSupplicant->setColumnWidth(1, 200);
    ui->tableSupplicant->setColumnWidth(2, 140);
    ui->tableSupplicant->setColumnWidth(3, 140);
    ui->tableSupplicant->setColumnWidth(4, 140);
    ui->tableSupplicant->setColumnWidth(5, 180);
    for(i=0; i<ui->tableSupplicant->rowCount(); i++)
    {
        ui->tableSupplicant->setRowHeight(i, 40);
    }

    // Supplicant item
    for(i=0; i<CH_MAX; i++)
    {
        for(j=0; j<suppHorHeadList.count()-1; j++)
        {
            lb = new QLabel();

            if(j==0)
            {
                lb->setText(suppVerHeadList.at(i));
                lb->setAlignment(Qt::AlignCenter | Qt::AlignVCenter);
            }
            else
            {
                lb->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            }
            lb->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE_BG \
                              "font: bold 16px \"Arial Black\";"      \
                              "color: rgb(255, 255, 255);"
                              "padding:2px;");
            lbSuppList->append(lb);
            ui->tableSupplicant->setCellWidget(i, j, (QWidget*)lb);
        }
        tb = new QToolButton();
        tb->setText(QString().asprintf("Reset ChId %02d", i));
        tb->installEventFilter(this);
        tbResetSuppList->append(tb);
        actionList->append(tb);
        ui->tableSupplicant->setCellWidget(i, suppHorHeadList.count()-1, (QWidget*)tb);
        connect(tb, SIGNAL(clicked(bool)), this, SLOT(btn_supp_reset_clicked(bool)));
    }

    labelList->append({ui->lIntervalUnit});
    actionList->append({ui->tbDispRefreshSet, ui->tbSuppRefreshSet});
#if 0
    optionList->append({ui->cbRefreshInterval});
#else
    ui->cbRefreshInterval->setStyleSheet(STYLESHEET_COMBOBOX);
#endif
    tlStatistics->clickTabIndex(0);
}

void Statistics::initValue(bool fromStatus)
{
    if(ui->pgDisplay->isVisible())
    {
        getDispStatistics();
        refresh_action(true);
    }
    else if(ui->pgSupplicant->isVisible())
    {
        getSuppStatistics();
    }
    Q_UNUSED(fromStatus);
}

void Statistics::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);
#if 0
    RLineEdit *le;
    int tab_x_offset = parent_absolute_offset_x+rect.x()+ui->stkLayer1->x()+ui->stkDatetime->x();
    int tab_y_offset = parent_absolute_offset_y+rect.y()+ui->stkLayer1->y()+ui->stkDatetime->y();

    QList<RLineEdit *>leDatetimeList = {
                        ui->leCurrentH, ui->leCurrentM, ui->leCurrentS};
    foreach(le, leDatetimeList)
    {
        le->setParentAbsoluteOffset(tab_x_offset, tab_y_offset);
    }
#endif
//    qDebug()<<"tab_x_offset" << tab_x_offset <<"tab_y_offset" << tab_y_offset;
}

void Statistics::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void Statistics::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

void Statistics::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    QList<RLineEdit *>keyboardList = {};
    QList<RLineEdit *>keybadList = {};
    RLineEdit *le;
    foreach(le, keyboardList)
    {
        le->installEventFilter(keyboard);
    }
    foreach(le, keybadList)
    {
        le->installEventFilter(keypad);
    }
}

//void Statistics::showEvent(QShowEvent *)
//{
//    initValue(true);
//}

bool Statistics::eventFilter(QObject *o, QEvent *e)
{
    if(e->type() == QEvent::Show)
    {
        if(o==ui->pgDisplay ||
           o==ui->pgSupplicant)
        {
            initValue(true);
        }
    }
    else if(e->type() == QEvent::Hide)
    {
        if(o==ui->pgDisplay)
        {
            if(refreshTimer->isActive())
                refreshTimer->stop();
        }
    }
    else if(e->type() == QEvent::MouseButtonPress && o!=NULL)
    {
        _rcvObject = o;
    }
    return QObject::eventFilter(o, e);
}

void Statistics::refresh_interval_changed(int)
{
    refresh_action(true);
}

void Statistics::refresh_action(bool)
{
    if(ui->checkAutoRefresh->isChecked())
    {
        refreshTimer->start(ui->cbRefreshInterval->currentText().toDouble() * 1000);
    }
    else
    {
        refreshTimer->stop();
    }
}

void Statistics::btn_disp_reset_clicked(bool)
{
    int idx;
    GridReal *gridIpc;
    for(int chIdx=0; chIdx<tbResetDispList->count(); chIdx++)
    {
        if(_rcvObject == tbResetDispList->at(chIdx))
        {
            _rcvObject = NULL;
            idx = viewProcess->get_ipc_array_idx(chIdx);
            gridIpc =  &viewProcess->ipc_gridReal[idx];
            if(gridIpc->channelId > ChannelId_Invalid)
            {
                if(rtkApi->qt_rtk_ipc_debug_reset(STR_IPC, idx, chIdx, gridIpc->channelId))
                {
                    getDispStatistics();
                }
            }
        }
    }
}

void Statistics::btn_supp_reset_clicked(bool)
{
    for(int chId=0; chId<tbResetSuppList->count(); chId++)
    {
        if(_rcvObject == tbResetSuppList->at(chId))
        {
            _rcvObject = NULL;
            if(rtkApi->qt_rtk_ipc_debug_reset(chId))
            {
                getSuppStatistics();
            }
        }
    }
}

void Statistics::getDispStatistics()
{
    int idx;
    bool bWindowIdValid = false;
    bool bChannelIdValid = false;
    GridReal *gridIpc;
    QString strInvalid = "x";
    QString strWnd, strCh;
    bool bBlank = false;
    unsigned long long bufferWriteCnt, sizeZeroCnt, connectErrCnt, writeErrCnt;
    for(int chIdx=0; chIdx<Config::sys.ipcChannelMax; chIdx++)
    {
        idx = viewProcess->get_ipc_array_idx(chIdx);
        gridIpc =  &viewProcess->ipc_gridReal[idx];
        bufferWriteCnt = 0;
        sizeZeroCnt = 0;
        connectErrCnt = 0;
        writeErrCnt = 0;
        bWindowIdValid = (gridIpc->wndId > WindowId_Invalid);
        bChannelIdValid = (gridIpc->channelId > ChannelId_Invalid);
        if(bWindowIdValid)
        {
            rtkApi->qt_rtk_disp_get_blank(STR_IPC, idx, chIdx, gridIpc->wndId, &bBlank);
        }
        if(bChannelIdValid)
        {
            rtkApi->qt_rtk_ipc_debug_getInfo(STR_IPC, idx, chIdx, gridIpc->channelId,
                                            &bufferWriteCnt, &sizeZeroCnt,
                                            &connectErrCnt, &writeErrCnt);
        }
        strWnd = bWindowIdValid ?
                    QString("%1").arg(gridIpc->wndId) : strInvalid;
        strCh = bChannelIdValid ?
                    QString("%1").arg(gridIpc->channelId) : strInvalid;
        ((QLabel*)ui->tableDisplay->cellWidget(chIdx, 1))->setText(strWnd);
        ((QLabel*)ui->tableDisplay->cellWidget(chIdx, 2))->setText(strCh);

        ((QLabel*)ui->tableDisplay->cellWidget(chIdx, 3))->setText(bBlank ? "Y" : "N");
        if(((QLabel*)ui->tableDisplay->cellWidget(chIdx, 3))->isVisible() != bWindowIdValid)
        {
            ((QLabel*)ui->tableDisplay->cellWidget(chIdx, 3))->setVisible(bWindowIdValid);
        }

        ((QLabel*)ui->tableDisplay->cellWidget(chIdx, 4))->setText(QString().asprintf("%lld", bufferWriteCnt));
        ((QLabel*)ui->tableDisplay->cellWidget(chIdx, 5))->setText(QString().asprintf("%lld", sizeZeroCnt));
        ((QLabel*)ui->tableDisplay->cellWidget(chIdx, 6))->setText(QString().asprintf("%lld", connectErrCnt));
        ((QLabel*)ui->tableDisplay->cellWidget(chIdx, 7))->setText(QString().asprintf("%lld", writeErrCnt));
        if(tbResetDispList->at(chIdx)->isVisible() != bChannelIdValid)
        {
            ((QLabel*)ui->tableDisplay->cellWidget(chIdx, 4))->setVisible(bChannelIdValid);
            ((QLabel*)ui->tableDisplay->cellWidget(chIdx, 5))->setVisible(bChannelIdValid);
            ((QLabel*)ui->tableDisplay->cellWidget(chIdx, 6))->setVisible(bChannelIdValid);
            ((QLabel*)ui->tableDisplay->cellWidget(chIdx, 7))->setVisible(bChannelIdValid);
            tbResetDispList->at(chIdx)->setVisible(bChannelIdValid);
        }
    }
}

void Statistics::getSuppStatistics()
{
    unsigned long long bufferWriteCnt, sizeZeroCnt, connectErrCnt, writeErrCnt;
    for(int chId=0; chId<CH_MAX; chId++)
    {
        bufferWriteCnt = 0;
        sizeZeroCnt = 0;
        connectErrCnt = 0;
        writeErrCnt = 0;

        rtkApi->qt_rtk_ipc_debug_getInfo(chId,
                                        &bufferWriteCnt, &sizeZeroCnt,
                                        &connectErrCnt, &writeErrCnt, true);

        ((QLabel*)ui->tableSupplicant->cellWidget(chId, 1))->setText(QString().asprintf("%lld", bufferWriteCnt));
        ((QLabel*)ui->tableSupplicant->cellWidget(chId, 2))->setText(QString().asprintf("%lld", sizeZeroCnt));
        ((QLabel*)ui->tableSupplicant->cellWidget(chId, 3))->setText(QString().asprintf("%lld", connectErrCnt));
        ((QLabel*)ui->tableSupplicant->cellWidget(chId, 4))->setText(QString().asprintf("%lld", writeErrCnt));
    }
}
