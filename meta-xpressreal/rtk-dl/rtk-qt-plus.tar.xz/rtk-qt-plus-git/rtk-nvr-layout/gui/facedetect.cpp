/**
 * @file facedetect.cpp
 * @author Realtek Semiconductor Corp.
 * @date Apri 2018
 * @brief The widget page to set face detect
 */

#include "facedetect.h"
#include "ui_facedetect.h"
#include "mainwidget.h"

FaceDetect::FaceDetect(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FaceDetect)
{
    ui->setupUi(this);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;

    gridReal = NULL;

    ui->widgetFaceDetect->setStyleSheet("background-color: rgba(20, 25, 28, 200);");
    connect(ui->tbSet, SIGNAL(clicked(bool)), this, SLOT(set_clicked(bool)));
}

FaceDetect::~FaceDetect()
{
    delete ui;
}

void FaceDetect::setup()
{
    labelList->append(ui->lName);
    editList->append(ui->leName);
    actionList->append(ui->tbSet);
    initValue();
}

void FaceDetect::initValue()
{
    ui->leName->setText(strName);
}

void FaceDetect::showEvent(QShowEvent *event)
{
    Q_UNUSED(event);
    initValue();
#if 0
    // TBD： start face detection api
#endif
}

void FaceDetect::hideEvent(QShowEvent *event)
{
    Q_UNUSED(event);
#if 0
    // TBD： stop face detection api
#endif
}

void FaceDetect::setGeometry(const QRect &rect)
{
//    qDebug() << __func__ << "(const QRect &rect)";
    QWidget::setGeometry(rect);

    int tab_x_offset = parent_absolute_offset_x+rect.x();
    int tab_y_offset = parent_absolute_offset_y+rect.y();

    ui->widgetFaceDetect->setGeometry(0, 0, rect.width(),rect.height());
    ui->leName->setParentAbsoluteOffset(tab_x_offset, tab_y_offset);
}

void FaceDetect::setGeometry(int x, int y, int w, int h)
{
//    qDebug() << __func__ << "(int x, int y, int w, int h)";
    this->setGeometry(QRect(x, y, w, h));
}

void FaceDetect::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    ui->leName->installEventFilter(keyboard);
    Q_UNUSED(keypad);
}

void FaceDetect::setGridReal(GridReal *gridReal)
{
    this->gridReal = gridReal;
}

void FaceDetect::set_clicked(bool)
{
    if(gridReal == NULL)
        return;

#if 0
    QString newName = ui->leName->text();
    int wndId = gridReal->wndId;
    int channelId = gridReal->channelId;

    // TBD
    if(RTK_SET_NAME(   newName.toStdString().c_str()) == RTK_SUCCESS)
    {
        strName = newName;
        dialog->showInfo(STR_SETTING_APPLY);
    }
    else
    {
        dialog->showError(STR_SETTING_FAILED);
    }
#endif
}
