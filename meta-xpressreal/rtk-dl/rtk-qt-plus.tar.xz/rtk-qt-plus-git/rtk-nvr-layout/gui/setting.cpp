/**
 * @file setting.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page to do setting
 */

#include "setting.h"
#include "ui_setting.h"
#include "mainwidget.h"

Setting::Setting(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Setting)
{
    ui->setupUi(this);

    this->network = ui->network;
    this->ipc = ui->ipc;
    this->storage = ui->storage;
    this->system = ui->system;
//    this->setStyleSheet("background-color: rgb(20, 25, 28);");
    ui->lTitle->setStyleSheet(STYLESHEET_TITLE_1);
    ui->wOption->setStyleSheet("background-color: rgb(0, 5, 0);");
    ui->wContent->setStyleSheet("background-color: rgb(20, 25, 28);");

//    ui->tbNetwork->setToolTip("Network");
//    ui->tbIPC->setToolTip("IPC");
//    ui->tbStorage->setToolTip("Storage");

    connect(ui->tbNetwork,  SIGNAL(clicked(bool)), this, SLOT(setNetwork(bool)));
    connect(ui->tbIPC,      SIGNAL(clicked(bool)), this, SLOT(setIPC(bool)));
    connect(ui->tbStorage,  SIGNAL(clicked(bool)), this, SLOT(setStorage(bool)));
    connect(ui->tbSystem,  SIGNAL(clicked(bool)), this, SLOT(setSystem(bool)));
}

Setting::~Setting()
{
    delete ui;
}

void Setting::setup()
{
    network->setup();
    system->setup();
    setNetwork(true);
}

void Setting::setGeometry(const QRect &rect)
{
    const int margin = 120;
    int width = rect.width()-margin;
    if (width < 0)
        width = 0;

    QWidget::setGeometry(rect);
    ui->wOption->setGeometry(0, 0, margin, rect.height());
    ui->wContent->setGeometry(margin,0,width,rect.height());

    ui->network->setParentAbsoluteOffset(rect.x()+margin, rect.y());
    ui->ipc->setParentAbsoluteOffset(rect.x()+margin, rect.y());
    ui->storage->setParentAbsoluteOffset(rect.x()+margin, rect.y());
    ui->system->setParentAbsoluteOffset(rect.x()+margin, rect.y());

    ui->network->setGeometry(0, 0, width, rect.height());
    ui->ipc->setGeometry(0, 0, width, rect.height());
    ui->storage->setGeometry(0, 0, width, rect.height());
    ui->system->setGeometry(0, 0, width, rect.height());
}

void Setting::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void Setting::setOption(QToolButton *btn)
{
    QToolButton *btnOpt[] = {ui->tbNetwork, ui->tbIPC, ui->tbStorage, ui->tbSystem, NULL};
    QWidget *widget[] = {ui->network, ui->ipc, ui->storage, ui->system, NULL};
    int i=0;
    while (btnOpt[i] != NULL)
    {
        if(btnOpt[i] == btn)
        {
            btnOpt[i]->setStyleSheet("QToolButton{"
                                        "background-color: rgba(158, 184, 184, 0.2);"
                                        "}"
                                     "QToolButton:hover{"
                                        "background-color: rgba(158, 184, 184, 0.2);"
                                        "}"
                                    );
            widget[i]->setVisible(true);
            widget[i]->raise();
        }
        else
        {
            btnOpt[i]->setStyleSheet("QToolButton{"
                                        "background-color: rgb(0, 5, 0);"
                                        "}"
                                     "QToolButton:hover{"
                                        "background-color: rgba(158, 184, 184, 0.2);"
                                        "}"
                                    );
            widget[i]->setVisible(false);
        }
        i++;
    }
    if(btn == ui->tbIPC)
    {
        ui->wContent->setStyleSheet("background-color: transparent;");
    }
    else
    {
        ui->wContent->setStyleSheet("background-color: rgb(20, 25, 28);");
    }
}

void Setting::setNetwork(bool)
{
    setOption(ui->tbNetwork);
}

void Setting::setIPC(bool)
{
    setOption(ui->tbIPC);
}

void Setting::setStorage(bool)
{
    setOption(ui->tbStorage);
}

void Setting::setSystem(bool)
{
    setOption(ui->tbSystem);
}
