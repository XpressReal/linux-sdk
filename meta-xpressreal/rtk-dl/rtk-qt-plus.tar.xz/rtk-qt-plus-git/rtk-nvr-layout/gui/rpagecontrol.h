/**
 * @file rpagecontrol.h
 * @author Realtek Semiconductor Corp.
 * @date April 2018
 * @brief The page operation for list or table
 */

#ifndef RPAGECONTROL_H
#define RPAGECONTROL_H
#include <QToolButton>
#include "rlineedit.h"

class RPageControl : public QWidget
{
    Q_OBJECT

public:
    RPageControl(QWidget *parent = 0);
    ~RPageControl();

    void initItemPerPage(int itemPerPage);
    void setParentAbsoluteOffset(int x, int y);
    void setButtonSize(int size);
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void installEventFilterForKeypad(QObject *keypad);

    void setItemCount(int count);
    void setItemPerPage(int count);
    int getItemPerPage();
    int getPageCurr();
    void pageUpdate(bool ifSignal=true);

private:
    QToolButton *btnPrev, *btnNext;
    QLabel *lTotal;
    RLineEdit *leCurrent;
    int pageCurr;   // 0 ~ (pageCount-1)
    int pageCount;
    int itemPerPage, itemCount;
    int btnSize;
    int parent_absolute_offset_x, parent_absolute_offset_y;

//    QString getText(double currentValue);
    void updatePageCount();

signals:
    void pageUpdated();

private slots:
    void closeKeyboard();
    void pagePrev(bool);
    void pageNext(bool);

protected:
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // RPAGECONTROL_H
