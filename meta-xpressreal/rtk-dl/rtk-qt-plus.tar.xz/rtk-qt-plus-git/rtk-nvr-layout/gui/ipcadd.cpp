/**
 * @file ipcadd.cpp
 * @author Realtek Semiconductor Corp.
 * @date May 2018
 * @brief The widget page to add IP camera
 */

#include "ipcadd.h"
#include "ui_ipcadd.h"
#include "mainwidget.h"

IpcAdd::IpcAdd(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::IpcAdd)
{
    ui->setupUi(this);

    this->ipcConnect = ui->ipcConnect;
    this->ipcDetect = ui->ipcDetect;
//    this->setStyleSheet("background-color: rgb(20, 25, 28);");
    ui->lTitle->setStyleSheet(STYLESHEET_TITLE_1);
    ui->wOption->setStyleSheet("background-color: rgb(0, 5, 0);");
    ui->wContent->setStyleSheet("background-color: rgb(20, 25, 28);");

    ui->tbIpcConnect->setStyleSheet("color: rgb(179, 179, 179);");
    ui->tbIpcDetect->setStyleSheet("color: rgb(179, 179, 179);");
//    ui->tbIpcConnect->setToolTip("IPC Connect");
//    ui->tbIpcDetect->setToolTip("IPC Detect");

    connect(ui->tbIpcConnect, SIGNAL(clicked(bool)), this, SLOT(setIpcConnect(bool)));
    connect(ui->tbIpcDetect,  SIGNAL(clicked(bool)), this, SLOT(setIpcDetect(bool)));
}

IpcAdd::~IpcAdd()
{
    delete ui;
}

void IpcAdd::setup()
{
    ipcConnect->setup();
    ipcDetect->setup();
    setIpcConnect(true);
    if(Config::sys.onvifEnable != true)
    {
        ui->tbIpcDetect->setVisible(false);
    }
}

void IpcAdd::setGeometry(const QRect &rect)
{
    const int margin = 120;
    int width = rect.width()-margin;
    if (width < 0)
        width = 0;

    QWidget::setGeometry(rect);
    ui->wOption->setGeometry(0, 0, margin, rect.height());
    ui->wContent->setGeometry(margin,0,width,rect.height());

    ui->ipcConnect->setParentAbsoluteOffset(rect.x()+margin, rect.y());
    ui->ipcDetect->setParentAbsoluteOffset(rect.x()+margin, rect.y());

    ui->ipcConnect->setGeometry(0, 0, width, rect.height());
    ui->ipcDetect->setGeometry(0, 0, width, rect.height());
}

void IpcAdd::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void IpcAdd::setOption(QToolButton *btn)
{
    QToolButton *btnOpt[] = {ui->tbIpcConnect, ui->tbIpcDetect, NULL};
    QWidget *widget[] = {ui->ipcConnect, ui->ipcDetect, NULL};
    int i=0;
    while (btnOpt[i] != NULL)
    {
        if(btnOpt[i] == btn)
        {
            btnOpt[i]->setStyleSheet("QToolButton{"
                                        "background-color: rgba(158, 184, 184, 0.2);"
                                        "color: rgb(179, 179, 179);"
                                        "font: bold 20px \"Arial\";"
                                        "}"
                                     "QToolButton:hover{"
                                        "background-color: rgba(158, 184, 184, 0.2);"
                                        "color: rgb(179, 179, 179);"
                                        "font: bold 20px \"Arial\";"
                                        "}"
                                    );
            widget[i]->setVisible(true);
            widget[i]->raise();
        }
        else
        {
            btnOpt[i]->setStyleSheet("QToolButton{"
                                        "background-color: rgb(0, 5, 0);"
                                        "color: rgb(179, 179, 179);"
                                        "font: bold 20px \"Arial\";"
                                        "}"
                                     "QToolButton:hover{"
                                        "background-color: rgba(158, 184, 184, 0.2);"
                                        "color: rgb(179, 179, 179);"
                                        "font: bold 20px \"Arial\";"
                                        "}"
                                    );
            widget[i]->setVisible(false);
        }
        i++;
    }
}

void IpcAdd::setIpcConnect(bool)
{
    setOption(ui->tbIpcConnect);
}

void IpcAdd::setIpcDetect(bool)
{
    setOption(ui->tbIpcDetect);
}
