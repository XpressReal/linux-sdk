/**
 * @file storage.h
 * @author Realtek Semiconductor Corp.
 * @date Oct 2017
 * @brief The widget page to do storage
 */

#ifndef STORAGE_H
#define STORAGE_H

#include <QWidget>
#include <QList>
#include <QLabel>
#include <QGridLayout>
#include "rlineedit.h"
#include "rtablayer.h"
#include "rcheckbox.h"
#include "define.h"

namespace Ui {
class Storage;
}

class Storage : public QWidget
{
    Q_OBJECT

public:
    explicit Storage(QWidget *parent = 0);
    ~Storage();

    QList<QLabel*> *lChannelList, *lStatusList;
    QList<RCheckBox*> *checkBoxList;

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setParentAbsoluteOffset(int x, int y);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);
    void doIdxRec(int idx, bool doRec);

private:
    Ui::Storage *ui;
    RTabLayer *tlStorage;
    int parent_absolute_offset_x, parent_absolute_offset_y;

    void initValue();
    void processRec(int idx, bool bNewDir);

private slots:
    void manage_set_clicked(bool);

protected:
//    void showEvent(QShowEvent *event);
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // STORAGE_H
