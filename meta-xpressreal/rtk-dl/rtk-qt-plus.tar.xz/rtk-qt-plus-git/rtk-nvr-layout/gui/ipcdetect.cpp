/**
 * @file ipcdetect.cpp
 * @author Realtek Semiconductor Corp.
 * @date May 2018
 * @brief The widget page to detect IPC
 */

#include "ipcdetect.h"
#include "ui_ipcdetect.h"
#include "mainwidget.h"

#define TABIDX_READY_SELECT 0
#define TABIDX_READY_IP     1
#define TABIDX_READY_PORT   2
#define TABIDX_READY_STATUS 3
#define TABIDX_READY_USER   4
#define TABIDX_READY_PASSWD 5
#define TABIDX_READY_URL    6
#define TABIDX_READY_EDIT   7
#define TABIDX_WAIT_IP      0
#define TABIDX_WAIT_URL     1
#define TABIDX_WAIT_ADD     2

IpcDetect::IpcDetect(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::IpcDetect)
{
    ui->setupUi(this);

//    QList<QToolButton *> btnLayer1 = {ui->tbCurrent, ui->tbHistory, ui->tbSetting};
//    tlIpcDetect = new RTabLayer(this);
//    tlIpcDetect->init(btnLayer1, ui->stkLayer1, TABLAYER_LAYER_1);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;

    ui->lIpcDetect->setStyleSheet(STYLESHEET_TITLE_2);
//    ui->pgManagement->installEventFilter(this);
//    ui->pgExport->installEventFilter(this);
    installEventFilter(this);

    lbList = new QList<QLabel*>();
    checkReadyList = new QList<RCheckBox*>();
    tbReadyList = new QList<QToolButton*>();
    tbWaitList = new QList<QToolButton*>();
    ui->widgetEdit->setStyleSheet("border:10px solid rgb(179, 179, 179);");
    ui->widgetEdit->setVisible(false);
    ui->leWsdlUrl->setVisible(false);

    connect(ui->tbEdit, SIGNAL(clicked(bool)), this, SLOT(edit_clicked(bool)));
    connect(ui->tbCancel, SIGNAL(clicked(bool)), this, SLOT(cancel_clicked(bool)));
    connect(ui->tbReadyRefresh, SIGNAL(clicked(bool)), this, SLOT(readyRefresh_clicked(bool)));
    connect(ui->tbReadyRemove, SIGNAL(clicked(bool)), this, SLOT(readyRemove_clicked(bool)));
    connect(ui->tbWaitRefresh, SIGNAL(clicked(bool)), this, SLOT(waitRefresh_clicked(bool)));
}

IpcDetect::~IpcDetect()
{
    foreach(RCheckBox *check, *checkReadyList)
    {
        delete check;
    }
    delete checkReadyList;
    foreach(QLabel *lb, *lbList)
    {
        delete lb;
    }
    delete lbList;
    foreach(QToolButton *tb, *tbWaitList)
    {
        delete tb;
    }
    delete tbWaitList;
    foreach(QToolButton *tb, *tbReadyList)
    {
        delete tb;
    }
    delete tbReadyList;
//    delete tlIpcDetect;
    delete ui;
}

void IpcDetect::setup()
{
    ui->tableReady->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
    ui->tableWait->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
}

void IpcDetect::initValue()
{
}

void IpcDetect::setGeometry(const QRect &rect)
{
//    qDebug() << __func__ << "(const QRect &rect)";
    QWidget::setGeometry(rect);
    ui->widgetEdit->setGeometry((rect.width()-ui->widgetEdit->width())/2,
                                (rect.height()-ui->widgetEdit->height())/2,
                                ui->widgetEdit->width(),
                                ui->widgetEdit->height());
    QList<RLineEdit *>leEditList = {ui->leUsrname, ui->lePassword};
    foreach(RLineEdit *le, leEditList)
    {
        le->setParentAbsoluteOffset(parent_absolute_offset_x + ui->widgetEdit->x(),
                                    parent_absolute_offset_y + ui->widgetEdit->y());
    }
}

void IpcDetect::setGeometry(int x, int y, int w, int h)
{
//    qDebug() << __func__ << "(int x, int y, int w, int h)";
    this->setGeometry(QRect(x, y, w, h));
}

void IpcDetect::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

void IpcDetect::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    ui->leUsrname->installEventFilter(keyboard);
    ui->lePassword->installEventFilter(keyboard);
    Q_UNUSED(keypad);
}

bool IpcDetect::eventFilter(QObject *o, QEvent *e)
{
    if(e->type() == QEvent::Show)
    {
        if(o==ipcDetect)
        {
            initValue();
            ui->widgetEdit->setVisible(false);
        }
    }
    return QObject::eventFilter(o, e);
}

void IpcDetect::initEdit(bool)
{
}

void IpcDetect::edit_clicked(bool)
{
    initValue();
    ui->widgetEdit->hide();
}

void IpcDetect::cancel_clicked(bool)
{
    ui->widgetEdit->hide();
}

void IpcDetect::readyRefresh_clicked(bool)
{
}

void ready_ipc_remove_confirm()
{
}

void IpcDetect::readyRemove_clicked(bool)
{
}

void IpcDetect::waitRefresh_clicked(bool)
{
}
