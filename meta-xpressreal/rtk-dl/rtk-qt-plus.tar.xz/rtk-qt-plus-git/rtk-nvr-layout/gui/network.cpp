/**
 * @file network.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page to set network
 */

#include "network.h"
#include "ui_network.h"
#include "gui/mainwidget.h"
#include <QHostAddress>
#include <QDir>

Network::Network(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Network)
{
    ui->setupUi(this);

    QList<QToolButton *> btnLayer1 = {ui->tbConnect, ui->tbPort};
    tlNetwork = new RTabLayer(this);
    tlNetwork->init(btnLayer1, ui->stkLayer1, TABLAYER_LAYER_1);

    QList<QToolButton *> btnLayerConnect = {ui->tbConnect2, ui->tbPppoe};
    tlConnect = new RTabLayer(this);
    tlConnect->init(btnLayerConnect, ui->stkConnect, TABLAYER_LAYER_2);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;

    ui->lNetwork->setStyleSheet(STYLESHEET_TITLE_2);

    QList<QComboBox*> optionList = {ui->cbNetMode};
    foreach(QComboBox *cb, optionList)
    {
        cb->setStyleSheet(STYLESHEET_COMBOBOX);
    }

    connect(ui->tbStaticSet,      SIGNAL(clicked(bool)), this, SLOT(setConnectStatic(bool)));
    connect(ui->tbDhcpSet,        SIGNAL(clicked(bool)), this, SLOT(setConnectDhcp(bool)));
    connect(ui->tbPppoeSet,       SIGNAL(clicked(bool)), this, SLOT(setConnectPppoe(bool)));
}

Network::~Network()
{
    delete tlNetwork;
    delete tlConnect;
    delete ui;
}

void Network::setup()
{
    labelList->append({ui->lStatus, ui->lMode,
                       ui->lStaticIpAddress, ui->lStaticSubmask, ui->lStaticGateway, ui->lStaticPriDns,
                       ui->lStaticSecDns, ui->lStaticMtu,
                       ui->lDhcpIp, ui->lDhcpSubmask, ui->lDhcpGateway, ui->lDhcpDns,
                       ui->lDhcpMtu,
                       ui->lPppoeStatus, ui->lPppoeUsername, ui->lPppoePassword,
                       ui->lPppoeMtu});
    editList->append({ui->leStaticIp, ui->leStaticSubmask, ui->leStaticGateway, ui->leStaticPriDns,
                      ui->leStaticSecDns, ui->leStaticMtu,
                      ui->leDhcpMtu,
                      ui->lePppoeUsername, ui->lePppoePassword,
                      ui->lePppoeMtu});
    readOnlyList->append({ui->leStatus, ui->leDhcpIp, ui->leDhcpSubmask,
                          ui->leDhcpGateway, ui->leDhcpDns,
                          ui->lePppoeStatus});
    actionList->append({ui->tbStaticSet, ui->tbDhcpSet, ui->tbPppoeSet});
    tlNetwork->clickTabIndex(0);
    tlConnect->clickTabIndex(0);
}

void Network::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);

    RLineEdit *le;
    int tab_x_offset = parent_absolute_offset_x+rect.x()+ui->stkLayer1->x()+ui->stkConnect->x();
    int tab_y_offset = parent_absolute_offset_y+rect.y()+ui->stkLayer1->y()+ui->stkConnect->y();

    QList<RLineEdit *>leConnectList = {
                        ui->leStaticIp, ui->leStaticSubmask, ui->leStaticGateway,
                        ui->leStaticPriDns, ui->leStaticSecDns, ui->leStaticMtu,
                        ui->leDhcpMtu};
    foreach(le, leConnectList)
    {
        le->setParentAbsoluteOffset(tab_x_offset+ui->stkConnectMode->x(),
                                    tab_y_offset+ui->stkConnectMode->y());
    }
    QList<RLineEdit *>lePppoeList = {
                        ui->lePppoeUsername, ui->lePppoePassword, ui->lePppoeMtu};
    foreach(le, lePppoeList)
    {
        le->setParentAbsoluteOffset(tab_x_offset, tab_y_offset);
    }
//    qDebug()<<"tab_x_offset" << tab_x_offset <<"tab_y_offset" << tab_y_offset;
}

void Network::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void Network::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

void Network::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    QList<RLineEdit *>keyboardList = {ui->lePppoeUsername, ui->lePppoePassword};
    QList<RLineEdit *>keybadList = {ui->leStaticIp, ui->leStaticSubmask, ui->leStaticGateway,
                                    ui->leStaticPriDns, ui->leStaticSecDns,
                                    ui->leStaticMtu, ui->leDhcpMtu,
                                    ui->lePppoeMtu};
    RLineEdit *le;
    foreach(le, keyboardList)
    {
        le->installEventFilter(keyboard);
    }
    foreach(le, keybadList)
    {
        le->installEventFilter(keypad);
    }
}

void Network::on_cbNetMode_currentIndexChanged(int index)
{
    ui->stkConnectMode->setCurrentIndex(index);
}

void Network::showEvent(QShowEvent *e)
{
    Q_UNUSED(e);
    if (ui->stkLayer1->currentIndex() == 0)
    {
        initConnect();
    }
}

void Network::initConnect()
{
//    qDebug() << __func__;
    QProcess proc;
    QList<QString> list, sublist;
    QString line, para, val;
    proc.start("uci", QStringList() << "show" << QString("network.%1").arg(IFNAME_LAN));
    proc.waitForFinished();
    QString output = proc.readAllStandardOutput();
    list = output.split("\n");
    foreach(line, list)
    {
        line = line.trimmed();
        qDebug() << line;
        if (line.startsWith(QString("network.%1.proto").arg(IFNAME_LAN),Qt::CaseInsensitive))
        {
            val = line.split("=").at(1).toLower();
            if (val.startsWith("'") && val.endsWith("'"))
            {
                val = val.remove(0,1);
                val.chop(1);
            }
        }
    }
//    qDebug() << QString("list.count=%1, check value=%2").arg(list.count()).arg(val);
    if (val=="static")
    {
        ui->stkConnect->setCurrentIndex(0);
        ui->stkConnectMode->setCurrentIndex(0);
        ui->leStaticIp->setText("");
        ui->leStaticSubmask->setText("");
        ui->leStaticGateway->setText("");
        ui->leStaticPriDns->setText("");
        ui->leStaticSecDns->setText("");
        ui->leStaticMtu->setText("1500");
        foreach(line, list)
        {
            sublist = line.split("=");
            if(sublist.count()<2)
                continue;
            para = sublist.at(0);
            val = sublist.at(1).trimmed();
            if (val.startsWith("'") && val.endsWith("'"))
            {
                val = val.remove(0,1);
                val.chop(1);
            }
//            qDebug() << val;
            /*
                network.lan=interface
                network.lan.ifname='eth0'
                network.lan.type='bridge'
                network.lan.proto='static'
                network.lan.ipaddr='192.168.0.9'
                network.lan.netmask='255.255.255.0'
            */
            if (para == QString("network.%1.ipaddr").arg(IFNAME_LAN))
            {
                ui->leStaticIp->setText(val);
            }
            else if (para == QString("network.%1.netmask").arg(IFNAME_LAN))
            {
                ui->leStaticSubmask->setText(val);
            }
            else if (para == QString("network.%1.gateway").arg(IFNAME_LAN))
            {
                ui->leStaticGateway->setText(val);
            }
            else if (para == QString("network.%1.dns").arg(IFNAME_LAN))
            {
                sublist = val.split(" ");
                ui->leStaticPriDns->setText(sublist.at(0));
                if (sublist.count() > 1)
                {
                    ui->leStaticSecDns->setText(sublist.at(1));
                }
            }
            else if (para == QString("network.%1.mtu").arg(IFNAME_LAN))
            {
                ui->leStaticMtu->setText(val);
            }
        }
    }
    else if (val == "dhcp")
    {
        ui->stkConnect->setCurrentIndex(0);
        ui->stkConnectMode->setCurrentIndex(1);
        ui->leDhcpIp->setText("");
        ui->leDhcpSubmask->setText("");
        ui->leDhcpGateway->setText("");
        ui->leDhcpDns->setText("");
        ui->leDhcpMtu->setText("1500");

    }
    else if (val == "pppoe")
    {
        ui->stkConnect->setCurrentIndex(1);

    }
#if 0
    QFile file;
    QString line;
    QStringList list;
    QHostAddress address;

    ui->leStaticIp->setText("");
    ui->leStaticSubmask->setText("");
    ui->leStaticGateway->setText("");

    file.setFileName(NETWORK_INTERFACE_PATH);
    if (!file.open(QIODevice::ReadOnly))
    {
        QDir dir = QDir(NETWORK_INTERFACE_PATH);
        QString path = QString(NETWORK_INTERFACE_PATH);
//        qDebug() << dir.absoluteFilePath(path);
//        qDebug() << "open file fail";
        return;
    }
    while(!file.atEnd())
    {
        line = file.readLine().trimmed();
        if (line.startsWith("#") || line.length() <= 0)
            continue;
        list = line.split(" ");
        if (list.count() < 2)
            continue;
        if (list.at(0) == "auto" && list.at(1) == "eth0")
        {
            while(!file.atEnd())
            {
                line = file.readLine().trimmed();
                if (line.startsWith("#") || line.length() <= 0)
                    continue;
                list = line.split(" ");
                if (list.count() < 2)
                    continue;
                if (list.at(0) == "address")
                {
                    ui->leStaticIp->setText(list.at(1));
                }
                else if (list.at(0) == "netmask")
                {
                    ui->leStaticSubmask->setText(list.at(1));
                }
                else if (list.at(0) == "gateway")
                {
                    ui->leStaticGateway->setText(list.at(1));
                }
                else
                {
                    break;
                }
            }
            break;
        }
    }
    file.close();
#endif
}

void Network::setConnectStatic(bool)
{
    QProcess proc;
    QString errMsg, strDns;
    bool isIp1, isIp2, isOk;
    int mtu;

//    qDebug() << __func__;
    if(ui->leStaticIp->isValidIpv4Ip() == false)
        errMsg.append(ui->lStaticIpAddress->text());
    if(ui->leStaticSubmask->isValidIpv4Ip() == false)
    {
        if (errMsg.length() > 0)
            errMsg.append(", ");
        errMsg.append(ui->lStaticSubmask->text());
    }
    QList<RLineEdit *> ipList = {ui->leStaticGateway, ui->leStaticPriDns, ui->leStaticSecDns};
    QList<QLabel *> lList = {ui->lStaticGateway, ui->lStaticPriDns, ui->lStaticSecDns};
    for (int i=0; i<ipList.count(); i++)
    {
        if(ipList.at(i)->text().length() > 0 &&
           ipList.at(i)->isValidIpv4Ip() == false)
        {
            if (errMsg.length() > 0)
                errMsg.append(", ");
            errMsg.append(lList.at(i)->text());
        }
    }
    if (errMsg.length() > 0)
    {
        dialog->showError(QString("Invalid %1 !").arg(errMsg));
        return;
    }

    proc.start("uci", QStringList() << "delete" << QString("network.%1").arg(IFNAME_LAN));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1=interface").arg(IFNAME_LAN));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1.ifname=eth0").arg(IFNAME_LAN));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1.type=bridge").arg(IFNAME_LAN));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1.proto=static").arg(IFNAME_LAN));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1.ipaddr=%2").arg(IFNAME_LAN).arg(ui->leStaticIp->text()));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1.netmask=%2").arg(IFNAME_LAN).arg(ui->leStaticSubmask->text()));
    proc.waitForFinished();
    if(ui->leStaticGateway->isValidIpv4Ip())
    {
        proc.start("uci", QStringList() << "set" << QString("network.%1.gateway=%2").arg(IFNAME_LAN).arg(ui->leStaticGateway->text()));
        proc.waitForFinished();
    }

    isIp1 = ui->leStaticPriDns->isValidIpv4Ip();
    isIp2 = ui->leStaticSecDns->isValidIpv4Ip();
    if(isIp1 && isIp2)
        strDns = QString("'%1 %2'").arg(ui->leStaticPriDns->text()).arg(ui->leStaticSecDns->text());
    else if(isIp1)
        strDns = ui->leStaticPriDns->text();
    else if(isIp2)
        strDns = ui->leStaticSecDns->text();
    if(strDns.length() > 0)
    {
        qDebug() << QString("uci set network.%1.dns=%2").arg(IFNAME_LAN).arg(strDns);
        proc.execute("uci", QStringList() << "set" << QString("network.%1.dns=%2").arg(IFNAME_LAN).arg(strDns));
        proc.waitForFinished();
    }
    mtu = ui->leStaticMtu->text().toInt(&isOk);
    mtu = (isOk) ? mtu : 1500;
    proc.start("uci", QStringList() << "set" << QString("network.%1.mtu=%2").arg(IFNAME_LAN).arg(mtu));
    proc.waitForFinished();

    proc.start("uci", QStringList() << "commit" << "network");
    proc.waitForFinished();
    proc.start("uci", QStringList() << "call" << "network" << "reload");
    proc.waitForFinished();

    dialog->showInfo(STR_SETTING_APPLY);
    /*
    {
        QString str;
        str = QString("config interface 'lan'\n"
                " option ifname 'eth0'\n"
                " option proto 'static'\n"
                " option ipaddr '%1'\n"
                " option netmask '%2'\n"
                " option gateway '%3'\n"
                " option dns '%4'\n")
                .arg(ui->leStaticIp->text())
                .arg(ui->leStaticSubmask->text())
                .arg(ui->leStaticGateway->text())
                .arg(ui->leStaticPriDns->text())
                .arg(ui->leStaticSecDns->text());
        qDebug() << str;
        // update /etc/config/network
        // /etc/init.d/network reload

    }

    QFile file;
    QString line;
    QStringList list;
    QStringList dataList;

    file.setFileName(NETWORK_INTERFACE_PATH);
    if (!file.open(QIODevice::ReadWrite))
    {
        qDebug() << "open file fail";
        return;
    }
    while(!file.atEnd())
    {
        line = file.readLine().trimmed();
        if (line.startsWith("#") || line.length() <= 0)
        {
            dataList << line;
            continue;
        }
        list = line.split(" ");
        if (list.count() < 2)
        {
            dataList << line;
            continue;
        }
        if (list.at(0) == "auto" && list.at(1) == "eth0")
        {
            while(!file.atEnd())
            {
                line = file.readLine().trimmed();
                if (line.startsWith("#") || line.length() <= 0)
                    continue;
                list = line.split(" ");
                if (list.count() < 2)
                    continue;
                if (list.at(0) == "address")
                {
                    ui->leStaticIp->setText(list.at(1));
                }
                else if (list.at(0) == "netmask")
                {
                    ui->leStaticSubmask->setText(list.at(1));
                }
                else if (list.at(0) == "gateway")
                {
                    ui->leStaticGateway->setText(list.at(1));
                }
                else
                {
                    break;
                }
            }
        }
        list << file.readLine();
    }
*/
}

void Network::setConnectDhcp(bool)
{
    QProcess proc;
    bool isOk;
    int mtu;

//    qDebug() << __func__;

    proc.start("uci", QStringList() << "delete" << QString("network.%1").arg(IFNAME_LAN));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1=interface").arg(IFNAME_LAN));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1.ifname=eth0").arg(IFNAME_LAN));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1.type=bridge").arg(IFNAME_LAN));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << "network.lan._orig_ifname='eth0 radio0.network1 radio1.network1'");
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << "network.lan._orig_bridge=true");
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1.proto=dhcp").arg(IFNAME_LAN));
    proc.waitForFinished();

    mtu = ui->leDhcpMtu->text().toInt(&isOk);
    mtu = (isOk) ? mtu : 1500;
    proc.start("uci", QStringList() << "set" << QString("network.%1.mtu=%2").arg(IFNAME_LAN).arg(mtu));
    proc.waitForFinished();

    proc.start("uci", QStringList() << "commit" << "network");
    proc.waitForFinished();
    proc.start("ubus", QStringList() << "call" << "network" << "reload");
    proc.waitForFinished();

    dialog->showInfo(STR_SETTING_APPLY);
}

void Network::setConnectPppoe(bool)
{
    QProcess proc;
    bool isOk;
    int mtu;

    //    qDebug() << __func__;

    proc.start("uci", QStringList() << "delete" << QString("network.%1").arg(IFNAME_LAN));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1=interface").arg(IFNAME_LAN));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1.ifname=eth0").arg(IFNAME_LAN));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << "network.lan._orig_ifname='eth0 radio0.network1 radio1.network1'");
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << "network.lan._orig_bridge=true");
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1.proto=pppoe").arg(IFNAME_LAN));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1.username=%2").arg(IFNAME_LAN).arg(ui->lePppoeUsername->text()));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.%1.password=%2").arg(IFNAME_LAN).arg(ui->lePppoePassword->text()));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.lan.ipv6=0"));
    proc.waitForFinished();
    proc.start("uci", QStringList() << "set" << QString("network.lan.defaultroute=1"));
    proc.waitForFinished();

    mtu = ui->lePppoeMtu->text().toInt(&isOk);
    mtu = (isOk) ? mtu : 1500;
    proc.start("uci", QStringList() << "set" << QString("network.%1.mtu=%2").arg(IFNAME_LAN).arg(mtu));
    proc.waitForFinished();

    proc.start("uci", QStringList() << "commit" << "network");
    proc.waitForFinished();
    proc.start("ubus", QStringList() << "call" << "network" << "reload");
    proc.waitForFinished();

    dialog->showInfo(STR_SETTING_APPLY);
}
