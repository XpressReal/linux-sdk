/**
 * @file mainlogin.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page of GUI main menu after login
 */

#include "mainmenu.h"
#include "ui_mainmenu.h"
#include "mainwidget.h"

MainMenu::MainMenu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainMenu)
{
    ui->setupUi(this);
    this->tbSlideshow = ui->tbSlideshow;
    ui->wBg->setGeometry(0, 0, 490, 686);
    ui->wBg->lower();
    ui->tbPrev->setIcons(QIcon(":/images/prev_normal.png"),
                         QIcon(":/images/prev_hover.png"),
                         QIcon(":/images/prev_normal.png"),
                         QIcon(":/images/prev_hover.png"),
                         false);
    ui->tbNext->setIcons(QIcon(":/images/next_normal.png"),
                         QIcon(":/images/next_hover.png"),
                         QIcon(":/images/next_normal.png"),
                         QIcon(":/images/next_hover.png"),
                         false);
    ui->tbSlideshow->setIcons(QIcon(":/images/slide-on_normal.png"),
                         QIcon(":/images/slide-on_hover.png"),
                         QIcon(":/images/slide-off_normal.png"),
                         QIcon(":/images/slide-off_hover.png"),
                         true);
    ui->tbSlideshow->setTexts("SLIDESHOW", "HOLD");

    ui->tbGrid1->setIcons(QIcon(":/images/grid1_normal.png"),
                         QIcon(":/images/grid1_hover.png"),
                         QIcon(":/images/grid1_selected.png"),
                         QIcon(":/images/grid1_hover.png"),
                         true);
    ui->tbGrid4->setIcons(QIcon(":/images/grid4_normal.png"),
                         QIcon(":/images/grid4_hover.png"),
                         QIcon(":/images/grid4_selected.png"),
                         QIcon(":/images/grid4_hover.png"),
                         true);
    ui->tbGrid8->setIcons(QIcon(":/images/grid8_normal.png"),
                         QIcon(":/images/grid8_hover.png"),
                         QIcon(":/images/grid8_selected.png"),
                         QIcon(":/images/grid8_hover.png"),
                         true);
    ui->tbGrid9->setIcons(QIcon(":/images/grid9_normal.png"),
                         QIcon(":/images/grid9_hover.png"),
                         QIcon(":/images/grid9_selected.png"),
                         QIcon(":/images/grid9_hover.png"),
                         true);
    ui->tbGrid16->setIcons(QIcon(":/images/grid16_normal.png"),
                         QIcon(":/images/grid16_hover.png"),
                         QIcon(":/images/grid16_selected.png"),
                         QIcon(":/images/grid16_hover.png"),
                         true);
    ui->tbGrid32->setIcons(QIcon(":/images/grid32_normal.png"),
                         QIcon(":/images/grid32_hover.png"),
                         QIcon(":/images/grid32_selected.png"),
                         QIcon(":/images/grid32_hover.png"),
                         true);
    ui->tbGrid36->setIcons(QIcon(":/images/grid36_normal.png"),
                         QIcon(":/images/grid36_hover.png"),
                         QIcon(":/images/grid36_selected.png"),
                         QIcon(":/images/grid36_hover.png"),
                         true);

    connect(ui->tbGrid1, SIGNAL(clicked(bool)), this, SLOT(ipc_grid1_selected(bool)));
    connect(ui->tbGrid4, SIGNAL(clicked(bool)), this, SLOT(ipc_grid4_selected(bool)));
    connect(ui->tbGrid8, SIGNAL(clicked(bool)), this, SLOT(ipc_grid8_selected(bool)));
    connect(ui->tbGrid9, SIGNAL(clicked(bool)), this, SLOT(ipc_grid9_selected(bool)));
    connect(ui->tbGrid16, SIGNAL(clicked(bool)), this, SLOT(ipc_grid16_selected(bool)));
    connect(ui->tbGrid32, SIGNAL(clicked(bool)), this, SLOT(ipc_grid32_selected(bool)));
    connect(ui->tbGrid36, SIGNAL(clicked(bool)), this, SLOT(ipc_grid36_selected(bool)));

    ui->tbPlayback->setIcons(QIcon(":/images/playback_normal.png"),
                         QIcon(":/images/playback_hover.png"),
                         QIcon(":/images/playback_normal.png"),
                         QIcon(":/images/playback_hover.png"),
                         false);
    ui->tbCtrl->setIcons(QIcon(":/images/control_normal.png"),
                         QIcon(":/images/control_hover.png"),
                         QIcon(":/images/control_normal.png"),
                         QIcon(":/images/control_hover.png"),
                         false);
    ui->tbAdd->setIcons(QIcon(":/images/add_normal.png"),
                         QIcon(":/images/add_hover.png"),
                         QIcon(":/images/add_normal.png"),
                         QIcon(":/images/add_hover.png"),
                         false);
    ui->tbSetting->setIcons(QIcon(":/images/setting_normal.png"),
                         QIcon(":/images/setting_hover.png"),
                         QIcon(":/images/setting_normal.png"),
                         QIcon(":/images/setting_hover.png"),
                         false);
    ui->tbInfo->setIcons(QIcon(":/images/log_normal.png"),
                         QIcon(":/images/log_hover.png"),
                         QIcon(":/images/log_normal.png"),
                         QIcon(":/images/log_hover.png"),
                         false);
    ui->tbVideoDebug->setIcons(QIcon(":/images/playback_normal.png"),
                         QIcon(":/images/playback_hover.png"),
                         QIcon(":/images/playback_normal.png"),
                         QIcon(":/images/playback_hover.png"),
                         false);

    RToolButton *btn;
    QList <RToolButton *> btnSlideList = {ui->tbPrev, ui->tbSlideshow, ui->tbNext};
    QList <RToolButton *> btnGridList = {ui->tbGrid1, ui->tbGrid4, ui->tbGrid8,
                                         ui->tbGrid9, ui->tbGrid16, ui->tbGrid32,
                                         ui->tbGrid36};
    QList <RToolButton *> btnMenuList = {ui->tbPlayback, ui->tbCtrl, ui->tbAdd,
                                         ui->tbSetting, ui->tbInfo, ui->tbVideoDebug};
    foreach (btn, btnSlideList)
    {
        btn->setStyleSheet(QString(
                                "QToolButton{"
                                    "border:0px;"    // transparent for Linux
                                    "color: rgb(161, 161, 161);"
                                    "%1"
                                    "}"
                                "QToolButton:hover{"
                                    "border:0px;"    // transparent for Linux
                                    "color: rgb(224, 255, 24);"
                                    "%1"
                                    "}")
                           .arg("font: bold 14px \"Arial Black\";")
                           );
    }

    foreach (btn, btnGridList)
    {
        btn->setStyleSheet("QToolButton{"
                                    "border:0px;"    // transparent for Linux
                                    "}"
                           "QToolButton:hover{"
                                    "border:0px;"    // transparent for Linux
                                    "}");
    }

    foreach (btn, btnMenuList)
    {
        btn->setStyleSheet(QString(
                                "QToolButton{"
                                    "border:0px;"    // transparent for Linux
                                    "color: rgb(161, 161, 161);"
                                    "%1"
                                    "}"
                                "QToolButton:hover{"
                                    "border:0px;"    // transparent for Linux
                                    "color: rgb(255, 255, 255);"
                                    "%1"
                                    "}")
                         .arg("font: bold 28px \"Arial Black\";"));
    }

    ui->tbPower->setIcons(QIcon(":/images/power_normal.png"),
                         QIcon(":/images/power_hover.png"),
                         QIcon(":/images/power_normal.png"),
                         QIcon(":/images/power_hover.png"),
                         false);
    ui->tbPower->setStyleSheet("QToolButton{"
                                    "border:0px;"    // transparent for Linux
                               "}"
                               "QToolButton:hover{"
                                    "border:0px;"    // transparent for Linux
                               "}");
}

MainMenu::~MainMenu()
{
    delete ui;
}

void MainMenu::setup()
{
    // default value
    switch(Config::style.ipcGridNum)
    {
    case 1:
        ipc_grid1_selected(true);   break;
    case 4:
        ipc_grid4_selected(true);   break;
    case 8:
        ipc_grid8_selected(true);   break;
    case 16:
        ipc_grid16_selected(true);  break;
    case 32:
        ipc_grid32_selected(true);  break;
    case 36:
        ipc_grid36_selected(true);  break;
    case 9:
    default:
        ipc_grid9_selected(true);   break;
    }

    connect(ui->tbNext, SIGNAL(clicked(bool)), viewProcess, SLOT(ipc_next_selected(bool)));
    connect(ui->tbSlideshow, SIGNAL(clicked(bool)), viewProcess, SLOT(ipc_slideshow_selected(bool)));
    connect(ui->tbPrev, SIGNAL(clicked(bool)), viewProcess, SLOT(ipc_prev_selected(bool)));

    connect(ui->tbPlayback, SIGNAL(clicked(bool)), mainWidget, SLOT(playback_selected(bool)));
    connect(ui->tbCtrl, SIGNAL(clicked(bool)), mainWidget, SLOT(ctrl_selected(bool)));
    connect(ui->tbAdd, SIGNAL(clicked(bool)), mainWidget, SLOT(add_selected(bool)));
    connect(ui->tbSetting, SIGNAL(clicked(bool)), mainWidget, SLOT(setting_selected(bool)));
    connect(ui->tbInfo, SIGNAL(clicked(bool)), mainWidget, SLOT(info_selected(bool)));
    connect(ui->tbVideoDebug, SIGNAL(clicked(bool)), mainWidget, SLOT(videoDebug_selected(bool)));
    connect(ui->tbPower, SIGNAL(clicked(bool)), mainWidget, SLOT(power_selected(bool)));
}

void MainMenu::setZoominOption(bool enable)
{
    ui->tbPlayback->setVisible(!enable);
    enableSlideshowOption(!enable);
    enableGridOption(!enable);
}

void MainMenu::enableSlideshowOption(bool enable)
{
    ui->tbPrev->setVisible(enable);
    ui->tbSlideshow->setVisible(enable);
    ui->tbNext->setVisible(enable);
}

void MainMenu::enableGridOption(bool enable)
{
    QList<QToolButton *> btnList = {ui->tbGrid1, ui->tbGrid4,
                                    ui->tbGrid8, ui->tbGrid9,
                                    ui->tbGrid16,
                                    ui->tbGrid32, ui->tbGrid36};
    QToolButton *btn;
    foreach(btn, btnList)
    {
        btn->setVisible(enable);
    }
}

void MainMenu::ipc_grid_selected(RToolButton *select_btn)
{
    QList<RToolButton *> gridBtnList = {ui->tbGrid1, ui->tbGrid4,
                                        ui->tbGrid8, ui->tbGrid9,
                                        ui->tbGrid16,
                                        ui->tbGrid32, ui->tbGrid36};
    RToolButton *btn;
    foreach(btn, gridBtnList)
    {
        if (btn == select_btn)
        {
            btn->setActive(true, true);
        }
        else
        {
            btn->setActive(false, false);
        }
    }
}

void MainMenu::ipc_grid1_selected(bool)
{
    ipc_grid_selected(ui->tbGrid1);
    ui->tbGrid1->setActive(true, false);
    viewProcess->set_ipc_grid_num(1);
}

void MainMenu::ipc_grid4_selected(bool)
{
    ipc_grid_selected(ui->tbGrid4);
    ui->tbGrid4->setActive(true, false);
    viewProcess->set_ipc_grid_num(4);
}

void MainMenu::ipc_grid8_selected(bool)
{
    ipc_grid_selected(ui->tbGrid8);
    ui->tbGrid8->setActive(true, false);
    viewProcess->set_ipc_grid_num(8);
}

void MainMenu::ipc_grid9_selected(bool)
{
    ipc_grid_selected(ui->tbGrid9);
    ui->tbGrid9->setActive(true, false);
    viewProcess->set_ipc_grid_num(9);
}

void MainMenu::ipc_grid16_selected(bool)
{
    ipc_grid_selected(ui->tbGrid16);
    ui->tbGrid16->setActive(true, false);
    viewProcess->set_ipc_grid_num(16);
}

void MainMenu::ipc_grid32_selected(bool)
{
    ipc_grid_selected(ui->tbGrid32);
    ui->tbGrid32->setActive(true, false);
    viewProcess->set_ipc_grid_num(32);
}

void MainMenu::ipc_grid36_selected(bool)
{
    ipc_grid_selected(ui->tbGrid36);
    ui->tbGrid36->setActive(true, false);
    viewProcess->set_ipc_grid_num(36);
}

void MainMenu::showEvent(QShowEvent *)
{
}
