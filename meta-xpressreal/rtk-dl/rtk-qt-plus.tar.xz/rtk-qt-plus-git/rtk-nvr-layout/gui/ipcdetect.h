/**
 * @file ipcdetect.h
 * @author Realtek Semiconductor Corp.
 * @date May 2018
 * @brief The widget page to detect IPC
 */

#ifndef IPCDETECT_H
#define IPCDETECT_H

#include <QWidget>
#include <QList>
#include <QLabel>
#include "rlineedit.h"
#include "rtablayer.h"
#include "rcheckbox.h"
#include "define.h"

namespace Ui {
class IpcDetect;
}

class IpcDetect : public QWidget
{
    Q_OBJECT

public:
    QList<QString> ipRemoveList;
    QList<RCheckBox*> *checkReadyList;

    explicit IpcDetect(QWidget *parent = 0);
    ~IpcDetect();

    void setup();
    void initValue();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setParentAbsoluteOffset(int x, int y);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);

private:
    Ui::IpcDetect *ui;
    RTabLayer *tlIpcDetect;
    int parent_absolute_offset_x, parent_absolute_offset_y;
    QList<QLabel*> *lbList;
    QList<QToolButton*> *tbReadyList, *tbWaitList;


private slots:
    void initEdit(bool);
    void edit_clicked(bool);
    void cancel_clicked(bool);
    void readyRefresh_clicked(bool);
    void readyRemove_clicked(bool);
    void waitRefresh_clicked(bool);

protected:
//    void showEvent(QShowEvent *event);
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // IPCDETECT_H
