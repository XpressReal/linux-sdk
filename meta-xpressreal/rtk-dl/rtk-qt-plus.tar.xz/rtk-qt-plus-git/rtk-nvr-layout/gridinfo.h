/**
 * @file gridinfo.h
 * @author Realtek Semiconductor Corp.
 * @date Aug 2017
 * @brief The extension of QRect
 */

#ifndef GRIDINFO_H
#define GRIDINFO_H

#include <QRect>
#include "define.h"

class GridInfo : public QRect
{
public:
    GridInfo();
    GridInfo(int x, int y, int width, int height, int border, bool visible);
    void setGridInfo(int x, int y, int width, int height, int border, bool visible);
    void copy(GridInfo *from);
    void swap(GridInfo *from);
    int borderSize();
    bool isVisible();

private:
    int border;
    bool visible;
};

#endif // GRIDINFO_H
