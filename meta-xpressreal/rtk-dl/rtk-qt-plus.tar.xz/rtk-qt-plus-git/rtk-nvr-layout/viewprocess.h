/**
 * @file viewprocess.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The main display operation of IPC or playback per each channel
 */

#ifndef VIEWPROCESS_H
#define VIEWPROCESS_H

#include <QTimer>
#include <QThread>
#include <QMutex>
#include "viewinfo.h"
#include "gridreal.h"
#include "config.h"

class ViewProcess : public QThread
{
    Q_OBJECT

public:
    typedef enum
    {
        ViewMode_Grid,
        ViewMode_ZoomIn,
        ViewMode_Set,   // for user do IPC setting at indexed window location in GUI
        ViewMode_Hide,
    } ViewMode_E;

    ViewProcess();
    ~ViewProcess();

    QMutex mutex;
    ViewInfo view_ipc;      // 4K base
    ViewInfo view_file;     // 4K base
    GridReal ipc_gridReal[CHANNEL_MAX];     // for video FB base
    GridReal file_gridReal[CHANNEL_MAX];    // for video FB base
    bool bUpdateIpcFrame;
    bool bUpdateFileFrame;
//    bool bSetFrameBufferSize;
    bool bSetBrightness;
    bool bSetContrast;
    bool bSetHue;
    bool bSetSaturation;
    bool bSetSharpness;
    bool bIpcDetect;

    void setStart();
    void run();
    void setStop();
    void finalize();

    void set_ipc_grid_num(int grid_num);
    void set_file_grid_num(int grid_num, int idx = -1);
    int get_ipc_grid_num();
    int get_file_grid_num();
#if QT_ENV_ONLY == 1
    void update_color(QColor *color);
#endif
    void update_ipc_recSegment();
    void update_ipc_frame(int idx);
    void update_file_frame(int idx);
    ViewMode_E ipc_getViewMode();
    ViewMode_E file_getViewMode();
    int get_ipc_array_idx(int channel_idx);
    void ipc_start(int idx, QString rtsp_cmd);
    void ipc_stop(int idx, bool bSeamless);
    void ipc_rec_start(int idx);
    void ipc_rec_stop(int idx);
    void file_start(int idx, QString abs_file_path, int seekTime=0, bool mute=false, double volume=0);
    void file_stop(int idx, bool bSeamless);
    bool ipc_swap(int idx_a, int idx_b);
    bool file_swap(int idx_a, int idx_b);
    bool ipc_setViewMode(ViewMode_E newMode, int idx = 0);
    bool file_setViewMode(ViewMode_E newMode, int idx = 0);
    bool ipc_zoomin(int idx, QRect rect);
    bool file_zoomin(int idx, QRect rect);
    QString strViewMode(ViewMode_E mode);
    void set_system_image();
    void set_slideshow_interval();
//    void set_framebuffersize();


private:
    bool    bRun;
    QTimer *slideShowTimer;
    QTimer *updateFrameTimer;
    QTimer *updateStatusTimer;
    QTimer *ipcRecSegmentTimer;

    /*-------- IPC --------*/
    ViewInfo view_ipc_grid0;
    ViewInfo view_ipc_grid1;
    ViewInfo view_ipc_grid4;
    ViewInfo view_ipc_grid8;
    ViewInfo view_ipc_grid9;
    ViewInfo view_ipc_grid16;
#if 0
    ViewInfo view_ipc_grid17;
#endif
    ViewInfo view_ipc_grid32;
    ViewInfo view_ipc_grid36;
    ViewInfo view_ipc_grid1_set;

    ViewMode_E ipc_viewMode;
    int ipc_grid_num;
    int ipc_grid_idx;
    int ipc_set_idx;
    int ipc_zoomin_idx;
    int ipc_array_idx[CHANNEL_MAX]; // mapping from channel index to array index

    /*-------- file --------*/
    ViewInfo view_file_grid0;
    ViewInfo view_file_grid1;
    ViewInfo view_file_grid4;
    ViewInfo view_file_grid9;

    ViewMode_E file_viewMode;
    int file_grid_num;
    int file_grid_idx;
    int file_zoomin_idx;

    void initIpcViewInfo();
    void initFileViewInfo();
    void update_view_ipc();
    void update_view_file();
    QList<GridInfo*> *getIpcGridInfoList(int grid_num);
    QList<GridInfo*> *getFileGridInfoList(int grid_num);

    void run_start();
    void run_stop();
    void run_rec_start();
    void run_rec_stop();
    void run_get_source();
    void run_set_image();
    void run_set_speed();
    void run_set_seek();
    void run_set_mute();
    void run_set_volume();
    void run_apply_view();
    bool ipc_createNewAbsRecDir(int idx, QString *pAbsRecDir, QDateTime *pCurrent);
    bool isValidIpv4Ip(QString strIp);

public slots:
    void ipc_next_selected(bool bOnlyConnect);
    void ipc_prev_selected(bool bOnlyConnect);
    void ipc_slideshow_selected(bool);

private slots:
    void timer_update_slideshow();  // ipc only
    void timer_update_frame();
    void timer_update_ipc_status();
    void timer_rec_segment();
};

extern ViewProcess *viewProcess;

#endif // VIEWPROCESS_H
