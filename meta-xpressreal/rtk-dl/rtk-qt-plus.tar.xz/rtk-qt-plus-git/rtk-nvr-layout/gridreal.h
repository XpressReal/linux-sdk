/**
 * @file gridreal.h
 * @author Realtek Semiconductor Corp.
 * @date Aug 2017
 * @brief The main operation for each IP camera or playback per channel
 */

#ifndef GRIDREAL_H
#define GRIDREAL_H

#include <QColor>
#include <QDateTime>
#include "viewinfo.h"
#include "define.h"
#include "rtkapi.h"

#define RtspCmd_NULL        ""
#define AbsFilePath_NULL    ""
#define IP_NULL             ""

typedef enum
{
    PING_BEGIN = 0,
    PING_FAIL_AND_NO_FRAME,         // IPC disconnect
    PING_FAIL_BUT_NEW_FRAME,        // IPC disable ping
    PING_OK_BUT_NO_FRAME,           // rtsp command fail
    PING_OK_AND_NEW_FRAME,          // IPC connection
} IPC_STATE_E;

class GridReal
{
private:
    bool bNeedSrc;  // if need the truely soruce rect or already get it
    QRect src;

    bool bNeedCrop; // if crop the src from streaming
    QRect crop;

    bool bSetImage; // if need to set brightness, contrast, hue, saturation, sharpness

public:
    typedef enum
    {
        GridType_IPC,
        GridType_File,
    } GridType_E;

    typedef enum
    {
        GridStatus_NONE,
        GridStatus_SETUP,       // in setup state but un-finished
        GridStatus_IPC_HIDE,    // for ipc only, when grid is invisible, stop decoder no matther if rec
        GridStatus_FILE_PAUSE,  // for file only
        GridStatus_PLAY
    } GridStatus_E;

    GridType_E      type;
    GridStatus_E    status;
    GridInfo        infoCurr;        // for video FB base
    int             channelIndex;

    bool            bNeedStart;
    bool            bNeedStop;
    QDateTime       timeNeedStart;
    QDateTime       timeNeedStop;

    int             timeoutNeedSrc;
    QString         absRecDir;          // ipc rec only
    bool            bNeedRecStart;      // ipc rec only
    bool            bNeedRecStop;       // ipc rec only
    bool            bAlreadyRec;        // ipc rec only
    QDateTime       timeNeedRecStart;   // ipc rec only, update when bNeedRecStart changes
    QDateTime       timeNeedRecStop;    // ipc rec only, update when bNeedRecStop changes
    QDateTime       timeRecStart;       // ipc rec only
    double          recElapsed;         // ipc rec only, milisecondes
    double          recSegmentTime;     // ipc rec only, milisecondes

    QString         absFilePath;        // file only
    bool            bAlreadyFilePlay;   // file only
    bool            bSeamless;          // ipc or file
    int             timeoutNeedSpeed;   // file only
    bool            bNeedSpeed;         // file only
    double          speed;              // file only
    bool            bNeedSeek;          // file only
    int             seekTime;           // file only
    bool            bNeedMute;          // file only
    bool            mute;               // file only
    bool            bNeedVolume;        // file only
    double          volume;             // file only
    QString         rtspCmd;            // ipc only
#if RTSP_AV
    RtspClientId    cid;                // ipc
#elif RTSP_GST
    RtspPlayer      *rtspPlayer;        // ipc or file
#endif
    WindowId        wndId;
    ChannelId       channelId;
    bool            needBind;
#if QT_ENV_ONLY == 1
    QColor          bgColor;
#endif
    /*------------- for monitorProcess --------------*/
    QString         ip;
    bool            bIpValid;
    bool            bNewFrameArrived;
    IPC_STATE_E     ipcState;
    unsigned long long bufferWriteCnt;
    unsigned long long sizeZeroCnt;
    unsigned long long connectErrCnt;
    unsigned long long writeErrCnt;
    unsigned long noFrameTime;
    int monitorQueryTime;    // monitor query time to get debug info or reconnect
    /*-----------------------------------------------*/

    GridReal();

    void setSrcDefault();
    void setSrc(QRect rect, bool bNeedSrc = false);
    void setSrc(int x, int y, int width, int height, bool bNeedSrc = false);
    QRect getSrc();
    bool ifGetSrc();
    int src_x();
    int src_y();
    int src_width();
    int src_height();

    void setCropDefault(bool bNeedCrop = true);
    void setCrop(QRect rect, bool bNeedCrop=true);
    void setCrop(int x, int y, int width, int height, bool bNeedCrop=true);
    QRect getCrop();
    bool ifCrop();
    int crop_x();
    int crop_y();
    int crop_width();
    int crop_height();
    void unmark_crop();
    void setImage(bool bSetImage);
    bool ifSetImage();
    void setSpeed(double speed);
    void setMute(bool bMute);
    void setVolume(double volume);

    void copy(GridReal *from);
    void swap(GridReal *from);
#if 0
    void swapSrc(GridReal *from);
    void swapCrop(GridReal *from);
#endif
};

#endif // GRIDREAL_H
