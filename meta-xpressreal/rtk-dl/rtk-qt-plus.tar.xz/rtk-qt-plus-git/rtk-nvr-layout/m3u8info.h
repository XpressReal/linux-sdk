/**
 * @file m3u8info.h
 * @author Realtek Semiconductor Corp.
 * @date Nov 2017
 * @brief The structure for the m3u8 files after parsing
 */

#ifndef M3U8INFO_H
#define M3U8INFO_H

#include <QDateTime>
#include <QHash>
#include <QString>
#include <QMutex>
#include "config.h"

class M3u8Info   // Http Living Stream
{
public:
    QString baseName;   // dir base name, ex: 20171019_011218
    QString absPath;    // absolute file path, ex: d:/hls/01/20171019_011218/playlist.m3u8
    int absPathHeaderLen;   // absolute dir path len,
                            /* ex: absPathHeaderLen = 10
                                   absPath.left(absPathHeaderLen) d:/hls/01/ without date
                            */
    QDateTime recStartTime;
    QDateTime recEndTime;
    double  recTime;            // unit: 1 sec
    double  storeSize;

    bool ifEqual(M3u8Info src)
    {
        return ((this->baseName == src.baseName) &&
                (this->absPath == src.absPath) &&
                (this->absPathHeaderLen == src.absPathHeaderLen) &&
                (this->recStartTime == src.recStartTime) &&
                (this->recEndTime == src.recEndTime) &&
                (this->recTime == src.recTime) &&
                (this->storeSize == src.storeSize));
    }

    void copy(M3u8Info src)
    {
        this->baseName = src.baseName;
        this->absPath = src.absPath;
        this->absPathHeaderLen = src.absPathHeaderLen;
        this->recStartTime = src.recStartTime;
        this->recEndTime = src.recEndTime;
        this->recTime = src.recTime;
        this->storeSize = src.storeSize;
    }
};

class M3u8Channel
{
public:
    QDateTime lastParseTime;
    QHash<QString, M3u8Info> hashM3u8;

    M3u8Channel(int newId)
    {
        this->chIdx = newId;
        lastParseTime.setDate(QDate(1911, 1, 1));
        lastParseTime.setTime(QTime(0, 0, 0, 0));
    }

    void hashInsert(QString key, M3u8Info m3u8Info);    // add or update
    void hashRemove(QString key);
    void hashClear();
    QList<QString> hashKeyListByDate(QDate date);
    QList<QDate> getDateList();
    void display();

private:
    QHash<QDate, QList<QString>*> hashDate;
    int chIdx;
    QMutex mutex;

    void dateAdd(QDate idxDate, QString key);    // add, no update
    void dateRemove(QDate idxDate, QString key);
    void dbgDateM3u8Info(QDate idxDate, QString key, QString action);
    void dbgDateList(QDate idxDate, QList<QString>*pList, QString action);

};

#endif // M3U8INFO_H
