/**
 * @file rtksim.cpp
 * @author Realtek Semiconductor Corp.
 * @date Nov 2017
 * @brief The interface of Realtek library for QT_ENV_ONLY
 */

#include "rtksim.h"
#include "option.h"

#if QT_ENV_ONLY != 1
#else
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <dirent.h>
#include <stdio.h>
#include <sys/time.h>

/******************************* rtk_media_if.c ********************************/
#define NVR_WND_WIDTH_MIN 16
#define NVR_WND_WIDTH_MAX 3840
#define NVR_WND_HEIGHT_MIN 16
#define NVR_WND_HEIGHT_MAX 2160
#define NVR_WND_X_MIN 0
#define NVR_WND_X_MAX NVR_WND_WIDTH_MAX
#define NVR_WND_Y_MIN 0
#define NVR_WND_Y_MAX NVR_WND_HEIGHT_MAX
#define MAX_VIDEO_FRAME_RATE 30

#if 0
#define NVR_WND_LIVE_MIN INPUT_STREAM_FILE
#define NVR_WND_LIVE_MAX INPUT_STREAM_LIVE
#else
#define NVR_WND_LIVE_MIN 0
#define NVR_WND_LIVE_MAX 1
#endif
/******************************* rtkcontrol.cpp ********************************/
RtkReturn_e rtk_serv_initialize(void)
{
    return RTK_SUCCESS;
}

RtkReturn_e rtk_serv_terminate(void)
{
    return RTK_SUCCESS;
}

RtkReturn_e rtk_serv_force_terminate(void)
{
    return RTK_SUCCESS;
}

WindowId rtk_disp_create(unsigned int x, unsigned int y,
             unsigned int width, unsigned int height, InputStreamType_e inputType)
{
    static int wndId = 0;

    if((x < NVR_WND_X_MIN || x > NVR_WND_X_MAX ||
        y < NVR_WND_Y_MIN || y > NVR_WND_Y_MAX ||
        (width < NVR_WND_WIDTH_MIN && width > 0) ||
        width > NVR_WND_WIDTH_MAX ||
        (height < NVR_WND_HEIGHT_MIN && height > 0) ||
        height > NVR_WND_HEIGHT_MAX ||
        inputType< NVR_WND_LIVE_MIN || inputType > NVR_WND_LIVE_MAX))
    {
        printf("Over the wnd support boundary (x, y, w, h, t)=(%d, %d, %d, %d, %d)!\n", x, y, width, height, inputType);
        return RTK_ERR_INVALID_PARAM;
    }

    RtkSimWnd *rtkSimWnd = new RtkSimWnd();
    rtkSimWnd->wnd = wndId++;
    rtkSimWnd->wndParam.x = x;
    rtkSimWnd->wndParam.y = y;
    rtkSimWnd->wndParam.width = width;
    rtkSimWnd->wndParam.height = height;
    rtkSimWnd->wndParam.inputType = inputType;

    rtkSim->rtkSimWndList.append(rtkSimWnd);
    return rtkSimWnd->wnd;
}

RtkReturn_e rtk_disp_destroy(WindowId wnd)
{
    if (wnd <= WindowId_Invalid)
    {
        return RTK_ERR_INVALID_PARAM;
    }
    for(int i=0; i<rtkSim->rtkSimWndList.count(); i++)
    {
        if(rtkSim->rtkSimWndList.at(i)->wnd == wnd)
        {
            rtkSim->rtkSimWndList.removeAt(i);
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_get_params(WindowId wnd, WindowParams_t * param)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            param = &(rtkSimWnd->wndParam);
            return RTK_SUCCESS;
        }
    }
    Q_UNUSED(param);
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_get_srcSize(WindowId wnd, Resolution_t * param)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            param->width = rtkSimWnd->res.width;
            param->height = rtkSimWnd->res.height;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_resize(WindowId wnd, unsigned int x, unsigned int y,
            unsigned int width, unsigned int height)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            rtkSimWnd->wndParam.x = x;
            rtkSimWnd->wndParam.y = y;
            rtkSimWnd->wndParam.width = width;
            rtkSimWnd->wndParam.height = height;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_swap(WindowId wndA, WindowId wndB)
{
    RtkSimWnd *rtkSimWndA = NULL;
    RtkSimWnd *rtkSimWndB = NULL;
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wndA)
        {
            rtkSimWndA = rtkSimWnd;
        }
        else if(rtkSimWnd->wnd == wndB)
        {
            rtkSimWndB = rtkSimWnd;
        }
    }
    if(rtkSimWndA == NULL || rtkSimWndB == NULL)
        return RTK_ERR_FAILURE;
    RtkSimWnd temp;
    temp.copyWndParam(&rtkSimWndA->wndParam);
    rtkSimWndA->copyWndParam(&rtkSimWndB->wndParam);
    rtkSimWndB->copyWndParam(&temp.wndParam);
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_crop(WindowId wnd, unsigned int crop_x, unsigned int crop_y,
          unsigned int crop_w, unsigned int crop_h)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            rtkSimWnd->crop_x = crop_x;
            rtkSimWnd->crop_y = crop_y;
            rtkSimWnd->crop_w = crop_w;
            rtkSimWnd->crop_h = crop_h;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_set_blank(bool enable, int num, ...)
{
    // cannot set blank to the window with channel state as CH_STATE_STOP
    va_list wnds;
    WindowId wnd;
    int i;
    QString str;

    str = QString().asprintf("%s(enable=%d, num=%d, <", __func__, enable, num);

    va_start(wnds, num);
    for (i = 0; i < num; i++)
    {
        wnd = va_arg(wnds, WindowId);
        foreach(RtkSimWnd *pRtkSimWnd, rtkSim->rtkSimWndList)
        {
            if(pRtkSimWnd->wnd == wnd)
            {
                pRtkSimWnd->bBlank = enable;
                break;
            }
        }
        str.append(QString().asprintf("%d ", wnd));
    }
    va_end(wnds);
    str.append(">)");
    qDebug() << str;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_get_blank(WindowId wnd, bool * enabled)
{
    Q_UNUSED(wnd);
    foreach(RtkSimWnd *pRtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(pRtkSimWnd->wnd == wnd)
        {
            *enabled = pRtkSimWnd->bBlank;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_INVALID_PARAM;
}

RtkReturn_e rtk_disp_set_freeze(bool enable, int num, ...)
{
    // cannot set freeze to the window with channel state as CH_STATE_STOP
    va_list wnds;
    WindowId wnd;
    int i;
    QString str;

    str = QString().asprintf("%s(enable=%d, num=%d, <", __func__, enable, num);

    va_start(wnds, num);
    for (i = 0; i < num; i++)
    {
        wnd = va_arg(wnds, WindowId);
        foreach(RtkSimWnd *pRtkSimWnd, rtkSim->rtkSimWndList)
        {
            if(pRtkSimWnd->wnd == wnd)
            {
                pRtkSimWnd->bFreeze = enable;
                break;
            }
        }
        str.append(QString().asprintf("%d ", wnd));
    }
    va_end(wnds);
    str.append(">)");
    qDebug() << str;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_get_freeze(WindowId wnd, bool * enabled)
{
    Q_UNUSED(wnd);
    foreach(RtkSimWnd *pRtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(pRtkSimWnd->wnd == wnd)
        {
            *enabled = pRtkSimWnd->bFreeze;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_INVALID_PARAM;
}

RtkReturn_e rtk_disp_set_output(HDMIMode_e hdmiMode, DPMode_e dpMode)
{
    rtkSim->hdmiMode = hdmiMode;
    rtkSim->dpMode = dpMode;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_get_output(HDMIMode_e * mode, DPMode_e * dpMode)
{
    *mode = rtkSim->hdmiMode;
    *dpMode = rtkSim->dpMode;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_set_outputFrameRate(ChannelId ch, unsigned int fps)
{
    RtkSimCh *rtkSimCh = rtkSim->getRtkSimChByRtkSimWnd(ch);
    if(rtkSimCh == NULL)
        return RTK_ERR_FAILURE;
    rtkSimCh->output_fps = fps;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_set_brightness(unsigned char brightness)
{
    rtkSim->brightness = brightness;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_get_brightness(unsigned char * brightness)
{
    *brightness = rtkSim->brightness;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_set_contrast(unsigned char contrast)
{
    rtkSim->contrast = contrast;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_get_contrast(unsigned char * contrast)
{
    *contrast = rtkSim->contrast;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_set_hue(unsigned char hue)
{
    rtkSim->hue = hue;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_get_hue(unsigned char * hue)
{
    *hue = rtkSim->hue;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_set_saturation(unsigned char saturation)
{
    rtkSim->saturation = saturation;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_get_saturation(unsigned char * saturation)
{
    *saturation = rtkSim->saturation;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_set_sharpness(unsigned char sharpness)
{
    rtkSim->sharpness = sharpness;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_get_sharpness(unsigned char * sharpness)
{
    *sharpness = rtkSim->sharpness;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_set_debug(unsigned int cmd, unsigned int value, char * path)
{
    Q_UNUSED(cmd);
    Q_UNUSED(value);
    Q_UNUSED(path);
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_set_channel_brightness(WindowId wnd, unsigned int brightness)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            rtkSimWnd->brightness = brightness;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}


RtkReturn_e rtk_disp_get_channel_brightness(WindowId wnd, unsigned int * brightness)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            *brightness = rtkSimWnd->brightness;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_set_channel_contrast(WindowId wnd, unsigned int contrast)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            rtkSimWnd->contrast = contrast;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_get_channel_contrast(WindowId wnd, unsigned int * contrast)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            *contrast = rtkSimWnd->contrast;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_set_channel_hue(WindowId wnd, unsigned int hue)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            rtkSimWnd->hue = hue;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_get_channel_hue(WindowId wnd, unsigned int * hue)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            *hue = rtkSimWnd->hue;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_set_channel_saturation(WindowId wnd, unsigned int saturation)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            rtkSimWnd->saturation = saturation;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_get_channel_saturation(WindowId wnd, unsigned int * saturation)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            *saturation = rtkSimWnd->saturation;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_set_channel_sharpness(WindowId wnd, unsigned int sharpness)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            rtkSimWnd->sharpness = sharpness;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_get_channel_sharpness(WindowId wnd, unsigned int * sharpness)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            *sharpness = rtkSimWnd->sharpness;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_disp_set_bgcolor(unsigned char r, unsigned char g, unsigned char b)
{
    Q_UNUSED(r);
    Q_UNUSED(g);
    Q_UNUSED(b);
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_set_videoFB_Resolution(FrameBufferSize_e fbSize)
{
    rtkSim->fbSize = fbSize;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_disp_get_videoFB_Resolution(FrameBufferSize_e * fbSize)
{
    *fbSize = rtkSim->fbSize;
    return RTK_SUCCESS;
}

ChannelId rtk_dec_add_channel_video(unsigned int width, unsigned int height)
{
    int chIdx = rtkSim->ch_next_idx;
    for(int i=0; i<CH_MAX; i++)
    {
        RtkSimCh *pRtkSimCh = &rtkSim->rtkSimCh[chIdx];
        if(pRtkSimCh->bAdded == false)
        {
            pRtkSimCh->bAdded = true;
            pRtkSimCh->dbgInfo.bufferWrtieCnt = 0;
            pRtkSimCh->dbgInfo.sizeZeroCnt = 0;
            pRtkSimCh->dbgInfo.writeErrorCnt = 0;
            pRtkSimCh->dbgInfo.connectErrorCnt = 0;
            pRtkSimCh->dbgInfo.bufferStart = QDateTime::currentDateTime();

            rtkSim->ch_buffwrite[chIdx] = false;
            rtkSim->ch_next_idx = (chIdx + 1) % CH_MAX;
            return chIdx;
        }
        chIdx = (rtkSim->ch_next_idx + i) % CH_MAX;
    }
    Q_UNUSED(width);
    Q_UNUSED(height);
    return ChannelId_Invalid;
}

RtkReturn_e rtk_dec_set_channel_video (ChannelId ch, ChannelParams_t * param)
{
    if (ch < 0 || ch >= CH_MAX)
        return RTK_ERR_INVALID_PARAM;

    rtkSim->rtkSimCh[ch].chParam.vid_codec = param->vid_codec;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_dec_remove_channel(ChannelId ch)
{
    if (ch < 0 || ch >= CH_MAX)
        return RTK_ERR_INVALID_PARAM;

    rtkSim->rtkSimCh[ch].bAdded = false;
    rtkSim->ch_buffwrite[ch] = false;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_dec_get_params(ChannelId ch, ChannelParams_t * param)
{
    RtkSimCh *rtkSimCh = rtkSim->getRtkSimChByRtkSimWnd(ch);
    if(rtkSimCh == NULL)
        return RTK_ERR_FAILURE;
    param = &(rtkSimCh->chParam);
    Q_UNUSED(param);
    return RTK_SUCCESS;
}

RtkReturn_e rtk_dec_bind(ChannelId ch, WindowId wnd)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSim->rtkSimWndList)
    {
        if(rtkSimWnd->wnd == wnd)
        {
            rtkSimWnd->ch = ch;
            return RTK_SUCCESS;
        }
    }
    return RTK_ERR_FAILURE;
}

RtkReturn_e rtk_dec_set_play(ChannelState_e state, ChannelId ch)
{
    RtkSimCh *rtkSimCh = rtkSim->getRtkSimChByRtkSimWnd(ch);
    if(rtkSimCh == NULL)
        return RTK_ERR_FAILURE;
#if 0
    if(rtkSimCh->state != state)
    {
        if(rtkSimCh->state == CH_STATE_PLAY)
        {
        }
        else if(state == CH_STATE_PLAY)
        {
        }
    }
#endif
    rtkSimCh->state = state;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_dec_get_play(ChannelId ch, ChannelState_e * state)
{
    RtkSimCh *rtkSimCh = rtkSim->getRtkSimChByRtkSimWnd(ch);
    if(rtkSimCh == NULL)
        return RTK_ERR_FAILURE;
    *state = rtkSimCh->state;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_dec_fps(ChannelId ch, unsigned int fps)
{
    RtkSimCh *rtkSimCh = rtkSim->getRtkSimChByRtkSimWnd(ch);
    if(rtkSimCh == NULL)
        return RTK_ERR_FAILURE;
    rtkSimCh->dec_fps = fps;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_dec_start_audio(ChannelId ch)
{
    Q_UNUSED(ch);
    return RTK_SUCCESS;
}

RtkReturn_e rtk_dec_stop_audio(ChannelId ch)
{
    Q_UNUSED(ch);
    return RTK_SUCCESS;
}

RtkReturn_e rtk_dec_set_mute(bool enable, ChannelId ch)
{
    RtkSimCh *rtkSimCh = rtkSim->getRtkSimChByRtkSimWnd(ch);
    if(rtkSimCh == NULL)
        return RTK_ERR_FAILURE;
    rtkSimCh->mute = enable;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_dec_set_volume(double volume, ChannelId ch)
{
    RtkSimCh *rtkSimCh = rtkSim->getRtkSimChByRtkSimWnd(ch);
    if(rtkSimCh == NULL)
        return RTK_ERR_FAILURE;
    rtkSimCh->volume = volume;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_dec_get_volume(ChannelId ch, double *volume)
{
    RtkSimCh *rtkSimCh = rtkSim->getRtkSimChByRtkSimWnd(ch);
    if(rtkSimCh == NULL)
        return RTK_ERR_FAILURE;
    *volume = rtkSimCh->volume;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_dec_increase_volume(ChannelId ch)
{
    Q_UNUSED(ch);
    return RTK_SUCCESS;
}

RtkReturn_e rtk_dec_decrease_volume(ChannelId ch)
{
    Q_UNUSED(ch);
    return RTK_SUCCESS;
}

RtkReturn_e rtk_dec_flush(ChannelId ch)
{
    Q_UNUSED(ch);
    return RTK_SUCCESS;
}

RtkReturn_e rtk_snapshot_display(const char *filename)
{
    Q_UNUSED(filename);
    return RTK_SUCCESS;
}

RtkReturn_e rtk_snapshot_display_wnd_ARGB(WindowId wnd, void **buffer)
{
    Q_UNUSED(wnd);
    Q_UNUSED(buffer);
    return RTK_SUCCESS;
}

RtkReturn_e rtk_get_window_image(WindowId wnd, SnapshotBuffer_t *point)
{
    Q_UNUSED(wnd);
    Q_UNUSED(point);
    return RTK_SUCCESS;
}

RtkReturn_e rtk_free_window_image(SnapshotBuffer_t point)
{
    Q_UNUSED(point);
    return RTK_SUCCESS;
}

RtkReturn_e rtk_ipc_debug_getInfo(ChannelId ch, unsigned long long * bufferWriteCnt,
                                  unsigned long long * sizeZeroCnt,
                                  unsigned long long * connectErrCnt,
                                  unsigned long long * writeErrCnt)
{
    if(ch < 0 || ch >= CH_MAX)
        return RTK_ERR_INVALID_PARAM;

    RtkSimCh *pRtkSimCh = &rtkSim->rtkSimCh[ch];
    if(pRtkSimCh->bAdded)
    {
        double rate = (100.0 + rand() % 10) / 100;
        QDateTime current = QDateTime::currentDateTime();
        pRtkSimCh->dbgInfo.bufferWrtieCnt += rate * pRtkSimCh->dbgInfo.bufferStart.msecsTo(current);
        pRtkSimCh->dbgInfo.bufferStart = current;
    }
#if 1
    *bufferWriteCnt = pRtkSimCh->dbgInfo.bufferWrtieCnt;
    *sizeZeroCnt = pRtkSimCh->dbgInfo.sizeZeroCnt;
    *connectErrCnt = pRtkSimCh->dbgInfo.connectErrorCnt;
    *writeErrCnt = pRtkSimCh->dbgInfo.writeErrorCnt;
#else
    *bufferWriteCnt = 0;
    *sizeZeroCnt = 0;
    *connectErrCnt = 0;
    *writeErrCnt = 0;
#endif
    return RTK_SUCCESS;
}

RtkReturn_e rtk_ipc_debug_printInfo(ChannelId ch, char fEn)
{
    if(ch < 0 || ch >= CH_MAX)
        return RTK_ERR_INVALID_PARAM;

    RtkSimCh *pRtkSimCh = &rtkSim->rtkSimCh[ch];
    pRtkSimCh->dbgInfo.enPrint = fEn;
    return RTK_SUCCESS;
}

RtkReturn_e rtk_ipc_debug_reset(ChannelId ch)
{
    if(ch < 0 || ch >= CH_MAX)
        return RTK_ERR_INVALID_PARAM;

    RtkSimCh *pRtkSimCh = &rtkSim->rtkSimCh[ch];
    pRtkSimCh->dbgInfo.bufferWrtieCnt = 0;
    pRtkSimCh->dbgInfo.sizeZeroCnt = 0;
    pRtkSimCh->dbgInfo.connectErrorCnt = 0;
    pRtkSimCh->dbgInfo.writeErrorCnt = 0;
    return RTK_SUCCESS;
}

int rtk_buffer_send(ChannelId ch, void *data, int size, unsigned int ptsMs, unsigned int timeoutMs)
{
    RtkSimCh *pRtkSimCh = rtkSim->getRtkSimChByRtkSimWnd(ch);

    if(ch < 0 || ch >= CH_MAX)
        return 0;

    /* Try to connect socket to the corresponding address */
    if(pRtkSimCh == NULL)
    {
        pRtkSimCh->dbgInfo.connectErrorCnt ++;
        return 0;
    }

    if(size <= 0)
    {
        pRtkSimCh->dbgInfo.sizeZeroCnt ++;
        return 0;
    }

    if(pRtkSimCh->bAdded &&
       rtkSim->ch_buffwrite[ch] != true)
    {
        QString strData;
        unsigned char * charData = (unsigned char *)data;
        for(int i=0; i<16 && i<size; i++)
        {
            strData.append(QString().asprintf("%02x, ", *(charData+i)));
        }
        qDebug() << __func__
                 << QString().asprintf("ch=%d, size=%d, data={%s}",
                                      ch, size, strData.toStdString().c_str());
        rtkSim->ch_buffwrite[ch] = true;
    }

#if 0
    static unsigned int chIdx[CH_MAX] = {0};// all 0
    static double time_ms_base[CH_MAX] = {0};  // all 0
    static double time_ms_prior[CH_MAX] = {0};    // all 0
    struct timeval current_t;
    double time_ms_current;
    char fPath[128], fInfoPath[128];
    FILE *f = NULL;
    FILE *fInfo = NULL;
    bool bWritten = false;

    gettimeofday(&current_t, NULL);
    time_ms_current = 0.0 + current_t.tv_sec * 1000 + (0.0 + current_t.tv_usec) / 1000;

    DIR *dir = opendir("/mnt/sda5/kttest/frame");
    if(dir)
    {
        closedir(dir);
        sprintf(fPath, "/mnt/sda5/kttest/frame/%02d.bin", ch);
        f = fopen(fPath, "a");
        if (f != NULL)
        {
            fwrite(data,1,size,f);
            fflush(f);
            fclose(f);
            bWritten = true;
        }
        else
        {
            bWritten = false;
        }

        sprintf(fInfoPath, "/mnt/sda5/kttest/frame/%02d_info.txt", ch);
        fInfo = fopen(fInfoPath, "a");
        if (fInfo != NULL)
        {
            if(bWritten && time_ms_base[ch] == 0)
            {
                time_ms_base[ch] = time_ms_current;
                time_ms_prior[ch] = time_ms_current;
            }
            if (bWritten)
            {
                fprintf(fInfo, "%010d\t%10d\t%10.3f\t%10.3f\r\n",
                        chIdx[ch], size,
                        (time_ms_current-time_ms_prior[ch]),
                        (time_ms_current-time_ms_base[ch]));
            }
            else
            {
                fprintf(fInfo, "%010d\t%10d\t%10.3f\t%10.3f\tUnlog\r\n",
                        chIdx[ch], size,
                        (time_ms_current-time_ms_prior[ch]),
                        (time_ms_current-time_ms_base[ch]));
            }
            fflush(fInfo);
            fclose(fInfo);

            time_ms_prior[ch] = time_ms_current;
        }
    }
    chIdx[ch] ++;
#endif
    Q_UNUSED(ptsMs);
    Q_UNUSED(timeoutMs);
    return size;
}

#if RTSP_AV
/******************************* rtkrtspav.cpp ********************************/
#define INDEX_INVALID   -1
_RtkRtspFClient *clientList[CLIENT_MAX];

int rtk_rtsp_av_initialize()
{
    return RTK_SUCCESS;
}

int rtk_rtsp_av_terminate()
{
    return RTK_SUCCESS;
}

RtspClientId rtk_rtsp_av_client_new(const char *url)
{
    _RtkRtspFClient *client;
    int emptyIdx = INDEX_INVALID;
    int index = INDEX_INVALID;
    if (url == NULL)
    {
        return RTK_ERR_INVALID_PARAM;
    }
    for (int i=0; i<CLIENT_MAX; i++)
    {
        if (clientList[i] == NULL)
        {
            if (emptyIdx == INDEX_INVALID)
            {
                emptyIdx = i;
            }
            continue;
        }
        if (strcmp (clientList[i]->info.url, url) == 0)
        {
            index = i;
        }
    }
    if (index == INDEX_INVALID) {
        if (emptyIdx == INDEX_INVALID)
        {
            return RTK_ERR_INSUFFICIENT_RESOURCE;
        }

        rtkSim->mutex.lock();
        client = new _RtkRtspFClient();
        index = emptyIdx;
        {
            int len = strlen(url);
            if(len <= 0) {
                len = 0;
                client->info.url[0] = 0x0;
            }
            if(len >= URL_LENGTH) {
                len = URL_LENGTH;
            }
            memcpy(client->info.url, url, len);
            client->info.url[len-1] = 0x0;
        }
        client->index = index;
        client->v_stream_idx = INDEX_INVALID;
        client->a_stream_idx = INDEX_INVALID;
        client->bRunThread = true;
        client->bPktTimeout = false;
        client->bDisplay = false;
        client->bRec = false;
        clientList[index] = client;
        rtkSim->mutex.unlock();
    }
    return index;
}

void rtk_rtsp_av_client_free(RtspClientId cid)
{
    _RtkRtspFClient *client;
    if (cid < 0 || cid >= CLIENT_MAX)
        return;
    client = clientList[cid];
    if (client == NULL)
        return;
    rtkSim->mutex.lock();
    free (client);
    clientList[cid] = NULL;
    rtkSim->mutex.unlock();
}

void rtk_rtsp_av_player_play(RtspClientId cid, int v_ch, int a_ch)
{
    if (cid < 0 || cid >= CLIENT_MAX)
        return;
    _RtkRtspFClient *client = clientList[cid];
    if (client == NULL)
        return;
    client->info.v_ch = v_ch;
    if (v_ch >= 0)
    {
        client->bDisplay = true;
    }
    client->info.a_ch = a_ch;
    if (a_ch >= 0)
    {
        client->bSound = true;
    }
}

void rtk_rtsp_av_player_stop(RtspClientId cid)
{
    if (cid < 0 || cid >= CLIENT_MAX)
        return;
    _RtkRtspFClient *client = clientList[cid];
    if (client == NULL)
        return;
    client->bDisplay = false;
    client->bSound = false;
}

void rtk_rtsp_av_rec_set_info(RtspClientId cid,
                            int gui_ch, int v_ch, int a_ch,
                            int wnd_x, int wnd_y, int wnd_width, int wnd_height)
{
    if (cid < 0 || cid >= CLIENT_MAX)
        return;
    _RtkRtspFClient *client = clientList[cid];
    if (client == NULL)
        return;
    client->info.gui_ch = gui_ch;
    client->info.v_ch = v_ch;
    client->info.a_ch = a_ch;
    client->info.wnd_x = wnd_x;
    client->info.wnd_y = wnd_y;
    client->info.wnd_width = wnd_width;
    client->info.wnd_height = wnd_height;
}

void rtk_rtsp_av_rec_start(RtspClientId cid, const char *path, int duration)
{

}

void rtk_rtsp_av_rec_stop(RtspClientId cid)
{

}

void rtk_rtsp_av_rec_change(RtspClientId cid, const char *path, int duration)
{

}
#elif RTSP_GST
/******************************* rtkrtsp.cpp ********************************/
RtspPlayer *rtsp_player_new (const char *url, int ch)
{
    Q_UNUSED(url);
    Q_UNUSED(ch);
    RtkSimData *pRtkSimData = new RtkSimData();
    rtkSim->mutex.lock();
    rtkSim->rtkSimDataList.append(pRtkSimData);
    rtkSim->mutex.unlock();
    return pRtkSimData->pPlayer;
}

void rtsp_player_free (RtspPlayer *player)
{
    rtkSim->mutex.lock();
    foreach(RtkSimData *pRtkSimData, rtkSim->rtkSimDataList)
    {
        if(pRtkSimData->pPlayer == player)
        {
            if(pRtkSimData->pTime != NULL)
            {
                rtkSim->rec_stop(pRtkSimData);
            }
            rtkSim->rtkSimDataList.removeOne(pRtkSimData);
            rtkSim->mutex.unlock();
            return;
        }
    }
    rtkSim->mutex.unlock();
}

void rtsp_player_play (RtspPlayer *player)
{
    Q_UNUSED(player);
}

void rtsp_player_stop (RtspPlayer *player)
{
    Q_UNUSED(player);
}

void rtsp_player_set_stream (RtspPlayer *player, Stream stream)
{
    Q_UNUSED(player);
    Q_UNUSED(stream);
}

void rtsp_player_rec_start (RtspPlayer *player, const char *path, uint duration)
{
    rtkSim->mutex.lock();
    foreach(RtkSimData *pRtkSimData, rtkSim->rtkSimDataList)
    {
        if(pRtkSimData->pPlayer == player)
        {
            if(pRtkSimData->pTime != NULL)
            {
                rtkSim->rec_stop(pRtkSimData);
            }
            rtkSim->rec_start(pRtkSimData, QString().sprintf("%s", path), duration);
            rtkSim->mutex.unlock();
            return;
        }
    }
    rtkSim->mutex.unlock();
}

void rtsp_player_rec_stop (RtspPlayer *player)
{
    rtkSim->mutex.lock();
    foreach(RtkSimData *pRtkSimData, rtkSim->rtkSimDataList)
    {
        if(pRtkSimData->pPlayer == player)
        {
            if(pRtkSimData->pTime != NULL)
            {
                rtkSim->rec_stop(pRtkSimData);
            }
            rtkSim->mutex.unlock();
            return;
        }
    }
    rtkSim->mutex.unlock();
}

void rtsp_player_rec_change (RtspPlayer *player, const char *path, uint duration)
{
    rtkSim->mutex.lock();
    foreach(RtkSimData *pRtkSimData, rtkSim->rtkSimDataList)
    {
        if(pRtkSimData->pPlayer == player)
        {
            if(pRtkSimData->pTime != NULL)
            {
                rtkSim->rec_stop(pRtkSimData);
            }
            rtkSim->rec_start(pRtkSimData, QString().sprintf("%s", path), duration);
            rtkSim->mutex.unlock();
            return;
        }
    }
    rtkSim->mutex.unlock();
}

void rtsp_client_set_latency (RtspClient *self, uint latency)
{
    Q_UNUSED(self);
    Q_UNUSED(latency);
}

/******************************* rtkplyer.cpp********************************/

int/*RtkReturn_e*/ rtk_player_initialize(void)
{
    return RTK_SUCCESS;
}

ChannelId rtk_player_add_channel_video()
{
    return rtk_dec_add_channel_video(-1, -1);
}

ChannelId rtk_player_add_channel_audio()
{
    return ChannelId_Invalid;
}

ChannelId rtk_player_add_channel_av()
{
    return rtk_dec_add_channel_video(-1, -1);
}

int/*RtkReturn_e*/ rtk_player_add_idx_channel_video(ChannelId availableCh)
{
    Q_UNUSED(availableCh);
    return RTK_SUCCESS;
}

int/*RtkReturn_e*/ rtk_player_add_idx_channel_audio(ChannelId availableCh)
{
    Q_UNUSED(availableCh);
    return RTK_SUCCESS;
}

int/*RtkReturn_e*/ rtk_player_add_idx_channel_av(ChannelId availableCh)
{
    Q_UNUSED(availableCh);
    return RTK_SUCCESS;
}

#if 0
int/*RtkReturn_e*/ rtk_player_set_channel_video(ChannelId ch, PlayerChannelParams_t * param)
{
    Q_UNUSED(ch);
    Q_UNUSED(param);
    return RTK_SUCCESS;
}

int/*RtkReturn_e*/ rtk_player_set_channel_audio(ChannelId ch, PlayerChannelParams_t * param)
{
    Q_UNUSED(ch);
    Q_UNUSED(param);
    return RTK_SUCCESS;
}
#endif
int/*RtkReturn_e*/ rtk_player_remove_channel(ChannelId ch)
{
    return rtk_dec_remove_channel(ch);
}

#if 0
int/*RtkReturn_e*/ rtk_player_bind(ChannelId ch, WindowId wnd)
{
    return rtk_dec_bind(ch, wnd);
}
#else
int/*RtkReturn_e*/ rtk_player_bind(ChannelId ch, WindowId wnd,
                                   int x, int y, int width, int height)
{
    Q_UNUSED(x);
    Q_UNUSED(y);
    Q_UNUSED(width);
    Q_UNUSED(height);
    return rtk_dec_bind(ch, wnd);
}
#endif

int/*RtkReturn_e*/ rtk_player_set_play(int/*ChannelState_e*/ state, ChannelId ch)
{
    return rtk_dec_set_play((ChannelState_e)state, ch);
}

int/*RtkReturn_e*/ rtk_player_seek(ChannelId ch, int time)
{
    Q_UNUSED(ch);
    Q_UNUSED(time);
    return RTK_SUCCESS;
}

int/*RtkReturn_e*/ rtk_player_set_speed(ChannelId ch, double rate)
{
    RtkSimCh *rtkSimCh = rtkSim->getRtkSimChByRtkSimWnd(ch);
    if(rtkSimCh == NULL)
        return RTK_ERR_FAILURE;
    rtkSimCh->dec_speed = rate;
    return RTK_SUCCESS;
}

int/*RtkReturn_e*/ rtk_player_set_fps(ChannelId ch, unsigned int fps)
{
    return rtk_dec_fps(ch, fps);
}

int/*RtkReturn_e*/ rtk_player_open(ChannelId ch, const char *filename)
{
    Q_UNUSED(ch);
    Q_UNUSED(filename);
    return RTK_SUCCESS;
}

int/*RtkReturn_e*/ rtk_player_start_audio(ChannelId ch)
{
    return rtk_dec_start_audio(ch);
}

int/*RtkReturn_e*/ rtk_player_stop_audio(ChannelId ch)
{
    return rtk_dec_stop_audio(ch);
}

int/*RtkReturn_e*/ rtk_player_set_mute(bool enable, ChannelId ch)
{
    return rtk_dec_set_mute(enable, ch);
}

int/*RtkReturn_e*/ rtk_player_set_volume(double volume, ChannelId ch)
{
    return rtk_dec_set_volume(volume, ch);
}

int/*RtkReturn_e*/ rtk_player_get_volume(ChannelId ch, double *volume)
{
    return rtk_dec_get_volume(ch, volume);
}

int/*RtkReturn_e*/ rtk_player_increase_volume(ChannelId ch)
{
    return rtk_dec_increase_volume(ch);
}

int/*RtkReturn_e*/ rtk_player_decrease_volume(ChannelId ch)
{
    return rtk_dec_decrease_volume(ch);
}

int/*RtkReturn_e*/ rtk_player_query_time(ChannelId ch, uint64_t *pCurrent)
{
    Q_UNUSED(ch);
    Q_UNUSED(pCurrent);
    return RTK_SUCCESS;
}

bool rtk_player_get_available(int ch)
{
    Q_UNUSED(ch);
    return true;
}

int/*RtkReturn_e*/ rtk_player_flush(ChannelId ch)
{
    return rtk_dec_flush(ch);
}

int/*RtkReturn_e*/ rtk_player_set_iFrame_only_mode(ChannelId ch, bool enable)
{
    Q_UNUSED(ch);
    Q_UNUSED(enable);
    return RTK_SUCCESS;
}
#endif

/******************************* simulation *******************************/
RtkSim *rtkSim = NULL;

RtkSimWnd::RtkSimWnd()
{
    wnd = WindowId_Invalid;
    wndParam.x = 0;
    wndParam.y = 0;
    wndParam.width = 0;
    wndParam.height = 0;
    wndParam.inputType = INPUT_STREAM_LIVE;
    ch = ChannelId_Invalid;

    bBlank = false;
    bFreeze = false;
    res.width = 1280;
    res.height = 720;
    crop_x = crop_y = crop_w = crop_h = 0;
    brightness = contrast = hue = saturation = IMAGE_VALUE_DEF;
    sharpness = SHARPNESS_VALUE_DEF;
}

void RtkSimWnd::copyWndParam(WindowParams_t *wndParam)
{
    this->wndParam.x = wndParam->x;
    this->wndParam.y = wndParam->y;
    this->wndParam.width = wndParam->width;
    this->wndParam.height = wndParam->height;
    this->wndParam.inputType = wndParam->inputType;
}

RtkSimCh::RtkSimCh()
{
    bAdded = false;
    state = CH_STATE_STOP;
    dec_speed = 1;
    dec_fps = 30;
    output_fps = 30;
    mute = false;
    volume = 0;

    dbgInfo.bufferWrtieCnt = 0;
    dbgInfo.sizeZeroCnt = 0;
    dbgInfo.writeErrorCnt = 0;
    dbgInfo.connectErrorCnt = 0;
    dbgInfo.enPrint = 1;
}

RtkSim::RtkSim()
{
    rtkSim = this;
    fbSize = FRAME_BUFFER_1920x1088;
    ch_next_idx = 0;
    for(int i=0; i<CH_MAX; i++)
    {
        ch_buffwrite[i] = false;
    }
    brightness = IMAGE_VALUE_DEF;
    contrast = IMAGE_VALUE_DEF;
    hue = IMAGE_VALUE_DEF;
    saturation = IMAGE_VALUE_DEF;
    sharpness = SHARPNESS_VALUE_DEF;
    hdmiMode = HDMI_1080P_60;
    dpMode = DP_NONE;
    bRun = false;
    pollingTime = 200;
}

RtkSimCh *RtkSim::getRtkSimChByRtkSimWnd(int ch)
{
    foreach(RtkSimWnd *rtkSimWnd, rtkSimWndList)
    {
        if(rtkSimWnd->ch == ch)
            return &rtkSimCh[ch];
    }
    return NULL;
}

#if RTSP_AV
#elif RTSP_GST
void RtkSim::setStart()
{
    this->start();
}

void RtkSim::run()
{
    bRun = true;
    while(bRun)
    {
        if(rtkSimDataList.count() > 0)
        {
            mutex.lock();
            foreach(RtkSimData *pRtkSimData, rtkSimDataList)
            {
                if(pRtkSimData->pTime == NULL ||
                   pRtkSimData->duration <= 0)
                    continue;
                if(pRtkSimData->pTime->elapsed() >= pRtkSimData->duration)
                {
                    rec_timeup(pRtkSimData);
                }
            }
            mutex.unlock();
        }
        msleep(pollingTime);
    }
}

void RtkSim::setStop()
{
    bRun = false;
}

void RtkSim::finalize()
{
    bRun = false;
    while (rtkSim->isRunning())
    {
        msleep(200);
    }
}

void RtkSim::rec_start(RtkSimData *pRtkSimData, QString path, uint duration)
{
    pRtkSimData->absRecFilePath = path + (path.endsWith("/") ? "" : "/") + "playlist.m3u8";
    pRtkSimData->ts_idx = 0;
    pRtkSimData->duration = duration * 1000;    // miliseconds
    pRtkSimData->pTime = new QTime();
    pRtkSimData->pTime->start();
}

void RtkSim::rec_stop(RtkSimData *pRtkSimData)
{
    if (pRtkSimData->pTime == NULL)
        return;

    // file update
    QFile data(pRtkSimData->absRecFilePath);
    if (data.exists() != true)
    {
        rec_createFile(pRtkSimData);
    }
    if (data.exists())
    {
        if (data.open(QFile::Append))
        {
            QTextStream out(&data);
            double time = ((double)pRtkSimData->pTime->elapsed()) / 1000;
            out << "#EXTINF:" << QString().asprintf("%.15f", time) << ",\n";
            out << "segment" << QString().asprintf("%05d", pRtkSimData->ts_idx) << ".ts" << "\n";

            out << "#EXT-X-ENDLIST" << "\n";
            data.close();
        }
    }
    if(pRtkSimData->pTime != NULL)
    {
        delete (pRtkSimData->pTime);
        pRtkSimData->pTime = NULL;
    }
}

void RtkSim::rec_timeup(RtkSimData *pRtkSimData)
{
    if (pRtkSimData->pTime == NULL)
        return;

    // file update
    QFile data(pRtkSimData->absRecFilePath);
    if (data.exists() != true)
    {
        rec_createFile(pRtkSimData);
    }
    if (data.exists())
    {
        if (data.open(QFile::Append))
        {
            QTextStream out(&data);
            double time = ((double)pRtkSimData->pTime->elapsed()) / 1000;
            out << "#EXTINF:" << QString().asprintf("%.15f", time) << ",\n";
            out << "segment" << QString().asprintf("%05d", pRtkSimData->ts_idx) << ".ts" << "\n";
            data.close();
        }
    }
    pRtkSimData->pTime->restart();
    pRtkSimData->ts_idx++;
}

void RtkSim::rec_createFile(RtkSimData *pRtkSimData)
{
    // file create
    QFile data(pRtkSimData->absRecFilePath);
    if (data.open(QFile::WriteOnly | QFile::Truncate)) {
        QTextStream out(&data);
        out << "#EXTM3U" << "\n";
        out << "#EXT-X-VERSION:3" << "\n";
        out << "#EXT-X-ALLOW-CACHE:NO" << "\n";
        out << "#EXT-X-MEDIA-SEQUENCE:0" << "\n";
        out << "#EXT-X-TARGETDURATION:" << pRtkSimData->duration/1000 << "\n";
        out << "\n";
        data.close();
    }
}
#endif

#endif
