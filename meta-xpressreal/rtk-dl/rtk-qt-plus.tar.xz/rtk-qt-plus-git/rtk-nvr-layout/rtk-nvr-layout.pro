#-------------------------------------------------
#
# Project created by QtCreator 2017-08-04T17:40:29
#
#-------------------------------------------------

QT       += core gui network

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = rtk-nvr-layout
TEMPLATE = app

# The following define makes your compiler emit warnings if you use
# any feature of Qt which as been marked as deprecated (the exact warnings
# depend on your compiler). Please consult the documentation of the
# deprecated API in order to know how to port your code away from it.
DEFINES += QT_DEPRECATED_WARNINGS "RTSP_GST=0" "RTSP_AV=1" "QT_ENV_ONLY=1"

# You can also make your code fail to compile if you use deprecated APIs.
# In order to do so, uncomment the following line.
# You can also select to disable deprecated APIs only up to a certain version of Qt.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0


SOURCES += \
    main.cpp \
    gui/mainwidget.cpp \
    gui/mainmenu.cpp \
    gui/mainlogin.cpp \
    gui/keypad.cpp \
    gui/keyboard.cpp \
    gui/rcalendarwidget.cpp \
    gui/rcheckbox.cpp \
    gui/rdialog.cpp \
    gui/rframe.cpp \
    gui/rlineedit.cpp \
    gui/rpagecontrol.cpp \
    gui/rslider.cpp \
    gui/rsound.cpp \
    gui/rspinlist.cpp \
    gui/rtoolbutton.cpp \
    gui/rtablayer.cpp \
    gui/ipcadd.cpp \
    gui/ipcconnect.cpp \
    gui/ipcdetect.cpp \
    gui/setting.cpp \
    gui/system.cpp \
    gui/network.cpp \
    gui/playback.cpp \
    gui/ipc.cpp \
    gui/storage.cpp \
    gui/info.cpp \
    gui/alarm.cpp \
    gui/statistics.cpp \
    gui/videodebug.cpp \
    gui/facedetect.cpp \
    config.cpp \
    option.cpp \
    gridinfo.cpp \
    gridreal.cpp \
    viewinfo.cpp \
    viewprocess.cpp \
    monitorprocess.cpp \
    hlsprocess.cpp \
    onvifprocess.cpp \
    m3u8info.cpp \
    rtksim.cpp \
    rtkapi.cpp

HEADERS += \
    define.h \
    gui/mainwidget.h \
    gui/mainmenu.h \
    gui/mainlogin.h \
    gui/keypad.h \
    gui/keyboard.h \
    gui/rcalendarwidget.h \
    gui/rcheckbox.h \
    gui/rdialog.h \
    gui/rframe.h \
    gui/rlineedit.h \
    gui/rpagecontrol.h \
    gui/rslider.h \
    gui/rsound.h \
    gui/rspinlist.h \
    gui/rtoolbutton.h \
    gui/rtablayer.h \
    gui/ipcadd.h \
    gui/ipcconnect.h \
    gui/ipcdetect.h \
    gui/setting.h \
    gui/system.h \
    gui/network.h \
    gui/playback.h \
    gui/ipc.h \
    gui/alarm.h \
    gui/storage.h \
    gui/info.h \
    gui/statistics.h \
    gui/videodebug.h \
    gui/facedetect.h \
    config.h \
    option.h \
    gridinfo.h \
    gridreal.h \
    viewinfo.h \
    viewprocess.h \
    monitorprocess.h \
    hlsprocess.h \
    onvifprocess.h \
    m3u8info.h \
    rtksim.h \
    rtkapi.h

FORMS += \
    gui/mainwidget.ui \
    gui/mainmenu.ui \
    gui/mainlogin.ui \
    gui/keypad.ui \
    gui/keyboard.ui \
    gui/rcalendarwidget.ui \
    gui/rdialog.ui \
    gui/ipcadd.ui \
    gui/ipcconnect.ui \
    gui/ipcdetect.ui \
    gui/setting.ui \
    gui/system.ui \
    gui/network.ui \
    gui/playback.ui \
    gui/ipc.ui \
    gui/alarm.ui \
    gui/statistics.ui \
    gui/videodebug.ui \
    gui/storage.ui \
    gui/info.ui \
    gui/facedetect.ui

RESOURCES += \
    images.qrc

OTHER_FILES += \
    config.ini

