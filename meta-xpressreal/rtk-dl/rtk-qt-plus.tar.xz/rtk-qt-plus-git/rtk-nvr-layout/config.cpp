/**
 * @file config.cpp
 * @author Realtek Semiconductor Corp.
 * @date Aug 2017
 * @brief The config value for GUI or system
 */

#include <QSettings>
#include <QFile>
#include <QHostAddress>
#include "config.h"
#include "gui/mainwidget.h"

SYSTEM_S Config::sys_def = {
    0x0,            // dbgFlag
    true,           // isWayland
    true,           // logMsg
    CHANNEL_MAX,    // ipcChannelMax
    1,              // fileChannelMax
    1920,           // width                    1920                3840
    1080,           // height                   1080                2160
    32,             // widthBase
    18,             // heightBase
    384,            // playbackX                384 /480 /368 /464  384
    1536,           // playbackWidth            1536/1440/1536/1440 3456
    864,            // playbackHeight           864 /810 /864 /810  1944
    0,              // playbackTopDownBorder    0   /0   /8   /8    0
    0,              // playbackLeftRightBorder  0   /0   /16  /16   0
    1,              // frameBufferSizeIndex
    0.5,            // rationOSD
    1,              // ratioFB
    true,           // autoLogin
    true,           // bootupIpcConnect
    100,            // setBlankTime
    1000,           // setPlayerConnectTime
    200,            // viewProcessPoolingTime
    true,           // monitorProcessEnable
    200,            // monitorProcessPoolingTime
    1000,           // monitorProcessQueryTime
    10000,          // monitorProcessNoFrameTimeout
    30000,          // monitorProcessReconnectTime
    3600000,        // monitorProcessReconnectMaxTime
    30000,          // monitorProcessRepingTime
    3000,           // getSourcePollingTime
    2000,           // setSpeedPollingTime
    300,            // recSegmentPollingTime
    200,            // setRtspLatency
    500,            // terminateDelay
    1000,           // playbackQueryTime
    1000,           // playbackPlayDelayTime
    true,           // playbackBlankEnable
    300,            // playbackBlankTime
    SOUND_VALUE_DEF,// playbackSound
    10,             // hlsDuration
    false,          // seamless
    false,          // onvifEnable
    20000,          // onvifPollingTime
    false,          // faceDetectEnable
};
SYSTEM_S Config::sys;

STYLE_S Config::style = {
    9,              // ipcGridNum
    1,              // fileGridNum
    4,              // ipcBorderSize
    2,              // fileBorderSize
    _RGBA_COLOR_BLACK_,     // borderColor
    "rgba(191,255,57,255)", // borderDragColor
    "rgba(191,255,57,255)",  // borderZoomColor
    "rgba(255,255,255,255)",// tagFontColor
    _RGBA_COLOR_BLACK_, // tagBgColor
    "rgba(191,255,57,50)",   // maskZoomColor
    2,              // tagAlignment
};

SETTING_S Config::setting = {
    60,                 // segmentTime
    35790,              // segmentTimeMax, 35790: max value of type int for QTimer::interval()
    SLIDESHOW_INTERVAL_DEF, // slideshowInterval
    0,                  // dateFormat
    0,                  // timeFormat
    IMAGE_VALUE_DEF,    // brightness
    IMAGE_VALUE_DEF,    // contrast
    IMAGE_VALUE_DEF,    // hue
    IMAGE_VALUE_DEF,    // saturation
    SHARPNESS_VALUE_DEF,// sharpness
    0x0,                // bgColorR
    0x0,                // bgColorG
    0x0,                // bgColorB
    0xFF,               // bgColorA
    HDMI_1080P_60,      // hdmiMode
    DP_NONE,            // dpMode
};

IPC_SET_S Config::ipc = {};

/*
美國us: MM/dd/yyyy HH:mm:ss,
義大利it: dd/MM/yy HH.mm.ss,
英國uk: dd/MM/yyyy HH:mm:ss,
台灣tw: yyyy/MM/dd HH:mm:ss,
中國cn: yyyy-MM-dd HH:mm:ss
*/
QList<QString> Config::listDateFormat = {"yyyy/MM/dd", "yyyy-MM-dd", "MM/dd/yyyy", "dd/MM/yyyy"};
QList<QString> Config::listTimeFormat = {"HH:mm:ss", "HH.mm.ss"};
QList<QString> Config::listOvertimeFormat = {"%02d:%02d:%02d", "%02d.%02d.%02d"};   // same number as listTimeFormat
QString Config::applicationDirPath;
QString Config::absoluteHlsDirPath; // ex: /mnt/sda/hls/
//QString Config::profileName = _CFG_PROFILE_INI_;

bool Config::init()
{
    applicationDirPath = QCoreApplication::applicationDirPath()+"/";
    absoluteHlsDirPath = Config::applicationDirPath+_CFG_HLS_DIR_;

    loadConfig();
    printInfo();
    loadProfile(applicationDirPath+_CFG_PROFILE_INI_);

//    if (QDir().mkpath(absoluteHlsDirPath) != true)
//    {
//        qDebug() << QString("Fail to create dir path %1").arg(absoluteHlsDirPath);
//    }
    return true;
}

Config::Config()
{
    // init ipc default value
    for(int i=0; i<CHANNEL_MAX; i++)
    {
        ipc.ch[i].rtspCmd = "rtsp://192.168.0.168:554/profile1";
        ipc.ch[i].ifConnect = false;
        ipc.ch[i].ifStorage = false;
        ipc.ch[i].segmentTime = 60;
        ipc.ch[i].codec = opt_ValToStr(optVideoCodec, VIDEO_H264);
        ipc.ch[i].brightness = IMAGE_VALUE_DEF;
        ipc.ch[i].contrast = IMAGE_VALUE_DEF;
        ipc.ch[i].hue = IMAGE_VALUE_DEF;
        ipc.ch[i].saturation = IMAGE_VALUE_DEF;
        ipc.ch[i].sharpness = SHARPNESS_VALUE_DEF;
    }
}

Config::~Config()
{
    saveDefaultProfile();
}

QString Config::getAbsDirPath(QString dirPath)
{
    QDir dir;
    QString absDirPath;
    dir.setPath(dirPath);
    absDirPath = dir.absolutePath();
    return absDirPath;
}




#define END             settings.endArray()
#define ARRAY(I)        settings.setArrayIndex(I);
#define BEGIN(S)        settings.beginReadArray(S)
#define GET_BOOL(S,V)   V=settings.value(S,V).toBool()
#define GET_INT(S,V)    V=settings.value(S,V).toInt()
#define GET_HEX(S,V)    V=settings.value(S,QString().asprintf("%x", V)).toString().toUInt(NULL, 16)
#define GET_UINT(S,V)   V=settings.value(S,V).toUInt()
#define GET_STR(S,V)    V=settings.value(S,V).toString()
#define GET_IP(S,V)     V=QHostAddress(settings.value(S, QHostAddress(V).toString()).toString()).toIPv4Address()
#define GET_IDX(S,V,L)  V=(L.indexOf(settings.value(S).toString()) < 0) ? V : L.indexOf(settings.value(S).toString())
#define GET_DOUBLE(S,V) V=settings.value(S,V).toDouble()
#define SET_VAL(S,V)    settings.setValue(S,V)
#define SET_IP(S,V)     settings.setValue(S,QHostAddress(V).toString())
#define SET_IDX(S,V,L)  settings.setValue(S,L.at(V))


void Config::loadConfig()
{
    QString absFilePath = applicationDirPath+_CFG_CONFIG_INI_;
    memcpy(&sys, &sys_def, sizeof(sys));

    if (!QFile(absFilePath).exists())
    {
        qDebug() << QString("%1 does not exist !").arg(absFilePath);
        return;
    }
    qDebug() << __func__;
    QSettings settings(absFilePath, QSettings::IniFormat);
    Q_UNUSED(settings)

    BEGIN("SYSTEM");
        GET_HEX("dbgFlag", sys.dbgFlag);
        GET_BOOL("isWayland", sys.isWayland);
        GET_BOOL("logMsg", sys.logMsg);
        GET_INT("ipcChannelMax", sys.ipcChannelMax);
        GET_INT("fileChannelMax", sys.fileChannelMax);
        GET_INT("width", sys.width);
        GET_INT("height", sys.height);
        GET_INT("widthBase", sys.widthBase);
        GET_INT("heightBase", sys.heightBase);
        GET_INT("playbackX", sys.playbackX);
        GET_INT("playbackWidth", sys.playbackWidth);
        GET_INT("playbackHeight", sys.playbackHeight);
        GET_INT("playbackTopDownBorder", sys.playbackTopDownBorder);
        GET_INT("playbackLeftRightBorder", sys.playbackLeftRightBorder);
        GET_UINT("setBlankTime", sys.setBlankTime);
        GET_UINT("setPlayerConnectTime", sys.setPlayerConnectTime);
        GET_UINT("viewProcessPoolingTime", sys.viewProcessPoolingTime);
        GET_BOOL("monitorProcessEnable", sys.monitorProcessEnable);
        GET_UINT("monitorProcessPoolingTime", sys.monitorProcessPoolingTime);
        GET_UINT("monitorProcessQueryTime", sys.monitorProcessQueryTime);
        GET_UINT("monitorProcessNoFrameTimeout", sys.monitorProcessNoFrameTimeout);
        GET_UINT("monitorProcessReconnectTime", sys.monitorProcessReconnectTime);
        GET_UINT("monitorProcessReconnectMaxTime", sys.monitorProcessReconnectMaxTime);
        GET_UINT("monitorProcessRepingTime", sys.monitorProcessRepingTime);
        GET_UINT("getSourcePollingTime", sys.getSourcePollingTime);
        GET_UINT("setSpeedPollingTime", sys.setSpeedPollingTime);
        GET_UINT("recSegmentPollingTime", sys.recSegmentPollingTime);
        GET_UINT("setRtspLatency", sys.setRtspLatency);
        GET_UINT("terminateDelay", sys.terminateDelay);
        GET_UINT("playbackQueryTime", sys.playbackQueryTime);
        GET_UINT("playbackPlayDelayTime", sys.playbackPlayDelayTime);
        GET_BOOL("playbackBlankEnable", sys.playbackBlankEnable);
        GET_UINT("playbackBlankTime", sys.playbackBlankTime);
        GET_UINT("hlsDuration", sys.hlsDuration);
        GET_BOOL("seamless", sys.seamless);
        GET_BOOL("onvifEnable", sys.onvifEnable);
        GET_UINT("onvifPollingTime", sys.onvifPollingTime);
        GET_BOOL("faceDetectEnable", sys.faceDetectEnable);
    END;
    if (sys.width <= 0)         sys.width = sys_def.width;
    if (sys.height <= 0)        sys.height = sys_def.height;
    if (sys.widthBase <= 0)     sys.widthBase = sys_def.widthBase;
    if (sys.heightBase <= 0)    sys.heightBase = sys_def.heightBase;
    if (sys.playbackWidth <= 0) sys.playbackWidth = sys_def.playbackWidth;
    if (sys.playbackHeight <= 0)sys.playbackHeight = sys_def.playbackHeight;
    if (sys.playbackLeftRightBorder <= 0)sys.playbackLeftRightBorder = 0;
    if (sys.ipcChannelMax <= 0 || sys.ipcChannelMax > CHANNEL_MAX)    sys.ipcChannelMax = sys_def.ipcChannelMax;
    if (sys.fileChannelMax <= 0 || sys.fileChannelMax > CHANNEL_MAX)    sys.fileChannelMax = sys_def.fileChannelMax;
    if (sys.width <= 1920)
    {
        sys.ratioOSD = 0.5;
    }
    else if (sys.width <= 3840)
    {
        sys.ratioOSD = 1;
    }
    BEGIN("STYLE");
        GET_UINT("ipcBorderSize", style.ipcBorderSize);
        GET_UINT("fileBorderSize", style.fileBorderSize);
        GET_STR("borderColor", style.borderColor);
        GET_STR("borderDragColor", style.borderDragColor);
        GET_STR("borderZoomColor", style.borderZoomColor);
        GET_STR("tagFontColor", style.tagFontColor);
        GET_STR("tagBgColor", style.tagBgColor);
        GET_STR("maskZoomColor", style.maskZoomColor);
    END;

    BEGIN("SETTING");
    END;
}

bool Config::loadProfile(QString absFilePath)
{
    if (!QFile(absFilePath).exists())
        return false;
    QSettings settings(absFilePath, QSettings::IniFormat);

    GET_STR("absoluteHlsDirPath", absoluteHlsDirPath);
    BEGIN("IPC");
    for (int i=0; i < CHANNEL_MAX; ++i)
    {
        ARRAY(i);
        GET_STR("rtspCmd", ipc.ch[i].rtspCmd);
        GET_BOOL("ifConnect", ipc.ch[i].ifConnect);
        GET_BOOL("ifStorage", ipc.ch[i].ifStorage);
        GET_INT("segmentTime", ipc.ch[i].segmentTime);

        QString codec;
        GET_STR("codec", codec);
        int value = opt_StrToVal(optVideoCodec, codec);
        if(value >=0)
        {
            ipc.ch[i].codec = codec;
        }

        int valBrightness = ipc.ch[i].brightness;
        GET_INT("brightness", valBrightness);
        if(valBrightness >= IMAGE_VALUE_MIN && valBrightness <= IMAGE_VALUE_MAX)
            ipc.ch[i].brightness = valBrightness;

        int valContrast = ipc.ch[i].contrast;
        GET_INT("contrast", valContrast);
        if(valContrast >= IMAGE_VALUE_MIN && valContrast <= IMAGE_VALUE_MAX)
            ipc.ch[i].contrast = valContrast;

        int valHue = ipc.ch[i].hue;
        GET_INT("hue", valHue);
        if(valHue >= IMAGE_VALUE_MIN && valHue <= IMAGE_VALUE_MAX)
            ipc.ch[i].hue = valHue;

        int valSaturation = ipc.ch[i].saturation;
        GET_INT("saturation", valHue);
        if(valSaturation >= IMAGE_VALUE_MIN && valSaturation <= IMAGE_VALUE_MAX)
            ipc.ch[i].saturation = valSaturation;

        int valSharpness = ipc.ch[i].sharpness;
        GET_INT("sharpness", valSharpness);
        if(valSharpness >= SHARPNESS_VALUE_MIN && valSharpness <= SHARPNESS_VALUE_MAX)
            ipc.ch[i].sharpness = valSharpness;
    }
    END;

    BEGIN("STYLE");
        uint tagAlignment = style.tagAlignment;
        GET_UINT("tagAlignment", tagAlignment);
        if(tagAlignment <= 3)
            style.tagAlignment = tagAlignment;
    END;

    BEGIN("SYSTEM");
        GET_BOOL("autoLogin", sys.autoLogin);
        GET_BOOL("bootupIpcConnect", sys.bootupIpcConnect);

        int frameBufferSizeIndex = sys.frameBufferSizeIndex;
        GET_INT("frameBufferSizeIndex", frameBufferSizeIndex);
        setFrameBufferSizeIndex(frameBufferSizeIndex);

        uint sound = sys.playbackSound;
        GET_UINT("playbackSound", sound);
        if(sound >= SOUND_VALUE_MIN && sound <= SOUND_VALUE_MAX)
            sys.playbackSound = sound;
    END;

    BEGIN("SETTING");
        int segmentTime = setting.segmentTime;
        GET_INT("segmentTime", segmentTime);
        if(segmentTime >= 0)
            setting.segmentTime = segmentTime;

        int valSlideshowInt = setting.slideshowInterval;
        GET_INT("slideshowInterval", valSlideshowInt);
        if(valSlideshowInt >= SLIDESHOW_INTERVAL_MIN && valSlideshowInt <= SLIDESHOW_INTERVAL_MAX)
            setting.slideshowInterval = valSlideshowInt;

        int valDateFormat = setting.dateFormat;
        GET_INT("dateFormat", valDateFormat);
        if(valDateFormat >= 0 && valDateFormat < listDateFormat.count())
            setting.dateFormat = valDateFormat;

        int valTimeFormat = setting.timeFormat;
        GET_INT("timeFormat", valTimeFormat);
        if(valTimeFormat >= 0 && valTimeFormat < listTimeFormat.count())
            setting.timeFormat = valTimeFormat;

        int valBrightness = setting.brightness;
        GET_INT("brightness", valBrightness);
        if(valBrightness >= IMAGE_VALUE_MIN && valBrightness <= IMAGE_VALUE_MAX)
            setting.brightness = valBrightness;

        int valContrast = setting.contrast;
        GET_INT("contrast", valContrast);
        if(valContrast >= IMAGE_VALUE_MIN && valContrast <= IMAGE_VALUE_MAX)
            setting.contrast = valContrast;

        int valHue = setting.hue;
        GET_INT("hue", valHue);
        if(valHue >= IMAGE_VALUE_MIN && valHue <= IMAGE_VALUE_MAX)
            setting.hue = valHue;

        int valSaturation = setting.saturation;
        GET_INT("saturation", valHue);
        if(valSaturation >= IMAGE_VALUE_MIN && valSaturation <= IMAGE_VALUE_MAX)
            setting.saturation = valSaturation;

        int valSharpness = setting.sharpness;
        GET_INT("sharpness", valSharpness);
        if(valSharpness >= SHARPNESS_VALUE_MIN && valSharpness <= SHARPNESS_VALUE_MAX)
            setting.sharpness = valSharpness;

        int valColor = 0;
        GET_HEX("bgColorR", valColor);
        setting.bgColorR = qMin(0xFF, qMax(0, valColor));
        GET_HEX("bgColorG", valColor);
        setting.bgColorG = qMin(0xFF, qMax(0, valColor));
        GET_HEX("bgColorB", valColor);
        setting.bgColorB = qMin(0xFF, qMax(0, valColor));
        GET_HEX("bgColorA", valColor);
        setting.bgColorA = qMin(0xFF, qMax(0, valColor));

        GET_INT("hdmiMode", setting.hdmiMode);
        GET_INT("dpMode", setting.dpMode);
    END;
    return true;
}

void Config::saveProfile(QString absFilePath)
{
//    if (!QFile(absFilePath).exists())
//    {
//        QFile file;
//        file.setFileName(absFilePath);
//        if (!file.open(QIODevice::WriteOnly))
//            return;
//        file.write("\n");
//        file.close();
//    }

    QSettings settings(absFilePath, QSettings::IniFormat);

    SET_VAL("absoluteHlsDirPath", absoluteHlsDirPath);
    BEGIN("IPC");
    for (int i=0; i < CHANNEL_MAX; ++i)
    {
        ARRAY(i);
        SET_VAL("rtspCmd", ipc.ch[i].rtspCmd);
        SET_VAL("ifConnect", ipc.ch[i].ifConnect);
        SET_VAL("ifStorage", ipc.ch[i].ifStorage);
        SET_VAL("segmentTime", ipc.ch[i].segmentTime);
        SET_VAL("codec", ipc.ch[i].codec);
        SET_VAL("brightness", ipc.ch[i].brightness);
        SET_VAL("contrast", ipc.ch[i].contrast);
        SET_VAL("hue", ipc.ch[i].hue);
        SET_VAL("saturation", ipc.ch[i].saturation);
        SET_VAL("sharpness", ipc.ch[i].sharpness);
    }
    END;

    BEGIN("STYLE");
        SET_VAL("tagAlignment", style.tagAlignment);
    END;

    BEGIN("SYSTEM");
        SET_VAL("autoLogin", sys.autoLogin);
        SET_VAL("bootupIpcConnect", sys.bootupIpcConnect);
        SET_VAL("frameBufferSizeIndex", sys.frameBufferSizeIndex);
        SET_VAL("playbackSound", sys.playbackSound);
    END;

    BEGIN("SETTING");
        SET_VAL("segmentTime", setting.segmentTime);
        SET_VAL("dateFormat", setting.dateFormat);
        SET_VAL("timeFormat", setting.timeFormat);
        SET_VAL("brightness", setting.brightness);
        SET_VAL("contrast", setting.contrast);
        SET_VAL("hue", setting.hue);
        SET_VAL("saturation", setting.saturation);
        SET_VAL("sharpness", setting.sharpness);
        SET_VAL("bgColorR", QString().asprintf("0x%02x", setting.bgColorR));
        SET_VAL("bgColorG", QString().asprintf("0x%02x", setting.bgColorG));
        SET_VAL("bgColorB", QString().asprintf("0x%02x", setting.bgColorB));
        SET_VAL("bgColorA", QString().asprintf("0x%02x", setting.bgColorA));
        SET_VAL("slideshowInterval", setting.slideshowInterval);
        SET_VAL("hdmiMode", setting.hdmiMode);
        SET_VAL("dpMode", setting.dpMode);
    END;
}

void Config::saveDefaultProfile()
{
    saveProfile(applicationDirPath+_CFG_PROFILE_INI_);
}

void Config::setFrameBufferSizeIndex(int frameBufferSizeIndex)
{
    sys.frameBufferSizeIndex = frameBufferSizeIndex;

    if (frameBufferSizeIndex <= 0 || frameBufferSizeIndex > 1)
    {
        // FRAME_BUFFER_1920x1088
        sys.frameBufferSizeIndex = 0;
        sys.ratioVFB = 0.5;
    }
    else
    {
        // FRAME_BUFFER_3840x2160
        sys.frameBufferSizeIndex = frameBufferSizeIndex;
        sys.ratioVFB = 1;
    }
}

void Config::updateBorderColorByBgColor()
{
    style.borderColor = QString("rgba(%1,%2,%3,%4)")
                                .arg(Config::setting.bgColorR)
                                .arg(Config::setting.bgColorG)
                                .arg(Config::setting.bgColorB)
                                .arg(Config::setting.bgColorA);
}

void Config::printInfo()
{
    qDebug() << QString().asprintf("0x%08x",_DBG_RTKAPI_) << "_DBG_RTKAPI_" << (DBG(_DBG_RTKAPI_) > 0);
    qDebug() << QString().asprintf("0x%08x",_DBG_ALARM_) << "_DBG_ALARM_" << (DBG(_DBG_ALARM_) > 0);
    qDebug() << QString().asprintf("0x%08x",_DBG_PLAYBACK_) << "_DBG_PLAYBACK_" << (DBG(_DBG_PLAYBACK_) > 0);
    qDebug() << QString().asprintf("0x%08x",_DBG_MONITOR_) << "_DBG_MONITOR_" << (DBG(_DBG_MONITOR_) > 0);
    qDebug() << QString().asprintf("0x%08x",_DBG_HLS_PARSER_) << "_DBG_HLS_PARSER_" << (DBG(_DBG_HLS_PARSER_) > 0);
    qDebug() << QString().asprintf("0x%08x",_DBG_ONVIF_) << "_DBG_ONVIF_" << (DBG(_DBG_ONVIF_) > 0);
    qDebug() << "dbgFlag" << QString().asprintf("%08x", sys.dbgFlag);
    qDebug() << "logMsg" << sys.logMsg;
    qDebug() << "autoLogin" << sys.autoLogin;
    qDebug() << "bootupIpcConnect" << sys.bootupIpcConnect;
    qDebug() << "setBlankTime" << sys.setBlankTime;
}

QString Config::strQDateFormat()
{
    return listDateFormat.at(setting.dateFormat);
}

QString Config::strQTimeFormat()
{
    return listTimeFormat.at(setting.timeFormat);
}

QString Config::strTimeFormat()
{
    return listOvertimeFormat.at(setting.timeFormat);
}

QString Config::strTime(int secs)
{
    QString str;
    if(secs > 80000)
    {
        qint64 diffT = (qint64)secs;
        int h, m, s;
        s = diffT % 60;
        m = diffT / 60;
        h = m / 60;
        m = m % 60;
        str = QString().asprintf(Config::strTimeFormat().toStdString().c_str(), h, m, s);
    }
    else
    {
        QTime t(0, 0, 0);
        t = t.addMSecs((int)(secs * 1000.0)); // only in 24 hours
        str = t.toString(Config::strQTimeFormat());
    }
    return str;
}

QString Config::strQDateTime(QDateTime datetime)
{
    return (datetime.toString(listDateFormat.at(setting.dateFormat) + " " +
            listTimeFormat.at(setting.timeFormat)));
}
