/**
 * @file hlsprocess.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The process to parse HLS directory and m3u8 files
 */

#include "hlsprocess.h"
#include <QFile>
#include <QFileInfo>
#include <QTime>
#include <QDebug>
#include "gui/mainwidget.h"

HlsProcess *hlsProcess = NULL;

HlsProcess::HlsProcess()
{
    hlsProcess = this;
    bRefetch = false;
    bSelectedMonthUpdated = false;
    bSelectedDateUpdated = false;
    bSelectedDateChannelUpdated = false;
    updateTimer = new QTimer(this);
    updateTimer->setInterval(500);
    for(int i=0; i<CHANNEL_MAX; i++)
    {
        pM3u8Channel[i] = new M3u8Channel(i);
    }
    connect(updateTimer, SIGNAL(timeout()), this, SLOT(timer_update()));
}

HlsProcess::~HlsProcess()
{
    if(updateTimer != NULL)
    {
        updateTimer->stop();
        delete(updateTimer);
    }
    for(int i=0; i<CHANNEL_MAX; i++)
    {
        delete(pM3u8Channel[i]);
    }
}

void HlsProcess::setStart()
{
    updateTimer->start();
    this->start();
}

void HlsProcess::setStop()
{
    bRun = false;
}

void HlsProcess::finalize()
{
    bRun = false;
    updateTimer->stop();
    while (hlsProcess->isRunning())
    {
        msleep(200);
    }
}

void HlsProcess::setRefetch()
{
    mutexRefetch.lock();
    bRefetch = true;
    mutexRefetch.unlock();
}

void HlsProcess::run()
{
    bRun = true;
    int channelMax = qMax(Config::sys.ipcChannelMax, Config::sys.fileChannelMax);
    while(bRun)
    {
        for (int chIdx=0; chIdx<channelMax; chIdx++)
        {
            if (bRun)
                refreshM3u8List(chIdx);
            else
                return;
            for (int i=0; i<10; i++)
            {
                if (bRun)
                {
                    if(bRefetch)
                    {
                        mutexRefetch.lock();
                        refreshM3u8List(playback->playChannelIdx);
                        if(playback->fileChannelIdx != playback->playChannelIdx)
                        {
                            refreshM3u8List(playback->fileChannelIdx);
                        }
                        bRefetch = false;
                        mutexRefetch.unlock();
                    }
                    this->msleep(500);
                }
                else
                    return;
            }
        }
    }
}

void HlsProcess::timer_update()
{
    if (bSelectedDateChannelUpdated)
    {
        playback->file_list_update();
        playback->play_update(false);
        bSelectedDateChannelUpdated = false;
        bSelectedDateUpdated = false;
    }
    else if (bSelectedDateUpdated)
    {
        playback->file_list_update();
        bSelectedDateUpdated = false;
    }
    if (bSelectedMonthUpdated)
    {
        if(playback->isVisible())
        {
            playback->rCalendar->regetCalendar();
        }
        bSelectedMonthUpdated = false;
    }
}

double HlsProcess::getDirSize(QString absDirPath)
{
    double size = 0;
    QDir dir(absDirPath);

    //calculate total size of current directories' files
    QDir::Filters fileFilters = QDir::Files|QDir::System|QDir::Hidden;
    for(QString filePath : dir.entryList(fileFilters))
    {
        QFileInfo fi(dir, filePath);
        size += fi.size();
    }

    //add size of child directories recursively
    QDir::Filters dirFilters = QDir::Dirs|QDir::NoDotAndDotDot|QDir::System|QDir::Hidden;
    for(QString childDirPath : dir.entryList(dirFilters))
    {
        size += getDirSize(absDirPath + QDir::separator() + childDirPath);
    }
    return size;
}

uint HlsProcess::getHashDateMask(QDate date)
{
    if (hashDateMask.find(date) != hashDateMask.end())
    {
        return hashDateMask.value(date);
    }
    return 0;
}

void HlsProcess::updateHashDateMask(int chIdx)
{
    QList<QDate> dateList = pM3u8Channel[chIdx]->getDateList();
    foreach(QDate date, dateList)
    {
//        qDebug() << chIdx << __func__ << date.year() << date.month() << date.day() << "true";
        setHashDateMask(true, date, chIdx);
    }
    QList<QDate> hashDateList = hashDateMask.keys();
    for (int i = hashDateList.count()-1; i >=0; i--)
    {
        QDate date = hashDateList.at(i);
        if(dateList.indexOf(date) < 0)
        {
//            qDebug() << chIdx << __func__ << date.year() << date.month() << date.day() << "false";
            setHashDateMask(false, date, chIdx);
        }
    }
}

uint HlsProcess::setHashDateMask(bool set, QDate date, int chIdx)
{
    uint bitmask;
    if (hashDateMask.find(date) != hashDateMask.end())
    {
        bitmask = hashDateMask.value(date);
        if (set)
        {
            bitmask |= (0x00000001 << chIdx);
        }
        else
        {
            bitmask &= ~(0x00000001 << chIdx);
        }
        if (bitmask > 0)
        {
            hashDateMask.insert(date, bitmask); // update
        }
        else
        {
            hashDateMask.remove(date);
        }
    }
    else
    {
        bitmask = 0;
        if (set)
        {
            bitmask |= (0x00000001 << chIdx);
            hashDateMask.insert(date, bitmask);
        }
    }
    return bitmask;
}

void HlsProcess::refreshM3u8List(int chIdx)
{
    QString absDirPath, absSubdirPath;
    QStringList filters;
    QDir dir;
    QFileInfoList fileInfoList;
    QFileInfo fileInfo;
    M3u8Channel *pChannel = pM3u8Channel[chIdx];
    QHash<QString, M3u8Info> *pHash = &pChannel->hashM3u8;
    bool bChange;
    int change, selectDateChange, selectMonthChange, itemCount;

//    qDebug() << chIdx << __func__;
    change = 0;
    selectDateChange = 0;
    selectMonthChange = 0;
    itemCount = 0;
    filters.append("*.m3u8");
    absDirPath = Config::absoluteHlsDirPath +
                (Config::absoluteHlsDirPath.endsWith("/") ? "" : "/") +
                HLS_SUBDIR(chIdx) + "/";

    QDate dateSelected = playback->rCalendar->getDateSelected();
    QDate monthShow = playback->rCalendar->getMonthShow();
    mutex.lock();
    QDateTime lastParseTime = QDateTime::currentDateTime();
    if (QDir(absDirPath).exists())
    {
        QDirIterator it(absDirPath, QDirIterator::Subdirectories);
        while(it.hasNext())
        {
            absSubdirPath = it.next();
            if (absSubdirPath.endsWith("/.") || absSubdirPath.endsWith("/.."))
                continue;

            dir.setPath(absSubdirPath);
            fileInfoList = dir.entryInfoList(filters, QDir::Files, QDir::Name | QDir::Reversed);
            foreach (fileInfo, fileInfoList)
            {
//                qDebug() << fileInfo.absoluteFilePath();
                M3u8Info m3u8Info;
                if (parseM3U8(fileInfo.absoluteFilePath(), absDirPath.length(), &m3u8Info) != true)
                    continue;

                itemCount ++;
                bChange = false;

                QString strAct;
                QHash<QString, M3u8Info>::const_iterator iterator = pHash->find(fileInfo.absoluteFilePath());
                if (iterator == pHash->end())
                {
                    strAct = "insert";
                    bChange = true;
                }
                else if (fileInfo.lastModified() >= pM3u8Channel[chIdx]->lastParseTime)
                {
                    strAct = "update";
                    bChange = true;
                }
                if (bChange)
                {
                    change ++;
//                    qDebug() << strAct << m3u8Info.strTime;

                    m3u8Info.storeSize = getDirSize(QFileInfo(m3u8Info.absPath).dir().absolutePath());
                    pChannel->hashInsert(m3u8Info.absPath, m3u8Info);// insert or update into pHash

                    if(dateSelected >= m3u8Info.recStartTime.date() &&
                       dateSelected <= m3u8Info.recEndTime.date())
                    {
                        selectDateChange ++;
//                        qDebug() << strAct << m3u8Info.strTime;
                    }
                    if((monthShow.year() > m3u8Info.recStartTime.date().year() ||
                        (monthShow.year() == m3u8Info.recStartTime.date().year() &&
                         monthShow.month() >= m3u8Info.recStartTime.date().month())) &&
                       (monthShow.year() < m3u8Info.recEndTime.date().year() ||
                        (monthShow.year() == m3u8Info.recEndTime.date().year() &&
                         monthShow.month() <= m3u8Info.recEndTime.date().month())))
                    {
                        selectMonthChange ++;
                    }
                }
            }
        }
        if (pHash->count() > itemCount)
        {
            QList<QString> list = pHash->keys(); /*pHash->uniqueKeys();*/
            foreach(QString key, list)
            {
                M3u8Info m3u8Info = pHash->value(key);
                if(dateSelected >= m3u8Info.recStartTime.date() &&
                   dateSelected <= m3u8Info.recEndTime.date())
                {
                    selectDateChange ++;
                }
                if((monthShow.year() > m3u8Info.recStartTime.date().year() ||
                    (monthShow.year() == m3u8Info.recStartTime.date().year() &&
                     monthShow.month() >= m3u8Info.recStartTime.date().month())) &&
                   (monthShow.year() < m3u8Info.recEndTime.date().year() ||
                    (monthShow.year() == m3u8Info.recEndTime.date().year() &&
                     monthShow.month() <= m3u8Info.recEndTime.date().month())))
                {
                    selectMonthChange ++;
                }

                if (!QFile(key).exists())
                {
                    // remove from pHash
                    pChannel->hashRemove(key);
                    change ++;
                }
            }
        }
    }
    else
    {
        if (pHash->count() > 0)
        {
            pChannel->hashClear();
            change ++;
            selectDateChange ++;
            selectMonthChange ++;
        }
    }
    if (change > 0)
    {
        updateHashDateMask(chIdx);
    }
    if (selectDateChange > 0)
    {
        bSelectedDateUpdated = true;
        if(chIdx == playback->playChannelIdx)
        {
            bSelectedDateChannelUpdated = true;
        }
    }
    if (selectMonthChange > 0)
    {
        bSelectedMonthUpdated = true;
    }
    pM3u8Channel[chIdx]->lastParseTime = lastParseTime;
    mutex.unlock();
}

bool HlsProcess::parseM3U8(QString absFilePath, int absPathHeaderLen, M3u8Info *info)
{
    QString line;
    QStringList list;
    QFile file;
    QFileInfo fileInfo(absFilePath);
    double time;
    bool bDuration = false;
    bool bFinished = false;

    if (info == NULL)
        return false;

    file.setFileName(absFilePath);
    if (!file.open(QIODevice::ReadOnly))
    {
        if(DBG(_DBG_HLS_PARSER_))
        {
            qDebug() << STR_DBG_HLS
                     << "open m3u8 file fail" << absFilePath;
        }
        return false;
    }

    info->absPath = fileInfo.absoluteFilePath();
    info->absPathHeaderLen = absPathHeaderLen;

    // ------ get baseName
    QString path = fileInfo.absolutePath().replace(info->absPath.left(absPathHeaderLen), "");
    while (path.endsWith("/"))
    {
        path.remove(path.length()-1, 1);
    }
    while (path.startsWith("/"))
    {
        path.remove(0, 1);
    }
    QStringList dirList = path.split("/");
    if (dirList.count() > 0)
    {
        info->baseName = dirList.last();
    }
    else
    {
        info->baseName = fileInfo.baseName();
    }

    // ------ get startTime
    info->recStartTime = QDateTime().fromString(info->baseName, STR_HLSDIR_DATETIME_MS);
    if (info->recStartTime.isValid() == false)
    {
        info->recStartTime = QDateTime().fromString(info->baseName, STR_HLSDIR_DATETIME);
        if (info->recStartTime.isValid() == false)
        {
            return false;
        }
    }

    // ------ get time
    info->recTime = 0;
    while(!file.atEnd())
    {
        line = file.readLine().trimmed();
        if (line.startsWith("#EXT-X-TARGETDURATION:", Qt::CaseInsensitive))
        {
            double duration = 0;
            list = line.split(":");
            line = list.at(1);
            duration = line.toDouble();
            bDuration = (duration > 0);
        }
        else if (line.startsWith("#EXTINF:",Qt::CaseInsensitive) && bDuration)
        {
            line = line.remove(0,8);
            list = line.split(",");
            line = list.at(0);
//            qDebug() << line;
            time = line.toDouble();
            info->recTime += time; // unit: 1 sec
        }
        else if(line.startsWith("#EXT-X-ENDLIST"))
        {
            bFinished = true;
        }
        else if(line.startsWith("segment") && bDuration == false)
        {

        }
    }
    file.close();

    // ------ get endTime
    info->recEndTime = info->recStartTime.addMSecs((int)(info->recTime * 1000 + 0.5));

    if (!bFinished)
    {
        if(DBG(_DBG_HLS_PARSER_))
        {
            qDebug() << STR_DBG_HLS
                     << "without #EXT-X-ENDLIST" << absFilePath;
        }
    }
    return true;
}

bool HlsProcess::checkAndMkDir(QString absDirPath)
{
    if (absDirPath.startsWith("/mnt/") ||
        absDirPath.startsWith("/dev/") ||
        absDirPath.startsWith("/media/"))
    {
        bool isMnt = false;
        QProcess proc;
        QList<QString> list, sublist;
        QString line, val, prefix;
        proc.start("df", QStringList());
        proc.waitForFinished();
        /*
        Filesystem         1K-blocks    Used Available Use% Mounted on
        /dev/root              86016   86016         0 100% /rom
        devtmpfs              731308       0    731308   0% /rom/dev
        tmpfs                 747884    1756    746128   1% /tmp
        /dev/mmcblk0p2         37861    1311     35731   4% /overlay
        overlayfs:/overlay     37861    1311     35731   4% /
        tmpfs                    512       0       512   0% /dev
        /dev/sda            30851072 6676928  24174144  22% /mnt/sda
        */
        QString output = proc.readAllStandardOutput();
        list = output.split("\n");
        foreach(line, list)
        {
            line = line.trimmed();
            qDebug() << line;
            sublist = line.split("%");
            if (sublist.count() <= 1)
                continue;
            val = sublist.at(1).trimmed();
            if (val.startsWith("/") && val.length() > 1) // skip the path "/" only
            {
                prefix = val + "/";
                if (absDirPath == val || absDirPath.startsWith(prefix))
                {
                    isMnt = true;
                    break;
                }
            }
        }
        if (!isMnt)
        {
            dialog->showError(QString("Please mount the device first for the directory %1 !").arg(absDirPath));
            return false;
        }
    }

    if (QDir().mkpath(absDirPath) != true)
    {
        dialog->showError(QString("Fail to create the directory %1 !").arg(absDirPath));
        return false;
    }
    return true;
}
