/**
 * @file m3u8info.cpp
 * @author Realtek Semiconductor Corp.
 * @date Nov 2017
 * @brief The structure for the m3u8 files after parsing
 */

#include "m3u8info.h"
#include "config.h"
#include <QDebug>

void M3u8Channel::hashInsert(QString key, M3u8Info m3u8Info)    // add or update
{
    mutex.lock();
    QHash<QString, M3u8Info>::const_iterator iterator = hashM3u8.find(key);
    if (iterator == hashM3u8.end())
    {
        if(DBG(_DBG_HLS_PARSER_))
            qDebug() << STR_DBG_HLS
                     << chIdx << "hashM3u8 insert:" << key;
        // add
        hashM3u8.insert(key, m3u8Info);
        QDate startDate = m3u8Info.recStartTime.date();
        QDate endDate = m3u8Info.recEndTime.date();
        dateAdd(startDate, key);
        if(endDate > startDate)
        {
            QDate date = startDate;
            while(date != endDate)
            {
                date = date.addDays(1);
                dateAdd(date, key);
            }
        }
    }
    else
    {
        if(DBG(_DBG_HLS_PARSER_))
            qDebug() << STR_DBG_HLS
                     << chIdx << "hashM3u8 update:" << key;
        M3u8Info info = iterator.value();
        QDate startDateOld = info.recStartTime.date();
        QDate endDateOld = info.recEndTime.date();
        QDate startDateNew = m3u8Info.recStartTime.date();
        QDate endDateNew = m3u8Info.recEndTime.date();
        // update
        hashM3u8.insert(key, m3u8Info);
        if(startDateOld == startDateNew &&
           endDateOld == endDateNew)
        {
        }
        else
        {
            // date remove
            dateRemove(startDateOld, key);
            if(endDateOld > startDateOld)
            {
                QDate date = startDateOld;
                while(date != endDateOld)
                {
                    date = date.addDays(1);
                    dateRemove(date, key);
                }
            }
            // date add
            dateAdd(startDateNew, key);
            if(endDateNew > startDateNew)
            {
                QDate date = startDateNew;
                while(date != endDateNew)
                {
                    date = date.addDays(1);
                    dateAdd(date, key);
                }
            }
        }
    }
    mutex.unlock();
}

void M3u8Channel::hashRemove(QString key)
{
    mutex.lock();
    QHash<QString, M3u8Info>::const_iterator iterator = hashM3u8.find(key);
    if (iterator != hashM3u8.end())
    {
        if(DBG(_DBG_HLS_PARSER_))
            qDebug() << STR_DBG_HLS
                     << chIdx << "hashM3u8 remove:" << key;
        // remove
        M3u8Info info = iterator.value();
        QDate startDate = info.recStartTime.date();
        QDate endDate = info.recEndTime.date();
        dateRemove(startDate, key);
        if(startDate != endDate)
        {
            dateRemove(endDate, key);
        }
        hashM3u8.remove(key);
    }
    mutex.unlock();
}

void M3u8Channel::hashClear()
{
    mutex.lock();
    foreach(QList<QString>*pList, hashDate)
    {
        pList->clear();
        delete (pList);
    }
    hashDate.clear();
    if(DBG(_DBG_HLS_PARSER_))
        qDebug() << STR_DBG_HLS
                 << chIdx << "hashDate clear()";

    hashM3u8.clear();
    if(DBG(_DBG_HLS_PARSER_))
        qDebug() << STR_DBG_HLS
                 << chIdx << "hashM3u8 clear()";
    mutex.unlock();
}

QList<QString> M3u8Channel::hashKeyListByDate(QDate date)
{
    QHash<QDate, QList<QString>*>::const_iterator iterator = hashDate.find(date);
    QList<QString> strList;
    if(iterator == hashDate.end())
    {
        return strList;
    }
    QList<QString>* pList = iterator.value();
    foreach(QString str, *pList)
    {
        strList.append(str);
    }
    std::sort(strList.begin(), strList.end());
    return strList;
}

QList<QDate> M3u8Channel::getDateList()
{
    return hashDate.keys();
}

void M3u8Channel::dateAdd(QDate idxDate, QString key)
{
    QHash<QDate, QList<QString>*>::const_iterator iterator = hashDate.find(idxDate);
    if(iterator == hashDate.end())
    {
        QList<QString> *pList = new QList<QString>();
        pList->append(key);
        hashDate.insert(idxDate, pList);
        dbgDateList(idxDate, pList, "insert");
        dbgDateM3u8Info(idxDate, key, "insert");
    }
    else
    {
        QList<QString>* pList = iterator.value();
        if(pList->removeAll(key))
        {
            dbgDateM3u8Info(idxDate, key, "remove");
        }
        pList->append(key);
        dbgDateM3u8Info(idxDate, key, "insert");
    }
}

void M3u8Channel::dateRemove(QDate idxDate, QString key)
{
    QHash<QDate, QList<QString>*>::const_iterator iterator = hashDate.find(idxDate);
    if (iterator != hashDate.end())
    {
        QList<QString> *pList = iterator.value();
        if(pList->removeAll(key))
        {
            dbgDateM3u8Info(idxDate, key, "remove");

            if(pList->count() <= 0)
            {
                dbgDateList(idxDate, pList, "remove");
                delete (pList);
                hashDate.remove(idxDate);
            }
        }
        else
        {
            dbgDateM3u8Info(idxDate, key, "no");
        }
    }
}

void M3u8Channel::dbgDateM3u8Info(QDate idxDate, QString key, QString action)
{
    if(DBG(_DBG_HLS_PARSER_))
    {
        qDebug() << STR_DBG_HLS
                 << chIdx
                 << QString("hashDate %1 %2 key=%3")
                        .arg(idxDate.toString(STR_HLSDIR_DATE))
                        .arg(action)
                        .arg(key);
    }
}

void M3u8Channel::dbgDateList(QDate idxDate, QList<QString>*pList, QString action)
{
    if(DBG(_DBG_HLS_PARSER_))
        qDebug() << STR_DBG_HLS
                 << chIdx
                 << QString().asprintf("hashDate %s %s QList* %p",
                                       idxDate.toString(STR_HLSDIR_DATE).toStdString().c_str(),
                                       action.toStdString().c_str(),
                                       pList);
}

void M3u8Channel::display()
{

}
