/**
 * @file define.h
 * @author Realtek Semiconductor Corp.
 * @date Aug 2017
 * @brief The defined value or string for GUI
 */

#ifndef DEFINE_H
#define DEFINE_H

#define CHANNEL_MAX         36  // >= Config::sys.ipcChannelMax
#define x_pos_align         16
#define _4K_WIDTH_          3840
#define _4k_HEIGHT_         2160

#define WindowId_Invalid    -1
#define ChannelId_Invalid   -1
#define ClientId_Invalid    -1
#define HLS_SUBDIR(x)   (QString().asprintf("%02d", x+1))

#define STR_DISCONNECT  "disconnect"
#define STR_CONNECT     "connect"
#define STR_HIDE        "hide"
#define STR_SETUP       "setup"
#define STR_REC         "rec"
#define STR_IPC         "ipc"
#define STR_FILE        "file"
#define STR_HLSDIR_DATE "yyyyMMdd"
#define STR_HLSDIR_DATETIME "yyyyMMdd_HHmmss"
#define STR_HLSDIR_DATETIME_MS "yyyyMMdd_HHmmss.zzz"
#define STR_SETTING_APPLY   "Apply setting !"
#define STR_SETTING_FAILED  "Setting failed !"
#define STR_DBG_HLS     "[HLS]"     // HLS parser
#define STR_DBG_PLAY    "[PLAY]"    // playback
#define STR_DBG_MONT    "[MONT]"    // monitor
#if 0
#define _RGBA_COLOR_BLACK_      "rgba(1,1,1,255)"   // rgb(0,0,0) will be replaced
#define _R_COLOR_BLACK_         1
#define _G_COLOR_BLACK_         1
#define _B_COLOR_BLACK_         1
#define _A_COLOR_BLACK_         255
#else
#define _RGBA_COLOR_BLACK_      "rgba(0,0,0,255)"
#endif

#define _K_             1000
#define IFNAME_LAN      "lan"    // interface name
//#if QT_ENV_ONLY == 1
//#define NETWORK_INTERFACE_PATH  "interfaces"
//#else
//#define NETWORK_INTERFACE_PATH  "/etc/network/interfaces"
//#endif

#define STYLESHEET_TITLE_1  "color: rgb(58, 69, 69); font: bold 18px \"Arial\";"
#define STYLESHEET_TITLE_2  "color: rgb(114, 130, 130); font: bold 28px \"Arial\";"

#define STYLESHEET_PLAYBACK_SUBTITLE_BG "background-color: rgb(53, 57, 60);"
#define STYLESHEET_PLAYBACK_SUBTITLE    STYLESHEET_PLAYBACK_SUBTITLE_BG    \
                                    "font: bold 16px \"Arial Black\";"      \
                                    "color: rgb(117, 117, 117);"

#define STYLESHEET_COMBOBOX "background-color: rgb(20, 25, 28);"    \
                            "border:0px;"   \
                            "font: bold 20px \"Arial Black\";"  \
                            "color: rgb(169, 204, 135);"

#define STYLESHEET_RADIOCHECK "background-color: rgb(20, 25, 28);"    \
                            "border:0px;"   \
                            "font: bold 20px \"Arial Black\";"  \
                            "color: rgb(169, 204, 135);"

#define TABLE_ITEM_HEIGHT    40

#define IMAGE_VALUE_MAX 64
#define IMAGE_VALUE_MIN 0
#define IMAGE_VALUE_DEF 32
#define IMAGE_VALUE_OFFSET 32

#define SHARPNESS_VALUE_MAX 31
#define SHARPNESS_VALUE_MIN 0
#define SHARPNESS_VALUE_DEF 0

#define SLIDESHOW_INTERVAL_MAX 60
#define SLIDESHOW_INTERVAL_MIN 3
#define SLIDESHOW_INTERVAL_DEF 5

#define SOUND_VALUE_MAX 100
#define SOUND_VALUE_MIN 0
#define SOUND_VALUE_DEF 10

#endif // DEFINE_H
