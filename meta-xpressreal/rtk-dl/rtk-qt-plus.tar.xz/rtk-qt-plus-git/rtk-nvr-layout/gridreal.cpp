/**
 * @file gridreal.cpp
 * @author Realtek Semiconductor Corp.
 * @date Aug 2017
 * @brief The main operation for each IP camera or playback per channel
 */

#include "gridreal.h"
#include "config.h"

GridReal::GridReal()
{
    QDateTime current = QDateTime::currentDateTime();

    type = GridType_IPC;
    status = GridStatus_NONE;
    channelIndex = -1;
    setSrcDefault();
    setCropDefault(false);
    bNeedStart = false;
    bNeedStop = false;
    bSetImage = false;
    timeNeedStart = current;
    timeNeedStop = current;
    bNeedSrc = true;
    bNeedCrop = false;
    timeoutNeedSrc = 0;
    absRecDir = Config::absoluteHlsDirPath;
    bNeedRecStart = false;
    bNeedRecStop = false;
    bAlreadyRec = false;
    timeNeedRecStart = current;
    timeNeedRecStop = current;
    timeRecStart = current;
    recElapsed = 0;
    recSegmentTime = 1000;

    timeoutNeedSpeed = 0;
    bNeedSpeed = false;
    speed = 1;
    bNeedSeek = false;
    seekTime = 0;
    bNeedMute = false;
    mute = false;
    bNeedVolume = false;
    volume = 0;
    rtspCmd = RtspCmd_NULL;
#if RTSP_AV
    cid = ClientId_Invalid;
#elif RTSP_GST
    rtspPlayer = NULL;
#endif
    absFilePath = AbsFilePath_NULL;
    bAlreadyFilePlay = false;
    bSeamless = false;
    wndId = WindowId_Invalid;
    channelId = ChannelId_Invalid;
    needBind = true;
#if QT_ENV_ONLY == 1
    bgColor = QColor(0, 0, 0);
#endif
    ip = IP_NULL;
    bIpValid = false;
    bNewFrameArrived = false;
    ipcState = PING_BEGIN;
    bufferWriteCnt = 0;
    sizeZeroCnt = 0;
    connectErrCnt = 0;
    writeErrCnt = 0;
    noFrameTime = 0;
    monitorQueryTime = 0;
}

void GridReal::setSrcDefault()
{
    this->bNeedSrc = true;
    timeoutNeedSrc = Config::sys.getSourcePollingTime;
    src.setRect(0,0,Config::sys.width, Config::sys.height);
}

void GridReal::setSrc(QRect rect, bool bNeedSrc)
{
    this->bNeedSrc = bNeedSrc;
    if (bNeedSrc)
    {
        timeoutNeedSrc = Config::sys.getSourcePollingTime;
    }
    this->src.setRect(rect.x(), rect.y(), rect.width(), rect.height());
}

void GridReal::setSrc(int x, int y, int width, int height, bool bNeedSrc)
{
    this->bNeedSrc = bNeedSrc;
    if (bNeedSrc)
    {
        timeoutNeedSrc = Config::sys.getSourcePollingTime;
    }
    this->src.setRect(x, y, width, height);
}

QRect GridReal::getSrc()
{
    return (QRect(this->src.x(), this->src.y(), this->src.width(), this->src.height()));
}

bool GridReal::ifGetSrc()
{
    return (!this->bNeedSrc);
}

int GridReal::src_x()
{
    return src.x();
}

int GridReal::src_y()
{
    return src.y();
}

int GridReal::src_width()
{
    return src.width();
}

int GridReal::src_height()
{
    return src.height();
}

void GridReal::setCropDefault(bool bNeedCrop)
{
    this->bNeedCrop = bNeedCrop;
    crop.setRect(0,0,Config::sys.width, Config::sys.height);
}

void GridReal::setCrop(QRect rect, bool bNeedCrop)
{
    this->bNeedCrop = bNeedCrop;
    this->crop.setRect(rect.x(), rect.y(), rect.width(), rect.height());
}

void GridReal::setCrop(int x, int y, int width, int height, bool bNeedCrop)
{
    this->bNeedCrop = bNeedCrop;
    this->crop.setRect(x, y, width, height);
}

QRect GridReal::getCrop()
{
    return (QRect(this->crop.x(), this->crop.y(), this->crop.width(), this->crop.height()));
}

bool GridReal::ifCrop()
{
    return this->bNeedCrop;
}

int GridReal::crop_x()
{
    return crop.x();
}

int GridReal::crop_y()
{
    return crop.y();
}

int GridReal::crop_width()
{
    return crop.width();
}

int GridReal::crop_height()
{
    return crop.height();
}

void GridReal::unmark_crop()
{
    bNeedCrop = false;
}

void GridReal::setImage(bool bSetImage)
{
    this->bSetImage = bSetImage;
}

bool GridReal::ifSetImage()
{
    return this->bSetImage;
}

void GridReal::setSpeed(double speed)
{
    bNeedSpeed = true;
    this->speed = speed;
    timeoutNeedSpeed = 0;
}

void GridReal::setMute(bool bMute)
{
    bNeedMute = true;
    this->mute = bMute;
}

void GridReal::setVolume(double volume)
{
    bNeedVolume = true;
    this->volume = volume;
}

void GridReal::copy(GridReal *from)
{
    this->setSrc(from->src_x(),from->src_y(),
                 from->src_width(), from->src_height(),
                 from->bNeedSrc);
    this->setCrop(from->crop_x(),from->crop_y(),
                  from->crop_width(),from->crop_height(),
                  from->bNeedCrop);
    this->bSetImage = from->bSetImage;

    this->type = from->type;
    this->status = from->status;
    this->infoCurr.copy(&from->infoCurr);
    this->channelIndex = from->channelIndex;
    this->bNeedStart = from->bNeedStart;
    this->bNeedStop = from->bNeedStop;
    this->timeNeedStart = from->timeNeedStart;
    this->timeNeedStop = from->timeNeedStop;

    this->timeoutNeedSrc = from->timeoutNeedSrc;
    this->absRecDir = from->absRecDir;
    this->bNeedRecStart = from->bNeedRecStart;
    this->bNeedRecStop = from->bNeedRecStop;
    this->bAlreadyRec = from->bAlreadyRec;
    this->timeNeedRecStart = from->timeNeedRecStart;
    this->timeNeedRecStop = from->timeNeedRecStop;
    this->timeRecStart = from->timeRecStart;
    this->recElapsed = from->recElapsed;
    this->recSegmentTime = from->recSegmentTime;

    this->absFilePath = from->absFilePath;
    this->bAlreadyFilePlay = from->bAlreadyFilePlay;
    this->bSeamless = from->bSeamless;
    this->timeoutNeedSpeed = from->timeoutNeedSpeed;
    this->bNeedSpeed = from->bNeedSpeed;
    this->speed = from->speed;
    this->bNeedSeek = from->bNeedSeek;
    this->seekTime = from->seekTime;
    this->bNeedMute = from->bNeedMute;
    this->mute = from->mute;
    this->bNeedVolume = from->bNeedVolume;
    this->volume = from->volume;
    this->rtspCmd = from->rtspCmd;
#if RTSP_AV
    this->cid = from->cid;
#elif RTSP_GST
    this->rtspPlayer = from->rtspPlayer;
#endif
    this->wndId = from->wndId;
    this->channelId = from->channelId;
    this->needBind = from->needBind;
#if QT_ENV_ONLY == 1
    this->bgColor = from->bgColor;
#endif
    this->ip = from->ip;
    this->bIpValid = from->bIpValid;
    this->bNewFrameArrived = from->bNewFrameArrived;
    this->ipcState = from->ipcState;
    this->bufferWriteCnt = from->bufferWriteCnt;
    this->sizeZeroCnt = from->sizeZeroCnt;
    this->connectErrCnt = from->connectErrCnt;
    this->writeErrCnt = from->writeErrCnt;
    this->noFrameTime = from->noFrameTime;
    this->monitorQueryTime = from->monitorQueryTime;
}

void GridReal::swap(GridReal *from)
{
    GridReal *tmp = new GridReal();
    tmp->copy(this);
    this->copy(from);
    from->copy(tmp);
}

#if 0
void GridReal::swapSrc(GridReal *from)
{
    QRect rect = this->getSrc();
    this->setSrc(from->getSrc(), this->bNeedSrc);
    from->setSrc(rect, from->bNeedSrc);
}

void GridReal::swapCrop(GridReal *from)
{
    QRect rect = this->getCrop();
    this->setCrop(from->getCrop(), this->bNeedCrop);
    from->setCrop(rect, from->bNeedCrop);
}
#endif
