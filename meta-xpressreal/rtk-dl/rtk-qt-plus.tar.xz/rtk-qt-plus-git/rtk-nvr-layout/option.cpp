/**
 * @file option.cpp
 * @author Realtek Semiconductor Corp.
 * @date Nov 2017
 * @brief The option structure and api
 */

#include "option.h"
#include "rtksim.h"

#define OPT_COUNT_HDMIE_MODE    10
const OPTION_S optHdmiMode[OPT_COUNT_HDMIE_MODE+1] =
{
    {OPT_COUNT_HDMIE_MODE,      "HDMI Mode"},
    {HDMI_AUTO,                 "Auto"},
    {HDMI_720P_50,              "720P_50fps"},
    {HDMI_720P_60,              "720P_60fps"},
    {HDMI_1080P_30,             "1080P_30fps"},
    {HDMI_1080P_50,             "1080P_50fps"},
    {HDMI_1080P_60,             "1080P_60fps"},
    {HDMI_1080I_50,             "1080I_50fps"},
    {HDMI_1080I_60,             "1080I_60fps"},
//    {HDMI_4K_25,                "4K_25fps"},  // not option in GUI
    {HDMI_4K_30,                "4K_30fps"},
//    {HDMI_4K_60,                "4K_60fps"},  // not option in GUI
    {HDMI_NONE,                 "None"},
};

#define OPT_COUNT_DP_MODE    5
const OPTION_S optDpMode[OPT_COUNT_DP_MODE+1] =
{
    {OPT_COUNT_DP_MODE,         "DP Mode"},
    {DP_AUTO,                   "Auto"},
    {DP_720P_60,                "720p_60fps"},
    {DP_1080P_60,               "1080p_60fps"},
    {DP_4K_30,                  "4K_30fps"},
    {DP_NONE,                   "None"},
};

#define OPT_COUNT_VIDEO_CODEC    4
const OPTION_S optVideoCodec[OPT_COUNT_VIDEO_CODEC+1] =
{
    {OPT_COUNT_VIDEO_CODEC,     "Video Codec"},
//    {VIDEO_NONE,                "None"},  // unsupport now
//    {VIDEO_AUTO,                "Auto"},  // unsupport now
    {VIDEO_H264,                "H264"},
    {VIDEO_H265,                "H265"},
    {VIDEO_MJPEG,               "MJPEG"},
    {VIDEO_MPEG4,               "MPEG4"},
};

#define OPT_COUNT_VIDEO_FB      2
const OPTION_S optVideoFb[OPT_COUNT_VIDEO_FB+1] =
{
    {OPT_COUNT_VIDEO_FB,        "Video Fb"},
    {FRAME_BUFFER_1920x1088,    "1920 x 1088"},
    {FRAME_BUFFER_3840x2160,    "3840 x 2160"},
};

/******************************* function **********************************/

QString opt_ValToStr (const OPTION_S *pOption, int value)
{
    QString strNull = "";
    if (pOption == NULL)
        return strNull;

    int count = pOption[0].value;
    for(int i=1; i<=count; i++)
    {
        if (pOption[i].value == value)
        {
            return pOption[i].str;
        }
    }
    return strNull;
}

int opt_StrToVal (const OPTION_S *pOption, QString str)
{
    if (pOption == NULL)
        return (int)OPT_ERROR;
    int count = pOption[0].value;
    for (int i=1; i <= count; i++)
    {
        if (str.compare(pOption[i].str, Qt::CaseInsensitive) == 0)
        {
            return pOption[i].value;
        }
    }
    return (int)OPT_ERROR;
}

bool opt_AddOpt (QComboBox *cb, const OPTION_S *pOption, QList<int>listExclusiveVal)
{
    if (cb == NULL || pOption == NULL)
        return false;
    int count = pOption[0].value;
    for (int i=1; i <= count; i++)
    {
        if (listExclusiveVal.indexOf(pOption[i].value) >= 0)
            continue;
        cb->addItem(pOption[i].str);
    }
    return true;
}
