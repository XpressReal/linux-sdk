/**
 * @file rlineedit.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The extension of QLineEdit
 */

#include "rlineedit.h"
#include "mainwidget.h"
#include <QRegularExpression>

RLineEdit::RLineEdit(QWidget *parent) :
    QLineEdit(parent)
{
    dataType = DataType_TEXT;
    lName = NULL;
    strName = "";
    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;
    installEventFilter(this);

    // to close the visual keyboard/keypad in screen after typing "enter" key in physical keyboard
    connect(this, SIGNAL(returnPressed()), this, SLOT(closeKeyboard()));
    connect(this, SIGNAL(editingFinished()), this, SLOT(closeKeyboard()));
}

RLineEdit::~RLineEdit()
{
}

void RLineEdit::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

bool RLineEdit::setValueRange(double valMin, double valMax, int res)
{
    if(res > 0)
    {
        this->dataType = DataType_DOUBLE;
        strType = "real number";
    }
    else if(res == 0)
    {
        this->dataType = DataType_INT;
        strType = "integer";
    }
    else
        return false;

    this->valMin = qMin(valMin, valMax);
    this->valMax = qMax(valMin, valMax);
    this->res = res;
    return true;
}

bool RLineEdit::setValueRange(QLabel *lName, double valMin, double valMax, int res)
{
    if(setValueRange(valMin, valMax, res))
    {
        this->lName = lName;
        return true;
    }
    return false;
}

bool RLineEdit::setValueRange(QString strName, double valMin, double valMax, int res)
{
    if(setValueRange(valMin, valMax, res))
    {
        this->strName = strName;
        return true;
    }
    return false;
}

double RLineEdit::getValue()
{
    if(dataType != DataType_INT &&
       dataType != DataType_DOUBLE)
        return 0;
    return val;
}

bool RLineEdit::isTextValid(QString *str, bool showErr)
{
    bool ok;
    double currVal = 0;
    QString msg, strName;
    if(dataType != DataType_INT &&
       dataType != DataType_DOUBLE)
        return true;
    if(dataType == DataType_INT)
    {
        currVal = this->text().toInt(&ok);
    }
    else if(dataType == DataType_DOUBLE)
    {
        currVal = this->text().toDouble(&ok);
    }

    if(lName != NULL)
        strName = lName->text();
    else if(this->strName.length()>0)
        strName = this->strName;

    if(!ok)
    {
        if(strName.length() > 0)
        {
            msg = QString("Invalid format of %1 for %2 !").arg(strType).arg(strName);
        }
        else
        {
            msg = QString("Invalid format of %1 !").arg(strType);
        }
        if(str != NULL)
            *str = msg;
        if(showErr)
            dialog->showError(msg);
        return false;
    }
    if (currVal < valMin || currVal > valMax)
    {
        if(strName.length() > 0)
        {
            msg = QString("%3 is out of range %1 ~ %2 !")
                    .arg(getText(valMin)).arg(getText(valMax)).arg(strName);
        }
        else
        {
            msg = QString("Out of range %1 ~ %2 !")
                    .arg(getText(valMin)).arg(getText(valMax));
        }
        if(str != NULL)
            *str = msg;
        if(showErr)
            dialog->showError(msg);
        return false;
    }
    if(str != NULL)
        str->clear();
    this->val = currVal;
    return true;
}

QString RLineEdit::getText(double currentValue)
{
    if(dataType == DataType_INT)
    {
        return QString().asprintf("%.0lf", currentValue);
    }
    else if(dataType == DataType_DOUBLE)
    {
        switch(res)
        {
        case 1: return QString().asprintf("%.1lf", currentValue);    break;
        case 2: return QString().asprintf("%.2lf", currentValue);    break;
        case 3: return QString().asprintf("%.3lf", currentValue);    break;
        case 4: return QString().asprintf("%.4lf", currentValue);    break;
        case 5: return QString().asprintf("%.5lf", currentValue);    break;
        case 6:
        default:
             return QString().asprintf("%.6lf", currentValue);    break;
        }
    }
    return "";
}

void RLineEdit::setText(uint currentValue)
{
    setText((double)currentValue);
}

void RLineEdit::setText(int currentValue)
{
    setText((double)currentValue);
}

void RLineEdit::setText(double currentValue)
{
    QString text = getText(currentValue);
    QLineEdit::setText(text);
    val = currentValue;
}

void RLineEdit::setText(QString str)
{
    QLineEdit::setText(str);
}

bool RLineEdit::eventFilter(QObject *o, QEvent *e)
{
    RLineEdit *le = (RLineEdit *)o;
    int center_x, new_x, new_y, shift_y;

    if(le == this &&
       e->type() == QEvent::MouseButtonPress)
    {
//        qDebug() << __func__;
//        qDebug() << this->x() << this->y() << this->width() << this->height();
//        qDebug() << "parent_absolute_offset_x=" << parent_absolute_offset_x;
//        qDebug() << "parent_absolute_offset_y=" << parent_absolute_offset_y;
//        qDebug() << "this";
//        qDebug() << this->x() << this->y() << this->width() << this->height();

        QList<QWidget *>keyList = {keyboard, keypad};
        foreach (QWidget *key, keyList)
        {
            center_x = this->parent_absolute_offset_x + this->x() + this->width()/2;
            new_x = center_x - key->width()/2;
            new_y = this->parent_absolute_offset_y + this->y() + this->height();
            if (new_x<0)
            {
                new_x=0;
            }
            else if (new_x + key->width() > Config::sys.width)
            {
                new_x = Config::sys.width - key->width();
            }
            shift_y = (key == keyboard) ? KEYBOARD_Y_OFFSET : 0;
            // tune the widget position
            key->setGeometry(new_x,
                                new_y + shift_y,
                                key->width(),
                                key->height());
//            qDebug() << key->x() << key->y() << key->width()<< key->height();
        }

    }
    return QObject::eventFilter(o, e);
}

void RLineEdit::closeKeyboard()
{
    QList<QWidget *>keyList = {keyboard, keypad};
    foreach(QWidget *key, keyList)
    {
        if (key->isVisible())
        {
            key->setVisible(false);
        }
    }
    isTextValid(NULL, true);
}

bool RLineEdit::isValidIpv4Ip()
{
    // check format
    QRegularExpression re("^(\\d+).(\\d+).(\\d+).(\\d+)$");
    QRegularExpressionMatch match=re.match(this->text());
    if(match.hasMatch() == false)
    {
//        qDebug() << __func__ << "format mismatch";
        return false;
    }

    // check value
    int ip[4];
    ip[0] = match.captured(1).toInt();
    ip[1] = match.captured(2).toInt();
    ip[2] = match.captured(3).toInt();
    ip[3] = match.captured(4).toInt();
//    qDebug() << __func__ << ip[0] << ip[1] << ip[2] << ip[3];
    if (ip[0] < 0 || ip[0] > 255 ||
        ip[1] < 0 || ip[1] > 255 ||
        ip[2] < 0 || ip[2] > 255 ||
        ip[3] < 0 || ip[3] > 255)
    {
//        qDebug() << __func__ << "value mismatch";
        return false;
    }
    return true;
}
