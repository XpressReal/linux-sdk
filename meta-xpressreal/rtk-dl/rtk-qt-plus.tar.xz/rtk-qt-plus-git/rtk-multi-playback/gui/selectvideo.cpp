/**
 * @file selectvideo.cpp
 * @author Realtek Semiconductor Corp.
 * @date Dec 2017
 * @brief The widget page to do video selection
 */

#include <QFileDialog>
#include "selectvideo.h"
#include "ui_selectvideo.h"
#include "mainwidget.h"

SelectVideo::SelectVideo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SelectVideo)
{
    ui->setupUi(this);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;

    ui->wContent->setStyleSheet("background-color: rgb(20, 25, 28);");
    ui->lVideo->setStyleSheet(STYLESHEET_TITLE_2);

    // QList<QComboBox*> optionList = {};
    // foreach(QComboBox *cb, optionList)
    // {
    //     cb->setStyleSheet(STYLESHEET_COMBOBOX);
    // }
    lFileName = NULL;

    connect(ui->tbAddFiles, SIGNAL(clicked(bool)), this, SLOT(add_files_clicked(bool)));
    connect(ui->tbAddDir, SIGNAL(clicked(bool)), this, SLOT(add_dir_clicked(bool)));
    connect(ui->tbLoadList, SIGNAL(clicked(bool)), this, SLOT(load_list_clicked(bool)));
    connect(ui->tbSaveList, SIGNAL(clicked(bool)), this, SLOT(save_list_clicked(bool)));
    connect(ui->tbClearList, SIGNAL(clicked(bool)), this, SLOT(clear_list_clicked(bool)));
    connect(ui->tbCancel, SIGNAL(clicked(bool)), this, SLOT(cancel_clicked(bool)));
}

SelectVideo::~SelectVideo()
{
    delete ui;
}

void SelectVideo::setFileNameList(QListWidget *list)
{
    lFileName = list;
}

void SelectVideo::setup()
{
    labelList->append({ui->lAddFiles, ui->lAddDir, 
                        ui->lLoadList, ui->lSaveList, ui->lClearList});
    actionList->append({ui->tbAddFiles, ui->tbAddDir, 
                        ui->tbLoadList, ui->tbSaveList, 
                        ui->tbClearList, ui->tbCancel});
    QStringList filter = Config::sys.videoFileFilter.split(" ");
    QRegularExpression regex("^\\.[a-zA-Z0-9]+$");
    for (int i=0; i<filter.count(); i++)
    {
        if (regex.match(filter.at(i)).hasMatch())
            videoFileFilter.append(filter.at(i).toLower());
    }
    QString strToolTip = QString("video file filters: %1").arg(videoFileFilter.join(" "));
    qDebug () << QString().asprintf("%s:%d %s", 
                            __FUNCTION__, __LINE__, strToolTip.toStdString().c_str());
    // ui->tbAddDir->setToolTip(strToolTip);
}

void SelectVideo::initValue(bool fromStatus)
{
    // qDebug () << QString().asprintf("%s:%d", __FUNCTION__, __LINE__);
}

void SelectVideo::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);
}

void SelectVideo::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void SelectVideo::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

void SelectVideo::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    // QList<RLineEdit *>keyboardList = {};
    // QList<RLineEdit *>keybadList = {};
    // RLineEdit *le;
    // foreach(le, keyboardList)
    // {
    //     le->installEventFilter(keyboard);
    // }
    // foreach(le, keybadList)
    // {
    //     le->installEventFilter(keypad);
    // }
}

void SelectVideo::showEvent(QShowEvent *)
{
    // initValue(true);
}

// bool System::eventFilter(QObject *o, QEvent *e)
// {
//     return QObject::eventFilter(o, e);
// }

void SelectVideo::setLastItemToolTip (QString filePath)
{
    lFileName->item(lFileName->count()-1)->setToolTip(
                    QString("#%1: %2").arg(lFileName->count()).arg(filePath));
}

bool SelectVideo::ifPassFileFilter(QString filePath)
{
    bool ifPass = false;
    if (videoFileFilter.count() > 0)
    {
        QString fileCheck = filePath.toLower();
        for (int i=0; i<videoFileFilter.count(); i++)
        {
            if (fileCheck.endsWith(videoFileFilter.at(i)))
            {
                ifPass = true;
                break;
            }
        }

    }
    else
    {
        ifPass = true;
    }
    return ifPass;
}

void SelectVideo::addFiles(QStringList files)
{
    QString video_list_tmp_file = QCoreApplication::applicationDirPath()+"/"+VIDEO_LIST_TMP_FILE;
    const int listCount_org = lFileName->count();
    int total = 0;
    for(const QString &file : files) {
        lFileName->addItem(file);
        setLastItemToolTip(file);
        qDebug() << QString().asprintf("Add file #%d: %s", total+1, file.toStdString().c_str());
        total ++;
    }
    if (total > 0)
        qDebug () << QString().asprintf("%s:%d Add total files: %d", 
                            __FUNCTION__, __LINE__, total);
    saveList(video_list_tmp_file, false, false);
    playback->checkIfUpdateShuffleIndexList(listCount_org != lFileName->count());
    if(lFileName->count() > 0 && lFileName->currentRow() < 0)
        lFileName->setCurrentRow(0);
}

void SelectVideo::add_files_clicked(bool)
{
    if (lFileName == NULL)
        return;
    selectVideo->setVisible(false);
    QStringList files = QFileDialog::getOpenFileNames(
        this,
        tr("Add Video Files"),
        "/",
        tr("*.*"));
    addFiles (files);
}

void SelectVideo::addDir(QString folderPath)
{
    QString video_list_tmp_file = QCoreApplication::applicationDirPath()+"/"+VIDEO_LIST_TMP_FILE;
    const int listCount_org = lFileName->count();
    QStringList filesList, dirUnserachList;
    int cnt_total = 0, cnt_match = 0;
    QStringList subnameList;

    dirUnserachList.append(folderPath);
    while (dirUnserachList.count() > 0)
    {
        QString dirPath = dirUnserachList.first();
        dirUnserachList.removeFirst();

        QDir dir(dirPath);
        dir.setFilter(QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot);
        QFileInfoList list = dir.entryInfoList();
        for (const QFileInfo & fileInfo:list)
        {
            if(fileInfo.isDir())
            {
                dirUnserachList.append(fileInfo.filePath());
            }
            else
            {
                QString filePath = fileInfo.filePath().trimmed();
                if (filePath.indexOf('.') >= 0)
                {
                    QString subname = filePath.split('.').last();
                    if (subnameList.indexOf(subname) < 0)
                    {
                        subnameList.append(subname);
                        // qDebug() << QString().asprintf("Find new subname #%d : .%s", 
                        //                     subnameList.count(), subname.toStdString().c_str());
                    }
                }
                if (ifPassFileFilter(filePath))
                {
                    lFileName->addItem(filePath);
                    setLastItemToolTip(filePath);
                    qDebug() << QString().asprintf("Add file #%d: %s", cnt_match+1, filePath.toStdString().c_str());
                    cnt_match ++;
                }
                // else
                // {
                //     qDebug() << "Filtered file:" << filePath;
                // }
                cnt_total ++;
            }
        }
    }
    if (subnameList.count() > 0)
    {
        subnameList.sort();
        const int max_len = 60;
        const int subnameCount = subnameList.count();
#if 1   // to print large information separately
        int i =0;
        qDebug() << "Total " << subnameCount << "different subnames in the directory: ";
        while (i<subnameCount)
        {
            int len=subnameList.at(i).length()+1;
            int j=i;
            while (j<subnameCount)
            {
                if ((j+1) < subnameCount &&
                    (len+subnameList.at(j+1).length()+1)<max_len)
                {
                    len += (subnameList.at(j+1).length()+1);
                    j++;
                }
                else
                    break;
            }
            if (j<=i)
            {
                qDebug() << subnameList.at(i);
                i+=1;
            }
            else
            {
                QStringList sub = subnameList.mid(i, j-i+1);
                qDebug() << sub.join(" ");
                i=j+1;
            }
        }
#else
        QString subname_all = subnameList.join(" ");
        qDebug() << "Total " << subnameCount << "different subnames in the directory: " << subname_all;
#endif
    }
    if (cnt_total > 0)
        qDebug() << QString().asprintf("%s:%d Add files: matched %d/ total %d from %s", 
                            __FUNCTION__, __LINE__,
                            cnt_match, cnt_total, folderPath.toStdString().c_str());
    saveList(video_list_tmp_file, false, false);
    playback->checkIfUpdateShuffleIndexList(listCount_org != lFileName->count());
    if(lFileName->count() > 0 && lFileName->currentRow() < 0)
        lFileName->setCurrentRow(0);
}

void SelectVideo::add_dir_clicked(bool)
{
    if (lFileName == NULL)
        return;
    selectVideo->setVisible(false);
    QString folderPath = QFileDialog::getExistingDirectory(
        this,
        tr("Select Whole Directory"),
        "/");
    if (folderPath.isEmpty())
    {
        qDebug() << __FUNCTION__ << __LINE__ << "No directory is selected";
        return;
    }
    addDir(folderPath);
}

bool SelectVideo::loadList(QString filePath, bool ifDialog, bool ifMsg)
{
    QString video_list_tmp_file = QCoreApplication::applicationDirPath()+"/"+VIDEO_LIST_TMP_FILE;
    const int listCount_org = lFileName->count();
    int cnt_total = 0, cnt_file = 0, cnt_filter = 0, cnt_fail = 0;
    QFile file(filePath);
    QTextStream in(&file);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        if(ifMsg)
            qDebug () << QString().asprintf("%s:%d Fail to Load File %s !", 
                                __FUNCTION__, __LINE__, filePath.toStdString().c_str());
        if(ifDialog)
            dialog->showError(QString().sprintf("Fail to Load File %s !", filePath.toStdString().c_str()));
        return false;
    }
    while (!in.atEnd())
    {
        QString line = in.readLine().trimmed();
        // qDebug() << __FUNCTION__ << __LINE__ << line;
        if (line.length() <= 0)
            continue;
        cnt_total ++;
        QFileInfo fileInfo(line);
        QString path = fileInfo.filePath();
        if (fileInfo.exists() && fileInfo.isFile())
        {
            if (ifPassFileFilter(path))
            {
                lFileName->addItem(path);
                setLastItemToolTip(path);
                if(ifMsg)
                {
                    qDebug() << QString().asprintf("Add file #%d: %s", cnt_file+1, path.toStdString().c_str());
                }
                cnt_file ++;
            }
            else
            {
                // qDebug() << "Filtered file:" << path;
                cnt_filter ++;
            }
        }
        else
        {
            cnt_fail ++;
            if(ifMsg)
            {
                qDebug() << "Error file:" << path;
            }
        }
    }
    file.close();
    if (cnt_total > 0)
    {
        if(ifMsg)
        {
            qDebug () << QString().asprintf("%s:%d Add files: success %d/ filtered %d/ failed %d/ total %d from %s", 
                                __FUNCTION__, __LINE__, 
                                cnt_file, cnt_filter, cnt_fail, cnt_total, filePath.toStdString().c_str());
        }
    }

    saveList(video_list_tmp_file, false, false);
    playback->checkIfUpdateShuffleIndexList(listCount_org != lFileName->count());
    if(lFileName->count() > 0 && lFileName->currentRow() < 0)
        lFileName->setCurrentRow(0);

    return (cnt_file > 0);
}

void SelectVideo::load_list_clicked(bool)
{
    if (lFileName == NULL)
        return;
    selectVideo->setVisible(false);
    QString filePath = QFileDialog::getOpenFileName(
        this,
        tr("Select file to load"),
        "/",
        tr("*.txt"));

    if (filePath.isEmpty())
        return;
    loadList(filePath, true, true);
}

bool SelectVideo::saveList(QString filePath, bool ifDialog, bool ifMsg)
{
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        if(ifMsg)
            qDebug () << QString().asprintf("%s:%d Fail to Save File %s !", 
                                __FUNCTION__, __LINE__, filePath.toStdString().c_str());
        if(ifDialog)
            dialog->showError(QString().sprintf("Fail to Save File %s !", filePath.toStdString().c_str()));
        return false;
    }
    QTextStream out(&file);
    for (int i=0; i<lFileName->count(); i++)
    {
        out << lFileName->item(i)->text() << "\n";
    }
    file.close();
    if(ifMsg)
        qDebug () << QString().asprintf("%s:%d Success to Save File %s !", 
                            __FUNCTION__, __LINE__, filePath.toStdString().c_str());
    if(ifDialog)
        dialog->showInfo(QString().sprintf("Success to Save File %s !", filePath.toStdString().c_str()));
    return true;
}

void SelectVideo::save_list_clicked(bool)
{
    if (lFileName == NULL)
        return;
    selectVideo->setVisible(false);

    QString filePath = QFileDialog::getOpenFileName(
        this,
        tr("Select file to save"),
        "/",
        tr("*.txt"));

    if (filePath.isEmpty())
        return;
    saveList(filePath, true, true);
}

void SelectVideo::clearList()
{
    QString video_list_tmp_file = QCoreApplication::applicationDirPath()+"/"+VIDEO_LIST_TMP_FILE;
    const int listCount_org = lFileName->count();
    lFileName->clear();
    saveList(video_list_tmp_file, false, false);
    playback->checkIfUpdateShuffleIndexList(listCount_org != lFileName->count());
    lFileName->setCurrentRow(-1);
}

void SelectVideo::clear_list_clicked(bool)
{
    if (lFileName == NULL)
        return;
    selectVideo->setVisible(false);
    clearList();
}

void SelectVideo::cancel_clicked(bool)
{
    selectVideo->setVisible(false);
}
