/**
 * @file rslider.cpp
 * @author Realtek Semiconductor Corp.
 * @date March 2018
 * @brief The slider in Realtek style
 */

#include "rslider.h"
#include <QEvent>
#include <QMouseEvent>
#include <QDebug>
#include <math.h>

RSlider::RSlider(QWidget *parent) :
    QWidget(parent)
{
    this->setStyleSheet("border:0px;"    // transparent for Linux
                        "background:transparent;");
    dataType = DataType_INT;
    val = 50;
    valMax = 100;
    valMin = 0;
    valStep = 1;
    valLogInt = 2;
    res = 0;
    ifEmitValueChanged = true;

    ifBtnBarPressed = false;
    btnBarCenterBase.setX(0);
    btnBarCenterBase.setY(0);
    btnBarScreenBase.setX(0);
    btnBarScreenBase.setY(0);

    btnAdd = new RToolButton(this);
    btnAdd->setGeometry(0, 0, 30, 30);
    btnAdd->setIconSize(QSize(30, 30));
    btnAdd->setStyleSheet("border:0px;"    // transparent for Linux
                             "background:transparent;");
    btnAdd->setIcons(QIcon(":/images/slider_add_normal.png"),
                            QIcon(":/images/slider_add_hover.png"),
                            QIcon(":/images/slider_add_normal.png"),
                            QIcon(":/images/slider_add_hover.png"),
                            false);

    btnSub = new RToolButton(this);
    btnSub->setGeometry(0, 0, 30, 30);
    btnSub->setIconSize(QSize(30, 30));
    btnSub->setStyleSheet("border:0px;"    // transparent for Linux
                             "background:transparent;");
    btnSub->setIcons(QIcon(":/images/slider_subtract_normal.png"),
                            QIcon(":/images/slider_subtract_hover.png"),
                            QIcon(":/images/slider_subtract_normal.png"),
                            QIcon(":/images/slider_subtract_hover.png"),
                            false);

    wBarCenter = new QWidget(this);
    wBarCenter->setStyleSheet("border:0px;"    // transparent for Linux
                        "background:transparent;");
    wBarLeft = new QWidget(this);
    wBarLeft->setStyleSheet("border:0px;"    // transparent for Linux
                            "background: url(\":/images/slider_bar_bg-left_selected.png\")");
    wBarRight = new QWidget(this);
    wBarRight->setStyleSheet("border:0px;"    // transparent for Linux
                             "background: url(\":/images/slider_bar_bg-right_normal.png\")");
    wBarSelect = new QWidget(wBarCenter);
    wBarSelect->setStyleSheet("border:0px;"    // transparent for Linux
                              "background: url(\":/images/slider_bar_bg_selected.png\");"); // default: repeat
    wBarNormal = new QWidget(wBarCenter);
    wBarNormal->setStyleSheet("border:0px;"    // transparent for Linux
                              "background: url(\":/images/slider_bar_bg_normal.png\");"); // default: repeat

    label = new QLabel(this);
    label->setGeometry(36, 0, 100, 10);
    label->setStyleSheet("background:transparent;"
                         "color: rgb(176, 176, 176);"
                         "font: bold 10px \"Arial\";");
    label->setAlignment(Qt::AlignCenter | Qt::AlignTop);

    btnBar = new RToolButton(this);
    btnBar->setGeometry(0, 0, 30, 30);
    btnBar->setIconSize(QSize(30, 30));
    btnBar->setStyleSheet("border:0px;"    // transparent for Linux
                          "background:transparent;");
    btnBar->setIcons(QIcon(":/images/slider_bar_btn_normal.png"),
                        QIcon(":/images/slider_bar_btn_hover.png"),
                        QIcon(":/images/slider_bar_btn_normal.png"),
                        QIcon(":/images/slider_bar_btn_hover.png"),
                        false);
    btnBar->setMouseTracking(true);
    btnBar->installEventFilter(this);

    connect(btnAdd, SIGNAL(pressed()),  this, SLOT(_btnAddPressed()));
    connect(btnAdd, SIGNAL(released()), this, SLOT(_btnAddReleased()));
    connect(btnSub, SIGNAL(pressed()),  this, SLOT(_btnSubPressed()));
    connect(btnSub, SIGNAL(released()), this, SLOT(_btnSubReleased()));
    timerAdd = new QTimer(this);
    timerSub = new QTimer(this);
    connect(timerAdd, SIGNAL(timeout()), this, SLOT(_timerAddUpdate()));
    connect(timerSub, SIGNAL(timeout()), this, SLOT(_timerSubUpdate()));
}

RSlider::~RSlider()
{
    delete(timerSub);
    delete(timerAdd);
    delete(btnAdd);
    delete(btnSub);
    delete(wBarNormal);
    delete(wBarSelect);
    delete(wBarLeft);
    delete(wBarRight);
    delete(wBarCenter);
    delete(btnBar);

    delete(label);
}

void RSlider::setGeometry(int x, int y, int w, int h)
{
    setGeometry(QRect(x, y, w, h));
}

void RSlider::setGeometry(const QRect &rect)
{
//    qDebug() << rect.x() << rect.y() << rect.width() << rect.height();
    QWidget::setGeometry(rect);
    int btnWidth = (rect.height() * 6 <= rect.width()) ? rect.height() : 30;
    int y = (rect.height() - btnWidth) / 2;
    btnSub->setGeometry(0, y, btnWidth, btnWidth);
    btnSub->setIconSize(QSize(btnWidth, btnWidth));
    btnAdd->setGeometry(rect.width()-btnWidth, y, btnWidth, btnWidth);
    btnAdd->setIconSize(QSize(btnWidth, btnWidth));
    int interval = btnWidth;
    int wBarCenterWidth = rect.width() - btnWidth * 2 - interval;
    wBarCenterXMin = btnWidth+interval/2;
    wBarCenterXMax = wBarCenterXMin + wBarCenterWidth;
    int wBarHeight = 20;
    int wBarY = (rect.height()-wBarHeight)/2;
    wBarCenter->setGeometry(wBarCenterXMin, wBarY, wBarCenterWidth, wBarHeight);
    wBarLeft->setGeometry(wBarCenterXMin-4, wBarY, 4, wBarHeight);
    wBarRight->setGeometry(wBarCenterXMax , wBarY, 4, wBarHeight);
    btnBar->setIconSize(QSize(btnWidth, btnWidth));
    btnBar->setGeometry((wBarCenterXMin+wBarCenterXMax)/2-btnWidth/2, 0, btnWidth, btnWidth);
    wBarSelect->setGeometry(0, 0, wBarCenterWidth/2, 20);
    wBarNormal->setGeometry(wBarCenterWidth/2, 0, wBarCenterWidth/2, 20);

    setValue(val);
}

bool RSlider::eventFilter(QObject *o, QEvent *e)
{
    RToolButton *btn = (RToolButton *)o;

    if(btn == btnBar)
    {
        const QMouseEvent* const me = static_cast<const QMouseEvent*>( e );

        if(e->type() == QEvent::MouseButtonPress)
        {
            btnBarCenterBase.setX(btnBar->pos().x()+btnBar->width()/2);
            btnBarCenterBase.setY(btnBar->pos().y()+btnBar->height()/2);
            btnBarScreenBase = me->screenPos();
            ifBtnBarPressed = true;

        }
        else if(e->type() == QEvent::MouseButtonRelease ||
                e->type() == QEvent::MouseMove)
        {
            if(ifBtnBarPressed)
            {
                int centerX = btnBarCenterBase.x() + me->screenPos().x() - btnBarScreenBase.x();
                centerX = qMin(centerX, wBarCenterXMax);
                centerX = qMax(centerX, wBarCenterXMin);
                if(wBarCenterXMax > wBarCenterXMin &&
                   valMax > valMin)
                {
                    double value = valMin + (valMax - valMin) * (centerX - wBarCenterXMin) / (wBarCenterXMax - wBarCenterXMin);
                    setValue(value, true);
                }
            }
            if(e->type() == QEvent::MouseButtonRelease)
            {
                ifBtnBarPressed = false;
            }
//            qDebug() << e << btnBar->geometry() << me->pos();
        }
    }
    return QObject::eventFilter(o, e);
}

bool RSlider::setValueRange(double valMin, double valMax, double valStep, int res)
{
    if(res > 0)
    {
        dataType = DataType_DOUBLE;
        strType = "real number";
    }
    else
    {
        dataType = DataType_INT;
        strType = "integer";
        res = 0;
    }

    this->valMin = qMin(valMin, valMax);
    this->valMax = qMax(valMin, valMax);
    this->valStep = valStep;
    this->res = res;

    return true;
}

bool RSlider::setValue(double value, bool discardSameValue)
{
    static double valueUpdate = 50;
    value = qMin(value, valMax);
    value = qMax(value, valMin);

    if(dataType == DataType_INT ||
       dataType == DataType_DOUBLE)
    {
        if(value != valMin &&
           value != valMax &&
           value != val &&
           valStep != 0)
        {
            int step = (int)((value - valMin) / valStep + 0.5);
            value = valMin + valStep * step;
            value = qMin(value, valMax);
        }
        val = value;
    }

    int logInt;
    if(val>=10 || val<=-10)
    {
        double logN = log(abs(val));
//        qDebug() << "logN=" << logN;
        logInt = (int)logN +
                 (((logN - (int)logN) > 0) ? 1 : 0) +
                 ((val < 0) ? 1 : 0) +
                 res;
    }
    else
    {
        logInt = 2 +
                 ((val < 0) ? 1 : 0) +
                 res;
    }
    if(valLogInt != logInt)
    {
        valLogInt = logInt;
        label->setGeometry(label->x(), label->y(), valLogInt * 8, label->height());
//        qDebug() << label->geometry();
    }

    int centerX = wBarCenterXMin + 0.5 + (wBarCenterXMax - wBarCenterXMin) * (val - valMin) / (valMax - valMin);
    btnBar->setGeometry(centerX-btnBar->width()/2, btnBar->pos().y(),
                        btnBar->width(), btnBar->height());
    label->setGeometry(centerX-label->width()/2, 0,
                       label->width(), label->height());
    int selectWidth = centerX - wBarCenterXMin;
    wBarSelect->setGeometry(0, 0, selectWidth, wBarSelect->height());
    wBarNormal->setGeometry(selectWidth, 0, wBarCenter->width()-selectWidth, wBarSelect->height());
    _updateLabelText();

    if(discardSameValue &&
       valueUpdate == val)
        return true;
    valueUpdate = val;

    if(ifEmitValueChanged)
    {
        if(dataType == DataType_INT)
        {
            emit(valueChanged((int)val));
        }
        else
        {
            emit(valueChanged(val));
        }
    }
    return true;
}

double RSlider::getValue()
{
    return val;
}

void RSlider::setEmitValueChanged(bool ifEmit)
{
    ifEmitValueChanged = ifEmit;
}

void RSlider::_btnAddPressed()
{
    setValue(val + valStep);
    timerAdd->setInterval(1000);
    timerAdd->start();
}

void RSlider::_btnAddReleased()
{
    timerAdd->stop();
}

void RSlider::_btnSubPressed()
{
    setValue(val - valStep);
    timerSub->setInterval(1000);
    timerSub->start();
}

void RSlider::_btnSubReleased()
{
    timerSub->stop();
}

void RSlider::_timerAddUpdate()
{
    if(val < valMax)
    {
        setValue(val + valStep);
    }
    _updateTimerInterval(timerAdd);
}

void RSlider::_timerSubUpdate()
{
    if(val > valMin)
    {
        setValue(val - valStep);
    }
    _updateTimerInterval(timerSub);
}

void RSlider::_updateLabelText()
{
    QString str;
    if(dataType == DataType_INT)
    {
        str = QString().asprintf("%.0lf", val);
    }
    else if(dataType == DataType_DOUBLE)
    {
        switch(res)
        {
        case 1: str = QString().asprintf("%.1lf", val);    break;
        case 2: str = QString().asprintf("%.2lf", val);    break;
        case 3: str = QString().asprintf("%.3lf", val);    break;
        case 4: str = QString().asprintf("%.4lf", val);    break;
        case 5: str = QString().asprintf("%.5lf", val);    break;
        case 6:
        default:
             str = QString().asprintf("%.6lf", val);    break;
        }
    }
    label->setText(str);
}

void RSlider::_updateTimerInterval(QTimer *timer)
{
    int interval = timer->interval();
    if (interval > 200)
        timer->setInterval(200);
    else if(interval > 100)
        timer->setInterval(interval - 10);
    else if(interval > 50)
        timer->setInterval(interval - 5);
}
