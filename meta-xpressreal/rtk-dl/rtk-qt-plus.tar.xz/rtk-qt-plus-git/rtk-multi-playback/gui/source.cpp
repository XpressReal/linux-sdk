/**
 * @file source.cpp
 * @author Realtek Semiconductor Corp.
 * @date May 2025
 * @brief The widget page to connect IPC
 */

#include "source.h"
#include "ui_source.h"
#include "mainwidget.h"

Source::Source(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Source)
{
    ui->setupUi(this);

//    QList<QToolButton *> btnLayer1 = {ui->tbCurrent, ui->tbHistory, ui->tbSetting};
//    tlSource = new RTabLayer(this);
//    tlSource->init(btnLayer1, ui->stkLayer1, TABLAYER_LAYER_1);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;

    ui->lSource->setStyleSheet(STYLESHEET_TITLE_2);
//    ui->pgManagement->installEventFilter(this);
//    ui->pgExport->installEventFilter(this);

    QList<QComboBox*> optionList = {ui->cbInput};
    foreach(QComboBox *cb, optionList)
    {
        cb->setStyleSheet(STYLESHEET_COMBOBOX);
    }

    for(int i=0; i<SOURCE_COUNT; i++)
    {
        lChannelList[i] = new QList<QLabel*>();
        lStatusList[i] = new QList<QLabel*>();
        edList[i] = new QList<RLineEdit*>();
        checkBoxList[i] = new QList<RCheckBox*>();
    }

    // the index value of cbInput should match to SourceType_e
    ui->cbInput->addItem("Video_File"); // SOURCE_VIDEO_FILE
    ui->cbInput->addItem("RTSP_Command");// SOURCE_RTSP_CMD
    connect(ui->cbInput, SIGNAL(currentIndexChanged(int)), this, SLOT(input_changed(int)));

    {   // File table initialization
        QLabel *lb;
        RLineEdit *edit;
        QComboBox *combo;
        RCheckBox *check;
        int i;
        QStringList horHeadList, verHeadList;

        ui->tableFile->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);

        // File header
        for(i=0; i<CHANNEL_MAX; i++)
        {
            verHeadList.append(HLS_SUBDIR(i));
        }
        horHeadList << "Channel" << "Status" << "Set";
        ui->tableFile->setColumnCount(horHeadList.count());
        ui->tableFile->setRowCount(verHeadList.count());
        ui->tableFile->setHorizontalHeaderLabels(horHeadList);
        ui->tableFile->horizontalHeader()->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE);
        ui->tableFile->horizontalHeader()->setFixedHeight(TABLE_ITEM_HEIGHT);
        ui->tableFile->verticalHeader()->setVisible(false);

        ui->tableFile->setColumnWidth(0, 100);
        ui->tableFile->setColumnWidth(1, 210);
        ui->tableFile->setColumnWidth(2, 130);
        for(i=0; i<ui->tableFile->rowCount(); i++)
        {
            ui->tableFile->setRowHeight(i, TABLE_ITEM_HEIGHT);
        }

        // File item
        for(i=0; i<CHANNEL_MAX; i++)
        {
            lb = new QLabel();
            lb->setAlignment(Qt::AlignCenter | Qt::AlignVCenter);
            lb->setText(verHeadList.at(i));
            this->lChannelList[SOURCE_VIDEO_FILE]->append(lb);
            ui->tableFile->setCellWidget(i, 0, (QWidget*)lb);

            lb = new QLabel();
            lb->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            lb->setText("Disconnected");
            this->lStatusList[SOURCE_VIDEO_FILE]->append(lb);
            ui->tableFile->setCellWidget(i, 1, (QWidget*)lb);

            check = new RCheckBox();
            check->setText("Connect");
            this->checkBoxList[SOURCE_VIDEO_FILE]->append(check);
            ui->tableFile->setCellWidget(i, 2, (QWidget*)check);
        }
    }

    {   // RTSP table initialization
        QLabel *lb;
        RLineEdit *edit;
        QComboBox *combo;
        RCheckBox *check;
        int i;
        QStringList horHeadList, verHeadList;

        ui->tableRtsp->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);

        // RTSP header
        for(i=0; i<CHANNEL_MAX; i++)
        {
            verHeadList.append(HLS_SUBDIR(i));
        }
        horHeadList << "Channel" << "Status" << "RTSP Command" << "Set";
        ui->tableRtsp->setColumnCount(horHeadList.count());
        ui->tableRtsp->setRowCount(verHeadList.count());
        ui->tableRtsp->setHorizontalHeaderLabels(horHeadList);
        ui->tableRtsp->horizontalHeader()->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE);
        ui->tableRtsp->horizontalHeader()->setFixedHeight(TABLE_ITEM_HEIGHT);
        ui->tableRtsp->verticalHeader()->setVisible(false);

        ui->tableRtsp->setColumnWidth(0, 100);
        ui->tableRtsp->setColumnWidth(1, 210);
        ui->tableRtsp->setColumnWidth(2, 570);
        ui->tableRtsp->setColumnWidth(3, 130);
        for(i=0; i<ui->tableRtsp->rowCount(); i++)
        {
            ui->tableRtsp->setRowHeight(i, TABLE_ITEM_HEIGHT);
        }

        // RTSP item
        for(i=0; i<CHANNEL_MAX; i++)
        {
            lb = new QLabel();
            lb->setAlignment(Qt::AlignCenter | Qt::AlignVCenter);
            lb->setText(verHeadList.at(i));
            this->lChannelList[SOURCE_RTSP_CMD]->append(lb);
            ui->tableRtsp->setCellWidget(i, 0, (QWidget*)lb);

            lb = new QLabel();
            lb->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            lb->setText("Disconnected");
            this->lStatusList[SOURCE_RTSP_CMD]->append(lb);
            ui->tableRtsp->setCellWidget(i, 1, (QWidget*)lb);

            edit = new RLineEdit(this);
            this->edList[SOURCE_RTSP_CMD]->append(edit);
            ui->tableRtsp->setCellWidget(i, 2, (QWidget*)edit);

            check = new RCheckBox();
            check->setText("Connect");
            this->checkBoxList[SOURCE_RTSP_CMD]->append(check);
            ui->tableRtsp->setCellWidget(i, 3, (QWidget*)check);
        }
    }

    connect(ui->tbSourceSet, SIGNAL(clicked(bool)), this, SLOT(set_clicked(bool)));
    connect(ui->tbSourceCancel, SIGNAL(clicked(bool)), this, SLOT(cancel_clicked(bool)));
}

Source::~Source()
{
    for (int i=0; i<SOURCE_COUNT; i++)
    {
        foreach(RCheckBox *check, *checkBoxList[i])
        {
            delete check;
        }
        delete checkBoxList[i];
        foreach(RLineEdit *ed, *edList[i])
        {
            delete ed;
        }
        delete edList[i];
        foreach(QLabel *lb, *lStatusList[i])
        {
            delete lb;
        }
        delete lStatusList[i];
        foreach(QLabel *lb, *lChannelList[i])
        {
            delete lb;
        }
        delete lChannelList[i];
    }
//    delete tlSource;
    delete ui;
}

void Source::setup()
{
    int i;
    for (int j=0; j<SOURCE_COUNT; j++)
    {
        for (i=0; i<CHANNEL_MAX; i++)
        {
            if (this->lChannelList[j]->count() > i)
                labelList->append(this->lChannelList[j]->at(i));
            if (this->lStatusList[j]->count() > i)
                labelList->append(this->lStatusList[j]->at(i));
            if (this->edList[j]->count() > i)
            {
                editList->append(this->edList[j]->at(i));
                if(Config::sys.onvifEnable)
                {
                    edList[j]->at(i)->installEventFilter(this);
                }
            }
            if (this->checkBoxList[j]->count() > i)
                checkList->append(this->checkBoxList[j]->at(i));
        }
    }
    labelList->append({ui->lInput});
    actionList->append({ui->tbSourceSet, ui->tbSourceCancel});

    for (i=Config::sys.ipcChannelMax; i<CHANNEL_MAX; i++)
    {
        ui->tableRtsp->setRowHidden(i, true);
    }

    for (i=Config::sys.fileChannelMax; i<CHANNEL_MAX; i++)
    {
        ui->tableFile->setRowHidden(i, true);
    }

    input_changed(0);
    initValue(false);
}

void Source::initValue(bool fromStatus)
{
    for (int chIdx=0; chIdx<Config::sys.fileChannelMax; chIdx++)
    {
        lStatusList[SOURCE_VIDEO_FILE]->at(chIdx)->setText(
                                playback->isGstPlayNull(SOURCE_VIDEO_FILE, chIdx) ? "Disconnected" : "Connected");
        checkBoxList[SOURCE_VIDEO_FILE]->at(chIdx)->setChecked(Config::file.ch[chIdx].ifConnect==true);
    }
    for (int chIdx=0; chIdx<Config::sys.ipcChannelMax; chIdx++)
    {
        lStatusList[SOURCE_RTSP_CMD]->at(chIdx)->setText(
                                playback->isGstPlayNull(SOURCE_RTSP_CMD, chIdx) ? "Disconnected" : "Connected");
        edList[SOURCE_RTSP_CMD]->at(chIdx)->setText(Config::ipc.ch[chIdx].rtspCmd);
        checkBoxList[SOURCE_RTSP_CMD]->at(chIdx)->setChecked(Config::ipc.ch[chIdx].ifConnect==true);
    }
    ui->cbInput->setCurrentIndex(Config::source);
}

void Source::setGeometry(const QRect &rect)
{
//    qDebug() << __func__ << "(const QRect &rect)";
    QWidget::setGeometry(rect);
    foreach(RLineEdit *edit, *edList[SOURCE_RTSP_CMD])
    {
        edit->setParentAbsoluteOffset(parent_absolute_offset_x+ui->tableRtsp->x(),
                                      parent_absolute_offset_y+ui->tableRtsp->y()+TABLE_ITEM_HEIGHT);
    }
}

void Source::setGeometry(int x, int y, int w, int h)
{
//    qDebug() << __func__ << "(int x, int y, int w, int h)";
    this->setGeometry(QRect(x, y, w, h));
}

void Source::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

void Source::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    for(int i=0; i<SOURCE_COUNT; i++)
    {
        foreach(RLineEdit *edit, *edList[i])
        {
            edit->installEventFilter(keyboard);
        }
    }
    Q_UNUSED(keypad);
}

bool Source::eventFilter(QObject *o, QEvent *e)
{
    if(e->type() == QEvent::MouseButtonPress)
    {
    }
    return QObject::eventFilter(o, e);
}

void Source::showEvent(QShowEvent *)
{
    initValue(true);
}

void Source::input_changed(int idx)
{
    QTableWidget *tableWidget[SOURCE_COUNT] = {ui->tableFile, ui->tableRtsp};
    for (int i=0; i<SOURCE_COUNT; i++)
    {
        tableWidget[i]->setVisible(i==idx);
    }
}

void Source::set_clicked(bool)
{
    set_apply(false, true);
}

void Source::cancel_clicked(bool)
{
    setting->setVisible(false);
}

void Source::set_apply(bool ifDialog, bool ifSave)
{
    int source = ui->cbInput->currentIndex();
    bool bChanged = false;
    if (Config::source != source)
    {
        qDebug() << QString().asprintf("%s:%d input source %d -> %d",
                            __FUNCTION__, __LINE__, Config::source , source);
        Config::source = source;
        bChanged = true;
    }

    int channelMax = (source==SOURCE_VIDEO_FILE ?  : Config::sys.ipcChannelMax);

    if (source == SOURCE_VIDEO_FILE)
    {
        for (int i=0; i<Config::sys.fileChannelMax; i++)
        {
            if (this->checkBoxList[source]->count() <= i)
                continue;
            if (Config::file.ch[i].ifConnect != this->checkBoxList[source]->at(i)->isChecked())
            {
                qDebug() << QString().asprintf("%s:%d file %d connect %d -> %d",
                                    __FUNCTION__, __LINE__, i, 
                                    Config::file.ch[i].ifConnect, this->checkBoxList[source]->at(i)->isChecked());
                Config::file.ch[i].ifConnect = this->checkBoxList[source]->at(i)->isChecked();
                bChanged = true;
            }
            else if (Config::file.ch[i].ifConnect)
            {
                qDebug() << QString().asprintf("%s:%d file %d connect %d",
                                    __FUNCTION__, __LINE__, i, 
                                    Config::file.ch[i].ifConnect);
            }
        }
    }
    else    // source == SOURCE_RTSP_CMD
    {
        for (int i=0; i<Config::sys.ipcChannelMax; i++)
        {
            if (this->edList[source]->count() <= i)
                continue;
            if (Config::ipc.ch[i].rtspCmd != this->edList[source]->at(i)->text())
            {
                qDebug() << QString().asprintf("%s:%d ipc %d rtsp cmd \"%s\" -> \"%s\"",
                                    __FUNCTION__, __LINE__, i, 
                                    Config::ipc.ch[i].rtspCmd, this->edList[source]->at(i)->text());
                Config::ipc.ch[i].rtspCmd = this->edList[source]->at(i)->text();
                bChanged = true;
            }
            if (Config::ipc.ch[i].ifConnect != this->checkBoxList[source]->at(i)->isChecked())
            {
                qDebug() << QString().asprintf("%s:%d ipc %d connect %d -> %d",
                                    __FUNCTION__, __LINE__, i, 
                                    Config::ipc.ch[i].ifConnect, this->checkBoxList[source]->at(i)->isChecked());
                Config::ipc.ch[i].ifConnect = this->checkBoxList[source]->at(i)->isChecked();
                bChanged = true;
            }
            else if (Config::ipc.ch[i].ifConnect)
            {
                qDebug() << QString().asprintf("%s:%d ipc %d connect %d",
                                    __FUNCTION__, __LINE__, i, 
                                    Config::ipc.ch[i].ifConnect);
            }
        }
    }
    if (bChanged)
    {
        Config::saveDefaultProfile();
    }
    if(ifDialog)
    {
        dialog->showInfo(STR_SETTING_APPLY);
    }
    setting->setVisible(false);
}
