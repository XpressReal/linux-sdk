/**
 * @file keyboard.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page for keyboard operation
 */

#include "keyboard.h"
#include "ui_keyboard.h"

Keyboard::Keyboard(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Keyboard),
    _rcvObject(0)
{
    int i;

    ui->setupUi(this);
    ui->stackedWidget->setStyleSheet("background-color:rgb(20,24,27);"
                                     "border-radius:6px;");

    QLabel *label[] = {ui->lRealtek1, ui->lRealtek2, NULL};
    i=0;
    while(label[i]!=NULL)
    {
        label[i]->setStyleSheet("color: rgb(169, 204, 125);"
                                "font: bold 36px \"Arial Black\";");
        i++;
    }


    QToolButton *symbolBtn[] = {// bigCapital
                          ui->btn_A, ui->btn_B, ui->btn_C, ui->btn_D, ui->btn_E,
                          ui->btn_F, ui->btn_G, ui->btn_H, ui->btn_I, ui->btn_J,
                          ui->btn_K, ui->btn_L, ui->btn_M, ui->btn_N, ui->btn_O,
                          ui->btn_P, ui->btn_Q, ui->btn_R, ui->btn_S, ui->btn_T,
                          ui->btn_U, ui->btn_V, ui->btn_W, ui->btn_X, ui->btn_Y,
                          ui->btn_Z,
                          // smaller
                          ui->btn_a, ui->btn_b, ui->btn_c, ui->btn_d, ui->btn_e,
                          ui->btn_f, ui->btn_g, ui->btn_h, ui->btn_i, ui->btn_j,
                          ui->btn_k, ui->btn_l, ui->btn_m, ui->btn_n, ui->btn_o,
                          ui->btn_p, ui->btn_q, ui->btn_r, ui->btn_s, ui->btn_t,
                          ui->btn_u, ui->btn_v, ui->btn_w, ui->btn_x, ui->btn_y,
                          ui->btn_z,
                          // symbol
                          ui->btn_0, ui->btn_1, ui->btn_2, ui->btn_3, ui->btn_4,
                          ui->btn_5, ui->btn_6, ui->btn_7, ui->btn_8, ui->btn_9,
                          ui->btn_exclam, ui->btn_at, ui->btn_numberSign, ui->btn_dollar, ui->btn_percent,
                          ui->btn_asciiCircum, ui->btn_ampersand, ui->btn_asterisk, ui->btn_parenLeft, ui->btn_parenRight,
                          ui->btn_asciiTilde, ui->btn_quoteLeft, ui->btn_braceLeft, ui->btn_braceRight, ui->btn_bracketLeft,
                          ui->btn_bracketRight, ui->btn_less, ui->btn_greater, ui->btn_comma, ui->btn_period,
                          ui->btn_question, ui->btn_bar, ui->btn_slash, ui->btn_backslash, ui->btn_underscore,
                          ui->btn_minus, ui->btn_plus, ui->btn_equal, ui->btn_colon, ui->btn_semicolon,
                          ui->btn_quoteDbl, ui->btn_apostrophe,
                          // ending
                          NULL};
    i=0;
    while(symbolBtn[i]!=NULL)
    {
        _textBtnList.append(symbolBtn[i]);
        symbolBtn[i]->setStyleSheet(QString(
                                    "QToolButton{"
                                            "background-color: rgb(86, 87, 90);"
                                            "color: rgb(255, 255, 255);"
                                            "%1"
                                            "border-radius:4px;}"
                                    "QToolButton:hover{"
                                            "background-color: rgb(169, 204, 135);"
                                            "color: rgb(20, 24, 27);"
                                            "%1"
                                            "border-radius:4px;}")
                                    .arg("font: bold 28px \"Arial\";"));
        i++;
    }

    QToolButton *textCtlBtn[] = {ui->btn_0_enter, ui->btn_0_backspace, ui->btn_0_space,
                                 ui->btn_1_enter, ui->btn_1_backspace, ui->btn_1_space,
                                 ui->btn_2_enter, ui->btn_2_backspace, ui->btn_2_space,
                                 NULL};
    i=0;
    while(textCtlBtn[i]!=NULL)
    {
        _textBtnList.append(textCtlBtn[i]);
        i++;
    }

    QToolButton *colorBtn[] = {ui->btn_0_enter, ui->btn_0_backspace, ui->btn_0_space, ui->btn_0_caps, ui->btn_0_123,
                               ui->btn_1_enter, ui->btn_1_backspace, ui->btn_1_space, ui->btn_1_caps, ui->btn_1_123,
                               ui->btn_2_enter, ui->btn_2_backspace, ui->btn_2_space, ui->btn_eng,
                               NULL};
    i=0;
    while(colorBtn[i]!=NULL)
    {
        colorBtn[i]->setStyleSheet(QString(
                                   "QToolButton{"
                                        "background-color:rgb(60, 63, 66);"
                                        "color: rgb(13, 18, 20);"
                                        "%1"
                                        "border-radius:4px;}"
                                   "QToolButton:hover{"
                                        "background-color:rgb(169, 204, 135);"
                                        "color: rgb(20, 24, 27);"
                                        "%1"
                                        "border-radius:4px;}")
                                    .arg("font: bold 20px \"Arial\";"));
        i++;
    }

    int cnt = _textBtnList.count();
    QToolButton *btn;
    for(int i=0; i<cnt; i++)
    {
        btn = _textBtnList.at(i);
        connect(btn, &QToolButton::clicked, this, [this, btn]() {
            sendKeyEvent(btn);
        });
    }

    ui->lRealtek1->raise();
    ui->lRealtek2->raise();
    ui->stackedWidget->setCurrentIndex(0);
    _old_eng_pg_idx = 0;
    _mousePressed = false;
    _mousePosition = QPoint();
    this->hide();
}

Keyboard::~Keyboard()
{
    delete ui;
}

void Keyboard::on_btn_0_caps_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    _old_eng_pg_idx = 1;
}

void Keyboard::on_btn_1_caps_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    _old_eng_pg_idx = 0;
}

void Keyboard::on_btn_0_123_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}

void Keyboard::on_btn_1_123_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}

void Keyboard::on_btn_eng_clicked()
{
    ui->stackedWidget->setCurrentIndex(_old_eng_pg_idx);
}

void Keyboard::mousePressEvent(QMouseEvent *e)
{
    if (e->button() == Qt::LeftButton)
    {
        _mousePressed = true;
        _mousePosition = e->pos();
    }
}

void Keyboard::mouseMoveEvent(QMouseEvent *e)
{
    if (_mousePressed)
    {
        move( mapToParent( e->pos() - _mousePosition ) );
    }
}

void Keyboard::mouseReleaseEvent(QMouseEvent *e)
{
    if (e->button() == Qt::LeftButton)
    {
        _mousePressed = false;
        _mousePosition = QPoint();
    }
}

bool Keyboard::eventFilter(QObject *o, QEvent *e)
{
    if(e->type() == QEvent::MouseButtonPress)
    {
        _rcvObject = o;
        this->show();
        this->raise();
    }
    else if(e->type() == QEvent::Hide ||
            e->type() == QEvent::FocusOut)
    {
        this->hide();
    }
    return QObject::eventFilter(o, e);
}

void Keyboard::sendKeyEvent(QWidget *w)
{
    QToolButton *btn = static_cast<QToolButton *>(w);

    if (!_rcvObject)
        return;

    QString name = btn->objectName().split('_').last();
//    qDebug() << __func__ << name << btn->text();

    QKeyEvent *e;
    if( name.length() == 1 )
    {
        QChar c = *name.data();
        e = new QKeyEvent(QEvent::KeyPress, c.unicode(), Qt::NoModifier, QString(c));
    }
    else
    {
        name = name.toUpper();
        if(name == "ENTER")
        {
            e = new QKeyEvent(QEvent::KeyPress, Qt::Key_Enter, Qt::NoModifier);
            QApplication::sendEvent(_rcvObject, e);
            this->hide();
            return;
        }

        if(name == "BACKSPACE")
            e = new QKeyEvent(QEvent::KeyPress, Qt::Key_Backspace, Qt::NoModifier);
        else if(name == "SPACE")
            e = new QKeyEvent(QEvent::KeyPress, Qt::Key_Space, Qt::NoModifier, QString(' '));
        else
        {
            int key = Qt::Key_unknown;

            if (name == "EXCLAM")           key = Qt::Key_Exclam;
            else if (name == "AT")          key = Qt::Key_At;
            else if (name == "NUMBERSIGN")  key = Qt::Key_NumberSign;
            else if (name == "DOLLAR")      key = Qt::Key_Dollar;
            else if (name == "PERCENT")     key = Qt::Key_Percent;
            else if (name == "ASCIICIRCUM") key = Qt::Key_AsciiCircum;
            else if (name == "AMPERSAND")   key = Qt::Key_Ampersand;
            else if (name == "ASTERISK")    key = Qt::Key_Asterisk;
            else if (name == "PARENLEFT")   key = Qt::Key_ParenLeft;
            else if (name == "PARENRIGHT")  key = Qt::Key_ParenRight;
            else if (name == "ASCIITILDE")  key = Qt::Key_AsciiTilde;
            else if (name == "QUOTELEFT")   key = Qt::Key_QuoteLeft;
            else if (name == "BRACELEFT")   key = Qt::Key_BraceLeft;
            else if (name == "BRACERIGHT")  key = Qt::Key_BraceRight;
            else if (name == "BRACKETLEFT") key = Qt::Key_BracketLeft;
            else if (name == "BRACKETRIGHT")key = Qt::Key_BracketRight;
            else if (name == "LESS")        key = Qt::Key_Less;
            else if (name == "GREATER")     key = Qt::Key_Greater;
            else if (name == "COMMA")       key = Qt::Key_Comma;
            else if (name == "PERIOD")      key = Qt::Key_Period;
            else if (name == "QUESTION")    key = Qt::Key_Question;
            else if (name == "BAR")         key = Qt::Key_Bar;
            else if (name == "SLASH")       key = Qt::Key_Slash;
            else if (name == "BACKSLASH")   key = Qt::Key_Backslash;
            else if (name == "UNDERSCORE")  key = Qt::Key_Underscore;
            else if (name == "MINUS")       key = Qt::Key_Minus;
            else if (name == "PLUS")        key = Qt::Key_Plus;
            else if (name == "EQUAL")       key = Qt::Key_Equal;
            else if (name == "COLON")       key = Qt::Key_Colon;
            else if (name == "SEMICOLON")   key = Qt::Key_Semicolon;
            else if (name == "QUOTEDBL")    key = Qt::Key_QuoteDbl;
            else if (name == "APOSTROPHE")  key = Qt::Key_Apostrophe;
            else
            {
                return;
            }

            e = new QKeyEvent(QEvent::KeyPress, key, Qt::NoModifier, QString(btn->text()));
        }
    }

    if(!e)
        return;

    QApplication::sendEvent(_rcvObject, e);

    delete e;
}
