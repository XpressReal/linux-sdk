/**
 * @file rdialog.h
 * @author Realtek Semiconductor Corp.
 * @date Oct 2017
 * @brief The widget page of dialog to show message or confirm
 */

#ifndef RDIALOG_H
#define RDIALOG_H

#include <QFrame>


namespace Ui {
class RDialog;
}

class RDialog : public QWidget
{
    Q_OBJECT

public:
    explicit RDialog(QWidget *parent = 0);
    ~RDialog();

    typedef enum
    {
        Unknown = -1,
        Rejected = 0,
        Accepted,
    } RDialogStatus_E;

    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void showError(QString msg);
    void showInfo(QString msg);
    void showWarning(QString msg);
    void showConfirm(QString msg, void(*fnAccept)() = NULL, void(*fnReject)() = NULL);

private:
    Ui::RDialog *ui;
    QList<QFrame *> frameList;
    void(*fnAccept)();
    void(*fnReject)();

protected:
    void mousePressEvent(QMouseEvent *e);

private slots:
    void doAccept(bool);
    void doReject(bool);
    void doErrorClose(bool);
    void doInfoClose(bool);
    void doWarningClose(bool);
    void showDialog(QFrame *obj);
};

#endif // RDIALOG_H
