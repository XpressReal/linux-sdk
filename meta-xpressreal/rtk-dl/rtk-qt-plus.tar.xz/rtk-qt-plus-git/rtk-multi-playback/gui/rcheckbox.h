/**
 * @file rcheckbox.h
 * @author Realtek Semiconductor Corp.
 * @date Jan 2018
 * @brief The extenstion of QWidget to fix bug of QCheckBox
 */

#ifndef RCHECKBOX_H
#define RCHECKBOX_H

#include <QWidget>
#include <QLabel>
#include "rtoolbutton.h"

class RCheckBox : public QWidget    //[20180115:Brian] NAS-292：Fix bug of QCheckBox
{
    Q_OBJECT
public:
    RCheckBox(QWidget *parent = 0);
    ~RCheckBox();

    RToolButton *btn;
    QLabel      *label;

//    void setIcons(const QIcon &off_normal_icon,
//                  const QIcon &off_hover_icon,
//                  const QIcon &on_normal_icon,
//                  const QIcon &on_hover_icon,
//                  bool checkActive);
//    void setActive(bool active, bool bHover);
    bool isChecked();
    void setChecked(bool checked);
    void setText(QString text);
    QString getText();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);

signals:
    void pressed();
    void released();
    void clicked(bool);
    void toggled(bool);

private slots:
    void _btnPressed();
    void _btnReleased();
    void _btnClicked(bool);
    void _btnToggled(bool);
};

#endif // RCHECKBOX_H
