/**
 * @file rlineedit.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The extension of QLineEdit
 */

#ifndef RLINEEDIT_H
#define RLINEEDIT_H
#include <QLabel>
#include <QLineEdit>

#define KEYBOARD_Y_OFFSET   6

class RLineEdit : public QLineEdit
{
    Q_OBJECT
public:
    typedef enum
    {
        DataType_TEXT   = 0,
        DataType_INT,
        DataType_DOUBLE
    } DataType_E;

    RLineEdit(QWidget *parent = 0);
    ~RLineEdit();

    void setParentAbsoluteOffset(int x, int y);
    bool setValueRange(double valMin, double valMax, int res);
    bool setValueRange(QLabel *lName, double valMin, double valMax, int res);
    bool setValueRange(QString strName, double valMin, double valMax, int res);
    double getValue();
    bool isTextValid(QString *str=NULL, bool showErr=false);
    void setText(uint currentValue);
    void setText(int currentValue);
    void setText(double currentValue);
    void setText(QString str);
    bool isValidIpv4Ip();

private:
    DataType_E dataType;
    QLabel *lName;
    QString strName;
    double  val, valMax, valMin;
    int res;    // resolution
    QString strType;
    int parent_absolute_offset_x, parent_absolute_offset_y;

    QString getText(double currentValue);

private slots:
    void closeKeyboard();

protected:
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // RLINEEDIT_H
