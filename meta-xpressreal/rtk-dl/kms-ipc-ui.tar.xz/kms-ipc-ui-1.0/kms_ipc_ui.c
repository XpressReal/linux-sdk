#include <gtk/gtk.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
#include <glib.h>

#include <xf86drm.h>
#include <xf86drmMode.h>

#define DRM_DRIVER "realtek"

static int drm_fd = -1;

static char* run_cmd(const char *cmd)
{
    FILE *fp = popen(cmd, "r");
    if (!fp) return NULL;

    char buf[1024];
    GString *out = g_string_new("");
    while (fgets(buf, sizeof(buf), fp))
        g_string_append(out, buf);

    pclose(fp);
    return g_string_free(out, FALSE);
}

static int drm_init(void)
{
    if (drm_fd >= 0) return 0;
    drm_fd = drmOpen(DRM_DRIVER, NULL);
    if (drm_fd < 0)
        drm_fd = open("/dev/dri/card0", O_RDWR);
    return drm_fd >= 0 ? 0 : -1;
}

static void drm_close(void)
{
    if (drm_fd >= 0) { drmClose(drm_fd); drm_fd = -1; }
}

static const char* connector_type_str(int type)
{
    switch (type) {
        case DRM_MODE_CONNECTOR_HDMIA:   return "HDMI-A";
        case DRM_MODE_CONNECTOR_HDMIB:   return "HDMI-B";
        case DRM_MODE_CONNECTOR_eDP:     return "eDP";
        case DRM_MODE_CONNECTOR_DisplayPort: return "DP";
        case DRM_MODE_CONNECTOR_VGA:     return "VGA";
        case DRM_MODE_CONNECTOR_DVII:    return "DVI-I";
        case DRM_MODE_CONNECTOR_DVID:    return "DVI-D";
        case DRM_MODE_CONNECTOR_DSI:     return "DSI";
        default:                         return "Unknown";
    }
}

static double calc_refresh(drmModeModeInfo *m)
{
    if (m->htotal == 0 || m->vtotal == 0) return 0;
    double refresh = (double)m->clock * 1000.0 / ((uint64_t)m->htotal * m->vtotal);
    if (m->flags & DRM_MODE_FLAG_INTERLACE)
        refresh *= 2.0;
    if (m->flags & DRM_MODE_FLAG_DBLSCAN)
        refresh /= 2.0;
    return refresh;
}

static char* mode_label(drmModeModeInfo *m)
{
    double refresh = calc_refresh(m);
    const char *suffix = (m->flags & DRM_MODE_FLAG_INTERLACE) ? "i" : "";
    return g_strdup_printf("%dx%d%s@%.2f", m->hdisplay, m->vdisplay, suffix, refresh);
}

static char* mode_dedup_key(drmModeModeInfo *m)
{
    double r = calc_refresh(m);
    int rounded = (int)round(r * 100);
    const char *suffix = (m->flags & DRM_MODE_FLAG_INTERLACE) ? "i" : "";
    return g_strdup_printf("%dx%d%s@%d", m->hdisplay, m->vdisplay, suffix, rounded);
}

/* Forward declarations for property combo callback */
typedef struct {
    int  conn_id;
    char prop_name[64];
} PropSelectData;

static void on_prop_changed(GtkWidget *combo, gpointer user_data);
static void on_prop_select_free(gpointer data);

static GtkWidget* create_prop_combo(int conn_id, const char *target_name,
                                     GtkWidget *grid, int *row)
{
    drmModeObjectProperties *props = drmModeObjectGetProperties(drm_fd, conn_id,
                                                                  DRM_MODE_OBJECT_CONNECTOR);
    if (!props) return NULL;

    GtkWidget *combo = NULL;

    for (uint32_t i = 0; i < props->count_props; i++) {
        drmModePropertyRes *prop = drmModeGetProperty(drm_fd, props->props[i]);
        if (!prop) continue;

        if (strcmp(prop->name, target_name) != 0) {
            drmModeFreeProperty(prop);
            continue;
        }

        uint64_t current_val = props->prop_values[i];

        GtkListStore *store = gtk_list_store_new(2, G_TYPE_STRING, G_TYPE_INT64);
        int active_idx = 0;
        int idx = 0;

        if (prop->flags & DRM_MODE_PROP_RANGE) {
            /* range: e.g. max bpc, values 8-12 */

            /* max bpc: only list 0, 8, 10 */
            if (strcmp(prop->name, "max bpc") == 0) {
                uint64_t bpc_values[] = {0, 8, 10};
                for (int k = 0; k < 3; k++) {
                    uint64_t v = bpc_values[k];
                    char label[32];
                    snprintf(label, sizeof(label), "%lu", (unsigned long)v);
                    GtkTreeIter iter;
                    gtk_list_store_append(store, &iter);
                    gtk_list_store_set(store, &iter, 0, label, 1, (gint64)v, -1);
                    if (current_val == v)
                        active_idx = idx;
                    idx++;
                }
            } else {
                uint64_t min = prop->values[0];
                uint64_t max = prop->values[1];
                for (uint64_t v = min; v <= max; v++) {
                    char label[32];
                    snprintf(label, sizeof(label), "%lu", (unsigned long)v);
                    GtkTreeIter iter;
                    gtk_list_store_append(store, &iter);
                    gtk_list_store_set(store, &iter, 0, label, 1, (gint64)v, -1);
                    if (current_val == v)
                        active_idx = idx;
                    idx++;
                }
            }
        } else if (prop->flags & DRM_MODE_PROP_ENUM) {
            /* enum: RGB or YCbCr, HDR mode, etc */
            for (int j = 0; j < prop->count_enums; j++) {
                struct drm_mode_property_enum *e = &prop->enums[j];
                GtkTreeIter iter;
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store, &iter, 0, e->name, 1, (gint64)e->value, -1);
                if (current_val == e->value)
                    active_idx = idx;
                idx++;
            }
        }

        if (idx > 0) {
            combo = gtk_combo_box_new_with_model(GTK_TREE_MODEL(store));

            GtkCellRenderer *rnd = gtk_cell_renderer_text_new();
            gtk_cell_layout_pack_start(GTK_CELL_LAYOUT(combo), rnd, TRUE);
            gtk_cell_layout_set_attributes(GTK_CELL_LAYOUT(combo), rnd, "text", 0, NULL);

            gtk_combo_box_set_active(GTK_COMBO_BOX(combo), active_idx);

            PropSelectData *pdata = g_new(PropSelectData, 1);
            pdata->conn_id = conn_id;
            strncpy(pdata->prop_name, prop->name, sizeof(pdata->prop_name) - 1);
            pdata->prop_name[sizeof(pdata->prop_name) - 1] = '\0';
            g_signal_connect_data(combo, "changed",
                                  G_CALLBACK(on_prop_changed), pdata,
                                  (GClosureNotify)on_prop_select_free, 0);

            GtkWidget *lbl = gtk_label_new(prop->name);
            gtk_label_set_xalign(GTK_LABEL(lbl), 0.0);
            gtk_grid_attach(GTK_GRID(grid), lbl, 0, *row, 1, 1);
            gtk_grid_attach(GTK_GRID(grid), combo, 1, *row, 1, 1);
            (*row)++;
        }

        g_object_unref(store);
        drmModeFreeProperty(prop);
        break;
    }

    drmModeFreeObjectProperties(props);
    return combo;
}

static void on_prop_changed(GtkWidget *combo, gpointer user_data)
{
    PropSelectData *data = (PropSelectData *)user_data;
    GtkTreeIter iter;
    if (gtk_combo_box_get_active_iter(GTK_COMBO_BOX(combo), &iter)) {
        GtkListStore *store = GTK_LIST_STORE(gtk_combo_box_get_model(GTK_COMBO_BOX(combo)));
        gint64 value;
        gtk_tree_model_get(GTK_TREE_MODEL(store), &iter, 1, &value, -1);

        char cmd[512];
        snprintf(cmd, sizeof(cmd),
                 "kms_ipc --property %d:\"%s\":%ld --property %d:\"Auto mode\":0 2>/dev/null",
                 data->conn_id, data->prop_name, (long)value, data->conn_id);
        g_print("Execute: %s\n", cmd);
        system(cmd);
    }
}

static void on_prop_select_free(gpointer data)
{
    g_free(data);
}

/* Update the text on the menu button, which is an HBox with [label, arrow]. */
static void update_mode_button_label(GtkWidget *btn, const char *text)
{
    GtkWidget *lbl = (GtkWidget *)g_object_get_data(G_OBJECT(btn), "mode-label");
    if (lbl && GTK_IS_LABEL(lbl))
        gtk_label_set_text(GTK_LABEL(lbl), text);
}

/* Keep the popover list as wide as the menu button. */
static void on_mode_btn_size_allocate(GtkWidget *btn,
                                      GtkAllocation *alloc,
                                      gpointer user_data)
{
    (void)btn;
    GtkWidget *scroll = (GtkWidget *)user_data;
    if (!scroll || !GTK_IS_SCROLLED_WINDOW(scroll))
        return;
    if (alloc->width > 0)
        gtk_widget_set_size_request(scroll, alloc->width, 300);
}

/* TV mode popover: item clicked -> apply mode, update button label, close */
static void on_tv_mode_activated(GtkListBox *list, GtkListBoxRow *row,
                                 gpointer user_data)
{
    (void)list;
    if (!row || !GTK_IS_LIST_BOX_ROW(row))
        return;

    char *label = (char *)g_object_get_data(G_OBJECT(row), "mode-label");
    if (!label)
        return;

    int conn_id = GPOINTER_TO_INT(g_object_get_data(G_OBJECT(row), "conn-id"));
    char cmd[512];
    snprintf(cmd, sizeof(cmd), "kms_ipc --set-tv-mode %d:%s 2>/dev/null",
             conn_id, label);
    g_print("Execute: %s\n", cmd);
    system(cmd);

    /* button and popover are kept on the list widget, not on the row */
    GtkWidget *btn = (GtkWidget *)g_object_get_data(G_OBJECT(list),
                                                    "mode-btn");
    if (btn && GTK_IS_MENU_BUTTON(btn))
        update_mode_button_label(btn, label);

    GtkWidget *pop = (GtkWidget *)g_object_get_data(G_OBJECT(list),
                                                    "mode-popover");
    if (pop && GTK_IS_POPOVER(pop))
        gtk_popover_popdown(GTK_POPOVER(pop));
}

static GtkWidget* create_display_page(int conn_id)
{
    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 8);
    gtk_container_set_border_width(GTK_CONTAINER(vbox), 12);

    drmModeConnector *conn = drmModeGetConnector(drm_fd, conn_id);
    if (!conn) {
        GtkWidget *l = gtk_label_new("Cannot get connector info");
        gtk_box_pack_start(GTK_BOX(vbox), l, FALSE, FALSE, 0);
        return vbox;
    }

    char name[64];
    snprintf(name, sizeof(name), "%s-%d",
             connector_type_str(conn->connector_type), conn->connector_type_id);

    GtkWidget *grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 4);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 12);

    int row = 0;
    GtkWidget *lbl_n = gtk_label_new("Connector:");
    gtk_label_set_xalign(GTK_LABEL(lbl_n), 0.0);
    GtkWidget *val_n = gtk_label_new(name);
    gtk_label_set_xalign(GTK_LABEL(val_n), 0.0);
    gtk_grid_attach(GTK_GRID(grid), lbl_n, 0, row, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), val_n, 1, row, 1, 1);
    row++;

    char id_str[16];
    snprintf(id_str, sizeof(id_str), "%d", conn_id);
    GtkWidget *lbl_i = gtk_label_new("ID:");
    gtk_label_set_xalign(GTK_LABEL(lbl_i), 0.0);
    GtkWidget *val_i = gtk_label_new(id_str);
    gtk_label_set_xalign(GTK_LABEL(val_i), 0.0);
    gtk_grid_attach(GTK_GRID(grid), lbl_i, 0, row, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), val_i, 1, row, 1, 1);
    row++;

    const char *status_str = "unknown";
    if (conn->connection == DRM_MODE_CONNECTED) status_str = "connected";
    else if (conn->connection == DRM_MODE_DISCONNECTED) status_str = "disconnected";
    GtkWidget *lbl_s = gtk_label_new("Status:");
    gtk_label_set_xalign(GTK_LABEL(lbl_s), 0.0);
    GtkWidget *val_s = gtk_label_new(status_str);
    gtk_label_set_xalign(GTK_LABEL(val_s), 0.0);
    gtk_grid_attach(GTK_GRID(grid), lbl_s, 0, row, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), val_s, 1, row, 1, 1);
    row++;

    gtk_box_pack_start(GTK_BOX(vbox), grid, FALSE, FALSE, 0);

    if (conn->connection == DRM_MODE_CONNECTED && conn->count_modes > 0) {
        GtkWidget *sep = gtk_separator_new(GTK_ORIENTATION_HORIZONTAL);
        gtk_box_pack_start(GTK_BOX(vbox), sep, FALSE, FALSE, 4);

        GtkWidget *mode_label_w = gtk_label_new("TV mode:");
        gtk_label_set_xalign(GTK_LABEL(mode_label_w), 0.0);
        gtk_box_pack_start(GTK_BOX(vbox), mode_label_w, FALSE, FALSE, 0);

        char *current_mode_key = NULL;
        drmModeEncoder *enc = drmModeGetEncoder(drm_fd, conn->encoder_id);
        if (enc && enc->crtc_id) {
            drmModeCrtc *crtc = drmModeGetCrtc(drm_fd, enc->crtc_id);
            if (crtc && crtc->mode_valid) {
                double r = calc_refresh(&crtc->mode);
                int rounded = (int)round(r * 100);
                const char *suffix = (crtc->mode.flags & DRM_MODE_FLAG_INTERLACE) ? "i" : "";
                current_mode_key = g_strdup_printf("%dx%d%s@%d",
                    crtc->mode.hdisplay, crtc->mode.vdisplay, suffix, rounded);
            }
            if (crtc) drmModeFreeCrtc(crtc);
        }
        if (enc) drmModeFreeEncoder(enc);

        GtkListStore *store = gtk_list_store_new(3, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING);
        GHashTable *seen = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, NULL);
        int active_idx = 0;
        int item_idx = 0;

        for (int i = 0; i < conn->count_modes; i++) {
            drmModeModeInfo *m = &conn->modes[i];

            char *key = mode_dedup_key(m);
            if (g_hash_table_contains(seen, key)) { g_free(key); continue; }
            g_hash_table_add(seen, key);

            char *label_text = mode_label(m);

            GtkTreeIter iter;
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter, 0, label_text, 1, i, 2, key, -1);

            if (current_mode_key && strcmp(key, current_mode_key) == 0)
                active_idx = item_idx;

            g_free(label_text);
            item_idx++;
        }

        g_free(current_mode_key);
        g_hash_table_destroy(seen);

        /* TV mode as a menu button with a popover.  The popover opens only on
         * click (GtkMenuButton is a toggle), is fixed 300 px tall with an
         * automatic scrollbar, and its width is the width of the widest mode,
         * clamped to a sane minimum so it does not look cramped. */
        GtkWidget *mode_btn = gtk_menu_button_new();

        /* A menu button drops its built-in arrow when a child is set with
         * gtk_button_set_label(), so build the label ourselves and keep the
         * right-side arrow next to it. */
        GtkWidget *mode_btn_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 6);
        GtkWidget *mode_btn_label = gtk_label_new("");
        g_object_set_data(G_OBJECT(mode_btn), "mode-label", mode_btn_label);
        gtk_box_pack_start(GTK_BOX(mode_btn_box), mode_btn_label,
                           TRUE, TRUE, 0);
        GtkWidget *mode_btn_arrow = gtk_arrow_new(GTK_ARROW_DOWN,
                                                  GTK_SHADOW_NONE);
        gtk_box_pack_start(GTK_BOX(mode_btn_box), mode_btn_arrow,
                           FALSE, FALSE, 0);
        gtk_widget_show_all(mode_btn_box);
        gtk_container_add(GTK_CONTAINER(mode_btn), mode_btn_box);

        GtkWidget *mode_list = gtk_list_box_new();
        gtk_list_box_set_selection_mode(GTK_LIST_BOX(mode_list),
                                        GTK_SELECTION_NONE);

        char *current_label = NULL;
        char *first_label = NULL;
        {
            GtkTreeIter iter;
            int idx = 0;
            if (gtk_tree_model_get_iter_first(GTK_TREE_MODEL(store), &iter)) {
                do {
                    char *label_text = NULL;
                    gtk_tree_model_get(GTK_TREE_MODEL(store), &iter, 0, &label_text, -1);
                    if (!first_label)
                        first_label = g_strdup(label_text ? label_text : "");
                    if (idx == active_idx)
                        current_label = g_strdup(label_text ? label_text : "");

                    GtkWidget *mi = gtk_list_box_row_new();
                    GtkWidget *mi_label = gtk_label_new(label_text);
                    gtk_label_set_xalign(GTK_LABEL(mi_label), 0.0);
                    gtk_container_add(GTK_CONTAINER(mi), mi_label);
                    gtk_list_box_insert(GTK_LIST_BOX(mode_list), mi, -1);

                    g_object_set_data(G_OBJECT(mi), "conn-id",
                                      GINT_TO_POINTER(conn_id));
                    g_object_set_data_full(G_OBJECT(mi), "mode-label",
                                           g_strdup(label_text ? label_text : ""),
                                           g_free);

                    g_free(label_text);
                    idx++;
                } while (gtk_tree_model_iter_next(GTK_TREE_MODEL(store), &iter));
            }
        }
        g_object_unref(store);

        GtkWidget *scroll = gtk_scrolled_window_new(NULL, NULL);
        gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll),
                                       GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
        gtk_widget_set_size_request(scroll, 1, 300);   /* width synced below */
        gtk_container_add(GTK_CONTAINER(scroll), mode_list);

        /* Popover contents must be visible even before the popover is
         * popped up; GtkPopover does not show its children on popup.  The
         * popover widget itself stays hidden until the button is clicked.
         */
        gtk_widget_show_all(scroll);

        GtkWidget *popover = gtk_popover_new(mode_btn);
        gtk_popover_set_position(GTK_POPOVER(popover), GTK_POS_BOTTOM);
        gtk_container_add(GTK_CONTAINER(popover), scroll);

        gtk_menu_button_set_popover(GTK_MENU_BUTTON(mode_btn), popover);
        gtk_box_pack_start(GTK_BOX(vbox), mode_btn, FALSE, FALSE, 0);

        gtk_label_set_text(GTK_LABEL(mode_btn_label),
                           current_label ? current_label
                                         : (first_label ? first_label : ""));
        g_free(current_label);
        g_free(first_label);

        g_object_set_data(G_OBJECT(mode_list), "mode-btn", mode_btn);
        g_object_set_data(G_OBJECT(mode_list), "mode-popover", popover);
        g_signal_connect(mode_list, "row-activated",
                         G_CALLBACK(on_tv_mode_activated), mode_list);

        /* keep the popover list width in sync with the button width */
        g_signal_connect(mode_btn, "size-allocate",
                         G_CALLBACK(on_mode_btn_size_allocate), scroll);

        /* -- separator -- */
        GtkWidget *sep2 = gtk_separator_new(GTK_ORIENTATION_HORIZONTAL);
        gtk_box_pack_start(GTK_BOX(vbox), sep2, FALSE, FALSE, 4);

        GtkWidget *prop_grid = gtk_grid_new();
        gtk_grid_set_row_spacing(GTK_GRID(prop_grid), 4);
        gtk_grid_set_column_spacing(GTK_GRID(prop_grid), 12);

        int prop_row = 0;
        create_prop_combo(conn_id, "RGB or YCbCr", prop_grid, &prop_row);
        create_prop_combo(conn_id, "HDR mode", prop_grid, &prop_row);
        create_prop_combo(conn_id, "max bpc", prop_grid, &prop_row);

        if (prop_row > 0)
            gtk_box_pack_start(GTK_BOX(vbox), prop_grid, FALSE, FALSE, 0);
    }

    drmModeFreeConnector(conn);
    return vbox;
}

typedef struct {
    char param_name[64];
    GtkWidget *entry_widget;
    GtkWidget *value_label;
} PqSetData;

static char* pqmode_get_value(const char *param_name)
{
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "kms_ipc --pqmode get:%s 2>/dev/null", param_name);
    g_print("Execute: %s\n", cmd);

    char *output = run_cmd(cmd);
    if (!output) return NULL;

    char pname[64] = {0};
    char pval[64] = {0};
    char *result = NULL;
    if (sscanf(output, "pq mode:%63[^ ] value:%63s", pname, pval) >= 2)
        result = g_strdup(pval);

    g_free(output);
    return result;
}

static void on_pq_set_clicked(GtkWidget *btn, gpointer user_data)
{
    (void)btn;
    PqSetData *data = (PqSetData *)user_data;
    const char *text = gtk_entry_get_text(GTK_ENTRY(data->entry_widget));
    if (strlen(text) == 0) return;

    char cmd[512];
    snprintf(cmd, sizeof(cmd),
             "kms_ipc --pqmode set:\"%s\":%s 2>/dev/null",
             data->param_name, text);
    g_print("Execute: %s\n", cmd);
    system(cmd);

    char *readback = pqmode_get_value(data->param_name);
    if (readback) {
        gtk_label_set_text(GTK_LABEL(data->value_label), readback);
        g_free(readback);
    } else {
        gtk_label_set_text(GTK_LABEL(data->value_label), text);
    }
}

static void on_pq_set_free(gpointer data)
{
    g_free(data);
}

static GtkWidget* create_pq_info_page(void)
{
    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 6);
    gtk_container_set_border_width(GTK_CONTAINER(vbox), 10);

    GtkWidget *label = gtk_label_new("PQ Info:");
    gtk_label_set_xalign(GTK_LABEL(label), 0.0);
    gtk_box_pack_start(GTK_BOX(vbox), label, FALSE, FALSE, 0);

    char *output = run_cmd("kms_ipc --pqmode get:all 2>/dev/null");
    if (!output) {
        GtkWidget *err = gtk_label_new("Cannot execute kms_ipc --pqmode get:all");
        gtk_box_pack_start(GTK_BOX(vbox), err, TRUE, TRUE, 0);
        return vbox;
    }

    const char *pq_params[] = {
        "SUPER_RES_DISABLE", "SHAPNESS", "MNR", "3DNR",
        "DECOUNTOUR_ENABLE", "DLSR", "DLSR_SCENE", "HENR",
        "UI_ALPHA", "GRAPHIC_FIR", "COLOR_ADJUST",
        "MNR_LEVEL", "OOTF_LEVEL", "LCE", "DEJAGGY", "PEAKING",
        NULL
    };

    GHashTable *writable = g_hash_table_new(g_str_hash, g_str_equal);
    for (int i = 0; pq_params[i]; i++)
        g_hash_table_add(writable, (gpointer)pq_params[i]);

    GHashTable *pq_vals = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, g_free);

    char **lines = g_strsplit(output, "\n", -1);
    for (int i = 0; lines[i]; i++) {
        char pname[64] = {0};
        char pval[64] = {0};
        if (sscanf(lines[i], "pq mode:%63[^ ] value:%63s", pname, pval) >= 2) {
            g_hash_table_insert(pq_vals,
                g_strdup(pname), g_strdup(pval));
        }
    }
    g_strfreev(lines);
    g_free(output);

    GtkWidget *pq_grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(pq_grid), 4);
    gtk_grid_set_column_spacing(GTK_GRID(pq_grid), 12);

    GtkWidget *h1 = gtk_label_new("Parameter");
    gtk_label_set_xalign(GTK_LABEL(h1), 0.0);
    gtk_widget_set_halign(h1, GTK_ALIGN_START);
    GtkWidget *h2 = gtk_label_new("Value");
    gtk_label_set_xalign(GTK_LABEL(h2), 0.0);
    gtk_widget_set_halign(h2, GTK_ALIGN_START);
    GtkWidget *h3 = gtk_label_new("New Value");
    gtk_label_set_xalign(GTK_LABEL(h3), 0.0);
    gtk_grid_attach(GTK_GRID(pq_grid), h1, 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(pq_grid), h2, 1, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(pq_grid), h3, 2, 0, 1, 1);

    GList *keys = g_hash_table_get_keys(pq_vals);
    keys = g_list_sort(keys, (GCompareFunc)g_strcmp0);

    int pq_row = 1;
    for (GList *iter = keys; iter; iter = iter->next) {
        const char *name = (const char *)iter->data;
        const char *val_str = (const char *)g_hash_table_lookup(pq_vals, name);
        int is_writable = g_hash_table_contains(writable, name);
        int is_invalid = (!val_str || strcmp(val_str, "invalid") == 0);
        int editable = is_writable && !is_invalid;

        /* Parameter name label */
        GtkWidget *lbl_name = gtk_label_new(name);
        gtk_label_set_xalign(GTK_LABEL(lbl_name), 0.0);
        gtk_widget_set_halign(lbl_name, GTK_ALIGN_START);
        gtk_grid_attach(GTK_GRID(pq_grid), lbl_name, 0, pq_row, 1, 1);

        /* Current value label */
        GtkWidget *lbl_val = gtk_label_new(val_str ? val_str : "N/A");
        gtk_label_set_xalign(GTK_LABEL(lbl_val), 0.0);
        gtk_widget_set_halign(lbl_val, GTK_ALIGN_START);
        gtk_grid_attach(GTK_GRID(pq_grid), lbl_val, 1, pq_row, 1, 1);

        /* Entry box + Set button in same HBox */
        GtkWidget *entry = gtk_entry_new();
        gtk_entry_set_max_length(GTK_ENTRY(entry), 16);
        gtk_widget_set_sensitive(entry, editable);
        if (is_invalid)
            gtk_entry_set_placeholder_text(GTK_ENTRY(entry), "invalid");
        else if (!is_writable)
            gtk_entry_set_placeholder_text(GTK_ENTRY(entry), "read only");
        else
            gtk_entry_set_placeholder_text(GTK_ENTRY(entry), "enter value");

        PqSetData *sd = g_new(PqSetData, 1);
        strncpy(sd->param_name, name, sizeof(sd->param_name) - 1);
        sd->param_name[sizeof(sd->param_name) - 1] = '\0';
        sd->entry_widget = entry;
        sd->value_label = lbl_val;

        GtkWidget *btn = gtk_button_new_with_label("Set");
        gtk_widget_set_sensitive(btn, editable);
        g_signal_connect_data(btn, "clicked",
                              G_CALLBACK(on_pq_set_clicked), sd,
                              (GClosureNotify)on_pq_set_free, 0);

        /* Enter key also triggers Set button click */
        g_signal_connect_swapped(entry, "activate",
                                 G_CALLBACK(gtk_button_clicked), btn);

        GtkWidget *hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 4);
        gtk_box_pack_start(GTK_BOX(hbox), entry, TRUE, TRUE, 0);
        gtk_box_pack_start(GTK_BOX(hbox), btn, FALSE, FALSE, 0);
        gtk_grid_attach(GTK_GRID(pq_grid), hbox, 2, pq_row, 1, 1);

        pq_row++;
    }

    g_list_free(keys);
    g_hash_table_destroy(pq_vals);

    GtkWidget *scroll = gtk_scrolled_window_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER(scroll), pq_grid);
    gtk_box_pack_start(GTK_BOX(vbox), scroll, TRUE, TRUE, 0);

    return vbox;
}

/* ---------------------------------------------------------------- */
/* main                                                             */
/* ---------------------------------------------------------------- */

int main(int argc, char *argv[])
{
    gtk_init(&argc, &argv);

    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "KMS IPC UI");
    gtk_window_set_default_size(GTK_WINDOW(window), 800, 600);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    GtkWidget *notebook = gtk_notebook_new();
    gtk_container_add(GTK_CONTAINER(window), notebook);

    if (drm_init() < 0) {
        GtkWidget *page = gtk_box_new(GTK_ORIENTATION_VERTICAL, 6);
        gtk_container_set_border_width(GTK_CONTAINER(page), 12);
        GtkWidget *label = gtk_label_new("Cannot open DRM device");
        gtk_box_pack_start(GTK_BOX(page), label, FALSE, FALSE, 0);
        gtk_notebook_append_page(GTK_NOTEBOOK(notebook), page, gtk_label_new("Error"));
    } else {
        drmModeRes *res = drmModeGetResources(drm_fd);
        if (!res) {
            GtkWidget *page = gtk_box_new(GTK_ORIENTATION_VERTICAL, 6);
            gtk_container_set_border_width(GTK_CONTAINER(page), 12);
            GtkWidget *label = gtk_label_new("No DRM resources");
            gtk_box_pack_start(GTK_BOX(page), label, FALSE, FALSE, 0);
            gtk_notebook_append_page(GTK_NOTEBOOK(notebook), page, gtk_label_new("No Data"));
        } else {
            for (int i = 0; i < res->count_connectors; i++) {
                drmModeConnector *conn = drmModeGetConnector(drm_fd, res->connectors[i]);
                if (!conn) continue;

                char tab_name[64];
                snprintf(tab_name, sizeof(tab_name), "%s-%d",
                         connector_type_str(conn->connector_type),
                         conn->connector_type_id);

                GtkWidget *page = create_display_page(conn->connector_id);
                gtk_notebook_append_page(GTK_NOTEBOOK(notebook), page,
                                         gtk_label_new(tab_name));

                drmModeFreeConnector(conn);
            }
            drmModeFreeResources(res);
        }
    }

    GtkWidget *pq_page = create_pq_info_page();
    gtk_notebook_append_page(GTK_NOTEBOOK(notebook), pq_page,
                             gtk_label_new("PQ Info"));

    gtk_widget_show_all(window);
    gtk_main();

    drm_close();
    return 0;
}
