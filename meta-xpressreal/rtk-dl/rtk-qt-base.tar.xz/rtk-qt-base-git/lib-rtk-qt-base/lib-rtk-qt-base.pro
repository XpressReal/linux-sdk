TEMPLATE = lib
CONFIG += plugin      # shared library
TARGET = rtkqtbase    # library name（generate libxxx.so）
QT += core gui widgets

# The following define makes your compiler emit warnings if you use
# any feature of Qt which as been marked as deprecated (the exact warnings
# depend on your compiler). Please consult the documentation of the
# deprecated API in order to know how to port your code away from it.
DEFINES += QT_DEPRECATED_WARNINGS

SOURCES += \
    rtkgst.cpp

HEADERS += \
    rtkgst.h

CONFIG += link_pkgconfig
PKGCONFIG += gstreamer-1.0
PKGCONFIG += gstreamer-video-1.0
INCLUDEPATH += ../../recipe-sysroot/usr/include
LIBS += -L../../recipe-sysroot/usr/lib -lRTK_media_info -lRTK_media_cap

QMAKE_CXXFLAGS += -w
