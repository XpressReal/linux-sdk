#include <QTcpSocket>
#include <QCoreApplication>
#include <QStringList>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QRegularExpression>
#include <QRegularExpressionMatch>
#include <QDateTime>
#include <QDebug>
#include <QTextStream>

#define CMD_SERVER_PORT 13579
#define HEADER      "CmdCli: "
#define HEADER_ERR  "CmdCli: [ERR] "

QString serverIp = "127.0.0.1";
int serverPort = CMD_SERVER_PORT;
QString iniFile = "rtk-test.ini";

void printHelp(char *argv)
{
    QString cmd = QString(argv).split("/").last();

    qInfo() << "Usage: ";
    qInfo() << QString(" %1 [-d \"DIR\"]").arg(cmd);
    qInfo() << QString(" %1 [-f \"VIDEO_FILE\"]").arg(cmd);
    qInfo() << QString(" %1 [-l \"LIST_FILE\"]").arg(cmd);
    qInfo() << QString(" %1 [-c]").arg(cmd);
    qInfo() << QString(" %1 [-pl \"VIDEO_FILE\"]").arg(cmd);
    qInfo() << QString(" %1 [-ps | -rs | -st | -rt | -mt | -um]").arg(cmd);
    qInfo() << QString(" %1 [-fs 0|1]").arg(cmd);
    qInfo() << QString(" %1 [-vl INT]").arg(cmd);
    qInfo() << QString(" %1 [-sp FLOAT]").arg(cmd);
    qInfo() << QString(" %1 [-sr FLOAT]").arg(cmd);
    qInfo() << QString(" %1 [-ss LONG]").arg(cmd);
    qInfo() << "Parameters: ";
    qInfo() << "-d, --AddDir        Add all valid files in the directory to play list ";
    qInfo() << "-f, --AddFile       Add the valid file to play list";
    qInfo() << "-l, --LoadList      Load the video list in the file";
    qInfo() << "-c, --ClearList     Clear play list";
    qInfo() << "-pl, --Play         Start to play file";
    qInfo() << "-ps, --Pause        Pause the play";
    qInfo() << "-rs, --Resume       Resume the play";
    qInfo() << "-st, --Stop         Stop playing";
    qInfo() << "-fs, --Fullscreen   Set video fullscreen or not";
    qInfo() << "-rt, --Rotate       Rotate";
    qInfo() << "-mt, --Mute         Mute the voice";
    qInfo() << "-um, --Unmute       Unmute the voice";
    qInfo() << "-vl, --Volume       Set volume to 0~100 \%";
    qInfo() << "-sp, --Speed        Speed rate";
    qInfo() << "-sr, --SeekRate     Seek to rate 0.0~100.0 \%";
    qInfo() << "-ss, --SeekSecond   Seek front or back by offset seconds";
    qInfo() << "--EndServer         End and close the server and player";
    qInfo() << "--help              print help information";
}

QString currentHeader()
{
    return QDateTime::currentDateTime().toString("[yy/MM/dd hh:mm:ss.zzz] ");
}

int sendMsg(QString msg)
{
    QTcpSocket socket;
    socket.connectToHost(serverIp.toStdString().c_str(), serverPort);
    if (!socket.waitForConnected(2000))
    {
        qWarning() << QString().sprintf("%s%s cmd: %s",
                                currentHeader().toStdString().c_str(), HEADER_ERR, 
                                msg.toStdString().c_str());
        qWarning() << QString().sprintf("%s%s Cannot connect to server %s:%d !",
                                currentHeader().toStdString().c_str(), HEADER_ERR, 
                                serverIp.toStdString().c_str(), serverPort);
        return 1;
    }

    socket.write(msg.toUtf8());
    socket.flush();

    int waitTime = 3000;
    if (msg.indexOf("-d ") >= 0 || msg.indexOf("--AddDir ") >= 0)
    {
        waitTime = 30000; // more than 5 sec for --AddDir to add large files in dir to video list
    } else if (msg.indexOf("-pl ") >= 0 || msg.indexOf("--Play ") >= 0)
    {
        waitTime = 15000; // it takes 1~10 seconds to get media info first and then play
    }
    if (!socket.waitForReadyRead(waitTime))
    {
        qWarning() << QString().sprintf("%s%s cmd: %s",
                                currentHeader().toStdString().c_str(), HEADER_ERR, 
                                msg.toStdString().c_str());
        qWarning() << QString().sprintf("%s%s No response from server!",
                                currentHeader().toStdString().c_str(), HEADER_ERR);
        return 2;
    }

    QByteArray replyData = socket.readAll();
    while (socket.bytesAvailable() || socket.waitForReadyRead(500))
    {
        replyData += socket.readAll();
    }
    QString replyStr = QString::fromUtf8(replyData);
    if (replyStr.count("\n") > 1)
        QTextStream(stdout) << currentHeader() << HEADER << "get reply:\n" << replyStr;
    else
        QTextStream(stdout) << currentHeader() << HEADER << "get reply: " << replyStr;

    socket.disconnectFromHost();
    // socket.waitForDisconnected();
    return 0;
}

bool isValidIPv4(const QString &ip)
{
    QStringList parts = ip.split('.');
    if (parts.size() != 4)
        return false;
    bool ok = true;
    for(const QString &part : parts) {
        int num = part.toInt(&ok);
        if (!ok || num < 0 || num > 255)
            return false;
    }
    return true;
}

int init()
{
    QFile inFile(iniFile);
    if (!inFile.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        if (!inFile.open(QIODevice::WriteOnly | QIODevice::Text))
        {
            qDebug() << QString().sprintf("%s%s Cannot open %s for writing",
                                    currentHeader().toStdString().c_str(), HEADER_ERR,
                                    iniFile.toStdString().c_str());
            return 1;
        }

        QTextStream out(&inFile);
        QString line = QString("serverIp=%1\n").arg(serverIp);
        out << line;
        line = QString("serverPort=%1\n").arg(serverPort);
        out << line;
        inFile.close();
        return 0;
    }

    QRegularExpression ipReg("^serverIp=([0-9]{1,3}(\\.[0-9]{1,3}){3})");
    QRegularExpression portReg("^serverPort=(\\d+)");

    QTextStream in(&inFile);
    while (!in.atEnd())
    {
        QString line = in.readLine();
        QRegularExpressionMatch ipMatch = ipReg.match(line);
        QRegularExpressionMatch portMatch = portReg.match(line);
        if (ipMatch.hasMatch())
        {
            if (isValidIPv4(ipMatch.captured(1)))
                serverIp = ipMatch.captured(1);
        }
        if (portMatch.hasMatch())
        {
            bool ok = true;
            int num = portMatch.captured(1).toInt(&ok);
            if (ok && num >=0 && num <= 65535)
                serverPort = num;
        }
    }
    inFile.close();

    return 0;
}

QStringList parseArgs(const QString& line)
{
    QStringList argsCandidate = line.split(' ');
    QStringList args;
    int i=0, maxIdx = argsCandidate.count()-1;
    while (i<=maxIdx)
    {
        if (argsCandidate[i].startsWith("\""))
        {
            QString arg;
            argsCandidate[i] = argsCandidate[i].right(argsCandidate[i].length()-1);
            // to correctly recognize the string with ""
            int endIdx = maxIdx;
            for (int j=i; j<=maxIdx; j++)
            {
                bool bMarkEnd = argsCandidate[j].endsWith("\"");
                if (bMarkEnd)
                {
                    argsCandidate[j] = argsCandidate[j].left(argsCandidate[j].length()-1);
                }
                if(j!=i)
                    arg.append(' ');
                arg.append(argsCandidate[j]);
                if (bMarkEnd)
                {
                    endIdx = j;
                    break;
                }
            }
            // qDebug() << HEADER << i << "startsWith \" ~ " << endIdx;
            args.append(arg);
            i = endIdx + 1;
        }
        else
        {
            args.append(argsCandidate[i]);
            i += 1;
        }
    }
    return args;
}

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    bool ifHelp = false;
    bool ifMsg = false;
    QString msg;

    iniFile = QCoreApplication::applicationDirPath()+"/"+iniFile;
    init();
    // qDebug() << QString("serverIp=%1").arg(serverIp);
    // qDebug() << QString("serverPort=%1").arg(serverPort);

    if (argc > 1)
    {
        if (argc == 2 && strcmp(argv[1],"--help") == 0)
            ifHelp = true;
        else
        {
            QString line;
            for (int i = 1; i < argc; ++i)
            {
                if(i > 0)
                    line += " ";
                line.append(QString(argv[i]));
            }
            QStringList args = parseArgs(line);
            for (int i = 0; i < args.count(); ++i)
            {
                QString str = args.at(i);
                // qDebug() << HEADER << str.length() << str;

                // if user input related path, we change it to abosulte path for server usage
                if ((str == "-d" || str == "--AddDir") && i + 1 < args.count())
                {
                    QString dirPath = args.at(i+1);
                    QDir dir(dirPath);
                    if (dir.exists())
                    {
                        args[i+1] = dir.absolutePath().prepend("\"").append("\"");;
                    }
                    else
                    {
                        qWarning() << QString().sprintf("%s%s Directory does not exist: %s",
                                        currentHeader().toStdString().c_str(), HEADER_ERR,
                                        dirPath.toStdString().c_str());
                        return false;
                    }
                }
                else if ((str == "-f" || str == "--AddFile" ||
                          str == "-l" || str == "--LoadList" ||
                          str == "-pl" || str == "--Play") && i + 1 < args.count())
                {
                    QString filePath = args.at(i+1);
                    QFile file(filePath);
                    if (file.exists())
                    {
                        QFileInfo fileInfo(filePath);
                        args[i+1] = fileInfo.absoluteFilePath().prepend("\"").append("\"");;
                    }
                    else
                    {
                        qWarning() << QString().sprintf("%s%s File does not exist: %s",
                                        currentHeader().toStdString().c_str(), HEADER_ERR,
                                        filePath.toStdString().c_str());
                        return false;
                    }
                }

                if (str == "--help")
                    ifHelp = true;
            }
            msg = args.join(' ');
            ifMsg = true;
        }
    }
    else
    {
        ifHelp = true;
    }

    if (ifHelp)
        printHelp(argv[0]);
    if (ifMsg)
    {
        return sendMsg(msg);
    }
    return 0;
}