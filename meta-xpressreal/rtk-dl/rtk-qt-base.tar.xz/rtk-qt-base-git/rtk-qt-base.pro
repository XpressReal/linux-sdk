TEMPLATE      = subdirs

SUBDIRS       = \
                lib-rtk-qt-base \
                rtk-playback \
                rtk-test


rtk-playback.depends = lib-rtk-qt-base