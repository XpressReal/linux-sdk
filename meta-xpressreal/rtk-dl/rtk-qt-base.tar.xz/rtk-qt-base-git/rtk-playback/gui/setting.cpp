/**
 * @file setting.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page to do setting
 */

#include "setting.h"
#include "ui_setting.h"
#include "mainwidget.h"

Setting::Setting(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Setting)
{
    ui->setupUi(this);

    // this->source = ui->source;
    this->test = ui->test;
    this->system = ui->system;
//    this->setStyleSheet("background-color: rgb(20, 25, 28);");
    ui->lTitle->setStyleSheet(STYLESHEET_TITLE_1);
    ui->wOption->setStyleSheet("background-color: rgb(0, 5, 0);");
    ui->wContent->setStyleSheet("background-color: rgb(20, 25, 28);");

//    ui->tbSource->setToolTip("Source");
//    ui->tbTest->setToolTip("Test");
//    ui->tbSystem->setToolTip("System");

//    connect(ui->tbSource,   SIGNAL(clicked(bool)), this, SLOT(setSource(bool)));
    connect(ui->tbTest,     SIGNAL(clicked(bool)), this, SLOT(setTest(bool)));
    connect(ui->tbSystem,  SIGNAL(clicked(bool)), this, SLOT(setSystem(bool)));
}

Setting::~Setting()
{
    delete ui;
}

void Setting::setup()
{
    ui->tbSource->setEnabled(false);
    ui->tbTest->setEnabled(Config::sys.testEnable);

//    source->setup();
    test->setup();
    system->setup();

    setSystem(true);
}

void Setting::setGeometry(const QRect &rect)
{
    const int margin = 120;
    int width = rect.width()-margin;
    if (width < 0)
        width = 0;

    QWidget::setGeometry(rect);
    ui->wOption->setGeometry(0, 0, margin, rect.height());
    ui->wContent->setGeometry(margin,0,width,rect.height());

//    ui->source->setParentAbsoluteOffset(rect.x()+margin, rect.y());
    ui->test->setParentAbsoluteOffset(rect.x()+margin, rect.y());
    ui->system->setParentAbsoluteOffset(rect.x()+margin, rect.y());

//    ui->source->setGeometry(0, 0, width, rect.height());
    ui->test->setGeometry(0, 0, width, rect.height());
    ui->system->setGeometry(0, 0, width, rect.height());
}

void Setting::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void Setting::setOption(QToolButton *btn)
{
    QToolButton *btnOpt[] = {ui->tbSource, ui->tbTest, ui->tbSystem, NULL};
    QWidget *widget[] = {ui->source, ui->test, ui->system, NULL};
    int i=0;
    while (btnOpt[i] != NULL)
    {
        if(btnOpt[i] == btn)
        {
            btnOpt[i]->setStyleSheet("QToolButton{"
                                        "background-color: rgba(158, 184, 184, 0.2);"
                                        "}"
                                     "QToolButton:hover{"
                                        "background-color: rgba(158, 184, 184, 0.2);"
                                        "}"
                                    );
            widget[i]->setVisible(true);
            widget[i]->raise();
        }
        else
        {
            btnOpt[i]->setStyleSheet("QToolButton{"
                                        "background-color: rgb(0, 5, 0);"
                                        "}"
                                     "QToolButton:hover{"
                                        "background-color: rgba(158, 184, 184, 0.2);"
                                        "}"
                                    );
            widget[i]->setVisible(false);
        }
        i++;
    }
    // if(btn == ui->tbIPC)
    // {
    //     ui->wContent->setStyleSheet("background-color: transparent;");
    // }
    // else
    // {
    //     ui->wContent->setStyleSheet("background-color: rgb(20, 25, 28);");
    // }
}

// void Setting::setSource(bool)
// {
//     setOption(ui->tbSource);
// }

void Setting::setTest(bool)
{
    setOption(ui->tbTest);
}

void Setting::setSystem(bool)
{
    setOption(ui->tbSystem);
}
