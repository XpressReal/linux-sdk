/**
 * @file system.cpp
 * @author Realtek Semiconductor Corp.
 * @date May 2025
 * @brief The widget page to do system setting
 */

#include "system.h"
#include "ui_system.h"
#include "mainwidget.h"
#include "rtkgst.h"

System::System(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::System)
{
    ui->setupUi(this);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;
    strAiMode = "ssd_mobilenet";

    ui->lSystem->setStyleSheet(STYLESHEET_TITLE_2);

    QList<QComboBox*> optionList = {ui->cbAiMode, 
                                    ui->cbVideoStream, ui->cbAudioStream, ui->cbSubtitleStream};
    foreach(QComboBox *cb, optionList)
    {
        cb->setStyleSheet(STYLESHEET_COMBOBOX);
    }

    connect(ui->tbSet, SIGNAL(clicked(bool)), this, SLOT(system_set_clicked(bool)));
    connect(ui->tbCancel, SIGNAL(clicked(bool)), this, SLOT(system_cancel_clicked(bool)));
}

System::~System()
{
    delete ui;
}

void System::setup()
{
    labelList->append({ui->lAiMode,
                       ui->lVideoStream, ui->lAudioStream, ui->lSubtitleStream});
    actionList->append({ui->tbSet, ui->tbCancel});
    // optionList->append({ui->cbAiMode,
    //                         ui->cbVideoStream, ui->cbAudioStream, ui->cbSubtitleStream});

    ui->cbAiMode->addItem("yolov5");
    ui->cbAiMode->addItem("ssd_mobilenet");
    ui->cbAiMode->addItem("posenet");
    ui->cbAiMode->addItem("face_recognition");

    ui->lAiMode->setVisible(Config::sys.aiApplication);
    ui->cbAiMode->setVisible(Config::sys.aiApplication);
#if GET_INFO_FROM_FRAMEWORK == 1
#else
    ui->lVideoStream->setVisible(false);
    ui->lAudioStream->setVisible(false);
    ui->lSubtitleStream->setVisible(false);
    ui->cbVideoStream->setVisible(false);
    ui->cbAudioStream->setVisible(false);
    ui->cbSubtitleStream->setVisible(false);
#endif
}

void System::initValue(bool fromStatus)
{
    // qDebug () << QString().asprintf("%s:%d", __FUNCTION__, __LINE__);
    ui->cbAiMode->setCurrentText(strAiMode);
    ui->cbVideoStream->clear();
    ui->cbAudioStream->clear();
    ui->cbSubtitleStream->clear();

#if GET_INFO_FROM_FRAMEWORK == 1
    cb_idx_v = cb_idx_a = cb_idx_s = -1;

    GstPlay *play = NULL;
    MediaInfo *info = NULL;
    rtkGst->rtk_gst_play_get_info(&play, &info);
    qDebug() << QString().sprintf("%s:%d", __FUNCTION__, __LINE__);
    if (info!= NULL)
    {
        qDebug() << QString().sprintf("%s:%d vect_v.size()=%d", __FUNCTION__, __LINE__, info->vect_v.size());
        qDebug() << QString().sprintf("%s:%d vect_a.size()=%d", __FUNCTION__, __LINE__, info->vect_a.size());
        qDebug() << QString().sprintf("%s:%d vect_s.size()=%d", __FUNCTION__, __LINE__, info->vect_s.size());
        for (int i=0; i<info->vect_v.size(); i++)
        {
            int idx = info->vect_v[i];
            StreamInfo *stream = &info->stream[idx];
            // qDebug() << QString().sprintf("%s:%d a i=%d idx=%d decodable=%d", __FUNCTION__, __LINE__, i, idx, stream->decodable);
            if (stream->decodable)
            {
                ui->cbVideoStream->addItem(QString().sprintf("%d %s %s %s", i, 
                                            stream->mime.c_str(), stream->language.c_str(), stream->title.c_str()));
                if (info->vect_idx_v == i)
                {
                    cb_idx_v = ui->cbVideoStream->count()-1;
                    ui->cbVideoStream->setCurrentIndex(cb_idx_v);
                }
            }
        }
        for (int i=0; i<info->vect_a.size(); i++)
        {
            int idx = info->vect_a[i];
            StreamInfo *stream = &info->stream[idx];
            // qDebug() << QString().sprintf("%s:%d a i=%d idx=%d decodable=%d", __FUNCTION__, __LINE__, i, idx, stream->decodable);
            if (stream->decodable)
            {
                ui->cbAudioStream->addItem(QString().sprintf("%d %s %s %s", i, 
                                            stream->mime.c_str(), stream->language.c_str(), stream->title.c_str()));
                if (info->vect_idx_a == i)
                {
                    cb_idx_a = ui->cbAudioStream->count()-1;
                    ui->cbAudioStream->setCurrentIndex(cb_idx_a);
                }
            }
        }
        for (int i=0; i<info->vect_s.size(); i++)
        {
            int idx = info->vect_s[i];
            StreamInfo *stream = &info->stream[idx];
            // qDebug() << QString().sprintf("%s:%d s i=%d idx=%d decodable=%d", __FUNCTION__, __LINE__, i, idx, stream->decodable);
            if (stream->decodable)
            {
                ui->cbSubtitleStream->addItem(QString().sprintf("%d %s %s %s", i,
                                                stream->mime.c_str(), stream->language.c_str(), stream->title.c_str()));
                if (info->vect_idx_s == i)
                {
                    cb_idx_s = ui->cbSubtitleStream->count()-1;
                    ui->cbSubtitleStream->setCurrentIndex(cb_idx_s);
                }
            }
        }
    }
#endif
}

void System::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);
}

void System::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void System::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

void System::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    // QList<RLineEdit *>keyboardList = {};
    // QList<RLineEdit *>keybadList = {};
    // RLineEdit *le;
    // foreach(le, keyboardList)
    // {
    //     le->installEventFilter(keyboard);
    // }
    // foreach(le, keybadList)
    // {
    //     le->installEventFilter(keypad);
    // }
}

void System::showEvent(QShowEvent *)
{
    initValue(true);
}

// bool System::eventFilter(QObject *o, QEvent *e)
// {
//     if(e->type() == QEvent::Show)
//     {
//         if(o==ui->pgCurrent ||
//            o==ui->pgFormat ||
//            o==ui->pgImage ||
//            o==ui->pgBg ||
//            o==ui->pgFb ||
//            o==ui->pgOutput ||
//            o==ui->pgAdmin)
//         {
//             initValue(true);
//         }
//     }
//     return QObject::eventFilter(o, e);
// }

void System::system_set_clicked(bool)
{
    // qDebug () << QString().asprintf("%s:%d", __FUNCTION__, __LINE__);
    if (strAiMode != ui->cbAiMode->currentText())
    {
        qDebug () << QString().asprintf("strAiMode = %s -> %s", strAiMode.toStdString().c_str(), ui->cbAiMode->currentText().toStdString().c_str());
        strAiMode = ui->cbAiMode->currentText();
    }
#if GET_INFO_FROM_FRAMEWORK == 1
    GstPlay *play = NULL;
    MediaInfo *info = NULL;
    rtkGst->rtk_gst_play_get_info(&play, &info);
    qDebug() << QString().sprintf("%s:%d", __FUNCTION__, __LINE__);
    if (info != NULL)
    {
        bool bChange_v = false;
        bool bChange_a = false;
        bool bChange_s = false;
        if (cb_idx_v != ui->cbVideoStream->currentIndex() &&
            ui->cbVideoStream->currentText().length() > 0)
        {
            QStringList list = ui->cbVideoStream->currentText().split(" ");
            bool bOk = false;
            int idx = -1;
            if (list.count() > 0)
                idx = list.at(0).toInt(&bOk);
            if (bOk && idx >= 0 &&
                idx < info->vect_v.size() &&
                idx != info->vect_idx_v)
            {
                qDebug () << QString().asprintf("vect_idx_v = %d -> %d", info->vect_idx_v, idx);
                info->vect_idx_v = idx;
                bChange_v = true;
            }
        }
        if (cb_idx_a != ui->cbAudioStream->currentIndex() &&
            ui->cbAudioStream->currentText().length() > 0)
        {
            QStringList list = ui->cbAudioStream->currentText().split(" ");
            bool bOk = false;
            int idx = -1;
            if (list.count() > 0)
                idx = list.at(0).toInt(&bOk);
            if (bOk && idx >= 0 &&
                idx < info->vect_a.size() &&
                idx != info->vect_idx_a)
            {
                qDebug () << QString().asprintf("vect_idx_a = %d -> %d", info->vect_idx_a, idx);
                info->vect_idx_a = idx;
                bChange_a = true;
            }
        }
        if (cb_idx_s != ui->cbSubtitleStream->currentIndex() &&
            ui->cbSubtitleStream->currentText().length() > 0)
        {
            QStringList list = ui->cbSubtitleStream->currentText().split(" ");
            bool bOk = false;
            int idx = -1;
            if (list.count() > 0)
                idx = list.at(0).toInt(&bOk);
            if (bOk && idx >= 0 &&
                idx < info->vect_s.size() &&
                idx != info->vect_idx_s)
            {
                qDebug () << QString().asprintf("vect_idx_s = %d -> %d", info->vect_idx_s, idx);
                info->vect_idx_s = idx;
                bChange_s = true;
            }
        }
        if (play != NULL)
        {
            if (bChange_v)
            {
                qDebug () << QString().asprintf("Unsupport to switch video now !");
            }
            if (bChange_a)
            {
                qDebug () << QString().asprintf("Unsupport to switch audio now !");
                rtkGst->rtk_gst_switch_audio(play, info->vect_idx_a);
            }
            if (bChange_s)
                rtkGst->rtk_gst_switch_subtitle(play, info->vect_idx_s);
        }
    }
#endif

    setting->setVisible(false);
}

void System::system_cancel_clicked(bool)
{
    setting->setVisible(false);
}
