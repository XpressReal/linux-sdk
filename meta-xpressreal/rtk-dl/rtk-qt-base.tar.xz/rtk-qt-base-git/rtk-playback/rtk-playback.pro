#-------------------------------------------------
#
# Project created by QtCreator 2017-08-04T17:40:29
#
#-------------------------------------------------

QT       += core gui network

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = rtk-playback
TEMPLATE = app

# The following define makes your compiler emit warnings if you use
# any feature of Qt which as been marked as deprecated (the exact warnings
# depend on your compiler). Please consult the documentation of the
# deprecated API in order to know how to port your code away from it.
DEFINES += QT_DEPRECATED_WARNINGS

# You can also make your code fail to compile if you use deprecated APIs.
# In order to do so, uncomment the following line.
# You can also select to disable deprecated APIs only up to a certain version of Qt.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0


SOURCES += \
    main.cpp \
    gui/mainwidget.cpp \
    gui/keypad.cpp \
    gui/keyboard.cpp \
    gui/rcheckbox.cpp \
    gui/rdialog.cpp \
    gui/rlineedit.cpp \
    gui/rslider.cpp \
    gui/rsound.cpp \
    gui/rspinlist.cpp \
    gui/rtoolbutton.cpp \
    gui/rtablayer.cpp \
    gui/selectvideo.cpp \
    gui/setting.cpp \
    gui/system.cpp \
    gui/test.cpp \
    gui/playback.cpp \
    config.cpp \
    commandserver.cpp

HEADERS += \
    define.h \
    gui/mainwidget.h \
    gui/keypad.h \
    gui/keyboard.h \
    gui/rcheckbox.h \
    gui/rdialog.h \
    gui/rlineedit.h \
    gui/rslider.h \
    gui/rsound.h \
    gui/rspinlist.h \
    gui/rtoolbutton.h \
    gui/rtablayer.h \
    gui/selectvideo.h \
    gui/setting.h \
    gui/system.h \
    gui/test.h \
    gui/playback.h \
    config.h \
    commandserver.h

FORMS += \
    gui/mainwidget.ui \
    gui/keypad.ui \
    gui/keyboard.ui \
    gui/rdialog.ui \
    gui/selectvideo.ui \
    gui/setting.ui \
    gui/system.ui \
    gui/test.ui \
    gui/playback.ui

RESOURCES += \
    images.qrc

OTHER_FILES += \
    config.ini

CONFIG += link_pkgconfig
PKGCONFIG += gstreamer-1.0
PKGCONFIG += gstreamer-video-1.0
INCLUDEPATH += ../lib-rtk-qt-base
LIBS += -L../lib-rtk-qt-base -lrtkqtbase

QMAKE_CXXFLAGS += -w
