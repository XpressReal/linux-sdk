/**
 * @file config.h
 * @author Realtek Semiconductor Corp.
 * @date Aug 2017
 * @brief The config value for GUI or system
 */

#ifndef CONFIG_H
#define CONFIG_H
#include <QHash>
#include <QVariant>
#include <QList>
#include <QString>
#include <QTextStream>
#include <QDateTime>
#include "define.h"

// #define _CFG_PROFILE_INI_       "profile.ini"
#define _CFG_CONFIG_INI_        "config.ini"
#define _CFG_HLS_DIR_           "hls/"

#define DBG(m)      (Config::sys.dbgFlag & m)
#define _DBG_RTKGST_            0x00000001
#define _DBG_ALARM_             0x00000002
#define _DBG_PLAYBACK_          0x00000004
#define _DBG_MONITOR_           0x00000008
#define _DBG_HLS_PARSER_        0x00000010
#define _DBG_ONVIF_             0x00000020

#define _STR_WAYLANDSINK_       "waylandsink"

typedef enum {
    SOURCE_VIDEO_FILE = 0,
    SOURCE_COUNT
} SourceType_e;

typedef struct
{
    uint    dbgFlag;
    bool    isWayland;
    bool    restartWeston;
    bool    logMsg;
    bool    aiApplication;
    bool    enableScreenShot;
    QString videoFileFilter;
    QString videoSink;
    QString textSink;
    int     ipcChannelMax;
    int     fileChannelMax;
    int     width;
    int     height;
    int     widthBase;      // %4==0
    int     heightBase;     // %2==0
    int     playbackX;      // %16==0
    int     playbackWidth;
    int     playbackHeight;
    int     playbackTopDownBorder;
    int     playbackLeftRightBorder;    // > 54(close icon width)
    uint    frameBufferSizeIndex;
    double  ratioOSD;   // OSD (weston, wayland), related to width, height
    double  ratioVFB;   // video framebuffer, related to rtk_disp_get_videoFB_Resolution
    bool    autoLogin;
    bool    bootupIpcConnect;
    uint    setBlankTime;
    uint    setPlayerConnectTime;
    uint    viewProcessPoolingTime;
    bool    monitorProcessEnable;
    uint    monitorProcessPoolingTime;
    uint    monitorProcessQueryTime;    // query frame counter
    uint    monitorProcessNoFrameTimeout;
    uint    monitorProcessReconnectTime;
    uint    monitorProcessReconnectMaxTime;
    uint    monitorProcessRepingTime;
    uint    getSourcePollingTime;
    uint    setSpeedPollingTime;
    uint    recSegmentPollingTime;
    uint    setRtspLatency; // prepare for buffer
    uint    terminateDelay;
    uint    playbackQueryTime;
    uint    playbackPlayDelayTime;
    bool    playbackBlankEnable;
    uint    playbackBlankTime;
    uint    playbackSound;
    uint    hlsDuration;    // seconds per file, < 1 day for the limit of QTime operation in rtksim
    bool    seamless;
    uint    onvifEnable;
    uint    onvifPollingTime;
    bool    faceDetectEnable;
    bool    testEnable;
    uint    testInterval;
    uint    cmdServerPort;
}SYSTEM_S;

typedef struct
{
    uint    ipcGridNum;
    uint    fileGridNum;
    uint    ipcBorderSize;  // %2==0
    uint    fileBorderSize;  // %2==0
    QString borderColor;
    QString borderDragColor;
    QString borderZoomColor;
    QString tagFontColor;
    QString tagBgColor;
    QString maskZoomColor;
    uint    tagAlignment;
}STYLE_S;

typedef struct
{
    int     segmentTime;    // unit: minute
    int     segmentTimeMax; // unit: minute
    uint    slideshowInterval;  // unit: sec
    int     dateFormat;
    int     timeFormat;
    uint    brightness;
    uint    contrast;
    uint    hue;
    uint    saturation;
    uint    sharpness;
    uint    bgColorR;
    uint    bgColorG;
    uint    bgColorB;
    uint    bgColorA;
    // int     hdmiMode;
    // int     dpMode;
}SETTING_S;

typedef struct
{
    QString yoloCaseCode;
    QString yoloNbg;
    QString yoloCoco;
    QString poseCaseCode;
    QString poseNbg;
    QString poseCoco;
    QString mobilenetCaseCode;
    QString mobilenetNbg;
    QString mobilenetBoxPri;
    QString mobilenetCoco;
    QString facerecogScript;
}AIPATH_S;

class Config
{
public:
    static SETTING_S        setting;
    static STYLE_S          style;
    static SYSTEM_S         sys, sys_def;
    static AIPATH_S         aipath;

    static QList<QString>   listDateFormat;
    static QList<QString>   listTimeFormat;
    static QList<QString>   listOvertimeFormat;
    static QString          applicationDirPath;
    static QString          absoluteHlsDirPath;
//    static QString          profileName;
    Config();
    ~Config();

    bool init(QString absolutePath);
    static QString getAbsDirPath(QString dirPath);
    static void setFrameBufferSizeIndex(int frameBufferSizeIndex);
    static void updateBorderColorByBgColor();
    static QString strQDateFormat();
    static QString strQTimeFormat(); // in 24 hrs
    static QString strTimeFormat();
    static QString strTime(int secs);
    static QString strQDateTime(QDateTime datetime);

private:
    static void loadConfig();
    static void printInfo();
};


#endif // CONFIG_H
