
1. VIPLite folder organization.

    common/
        Common source code and header file for whole VIPLite.
        
    include/
        VIPLite expose API header files.
        
    nbg_fmt/
        Read and parser NBG file. Generate executable-NBG file.
        
    nbg_linker/
        Relocation and link NBG file as network command buffer.
    
    vip_hal/
        VIPLite Hardware Abstraction Layer.

    vip_drv/
        VIPLite driver layer source code. 
        The components  included are task management, video memory management, power management and device management.
        It's works in kernel space on Linux/Android.
           

2. VIPLite driver naming rules.
    1. vip-hal function name : 
       viphal_xxx
       viphal_os_xxxx  for system function defines
    2. nbg_linker structure name : nbglk_xxx_t
    3. nbg_linker variable name : nbglk_xxx
    4. vip_drv function name :  vipdrv_xxx
    5. vip_drv structure name: vipdrv_xxx_t
    6. Public to application name of function and structure:  vip_xxxx_xxx
    
3. Build VIPLite driver on Linux.
    1. configure toolchains and build option in build_drv_linux.sh
    2. ./build_drv_linux.sh install
    
    Build Option:
    export VENDOR_NAME=xxxx is specify vendor code path. is vendor company name.
    export SOC_CONFIG is board/project name.
    export USE_LINUX_PCIE_DEVICE=1 is used Linux PCIE device driver. export USE_PCIE_MSI=1, enable PCIE MSI interrupt.
    export USE_LINUX_PLATFORM_DEVICE is used Linux platform device driver.
    export FPGA_BUILD=1 is specify to build for FPGA.
    export AUTO_CORRECT_CONFLICTS=1 is enabled automatically correct conflicting compilation switches in vip_lite_config.h
    
    
4. Build VIPLite driver on freesRTOS
    1. include makefile.freeRTOS into makefile of freeRTOS system.
    2. build freeRTOS system.
    3. VIPLite drvier is builded into freeRTOS together.
    
    
5. Build VIPLite driver on Android
    1. source Android build environment
    2. mm
