/* auto generated on 2025-07-23 17:40:54 */
#ifndef _VIP_LLM_FEATURE_DB_H
#define _VIP_LLM_FEATURE_DB_H

struct _vip_llm_hw_feature_db {
    unsigned int pid;
    unsigned int lanes_num : 8;          /* gcFEATURE_LLM_LANES_NUM */
    unsigned int units_num : 8;          /* gcFEATURE_LLM_UNITS_NUM */
    unsigned int a_buffer_size : 32;     /* gcFEATURE_LLM_ABUF_SIZE_IN_BYTE */
    unsigned int k_buffer_size : 32;     /* gcFEATURE_LLM_KBUF_SIZE_IN_BYTE */
    unsigned int scale_buffer_size : 32; /* gcFEATURE_LLM_SCALEBUF_SIZE_IN_BYTE */
};

static struct _vip_llm_hw_feature_db vipllm_chip_info[] = {
    {
        0x1000006d, /* pid */
        0x14,       /* lanes_num */
        0x20,       /* units_num */
        0x180100,   /* a_buffer_size */
        0x80000,    /* k_buffer_size */
        0x30000,    /* scale_buffer_size */
    },
};

#endif
