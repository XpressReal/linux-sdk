/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#ifndef _VIP_DRV_VIPCORE_PLATFORM_H
#define _VIP_DRV_VIPCORE_PLATFORM_H

#include <linux/of_device.h>
#include <linux/platform_device.h>
#include <vip_drv_os_port.h>
#include "vip_drv_vipcore_type.h"

/* LINUX platform device driver source code */

/*
 * there are 4 type of scenarios vip in system:
 *  1.vip is a real platform device. register it in dts. using platform_drv->driver.of_match_table to match.
 *      call function vipdrv_platform_device_auto_probe to implement it.
 *
 *  2.vip is a PCIe device. using pci_register_driver to match. then kernel call the probe callback to do probe.
 *      call function vipdrv_pcie_device_auto_probe to implement it.
 *
 *  3.vip is a PCIe device. the pci_driver not in viplite. the pcie has been probed before insmod vipcore.
 *      just to call pci_get_device to get the PCIe device.
 *      call function vipdrv_pcie_device_dummy_probe to implement it.
 *
 *  4.vip not in any bus. viplite register virtual platform device to do probe.
 *      call function vipdrv_misc_device_init to implement it.
 */

#if defined(USE_LINUX_PLATFORM_DEVICE)
/*
initialize vip-core platform from linux platform device,
@param platform_drv: IN, Linux platform bus driver object.
@param dev_count: IN,the number of element for pcie_ids.
@param vendor_operations: IN, vendor device ops
@param vipcore_vendor: OUT, vip core platform struct.
*/
vip_int32_t vipdrv_platform_device_auto_probe(struct of_device_id* vipcore_dev_match,
                                              vip_uint32_t vipcore_match_devcnt,
                                              vipdrv_vendor_operations_t* vendor_operations,
                                              vipdrv_vipcore_vendor_t* vipcore_vendor);

void vipdrv_platform_device_auto_remove(vipdrv_vipcore_vendor_t* vipcore_vendor);
#endif
/*
@param dev_count: IN,the number of element for pcie_ids.
@param vendor_operations: IN, vendor device ops
@param vipcore_vendor: IN, vip core platform struct.
*/
vip_int32_t vipdrv_misc_device_init(vip_uint32_t dev_count, vipdrv_vendor_operations_t* vendor_operations,
                                    vipdrv_vipcore_vendor_t* vipcore_vendor);

void vipdrv_misc_device_uninit(vipdrv_vipcore_vendor_t* vipcore_vendor);

/*
Alloc page for video memory heap.
@param size: the size of memory need be allocated.
@param phyiscal: OUT, contignous physical address.
*/
struct page* vipdrv_vendor_alloc_page(vip_size_t size, vip_physical_t* physical);

void vipdrv_vendor_free_page(vip_size_t size, struct page* heap_page);

/*
Map the CPU logical for AHB register of NPU.
*/
vip_status_e vipdrv_AHB_register_map(vipdrv_vendor_device_t* device, vip_physical_t register_physical,
                                     vip_uint32_t register_size, void** logical);

vip_status_e vipdrv_AHB_register_unmap(vipdrv_vendor_device_t* device, vip_physical_t register_physical,
                                       vip_uint32_t register_size, void* logical);

#endif
