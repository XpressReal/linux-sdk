/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/
#include <vip_lite_config.h>
#if vpmdENABLE_DEBUGFS
#include <linux/module.h>
#include <linux/vmalloc.h>
#include <linux/slab.h>
#include <linux/fs.h>
#include <linux/debugfs.h>
#include <linux/string.h>

#include "vip_drv_os_debug.h"
#include "vip_drv_vipcore_driver.h"
#include "vip_drv_vipcore_type.h"
#include "vip_drv_vipcore_vendor.h"

#include <vip_drv_interface.h>
#include <vip_drv_hardware.h>
#include <vip_drv_os_port.h>
#include <vip_drv_video_memory.h>
#include <vip_drv_mem_allocator.h>
#include <vip_drv_debug.h>
#include <vip_drv_mmu.h>
#include <vip_drv_context.h>
#include <vip_drv_task_common.h>
#include <vip_drv_task_descriptor.h>
#include <vip_lite_version.h>

#ifndef vpmdUSE_DEBUG_FS
#ifdef CONFIG_DEBUG_FS
/*
   debugFS is enabled when vpmdUSE_DEBUG_FS set to 1
   debugFS folder is in: /sys/kernel/debug/viplite/
*/
#define vpmdUSE_DEBUG_FS 1
#else
/*
   sysFS is enabled when vpmdUSE_DEBUG_FS set to 0
   sysFS folder is in: /sys/devices/platform/xxx.vipcore/
   use bin_attribute for sysfs to send msg larger than 1 page size
*/
#define vpmdUSE_DEBUG_FS 0
#endif
#endif

/* the highest bit indicates whether the default log level has been changed.
    7:7 bit 0: not changed, 1: changed, 6:0 bits: log level*/
vip_uint8_t g_rt_log_level = VIP_LOG_WARN & 0x7F;

#if vpmdENABLE_BW_PROFILING
/* Global flag to enable bw profiling for all networks, set by debugfs */
vip_uint8_t g_rt_bw_profile = 0;
#endif
#if vpmdENABLE_CNN_PROFILING
/* Global flag to enable cnn profiling for all networks, set by debugfs */
vip_uint8_t g_rt_cnn_profile = 0;
#endif
/* Global flag to enable hal capture, set by debugfs */
vip_uint8_t g_rt_hal_capture = 0;
/* Global flag to enable hang capture, set by debugfs */
vip_uint8_t g_rt_hang_capture = 0;

#if vpmdENABLE_DEBUGFS
struct dentry* debugfs_root;
vipdrv_video_mem_profile_t video_mem_data;
vip_uint32_t debugfs_core_cnt = 0;
vipdrv_core_loading_profile_t* core_loading = VIP_NULL;

typedef struct _debug_node_t {
    vip_uint32_t logi_dev_idx;
#if !vpmdUSE_DEBUG_FS
    struct kobject* dev_root_kobj;
#endif
} debug_node_t;

debug_node_t* node = VIP_NULL;
struct bin_attribute* attr_array = VIP_NULL;

#define DEBUGFS_SHOW_GET_LOGI_IDX    \
    debug_node_t* node = s->private; \
    vip_uint32_t logi_dev_idx = node->logi_dev_idx;

#define DEBUGFS_WRITE_GET_LOGI_IDX \
    vip_uint32_t logi_dev_idx;     \
    struct seq_file* s = VIP_NULL; \
    debug_node_t* node = VIP_NULL; \
    s = file->private_data;        \
    node = s->private;             \
    logi_dev_idx = node->logi_dev_idx;

#define SYSFS_GET_LOGI_IDX         \
    debug_node_t* node = VIP_NULL; \
    vip_uint32_t logi_dev_idx;     \
    node = attr->private;          \
    logi_dev_idx = node->logi_dev_idx;

#endif

#if vpmdUSE_DEBUG_FS
#define MAX_CORE_CNT 10
static vip_uint32_t register_address[MAX_CORE_CNT] = {0x0}, register_value[MAX_CORE_CNT] = {0x0};
#endif

static DEFINE_MUTEX(debugfs_mutex);

#define CHECK_CONTEXT_INITIALIZE()                                                 \
    {                                                                              \
        if (0 == *(vip_uint32_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_INITED)) { \
            len += fs_printf(p + len, "vip not working...\n");                     \
            return len;                                                            \
        }                                                                          \
    }

#if vpmdUSE_DEBUG_FS
#define FS_PRINTF(p, len, off, ...) len += fs_printf(p + len - off, __VA_ARGS__);
#if defined(CONFIG_CPU_CSKYV2) && LINUX_VERSION_CODE <= KERNEL_VERSION(3, 0, 8)
void seq_vprintf(struct seq_file* m, const char* f, va_list args)
{
    int len;
    if (m->count < m->size) {
        len = vsnprintf(m->buf + m->count, m->size - m->count, f, args);
        if (m->count + len < m->size) {
            m->count += len;
            return;
        }
    }
    m->count = m->size;
}
#endif
static int fs_printf(IN void* obj, IN const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    seq_vprintf((struct seq_file*)obj, fmt, args);
    va_end(args);

    return 0;
}
#else
typedef struct _sys_param {
    char* buf;
    loff_t offset;
} sys_param;
/* write 1024 bytes at most each time */
#define FS_PRINTF(p, len, off, ...) \
    if (len - off > 1024)           \
        goto flush_buffer;          \
    len += fs_printf(p + (len >= off ? len - off : 0), __VA_ARGS__);
static int fs_printf(IN void* obj, IN const char* fmt, ...)
{
    int len = 0;
    va_list args;
    va_start(args, fmt);
    len = vsprintf((char*)obj, fmt, args);
    va_end(args);

    return len;
}
#endif

/*
@brief show the viplite info profile result
*/
static loff_t vipdrv_vipinfo_show(void* m, void* data, vip_uint32_t logi_dev_idx)
{
    loff_t len = 0, offset = 0;
    vip_bool_e need_init = vip_true_e;
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t chip_ver1, chip_ver2, chip_cid, chip_date;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    vipdrv_device_t* device = VIP_NULL;

#if vpmdUSE_DEBUG_FS
    struct seq_file* ptr = (struct seq_file*)m;
#else
    sys_param* param = (sys_param*)m;
    char* ptr = param->buf;
    offset = param->offset;
#endif

    mutex_lock(&debugfs_mutex);

    if (0 < context->initialize) {
        need_init = vip_false_e;
    }

    if (vip_true_e == need_init) {
        vipdrv_initialize_t init_data;
        init_data.version = ((VERSION_MAJOR << 16) | (VERSION_MINOR << 8) | (VERSION_SUB_MINOR));
        status = vipdrv_init(&init_data);
        if (status != VIP_SUCCESS) {
            PRINTK_E("init hardware\n");
            mutex_unlock(&debugfs_mutex);
            return 0;
        }
    }

    device = vipdrv_get_device(logi_dev_idx);
    vipIsNULL(device);

#if vpmdENABLE_MULTIPLE_TASK
    if (context->initialize_mutex != VIP_NULL) {
        vipdrv_os_lock_mutex(context->initialize_mutex);
    }
#endif
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)
#if vpmdENABLE_POWER_MANAGEMENT
    status = vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_ON, VIP_NULL);
    if (VIPDRV_POWER_CLOCK & vipdrv_pm_query_state(hw)) {
#endif
        status = vipdrv_os_read_reg(hw->reg_base, 0x00020, &chip_ver1);
        if (status != VIP_SUCCESS) {
            PRINTK_E("viplite read chip ver1 faild, error = %d.\n", status);
        }

        status = vipdrv_os_read_reg(hw->reg_base, 0x00024, &chip_ver2);
        if (status != VIP_SUCCESS) {
            PRINTK_E("viplite read chip ver2 faild, error = %d.\n", status);
        }

        status = vipdrv_os_read_reg(hw->reg_base, 0x00030, &chip_cid);
        if (status != VIP_SUCCESS) {
            PRINTK_E("viplite read chip cid faild, error = %d.\n", status);
        }

        status = vipdrv_os_read_reg(hw->reg_base, 0x00028, &chip_date);
        if (status != VIP_SUCCESS) {
            PRINTK_E("viplite read chip date faild, error = %d.\n", status);
        }

        printk("dev%d hw%d info: pid=0x%x, date=0x%x, ver1=0x%x, ver2=0x%x.\n", logi_dev_idx, hw->core_index,
               chip_cid, chip_date, chip_ver1, chip_ver2);

        FS_PRINTF(ptr, len, offset, "dev%d hw%d info: pid=0x%x, date=0x%x, ver1=0x%x, ver2=0x%x.\n",
                  logi_dev_idx, hw->core_index, chip_cid, chip_date, chip_ver1, chip_ver2);
#if vpmdENABLE_POWER_MANAGEMENT
    } else {
        FS_PRINTF(ptr, len, offset, "dev%d hw%d not working, may vip has power off, can't read register\n",
                  logi_dev_idx, hw->core_index);
    }
    status = vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_OFF, VIP_NULL);
#endif
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_END

#if !vpmdUSE_DEBUG_FS
flush_buffer:
#endif
#if vpmdENABLE_MULTIPLE_TASK
    if (context->initialize_mutex != VIP_NULL) {
        vipdrv_os_unlock_mutex(context->initialize_mutex);
    }
#endif
    if (vip_true_e == need_init) {
        vipdrv_destroy();
    }

    mutex_unlock(&debugfs_mutex);

onError:
    return len;
}

static loff_t vipdrv_vipfreq_show(void* m, void* data, vip_uint32_t logi_dev_idx)
{
    loff_t len = 0, offset = 0;
    vip_status_e status = VIP_SUCCESS;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    vip_uint64_t mc_freq = 0;
    vipdrv_device_t* device = VIP_NULL;
#if vpmdUSE_DEBUG_FS
    struct seq_file* ptr = (struct seq_file*)m;
#else
    sys_param* param = (sys_param*)m;
    char* ptr = param->buf;
    offset = param->offset;
#endif

    mutex_lock(&debugfs_mutex);

    if (context->initialize > 0) {
#if vpmdENABLE_MULTIPLE_TASK
        if (context->initialize_mutex != VIP_NULL) {
            vipdrv_os_lock_mutex(context->initialize_mutex);
        }
#endif

        device = vipdrv_get_device(logi_dev_idx);
        vipIsNULL(device);

        VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)

#if vpmdENABLE_POWER_MANAGEMENT
        FS_PRINTF(ptr, len, offset, "vip frequency percent = %d\n", hw->core_fscale_percent);
        vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_ON, VIP_NULL);
        if (VIPDRV_POWER_CLOCK & vipdrv_pm_query_state(hw)) {
#endif
            if (VIP_SUCCESS == vipdrv_get_clock(hw, &mc_freq)) {
                FS_PRINTF(ptr, len, offset, "dev%d hw%d Core Frequency=%"PRId64" HZ\n", logi_dev_idx,
                          hw->core_index, mc_freq);
            }
#if vpmdENABLE_POWER_MANAGEMENT
        } else {
            FS_PRINTF(ptr, len, offset, "vip %d not working, may vip has power off, can't read register\n",
                      hw->core_id);
        }
        vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_OFF, VIP_NULL);
#endif
        VIPDRV_LOOP_HARDWARE_IN_DEVICE_END

#if vpmdENABLE_MULTIPLE_TASK
        if (context->initialize_mutex != VIP_NULL) {
            vipdrv_os_unlock_mutex(context->initialize_mutex);
        }
#endif
    } else {
        vip_status_e status = VIP_SUCCESS;
        vipdrv_initialize_t init_data;
        init_data.version = ((VERSION_MAJOR << 16) | (VERSION_MINOR << 8) | (VERSION_SUB_MINOR));
        status = vipdrv_init(&init_data);
        if (status != VIP_SUCCESS) {
            PRINTK_E("init hardware\n");
            mutex_unlock(&debugfs_mutex);
            return 0;
        }
#if vpmdENABLE_MULTIPLE_TASK
        if (context->initialize_mutex != VIP_NULL) {
            vipdrv_os_lock_mutex(context->initialize_mutex);
        }
#endif

        device = vipdrv_get_device(logi_dev_idx);
        if (device == VIP_NULL) {
#if vpmdENABLE_MULTIPLE_TASK
            if (context->initialize_mutex != VIP_NULL) {
                vipdrv_os_unlock_mutex(context->initialize_mutex);
            }
#endif
            goto onError;
        }
        VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)

#if vpmdENABLE_POWER_MANAGEMENT
        status = vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_ON, VIP_NULL);
        if (VIPDRV_POWER_CLOCK & vipdrv_pm_query_state(hw)) {
#endif
            if (VIP_SUCCESS == vipdrv_get_clock(hw, &mc_freq)) {
                FS_PRINTF(ptr, len, offset, "dev%d hw%d Core Frequency=%"PRId64" HZ\n", logi_dev_idx,
                          hw->core_index, mc_freq);
            }
#if vpmdENABLE_POWER_MANAGEMENT
        } else {
            FS_PRINTF(ptr, len, offset, "vip %d not working, may vip has power off, can't read register\n",
                      hw->core_id);
        }
        status = vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_OFF, VIP_NULL);
#endif
        VIPDRV_LOOP_HARDWARE_IN_DEVICE_END

#if vpmdENABLE_MULTIPLE_TASK
        if (context->initialize_mutex != VIP_NULL) {
            vipdrv_os_unlock_mutex(context->initialize_mutex);
        }
#endif
        vipdrv_destroy();
    }

onError:
#if !vpmdUSE_DEBUG_FS
flush_buffer:
#endif
    mutex_unlock(&debugfs_mutex);

    return len;
}

static ssize_t vipdrv_vipfreq_set(const char* buf, size_t count, vip_uint32_t logi_dev_idx)
{
    vip_int32_t ret = 0;
    vip_status_e status = VIP_SUCCESS;
    vipdrv_logi_device_t* logi_dev = VIP_NULL;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    vipdrv_device_t* device = VIP_NULL;
    mutex_lock(&debugfs_mutex);

    if (count > 128) {
        PRINTK_E("please echo bytes no more than 128, not reset time profile data.\n");
        mutex_unlock(&debugfs_mutex);
        return count;
    }
    ret = simple_strtol(buf, NULL, 0);
    if ((ret > 0) && (ret <= 100)) {
        /* 1. update hardware freq value if initialized, if not initialized, not update hw freq */
        if (context->initialize > 0) {
#if vpmdENABLE_MULTIPLE_TASK
            if (context->initialize_mutex != VIP_NULL) {
                vipdrv_os_lock_mutex(context->initialize_mutex);
            }
#endif
            device = vipdrv_get_device(logi_dev_idx);
            vipIsNULL(device);
            PRINTK("set dev%u vip frequency percent=%d\n", logi_dev_idx, ret);
#if vpmdENABLE_POWER_MANAGEMENT
            VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)
            vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_FREQ, &ret);
            VIPDRV_LOOP_HARDWARE_IN_DEVICE_END
#endif
#if vpmdENABLE_MULTIPLE_TASK
            if (context->initialize_mutex != VIP_NULL) {
                vipdrv_os_unlock_mutex(context->initialize_mutex);
            }
#endif
        }
        /* 2. update logi device freq value */
        logi_dev = vipdrv_get_logi_device(logi_dev_idx);
        logi_dev->core_fscale_percent = ret;
    } else {
        PRINTK("please set 1~~100 value for vip frequency percent\n");
    }
    mutex_unlock(&debugfs_mutex);

onError:
    return count;
}

static loff_t vipdrv_vip_pc_value_get(void* m, void* data, vip_uint32_t logi_dev_idx)
{
    vip_status_e status = VIP_SUCCESS;
    loff_t len = 0, offset = 0;
    vipdrv_hardware_t* hardware = VIP_NULL;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    vipdrv_device_t* device = VIP_NULL;
    vip_uint32_t i = 0;

#if vpmdUSE_DEBUG_FS
    struct seq_file* ptr = (struct seq_file*)m;
#else
    sys_param* param = (sys_param*)m;
    char* ptr = param->buf;
    offset = param->offset;
#endif

    if (0 == context->initialize) {
        FS_PRINTF(ptr, len, offset, "vip not working, fail to get pc value\n");
        return 0;
    }

    device = vipdrv_get_device(logi_dev_idx);
    vipIsNULL(device);

    for (i = 0; i < device->hardware_count; i++) {
        hardware = vipdrv_get_hardware(device, i);
        VIPDRV_CHECK_NULL(hardware);
        if (vip_false_e == vipdrv_os_get_atomic(hardware->idle)) {
            vip_uint32_t dmaAddr = 0xFFFFF, dmaLo = 0, dmaHi = 0;

#if vpmdENABLE_POWER_MANAGEMENT
            vipdrv_pm_send_evnt(hardware, VIPDRV_PWR_EVNT_CLK_ON, VIP_NULL);
#endif

            vipdrv_read_register(hardware, 0x00668, &dmaLo);
            vipdrv_read_register(hardware, 0x0066C, &dmaHi);
            vipdrv_read_register(hardware, 0x00664, &dmaAddr);

#if vpmdENABLE_POWER_MANAGEMENT
            vipdrv_pm_send_evnt(hardware, VIPDRV_PWR_EVNT_CLK_OFF, VIP_NULL);
#endif

            FS_PRINTF(ptr, len, offset, "dev%d hw%d PC Address = 0x%08X\n", logi_dev_idx,
                      hardware->core_index, dmaAddr);
            FS_PRINTF(ptr, len, offset, "   PC Value Low   = 0x%08X\n", dmaLo);
            FS_PRINTF(ptr, len, offset, "   PC Value High  = 0x%08X\n", dmaHi);
        }
    }

#if !vpmdUSE_DEBUG_FS
flush_buffer:
#endif
onError:
    return len;
}

typedef struct _debugfs_core_load {
    /* the number of task on this core */
    vip_uint32_t task_count;
    /* The time required to complete all tasks on this core */
    vip_uint64_t estimated_time;
    /* this core idle or busy */
    vip_bool_e idle;
} debugfs_core_load_t;

static loff_t vipdrv_core_loading_get(void* m, void* data, vip_uint32_t logi_dev_idx)
{
    vip_status_e status = VIP_SUCCESS;
    loff_t len = 0, offset = 0;
    vip_uint32_t ratio = 0, i = 0;
    vip_uint64_t total_time = 0;
    vip_uint64_t result = 0;
    vip_uint32_t total_core_index = 0;
    vip_bool_e need_init = vip_true_e;
    vipdrv_device_t* device = VIP_NULL;

    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
#if vpmdUSE_DEBUG_FS
    struct seq_file* ptr = (struct seq_file*)m;
#else
    sys_param* param = (sys_param*)m;
    char* ptr = param->buf;
    offset = param->offset;
#endif

    if (VIP_NULL == core_loading) {
        return 0;
    }

    if (0 < context->initialize) {
        need_init = vip_false_e;
    }

    if (vip_true_e == need_init) {
        vipdrv_initialize_t init_data;
        init_data.version = ((VERSION_MAJOR << 16) | (VERSION_MINOR << 8) | (VERSION_SUB_MINOR));
        status = vipdrv_init(&init_data);
        if (status != VIP_SUCCESS) {
            PRINTK_E("init vipdrv\n");
            return 0;
        }
    }

    for (i = 0; i < logi_dev_idx; i++) {
        device = vipdrv_get_device(i);
        vipIsNULL(device);
        total_core_index += device->hardware_count;
    }

    device = vipdrv_get_device(logi_dev_idx);
    vipIsNULL(device);

    if (0 == core_loading[total_core_index].destory_time) {
        total_time = vipdrv_os_get_time() - core_loading[total_core_index].init_time;
    } else {
        total_time = core_loading[total_core_index].destory_time - core_loading[total_core_index].init_time;
    }

    VIPDRV_DO_DIV64(total_time, 1000, result);
    FS_PRINTF(ptr, len, offset, "Dev%u VIP Total Time=%"PRId64" ms\n", logi_dev_idx, result);
    for (i = 0; i < device->hardware_count; i++) {
        VIPDRV_DO_DIV64((core_loading[total_core_index + i].infer_time * 100), total_time, result);
        ratio = (vip_uint32_t)(result);
        VIPDRV_DO_DIV64(core_loading[total_core_index + i].infer_time, 1000, result);
        if (0 == i) {
            FS_PRINTF(ptr, len, offset,
                      "History Loading -----> Core%d: Inference Time=%"PRId64" ms (%2d%%)\n", i, result,
                      ratio);
        } else {
            FS_PRINTF(ptr, len, offset,
                      "                       Core%d: Inference Time=%"PRId64" ms (%2d%%)\n", i, result,
                      ratio);
        }
    }

#if vpmdTASK_QUEUE_USED
    if (context->initialize) {
        vip_uint32_t i = 0;
        debugfs_core_load_t loads[vipdMP_NUM + 8];
        vipdrv_queue_property_t* property = VIP_NULL;
        vip_uint32_t core_count = 0;
        vip_uint32_t start_core = 0;
        vip_uint32_t index = 0;
        vipdrv_hardware_t* hardware = VIP_NULL;
        vipdrv_os_zero_memory((void*)loads, sizeof(debugfs_core_load_t) * vipdMP_NUM);

        for (core_count = 1; core_count <= device->hardware_count; core_count++) {
            for (start_core = 0; start_core <= device->hardware_count - core_count; start_core++) {
                if (VIP_SUCCESS ==
                    vipdrv_queue_query_property(&device->tskTCB_queue, (void*)(&index), &property)) {
                    for (i = start_core; i < start_core + core_count; i++) {
                        loads[i].estimated_time += property->estimated_time;
                        loads[i].task_count += property->task_count;
                    }
                }
                index++;
            }
        }

        for (i = 0; i < device->hardware_count; i++) {
            hardware = vipdrv_get_hardware(device, i);
            VIPDRV_CHECK_NULL(hardware);
            loads[i].idle = vipdrv_os_get_atomic(hardware->idle);
        }
        for (i = 0; i < device->hardware_count; i++) {
            if (0 == i) {
                FS_PRINTF(ptr, len, offset,
                          "Current Loading -----> Core%d: %s, Task Count=%d, Estimated Time=%"PRId64" us\n",
                          i, vip_true_e == loads[i].idle ? "Idle" : "Busy", loads[i].task_count,
                          loads[i].estimated_time);
            } else {
                FS_PRINTF(ptr, len, offset,
                          "                       Core%d: %s, Task Count=%d, Estimated Time=%"PRId64" us\n",
                          i, vip_true_e == loads[i].idle ? "Idle" : "Busy", loads[i].task_count,
                          loads[i].estimated_time);
            }
        }
    }
#endif

#if !vpmdUSE_DEBUG_FS
flush_buffer:
#endif
onError:
    return len;
}

static ssize_t vipdrv_core_loading_set(const char* buf, size_t count)
{
    vip_uint32_t ret;
    vip_uint32_t i = 0;
    if (VIP_NULL == core_loading) {
        return 0;
    }

    ret = strncmp(buf, "reset", 5);

    if (!ret) {
        for (i = 0; i < debugfs_core_cnt; i++) {
            core_loading[i].init_time = vipdrv_os_get_time();
            core_loading[i].submit_time = 0;
            core_loading[i].infer_time = 0;
            core_loading[i].destory_time = 0;
        }
    } else {
        PRINTK_E("invalid param, please set 'reset' string to reset core loading data.\n");
    }

    return count;
}

static loff_t vipdrv_mem_profile(void* m, void* data)
{
    loff_t len = 0, offset = 0;
#if vpmdUSE_DEBUG_FS
    struct seq_file* ptr = (struct seq_file*)m;
#else
    sys_param* param = (sys_param*)m;
    char* ptr = param->buf;
    offset = param->offset;
#endif

    FS_PRINTF(ptr, len, offset, "video memory profile\n");
    FS_PRINTF(ptr, len, offset,
              " ------------------------------------------------------------------------------\n");
    FS_PRINTF(ptr, len, offset,
              "|       current(byte)    |      peak(byte)    |   alloc count   |   free count \n");
    FS_PRINTF(ptr, len, offset,
              "|------------------------------------------------------------------------------\n");
    FS_PRINTF(ptr, len, offset, "|      0x%08x        |     0x%08x     |      %d         |    %d     \n",
              video_mem_data.video_memory, video_mem_data.video_peak, video_mem_data.video_allocs,
              video_mem_data.video_frees);

#if !vpmdUSE_DEBUG_FS
flush_buffer:
#endif

    return len;
}

static ssize_t vipdrv_mem_profile_set(const char* buf, size_t count)
{
    vip_uint32_t ret;

    ret = strncmp(buf, "reset", 5);
    if (!ret) {
        video_mem_data.video_memory = 0;
        video_mem_data.video_peak = 0;
        video_mem_data.video_allocs = 0;
        video_mem_data.video_frees = 0;
    } else {
        PRINTK_E("invalid param, please set reset to reset memory profile data.\n");
    }

    return count;
}

static vip_status_e show_memory_mapping(vipdrv_video_mem_handle_t* mem_handle, void* m, vip_uint32_t index,
                                        vip_bool_e is_heap_alloc, loff_t* len, loff_t offset)
{
    vip_uint32_t iter = 0;
    vip_char_t* alloc_type = VIP_NULL;
    vipdrv_mem_mapping_profile_t* memory_mapping = VIP_NULL;
    vip_uint8_t* kernel_logical = VIP_NULL;
    vip_uint8_t* user_logical = VIP_NULL;
    vipdrv_video_mem_phy_handle_t* ptr = mem_handle->handle;
#if vpmdUSE_DEBUG_FS
    struct seq_file* p = (struct seq_file*)m;
#else
    char* p = (char*)m;
#endif
    vip_status_e status = VIP_SUCCESS;

    memory_mapping = kmalloc(sizeof(vipdrv_mem_mapping_profile_t), GFP_KERNEL);
    if (memory_mapping == NULL) {
        PRINTK("memory mapping kmalloc memory failed.\n");
        return VIP_ERROR_FAILURE;
    }
    memset(memory_mapping, 0, sizeof(vipdrv_mem_mapping_profile_t));

    if (ptr->allocator_type & VIPDRV_ALLOCATOR_TYPE_WRAP_DMA_BUF) {
        alloc_type = "  dma_buf ";
    } else if (ptr->allocator_type & VIPDRV_ALLOCATOR_TYPE_DYN_ALLOC) {
        alloc_type = "dyna_alloc";
    } else if (ptr->allocator_type & VIPDRV_ALLOCATOR_TYPE_WRAP_USER_LOGICAL) {
        alloc_type = "wrap_logic";
    } else if (ptr->allocator_type & VIPDRV_ALLOCATOR_TYPE_WRAP_USER_PHYSICAL) {
        alloc_type = "wrap_physic";
    }

    if (!is_heap_alloc) {
        memory_mapping->alloc_type = alloc_type;
        memory_mapping->size_table = ptr->size_table;
        memory_mapping->virtual_addr = mem_handle->vip_address;
        memory_mapping->physical_table = ptr->physical_table;
        memory_mapping->kernel_logical = ptr->kerl_logical;
        memory_mapping->user_logical = ptr->user_logical;
        memory_mapping->physical_num = ptr->physical_num;
        for (iter = 0; iter < memory_mapping->physical_num; iter++) {
            if (memory_mapping->kernel_logical != VIP_NULL) {
                kernel_logical = memory_mapping->kernel_logical + iter * memory_mapping->size_table[iter];
            } else {
                kernel_logical = VIP_NULL;
            }
            if (memory_mapping->user_logical != VIP_NULL) {
                user_logical = memory_mapping->user_logical + iter * memory_mapping->size_table[iter];
            } else {
                user_logical = VIP_NULL;
            }

            if (0 == iter) {
                FS_PRINTF(p, *(len), offset,
                          "|   %08d   |  %s  |  0x%08x |    0x%"PRIx64"   "
                          "|   0x%08x  |    0x%"PRPx"  |     0x%"PRPx" |\n",
                          index, memory_mapping->alloc_type, memory_mapping->size_table[iter],
                          memory_mapping->physical_table[iter],
                          memory_mapping->virtual_addr + iter * memory_mapping->size_table[iter],
                          kernel_logical, user_logical);
            } else {
                FS_PRINTF(p, *(len), offset,
                          "            %08d          |  0x%08x |    0x%"PRIx64"   "
                          "|   0x%08x  |    0x%"PRPx"  |     0x%"PRPx" |\n",
                          iter, memory_mapping->size_table[iter], memory_mapping->physical_table[iter],
                          memory_mapping->virtual_addr + iter * memory_mapping->size_table[iter],
                          kernel_logical, user_logical);
            }

            FS_PRINTF(p, *(len), offset,
                      "|-----------------------------------------------"
                      "----------------------------------------------------------------------------|\n");
        }
    } else {
        memory_mapping->alloc_type = "heap_alloc";
#if vpmdENABLE_VIDEO_MEMORY_HEAP
        memory_mapping->size = ptr->size;
        memory_mapping->virtual_addr = mem_handle->vip_address;
        memory_mapping->physical = ptr->physical_table[0];
        memory_mapping->kernel_logical = ptr->kerl_logical;
        memory_mapping->user_logical = ptr->user_logical;
#else
        memory_mapping->size = 0;
        memory_mapping->virtual_addr = 0;
        memory_mapping->physical = 0;
        memory_mapping->kernel_logical = NULL;
        memory_mapping->user_logical = NULL;
#endif
        FS_PRINTF(p, *(len), offset,
                  "|   %08d   |  %s  |  0x%08x |    0x%"PRIx64"   |   0x%08x  "
                  "|     0x%"PRPx"  |      0x%"PRPx" |\n",
                  index, memory_mapping->alloc_type, memory_mapping->size, memory_mapping->physical,
                  memory_mapping->virtual_addr, memory_mapping->kernel_logical, memory_mapping->user_logical);
        FS_PRINTF(p, *(len), offset,
                  "|----------------------------------------------------"
                  "-----------------------------------------------------------------------|\n");
    }
#if !vpmdUSE_DEBUG_FS
flush_buffer:
#endif
    kfree(memory_mapping);

    return status;
}

/*
@brief show the viplite memory mapping profile result
*/
static loff_t vipdrv_mem_mapping(void* m, void* data)
{
    loff_t len = 0, offset = 0;
    vip_uint32_t left_mem_count = 0;
    vipdrv_video_mem_phy_handle_t* pointer = VIP_NULL;
    vip_bool_e is_heap_alloc = vip_false_e, heap_not_profile = vip_true_e;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    vip_uint32_t i = 0;
    vipdrv_video_mem_handle_t* mem_handle = VIP_NULL;
#if vpmdUSE_DEBUG_FS
    struct seq_file* p = (struct seq_file*)m;
#else
    sys_param* param = (sys_param*)m;
    char* p = param->buf;
    offset = param->offset;
#endif

    CHECK_CONTEXT_INITIALIZE();
    FS_PRINTF(p, len, offset, " start profiling...\n");
    FS_PRINTF(p, len, offset,
              " ------------------------------------------------------------------------------"
              "--------------------------------------------- \n");
    FS_PRINTF(p, len, offset,
              "|    index    |  alloc_type  |     size    |     physical    |      virtual   |    "
              "   kerl_logical     |        user_logical    |\n");
    FS_PRINTF(p, len, offset,
              "|------------------------------------------------------------------------------"
              "---------------------------------------------|\n");

    for (i = 1; i < vipdrv_database_free_pos(&context->mem_database); i++) {
        vipdrv_database_use(&context->mem_database, i, (void**)&mem_handle);
        if (VIP_NULL != mem_handle) {
            if (VIP_NULL != mem_handle->handle) {
                pointer = mem_handle->handle;
                is_heap_alloc = (pointer->allocator_type == VIPDRV_ALLOCATOR_TYPE_VIDO_HEAP) ? vip_true_e
                                                                                             : vip_false_e;
                if (is_heap_alloc) {
                    if (heap_not_profile) {
                        show_memory_mapping(mem_handle, (void*)p, i, vip_true_e, &len, offset);
                        heap_not_profile = vip_false_e;
                        left_mem_count++;
                    } else {
                        vipdrv_database_unuse(&context->mem_database, i);
                        continue;
                    }
                } else {
                    show_memory_mapping(mem_handle, (void*)p, i, vip_false_e, &len, offset);
                    left_mem_count++;
                }
            }
            vipdrv_database_unuse(&context->mem_database, i);
        }
    }
#if !vpmdUSE_DEBUG_FS
flush_buffer:
#endif
    if (left_mem_count < 1) {
        len += fs_printf(p + len, "all the video memory have freed, not need profile.\n");
        return len;
    }

    return len;
}

#if vpmdENABLE_MMU
static vip_status_e vipdrv_debug_dump_data(void* m, loff_t* len, loff_t offset, vip_uint32_t* data,
                                           vip_uint32_t physical, vip_uint32_t size)
{
    vip_uint32_t i = 0;
    vip_uint32_t line = size / 32;
    vip_uint32_t left = size % 32;
#if vpmdUSE_DEBUG_FS
    struct seq_file* ptr = (struct seq_file*)m;
#else
    char* ptr = (char*)m;
#endif

    for (i = 0; i < line; i++) {
        FS_PRINTF(ptr, *(len), offset, "%08X : %08X %08X %08X %08X %08X %08X %08X %08X\n", physical, data[0],
                  data[1], data[2], data[3], data[4], data[5], data[6], data[7]);
        data += 8;
        physical += 8 * 4;
    }

    switch (left) {
    case 28:
        FS_PRINTF(ptr, *(len), offset, "%08X : %08X %08X %08X %08X %08X %08X %08X\n", physical, data[0],
                  data[1], data[2], data[3], data[4], data[5], data[6]);
        break;
    case 24:
        FS_PRINTF(ptr, *(len), offset, "%08X : %08X %08X %08X %08X %08X %08X\n", physical, data[0], data[1],
                  data[2], data[3], data[4], data[5]);
        break;
    case 20:
        FS_PRINTF(ptr, *(len), offset, "%08X : %08X %08X %08X %08X %08X\n", physical, data[0], data[1],
                  data[2], data[3], data[4]);
        break;
    case 16:
        FS_PRINTF(ptr, *(len), offset, "%08X : %08X %08X %08X %08X\n", physical, data[0], data[1], data[2],
                  data[3]);
        break;
    case 12:
        FS_PRINTF(ptr, *(len), offset, "%08X : %08X %08X %08X\n", physical, data[0], data[1], data[2]);
        break;
    case 8:
        FS_PRINTF(ptr, *(len), offset, "%08X : %08X %08X\n", physical, data[0], data[1]);
        break;
    case 4:
        FS_PRINTF(ptr, *(len), offset, "%08X : %08X\n", physical, data[0]);
        break;
    default:
        break;
    }
#if !vpmdUSE_DEBUG_FS
flush_buffer:
#endif
    return VIP_SUCCESS;
}

static vip_status_e vipdrv_debug_dump_mtlb(void* m, loff_t* len, loff_t offset, vipdrv_mmu_info_t* mmu_info)
{
#if vpmdUSE_DEBUG_FS
    struct seq_file* ptr = (struct seq_file*)m;
#else
    char* ptr = (char*)m;
#endif

    if (vip_false_e == vipdrv_context_query_featureDB(0, VIP_FEATURE_MMU_PDMODE)) {
        FS_PRINTF(ptr, *(len), offset, "\n***DUMP MMU entry****\n");
        vipdrv_debug_dump_data(
                    (void*)ptr, len, offset, mmu_info->mem_prop->MMU_entry.logical,
                    mmu_info->mem_prop->MMU_entry.physical,
                    (mmu_info->mem_prop->MMU_entry.size > 64) ? 64 : mmu_info->mem_prop->MMU_entry.size);
    }

    FS_PRINTF(ptr, *(len), offset, "*****DUMP MTLB******\n");
    vipdrv_debug_dump_data((void*)ptr, len, offset, mmu_info->MTLB.logical, mmu_info->MTLB.physical,
                           mmu_info->MTLB.size);
#if !vpmdUSE_DEBUG_FS
flush_buffer:
#endif
    return VIP_SUCCESS;
}

static vip_status_e vipdrv_debug_dump_stlb(void* m, loff_t* len, loff_t offset, vipdrv_mmu_info_t* mmu_info)
{
    vip_int32_t i = 0, stlb_index = 0;
    vip_uint32_t* logical = VIP_NULL;
    vip_int32_t unit = 0;
    vip_uint32_t dump_size = 0;
    vip_uint32_t* tmp = VIP_NULL;
    vip_int32_t total_num = 0;
#if vpmdUSE_DEBUG_FS
    struct seq_file* ptr = (struct seq_file*)m;
#else
    char* ptr = (char*)m;
#endif
    FS_PRINTF(ptr, *(len), offset, "*****DUMP STLB Start******\n");
    for (stlb_index = 0; stlb_index < mmu_info->MTLB_cnt; stlb_index++) {
        vipdrv_MTLB_info_t* MTLB_info = &mmu_info->MTLB_info[stlb_index];
        vip_uint32_t size = 0;
        if (VIP_SUCCESS !=
            vipdrv_mmu_page_macro(MTLB_info->type, VIP_NULL, &unit, VIP_NULL, VIP_NULL, VIP_NULL, VIP_NULL)) {
            continue;
        }
        size = unit * sizeof(vip_uint32_t);

        FS_PRINTF(ptr, *(len), offset, "dump STLB (%s page), physical base=0x%"PRIx64", size=0x%x\n",
                  MTLB_info->type == VIPDRV_MMU_4K_PAGE    ? "4K"
                  : MTLB_info->type == VIPDRV_MMU_64K_PAGE ? "64K"
                                                           : "1M",
                  MTLB_info->STLB->physical, size);
        logical = (vip_uint32_t*)MTLB_info->STLB->logical;
        if (VIP_NULL != logical) {
            for (i = unit - 1; i >= 0; i--) {
                /* 0 bit indicate whether present or not. */
                if (logical[i] & (1 << 0)) {
                    break;
                }
            }

            total_num = i + 1;
            for (i = 0; i < total_num; i += 8) {
                tmp = logical + i;
                if ((total_num - i) >= 8) {
                    dump_size = 8 * sizeof(vip_uint32_t);
                } else {
                    dump_size = (total_num - i) * sizeof(vip_uint32_t);
                }
                vipdrv_debug_dump_data((void*)ptr, len, offset, tmp,
                                       MTLB_info->STLB->physical + sizeof(vip_uint32_t) * i, dump_size);
            }
        }
    }
    FS_PRINTF(ptr, *(len), offset, "*****DUMP STLB Done******\n");
#if !vpmdUSE_DEBUG_FS
flush_buffer:
#endif
    return VIP_SUCCESS;
}
/*
@brief show the viplite page table profile result
*/
static loff_t vipdrv_dump_mmu_table(void* m, void* data, vip_uint32_t logi_dev_idx)
{
    loff_t len = 0, offset = 0;
    vipdrv_mmu_info_t* mmu_info = VIP_NULL;
    vip_bool_e clock_off = vip_false_e;
    vipdrv_mmu_id_t mmu_id = {0};
#if vpmdENABLE_POWER_MANAGEMENT
    vipdrv_device_t* device = VIP_NULL;
#endif
#if vpmdENABLE_POWER_MANAGEMENT || vpmdENABLE_MULTIPLE_TASK
    vip_status_e status = VIP_SUCCESS;
#endif
#if vpmdUSE_DEBUG_FS
    struct seq_file* p = (struct seq_file*)m;
#else
    sys_param* param = (sys_param*)m;
    char* p = param->buf;
    offset = param->offset;
#endif

    CHECK_CONTEXT_INITIALIZE();

    vipdrv_mmu_page_get(mmu_id, &mmu_info);
    if (VIP_NULL == mmu_info) {
        PRINTK_E("mmu info is null\n");
        return 0;
    }

#if vpmdENABLE_MULTIPLE_TASK
    status = vipdrv_os_lock_mutex(mmu_info->mmu_mutex);
    if (status != VIP_SUCCESS) {
        PRINTK_E("lock mmu mutex\n");
        vipdrv_mmu_page_put(mmu_id);
        return 0;
    }
#endif

#if vpmdENABLE_POWER_MANAGEMENT
    device = vipdrv_get_device(logi_dev_idx);
    vipIsNULL(device);

    VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)

    vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_ON, VIP_NULL);
    if (!(VIPDRV_POWER_CLOCK & vipdrv_pm_query_state(hw))) {
        clock_off = vip_true_e;
    }
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_END
#endif

    if (vip_false_e == clock_off) {
        vipdrv_debug_dump_mtlb((void*)p, &len, offset, mmu_info);
        vipdrv_debug_dump_stlb((void*)p, &len, offset, mmu_info);
    }

#if vpmdENABLE_POWER_MANAGEMENT
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)
    vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_OFF, VIP_NULL);
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_END
#endif

#if vpmdENABLE_MULTIPLE_TASK
    status = vipdrv_os_unlock_mutex(mmu_info->mmu_mutex);
    if (status != VIP_SUCCESS) {
        PRINTK_E("unlock mmu mutex\n");
    }
#endif
    vipdrv_mmu_page_put(mmu_id);
#if vpmdENABLE_POWER_MANAGEMENT
onError:
#endif
    return len;
}
#endif

#if vpmdENABLE_HANG_DUMP
static loff_t vipdrv_get_hang_dump(void* m, void* data, vip_uint32_t logi_dev_idx)
{
    vip_status_e status = VIP_SUCCESS;
    loff_t len = 0, offset = 0;
    vipdrv_device_t* device = VIP_NULL;

#if vpmdUSE_DEBUG_FS
    struct seq_file* p = (struct seq_file*)m;
    offset = 0;
#else
    sys_param* param = (sys_param*)m;
    char* p = param->buf;
    offset = param->offset;
#endif

    CHECK_CONTEXT_INITIALIZE();
    PRINTK("debugFS hang dump dev%u start ...\n", logi_dev_idx);

    device = vipdrv_get_device(logi_dev_idx);
    vipIsNULL(device);

    VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)
    vipdrv_task_t task = {0};
    task.core_cnt = 1;
    task.core_index = hw->core_index;
    task.device = device;
#if vpmdENABLE_POWER_MANAGEMENT
    vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_ON, VIP_NULL);
    if (VIPDRV_POWER_CLOCK & vipdrv_pm_query_state(hw)) {
#endif
        vipdrv_dump_states(&task);
        vipdrv_task_tcb_dump(&task);
#if vpmdTASK_PARALLEL_ASYNC
        vipdrv_dump_waitlink_table(&task);
#endif
#if vpmdENABLE_POWER_MANAGEMENT
    } else {
        FS_PRINTF(p, len, offset, "vip not working, may vip has power off, can't read register\n");
    }
    vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_OFF, VIP_NULL);
#endif
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_END
#if !vpmdUSE_DEBUG_FS
flush_buffer:
#endif
    PRINTK("debugFS hang dump end ...\n");

onError:
    return len;
}
#endif

#if vpmdENABLE_SUSPEND_RESUME
static ssize_t vipdrv_suspend_set(const char* buf, size_t count, vip_uint32_t logi_dev_idx)
{
    vip_int32_t ret = 0;
    vip_status_e status = VIP_SUCCESS;
    vipdrv_device_t* device = VIP_NULL;

    mutex_lock(&debugfs_mutex);

    device = vipdrv_get_device(logi_dev_idx);
    vipIsNULL(device);

    ret = simple_strtol(buf, NULL, 0);
    if (ret) {
        /* suspend */

        VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)
        while (1) {
            if (VIPDRV_POWER_CLOCK & vipdrv_pm_query_state(hw)) {
                vipdrv_os_udelay(100);
            } else {
                vipdrv_pm_lock_hardware(hw);
                if (VIPDRV_POWER_CLOCK & vipdrv_pm_query_state(hw)) {
                    vipdrv_pm_unlock_hardware(hw);
                } else {
                    break;
                }
            }
        }

        VIPDRV_LOOP_HARDWARE_IN_DEVICE_END

        PRINTK("debugfs suspend start ....\n");
        vipdrv_pm_suspend();
        PRINTK("debugfs suspend done ....\n");

        VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)
        vipdrv_pm_unlock_hardware(hw);
        VIPDRV_LOOP_HARDWARE_IN_DEVICE_END
    } else if (0 == ret) {
        /* resume */
        VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)
        vipdrv_pm_lock_hardware(hw);
        VIPDRV_LOOP_HARDWARE_IN_DEVICE_END
        PRINTK("debugfs resume start ...\n");

        status = vipdrv_pm_resume();
        if (status != VIP_SUCCESS) {
            PRINTK("vipcore, fail to do pm resume\n");
        }
        PRINTK("debugfs resume done ...\n");

        VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)
        vipdrv_pm_unlock_hardware(hw);
        VIPDRV_LOOP_HARDWARE_IN_DEVICE_END
    } else {
        PRINTK_E("suspend not support this value=%d\n", ret);
    }

    mutex_unlock(&debugfs_mutex);

onError:
    return count;
}
#endif
#if vpmdENABLE_BW_PROFILING
static ssize_t vipdrv_rt_bw_profile_set(const char* buf, size_t count)
{
    vip_int32_t ret = 0;

    if (count > 128) {
        PRINTK_E("please echo bytes no more than 128, not modify rt_bw_profile status.\n");
        return count;
    }

    ret = simple_strtol(buf, NULL, 0);
    if ((ret == 0) || (ret == 1)) {
        g_rt_bw_profile = ret;
        PRINTK_I("rt_bw_profile set to %d\n", g_rt_bw_profile);
    } else {
        PRINTK_E("invalid value for rt_bw_profile, please set 0 or 1.\n");
    }

    return count;
}
#endif
#if vpmdENABLE_CNN_PROFILING
static ssize_t vipdrv_rt_cnn_profile_set(const char* buf, size_t count)
{
    vip_int32_t ret = 0;

    if (count > 128) {
        PRINTK_E("please echo bytes no more than 128, not modify rt_cnn_profile status.\n");
        return count;
    }

    ret = simple_strtol(buf, NULL, 0);
    if ((ret == 0) || (ret == 1) || (ret == 2)) {
        g_rt_cnn_profile = ret;
        PRINTK_I("rt_cnn_profile set to %d\n", g_rt_cnn_profile);
    } else {
        PRINTK_E("invalid value for rt_cnn_profile, please set 0, 1, or 2.\n");
    }

    return count;
}
#endif

static ssize_t vipdrv_rt_hal_capture_set(const char* buf, size_t count)
{
    vip_int32_t ret = 0;

    if (count > 128) {
        PRINTK_E("please echo bytes no more than 128, not modify rt_hal_capture status.\n");
        return count;
    }

    ret = simple_strtol(buf, NULL, 0);
    if ((ret == 0) || (ret == 1) || (ret == 2)) {
        g_rt_hal_capture = ret;
        PRINTK_I("rt_hal_capture set to %d\n", g_rt_hal_capture);
    } else {
        PRINTK_E("invalid value for rt_hal_capture, please set 0, 1 or 2.\n");
    }

    return count;
}

static ssize_t vipdrv_rt_hang_capture_set(const char* buf, size_t count)
{
    vip_int32_t ret = 0;

    if (count > 128) {
        PRINTK_E("please echo bytes no more than 128, not modify rt_hang_capture status.\n");
        return count;
    }

    ret = simple_strtol(buf, NULL, 0);
    if ((ret == 0) || (ret == 1)) {
        g_rt_hang_capture = ret;
        PRINTK_I("rt_hang_capture set to %d\n", g_rt_hang_capture);
    } else {
        PRINTK_E("invalid value for rt_hang_capture, please set 0 or 1.\n");
    }

    return count;
}

#if vpmdENABLE_DEBUG_LOG > 2
static ssize_t vipdrv_rt_log_set(const char* buf, size_t count)
{
    vip_int32_t ret = 0;

    if (count > 128) {
        PRINTK_E("please echo bytes no more than 128, not modify rt_log status.\n");
        return count;
    }
    ret = simple_strtol(buf, NULL, 0);
    if ((ret == 0) || (ret == 1) || (ret == 2) || (ret == 3) || (ret == 4)) {
        g_rt_log_level = (0x80 | (0x7f & ret));
    } else {
        PRINTK("please set 0, 1, 2, 3, 4 value for disable or enable log.\n");
    }

    return count;
}
#endif

/*
@brief Set debugfs profile data for network run
*/
vip_status_e vipdrv_debug_core_loading_profile_set(vipdrv_task_t* task, vipdrv_profile_dtype_t dtype)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint64_t cur_infer = 0;
    vip_uint64_t time = vipdrv_os_get_time();

    if (VIP_NULL == core_loading) {
        return status;
    }

    switch (dtype) {
    case PROFILE_START: {
        VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
        core_loading[hw->core_id].submit_time = time;
        VIPDRV_LOOP_HARDWARE_IN_TASK_END
    } break;

    case PROFILE_END: {
        VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
        cur_infer = time - core_loading[hw->core_id].submit_time;
        core_loading[hw->core_id].infer_time += cur_infer;
        VIPDRV_LOOP_HARDWARE_IN_TASK_END
    } break;

    default:
        break;
    }

    return status;
}

vip_status_e vipdrv_debug_videomemory_profile_alloc(vip_size_t size)
{
    vip_status_e status = VIP_SUCCESS;

    video_mem_data.video_memory += size;

    if (video_mem_data.video_memory > video_mem_data.video_peak) {
        video_mem_data.video_peak = video_mem_data.video_memory;
    }
    video_mem_data.video_allocs++;

    return status;
}

vip_status_e vipdrv_debug_videomemory_profile_free(vip_size_t size)
{
    vip_status_e status = VIP_SUCCESS;

    video_mem_data.video_memory -= size;
    video_mem_data.video_frees++;

    return status;
}

#if 0
static ssize_t vipdrv_multi_vip_set(
    const char *buf,
    size_t count
    )
{
    vip_uint8_t device_core_number[256] = {0};
    int index_buf = 0, core_num = 0, index_core = 0, sum_core = 0;
    vip_bool_e record = vip_false_e;
    vip_uint32_t* initialize = (vip_uint32_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_INITED);
    vip_uint32_t device_count = 0;
    vipdrv_phy_device_t *phy_dev = vipdrv_get_phy_device(MULTI_DEVICE_ENABLE_ID);

    if (0 < *initialize) {
        PRINTK_E("vip is still working...\n");
        return count;
    }
    if (phy_dev->vendor->core_count > vipdMAX_CORE) {
        PRINTK_E("core count=%d larg than max=%d\n", phy_dev->vendor->core_count, vipdMAX_CORE);
        return count;
    }

    while(buf[index_buf]) {
        if ('0' <= buf[index_buf] && '9' >= buf[index_buf]) {
            core_num = 10 * core_num + buf[index_buf] - '0';
            record = vip_true_e;
        }
        else {
            if (record) {
                /* core number after 0 is invalid */
                /* {2,1,0,4,0,0,0,0}. indicate that driver supports 2 logical device */
                if (0 == core_num) break;

                if ((phy_dev->vendor->core_count > index_core) || (index_core >= vipdMAX_CORE)) {
                    device_core_number[index_core++] = (vip_uint8_t)core_num;
                    sum_core += core_num;
                }
                else {
                    /* too many device */
                    PRINTK_E("device number should be less than %d\n", phy_dev->vendor->core_count);
                    return count;
                }
            }
            record = vip_false_e;
            core_num = 0;
        }
        index_buf++;
        if (index_buf > vipdMAX_CORE) {
            break;
        }
    }

    if (0 >= sum_core) {
        /* 1 core at least */
        PRINTK_E("set 1 core at least\n");
    }
    else if (phy_dev->vendor->core_count < sum_core) {
        /* too many core */
        PRINTK_E("total core number should be less than %d\n", phy_dev->vendor->core_count);
    }
    else {
        for (index_core = 0; index_core < phy_dev->vendor->core_count; index_core++) {
            phy_dev->vendor->device_core_number[index_core] = device_core_number[index_core];
        }
    }

    /* update device count */
    for (index_core = 0; index_core < phy_dev->vendor->core_count; index_core++) {
        if (phy_dev->vendor->device_core_number[index_core] > 0) {
            device_count++;
        }
        else {
            PRINTK("debugfs update device count=%d\n", device_count);
            break;
        }
    }

    return count;
}
#endif

static loff_t vipdrv_rt_net_profile(void* m, void* data)
{
    vip_uint32_t* initialize = (vip_uint32_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_INITED);
    vipdrv_database_t* tskDesc_database =
                (vipdrv_database_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TASK_DESC);
    loff_t len = 0, offset = 0;
    vip_uint32_t i = 0;
#if vpmdUSE_DEBUG_FS
    struct seq_file* ptr = (struct seq_file*)m;
#else
    sys_param* param = (sys_param*)m;
    char* ptr = param->buf;
    offset = param->offset;
#endif

    if (0 >= *initialize) {
        FS_PRINTF(ptr, len, offset, "vip not working, fail to show network profile\n");
        return len;
    }

    FS_PRINTF(ptr, len, offset,
              "------------------------------------------------------------------"
              "-----------------------------------------------------------------\n");
    FS_PRINTF(ptr, len, offset,
              "|  network handle      |  enable  | index |  network name             "
              "         |  infer cnt  |  avg infer time  |  avg cycle      |\n");
    for (i = 1; i < vipdrv_database_free_pos(tskDesc_database); i++) {
        vipdrv_task_descriptor_t* tsk_desc = VIP_NULL;
        vipdrv_subtask_info_t* subtask_info = VIP_NULL;
        vip_uint32_t j = 0;
        vip_uint64_t time = 0;
        vip_uint32_t cycle = 0;
        vipdrv_database_use(tskDesc_database, i, (void**)&tsk_desc);
        if (VIP_NULL == tsk_desc) {
            PRINTK_E("get network info for index=%d\n", i);
            continue;
        }
        if (VIP_NULL != tsk_desc->subtasks) {
            for (j = 0; j < tsk_desc->subtask_count; j++) {
                subtask_info = &tsk_desc->subtasks[j];
#if vpmdENABLE_APP_PROFILING
                time = subtask_info->avg_time;
                cycle = (subtask_info->avg_cycle[0].total_cycle -
                         subtask_info->avg_cycle[0].total_idle_cycle);
#endif
                FS_PRINTF(ptr, len, offset,
                          "------------------------------------------------------------------"
                          "-----------------------------------------------------------------\n");
                if (0 == j) {
                    FS_PRINTF(ptr, len, offset,
                              "|  0x%-16x  |  %d       | %-5d |  %-32s  |  %-9d  |  %-12dus  |"
                              "  %-13d  |\n",
                              vipdrv_task_desc_index2id(i), !tsk_desc->skip, j, tsk_desc->task_name,
                              subtask_info->submit_count, time, cycle);
                } else {
                    FS_PRINTF(ptr, len, offset,
                              "|                      |          | %-5d |  %-32s  |  %-9d  |"
                              "  %-12dus  |  %-13d  |\n",
                              j, tsk_desc->task_name, subtask_info->submit_count, time, cycle);
                }
            }
        }
        vipdrv_database_unuse(tskDesc_database, i);
    }
    FS_PRINTF(ptr, len, offset,
              "------------------------------------------------------------------"
              "-----------------------------------------------------------------\n");

#if !vpmdUSE_DEBUG_FS
flush_buffer:
#endif
    return len;
}

static ssize_t vipdrv_rt_net_profile_set(const char* buf, size_t count)
{
    vip_uint32_t* initialize = (vip_uint32_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_INITED);
    vip_uint32_t index = 0;
    vip_uint32_t tmp = 0;
    vipdrv_database_t* tskDesc_database =
                (vipdrv_database_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TASK_DESC);
    vipdrv_task_descriptor_t* tsk_desc = VIP_NULL;
    vip_char_t* usage = "echo [network handle] > rt_net_profile. (toggle the specifed network state)\n";

    if (0 >= *initialize) {
        PRINTK_E("vip not working, fail to manage network\n");
        return count;
    }

    sscanf(buf, "0x%x", &tmp);
    index = vipdrv_task_desc_id2index(tmp);
    if (VIP_SUCCESS == vipdrv_database_use(tskDesc_database, index, (void**)&tsk_desc)) {
        if (VIP_NULL != tsk_desc->subtasks) {
            tsk_desc->skip = !tsk_desc->skip;
        } else {
            PRINTK("did not find this network 0x%x\n", tmp);
            PRINTK("usage: %s", usage);
        }
        vipdrv_database_unuse(tskDesc_database, index);
    } else {
        PRINTK("did not find this network 0x%x\n", tmp);
        PRINTK("usage: %s", usage);
    }

    return count;
}

#if vpmdTASK_DISPATCH_DEBUG
static loff_t vipdrv_task_dispatch_get(void* m, void* data)
{
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    if (0 == context->initialize) {
        return 0;
    }

    VIPDRV_LOOP_DEVICE_START
    vipdrv_task_dispatch_profile(dev, VIPDRV_TASK_DIS_PROFILE_SHOW);
    VIPDRV_LOOP_DEVICE_END

    return 0;
}

static ssize_t vipdrv_task_dispatch_set(const char* buf, size_t count)
{
    vip_uint32_t ret;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    if (0 == context->initialize) {
        return 0;
    }

    ret = strncmp(buf, "reset", 5);

    if (!ret) {
        VIPDRV_LOOP_DEVICE_START
        vipdrv_task_dispatch_profile(dev, VIPDRV_TASK_DIS_PROFILE_RESET);
        VIPDRV_LOOP_DEVICE_END
    } else {
        PRINTK_E("invalid param, please set 'reset' string to reset task dispatch data.\n");
    }

    return count;
}
#endif

#if vpmdUSE_DEBUG_FS

#define vip_debugfs_write(a)                                                                         \
    static ssize_t vip_debugfs_##a##_write(struct file* file, const char __user* ubuf, size_t count, \
                                           loff_t* ppos)                                             \
    {                                                                                                \
        return count;                                                                                \
    }

vip_debugfs_write(vip_info) vip_debugfs_write(mem_mapping)
#if vpmdENABLE_MMU
            vip_debugfs_write(dump_mmu_table)
#endif
#if vpmdENABLE_HANG_DUMP
                        vip_debugfs_write(hang_dump)
#endif
                                    vip_debugfs_write(vip_pc_value)

                                                static ssize_t
            vip_debugfs_core_loading_write(struct file* file, const char __user* ubuf, size_t count,
                                           loff_t* ppos)
{
    vip_char_t buf[128] = {};

    if (count > 128) {
        PRINTK_E("please echo bytes no more than 128, not reset time profile data.\n");
        return count;
    }

    if (copy_from_user(&buf, ubuf, count)) {
        PRINTK_E("copy user data to kernel space fail,not reset time profile data.\n");
    }

    vipdrv_core_loading_set((const char*)&buf, count);

    return count;
}

/*
@brief show the time profile result
*/
static int vipdrv_seq_core_loading_show(struct seq_file* s, void* v)
{
    DEBUGFS_SHOW_GET_LOGI_IDX

    return vipdrv_core_loading_get((void*)s, VIP_NULL, logi_dev_idx);
}

/*
@brief show the viplite info profile result
*/
static int vipdrv_seq_vip_info_show(struct seq_file* s, void* v)
{
    DEBUGFS_SHOW_GET_LOGI_IDX

    return vipdrv_vipinfo_show((void*)s, VIP_NULL, logi_dev_idx);
}

static int vipdrv_seq_vip_pc_value_show(struct seq_file* s, void* v)
{
    DEBUGFS_SHOW_GET_LOGI_IDX

    return vipdrv_vip_pc_value_get((void*)s, VIP_NULL, logi_dev_idx);
}

static ssize_t vip_debugfs_mem_profile_write(struct file* file, const char __user* ubuf, size_t count,
                                             loff_t* ppos)
{
    vip_char_t buf[128] = {};

    if (count > 128) {
        PRINTK_E("please echo bytes no more than 128, not reset memory profile data.\n");
        return count;
    }

    if (copy_from_user(&buf, ubuf, count)) {
        PRINTK_E("copy user data to kernel space fail,not reset memory profile data.\n");
    }

    vipdrv_mem_profile_set((const char*)&buf, VIP_NULL);

    return count;
}

static int vipdrv_seq_mem_profile_show(struct seq_file* s, void* v)
{
    return vipdrv_mem_profile((void*)s, VIP_NULL);
}

static ssize_t vip_debugfs_vip_freq_write(struct file* file, const char __user* ubuf, size_t count,
                                          loff_t* ppos)
{
    vip_char_t buf[128] = {};

    DEBUGFS_WRITE_GET_LOGI_IDX

    if (copy_from_user(&buf, ubuf, count)) {
        PRINTK_E("copy user data to kernel space fail,not reset time profile data.\n");
    }

    vipdrv_vipfreq_set((const char*)&buf, count, logi_dev_idx);

    return count;
}

static int vipdrv_seq_vip_freq_show(struct seq_file* s, void* v)
{
    DEBUGFS_SHOW_GET_LOGI_IDX

    return vipdrv_vipfreq_show((void*)s, VIP_NULL, logi_dev_idx);
}

static int vipdrv_seq_mem_mapping_show(struct seq_file* s, void* v)
{
    ssize_t ret = 0;
    mutex_lock(&debugfs_mutex);
    ret = (ssize_t)vipdrv_mem_mapping((void*)s, VIP_NULL);
    mutex_unlock(&debugfs_mutex);
    return ret;
}

#if vpmdENABLE_MMU
static int vipdrv_seq_dump_mmu_table_show(struct seq_file* s, void* v)
{
    ssize_t ret = 0;

    DEBUGFS_SHOW_GET_LOGI_IDX

    mutex_lock(&debugfs_mutex);
    ret = (ssize_t)vipdrv_dump_mmu_table((void*)s, VIP_NULL, logi_dev_idx);
    mutex_unlock(&debugfs_mutex);
    return ret;
}
#endif
#if vpmdENABLE_HANG_DUMP
static int vipdrv_seq_hang_dump_show(struct seq_file* s, void* v)
{
    ssize_t ret = 0;

    DEBUGFS_SHOW_GET_LOGI_IDX

    mutex_lock(&debugfs_mutex);
    ret = (ssize_t)vipdrv_get_hang_dump((void*)s, VIP_NULL, logi_dev_idx);
    mutex_unlock(&debugfs_mutex);
    return ret;
}
#endif
#if vpmdENABLE_SUSPEND_RESUME
static ssize_t vip_debugfs_suspend_write(struct file* file, const char __user* ubuf, size_t count,
                                         loff_t* ppos)
{
    vip_char_t buf[128] = {};
    vip_uint32_t* initialize = (vip_uint32_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_INITED);

    DEBUGFS_WRITE_GET_LOGI_IDX

    if (0 == *initialize) {
        PRINTK_E("vip not working, fail to set suspend\n");
        return count;
    }

    if (count > 2) {
        PRINTK_E("please echo bytes no more than 2, echo 1 suspend vip, echo 0 resume vip\n");
        return count;
    }

    if (copy_from_user(&buf, ubuf, count)) {
        PRINTK_E("copy user data to kernel space fail, not suspend/resume vip\n");
    }

    vipdrv_suspend_set((const char*)&buf, count, logi_dev_idx);

    return count;
}

static int vipdrv_seq_suspend_show(struct seq_file* s, void* v)
{
    DEBUGFS_SHOW_GET_LOGI_IDX

    seq_printf(s, "suspend vip command: echo 1 > /sys/kernel/debug/viplite/dev%u/suspend\n", logi_dev_idx);
    seq_printf(s, "resume vip command: echo 0 > /sys/kernel/debug/viplite/dev%u/suspend\n", logi_dev_idx);

    return 0;
}
#endif
#if vpmdENABLE_DEBUG_LOG > 2
static ssize_t vip_debugfs_rt_log_write(struct file* file, const char __user* ubuf, size_t count,
                                        loff_t* ppos)
{
    vip_char_t buf[128] = {};

    if (copy_from_user(&buf, ubuf, count)) {
        PRINTK_E("copy user data to kernel space fail,not modify rt_log status.\n");
    }

    vipdrv_rt_log_set((const char*)&buf, count);

    return count;
}

static int vipdrv_seq_rt_log_show(struct seq_file* s, void* v)
{
    seq_printf(s, "rt_log=%d\n", g_rt_log_level & 0x7f);
    seq_printf(s, "  when rt_log=4, enable debug, info, warning and error logs print out\n");
    seq_printf(s, "  when rt_log=3, enable info, warning and error logs print out\n");
    seq_printf(s, "  when rt_log=2, warning and error log\n");
    seq_printf(s, "  when rt_log=1, enable error logs print out\n");
    seq_printf(s, "  when rt_log=0, disable all logs\n");
    return 0;
}
#endif
#if vpmdENABLE_BW_PROFILING
static ssize_t vip_debugfs_rt_bw_profile_write(struct file* file, const char __user* ubuf, size_t count,
                                               loff_t* ppos)
{
    vip_char_t buf[128] = {};

    if (copy_from_user(&buf, ubuf, count)) {
        PRINTK_E("copy user data to kernel space fail, not modify rt_bw_profile status.\n");
    }

    vipdrv_rt_bw_profile_set((const char*)&buf, count);

    return count;
}
#endif
#if vpmdENABLE_CNN_PROFILING
static ssize_t vip_debugfs_rt_cnn_profile_write(struct file* file, const char __user* ubuf, size_t count,
                                                loff_t* ppos)
{
    vip_char_t buf[128] = {};

    if (copy_from_user(&buf, ubuf, count)) {
        PRINTK_E("copy user data to kernel space fail, not modify rt_cnn_profile status.\n");
    }

    vipdrv_rt_cnn_profile_set((const char*)&buf, count);

    return count;
}
#endif
#if vpmdENABLE_BW_PROFILING
static int vipdrv_seq_rt_bw_profile_show(struct seq_file* s, void* v)
{
    seq_printf(s, "rt_bw_profile=%d\n", g_rt_bw_profile);
    seq_printf(s, "  when rt_bw_profile=1, enable global bw profiling for newly created networks\n");
    seq_printf(s, "  when rt_bw_profile=0, disable global bw profiling for newly created networks\n");
    return 0;
}
#endif
#if vpmdENABLE_CNN_PROFILING
static int vipdrv_seq_rt_cnn_profile_show(struct seq_file* s, void* v)
{
    seq_printf(s, "rt_cnn_profile=%d\n", g_rt_cnn_profile);
    seq_printf(s, "  when rt_cnn_profile=0, disable global cnn profiling for newly created networks\n");
    seq_printf(s, "  when rt_cnn_profile=1, enable cnn profiling level1 (run ops one by one)\n");
    seq_printf(s, "  when rt_cnn_profile=2, enable cnn profiling level2 (output inference time)\n");
    return 0;
}
#endif

static ssize_t vip_debugfs_rt_hal_capture_write(struct file* file, const char __user* ubuf, size_t count,
                                                loff_t* ppos)
{
    vip_char_t buf[128] = {};

    if (copy_from_user(&buf, ubuf, count)) {
        PRINTK_E("copy user data to kernel space fail, not modify rt_hal_capture status.\n");
    }

    vipdrv_rt_hal_capture_set((const char*)&buf, count);

    return count;
}

static ssize_t vip_debugfs_rt_hang_capture_write(struct file* file, const char __user* ubuf, size_t count,
                                                 loff_t* ppos)
{
    vip_char_t buf[128] = {};

    if (copy_from_user(&buf, ubuf, count)) {
        PRINTK_E("copy user data to kernel space fail, not modify rt_hang_capture status.\n");
    }

    vipdrv_rt_hang_capture_set((const char*)&buf, count);

    return count;
}

static int vipdrv_seq_rt_hal_capture_show(struct seq_file* s, void* v)
{
    seq_printf(s, "rt_hal_capture=%d\n", g_rt_hal_capture);
    seq_printf(s, "  when rt_hal_capture=2, enable hal capture for networks, states, command buffer, input, "
                  "output, coeff\n");
    seq_printf(s, "  when rt_hal_capture=1, enable hal capture for networks, only command buffer\n");
    seq_printf(s, "  when rt_hal_capture=0, disable hal capture for networks\n");
    return 0;
}

static int vipdrv_seq_rt_hang_capture_show(struct seq_file* s, void* v)
{
    seq_printf(s, "rt_hang_capture=%d\n", g_rt_hang_capture);
    seq_printf(s, "  when rt_hang_capture=1, enable hang capture for networks\n");
    seq_printf(s, "  when rt_hang_capture=0, disable hang capture for networks\n");
    return 0;
}

#if 0
static ssize_t vip_debugfs_multi_vip_write(
    struct file *file,
    const char __user *ubuf,
    size_t count,
    loff_t *ppos
    )
{
    vip_char_t buf[256] = {};

    if (copy_from_user(&buf, ubuf, count)) {
        PRINTK_E("copy user data to kernel space fail, fail to config multi-vip.\n");
    }

    vipdrv_multi_vip_set((const char*)&buf, count);

    return count;
}

static int vipdrv_seq_multi_vip_show(
    struct seq_file *s,
    void *v
    )
{
    int i = 0;
    vipdrv_phy_device_t *phy_dev = vipdrv_get_phy_device(MULTI_DEVICE_ENABLE_ID);

    seq_printf(s, "current config: {");
    for (i = 0; i < phy_dev->vendor->core_count; i++) {
        if (0 < i) {
            seq_printf(s, ", ");
        }
        seq_printf(s, "%d", phy_dev->vendor->device_core_number[i]);
    }
    seq_printf(s, "}\n");
    seq_printf(s, "config multi-vip: echo {");
    for (i = 0; i < phy_dev->vendor->core_count; i++) {
        if (0 < i) {
            seq_printf(s, ", ");
        }
        seq_printf(s, "1");
    }
    seq_printf(s, "} > /sys/kernel/debug/viplite/multi_vip\n");

    return 0;
}
#endif

static ssize_t vip_debugfs_rt_net_profile_write(struct file* file, const char __user* ubuf, size_t count,
                                                loff_t* ppos)
{
    vip_char_t buf[128] = {};

    if (copy_from_user(&buf, ubuf, count)) {
        PRINTK_E("copy user data to kernel space fail, fail to manage network.\n");
    }

    vipdrv_rt_net_profile_set((const char*)&buf, count);

    return count;
}

static int vipdrv_seq_rt_net_profile_show(struct seq_file* s, void* v)
{
    ssize_t ret = 0;

    ret = (ssize_t)vipdrv_rt_net_profile((void*)s, VIP_NULL);

    return ret;
}

static vip_status_e vipdrv_register_rw(const char __user* ubuf, size_t count, vip_uint32_t logi_dev_idx)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    vip_char_t buf[128] = {}, rw = 0;
    vip_uint32_t val = 0, address = 0;
    vip_uint32_t dev_index = 0, core_index = 0;
    int size = 0;
    vipdrv_device_t* device = VIP_NULL;
    vipdrv_hardware_t* hardware = VIP_NULL;
#if vpmdENABLE_DEBUG_LOG > 0
    vip_char_t* usage = "echo > [option] [core-index] [address] (value) > register_rw\n"
                        "  echo > [w --write] [core-index] [register address] [write val] > register_rw\n"
                        "  echo > [r --read] [core-index] [register address] > register_rw\n"
                        "  eg: echo r 0 0x30 > register_rw\n"
                        "      echo w 0 0x00 0x00070900 > register_rw\n";
#endif
    if (copy_from_user(&buf, ubuf, count)) {
        PRINTK_E("copy user data to kernel space fail.\n");
    }

    size = sscanf(buf, "%c %u", &rw, &core_index);
    if (rw == 'h') {
        PRINTK_E("Usage:\n %s", usage);
        return status;
    } else if (size != 2) {
        PRINTK_E("get used command\n");
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    /* sanity check */
    if (rw != 'W' && rw != 'w' && rw != 'R' && rw != 'r') {
        PRINTK_E("input is %c\n", rw);
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    if (logi_dev_idx >= context->device_count) {
        PRINTK_E("dev-index=%d, MAX=%d\n", dev_index, context->device_count);
        vipGoOnError(VIP_ERROR_FAILURE);
    }
    device = vipdrv_get_device(dev_index);
    vipIsNULL(device);

    if (core_index >= device->hardware_count) {
        PRINTK_E("dev-index=%d, core-index, MAX=%d\n", logi_dev_idx, core_index, device->hardware_count);
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    hardware = vipdrv_get_hardware(device, core_index);
    vipIsNULL(hardware);

#if vpmdENABLE_POWER_MANAGEMENT
    vipdrv_pm_send_evnt(hardware, VIPDRV_PWR_EVNT_CLK_ON, VIP_NULL);
    if (VIPDRV_POWER_CLOCK & vipdrv_pm_query_state(hardware)) {
#endif
        if (rw == 'w' || rw == 'W') {
            size = sscanf(buf, "%c %d %d %x %x", &rw, &dev_index, &core_index, &address, &val);
            if (size == 5) {
                status = vipdrv_os_write_reg(hardware->reg_base, address, val);
                if (status != VIP_SUCCESS) {
                    PRINTK_E("write dev%d hw%d address[0x%x] val[0x%x] failed.\n", logi_dev_idx, core_index,
                             address, val);
                    return count;
                }
                PRINTK_E("write dev%d hw%d address[0x%x] val[0x%x] success.\n", logi_dev_idx, core_index,
                         address, val);
            } else {
                PRINTK_E("write param error size=%d, usage:\n %s.\n", size, usage);
            }
        } else if (rw == 'r' || rw == 'R') {
            size = sscanf(buf, "%c %d %x", &rw, &core_index, &address);
            if (size == 3) {
                status = vipdrv_os_read_reg(hardware->reg_base, address, &register_value[logi_dev_idx]);
                if (status != VIP_SUCCESS) {
                    PRINTK_E("read dev%d hw%d address[0x%x] failed.\n", logi_dev_idx, core_index, address);
                    return count;
                }
                register_address[logi_dev_idx] = address;
                PRINTK_E("read dev%d hw%d address[0x%x] = [0x%x] success.\n", logi_dev_idx, core_index,
                         address, register_value[logi_dev_idx]);
            } else {
                PRINTK_E("read param error size=%d, usage:\n %s.\n", size, usage);
            }
        }
#if vpmdENABLE_POWER_MANAGEMENT
    } else {
        PRINTK_E("dev%d hw%d not working, may vip has power off, can't read register\n", logi_dev_idx,
                 hardware->core_index);
    }
    status = vipdrv_pm_send_evnt(hardware, VIPDRV_PWR_EVNT_CLK_OFF, VIP_NULL);
#endif
    PRINTK_D("end power off....\n");

    return status;

onError:
    PRINTK_E("Usage: %s", usage);
    return status;
}

static ssize_t vip_debugfs_register_rw_write(struct file* file, const char __user* ubuf, size_t count,
                                             loff_t* ppos)
{
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    vip_status_e status = VIP_SUCCESS;
    vip_bool_e need_init = vip_true_e;

    DEBUGFS_WRITE_GET_LOGI_IDX

    mutex_lock(&debugfs_mutex);

    if (0 < context->initialize) {
        need_init = vip_false_e;
    }

    if (vip_true_e == need_init) {
        vipdrv_initialize_t init_data;
        init_data.version = ((VERSION_MAJOR << 16) | (VERSION_MINOR << 8) | (VERSION_SUB_MINOR));
        status = vipdrv_init(&init_data);
        if (status != VIP_SUCCESS) {
            PRINTK_E("init vipdrv\n");
            mutex_unlock(&debugfs_mutex);
            return count;
        }
    }

    vipdrv_register_rw(ubuf, count, logi_dev_idx);

    if (vip_true_e == need_init) {
        PRINTK_D("vip drv destroy start\n");
        vipdrv_destroy();
    }

    mutex_unlock(&debugfs_mutex);

    return count;
}

static int vipdrv_seq_register_rw_show(struct seq_file* s, void* v)
{
    DEBUGFS_SHOW_GET_LOGI_IDX

    if ((0 == register_address[logi_dev_idx]) && (0 == register_value[logi_dev_idx])) {
        vip_char_t* usage = "echo > [option] [core-index] [address] (value) > register_rw\n"
                            "  echo > [w --write] [core-index] [register address] [write val] > register_rw\n"
                            "  echo > [r  --read] [core-index] [register address] > register_rw\n"
                            "  eg: echo r 0 0x30 > register_rw\n"
                            "      echo w 0 0x00 0x00070900 > register_rw\n";
        seq_printf(s, "usage: %s\n", usage);
    } else {
        mutex_lock(&debugfs_mutex);
        seq_printf(s, "register[0x%x] = 0x%x.\n", register_address[logi_dev_idx],
                   register_value[logi_dev_idx]);
        mutex_unlock(&debugfs_mutex);
    }

    return 0;
}

#if vpmdTASK_DISPATCH_DEBUG
static ssize_t vip_debugfs_task_dispatch_write(struct file* file, const char __user* ubuf, size_t count,
                                               loff_t* ppos)
{
    vip_char_t buf[128] = {};

    if (count > 128) {
        PRINTK_E("please echo bytes no more than 128, not reset task profile.\n");
        return count;
    }

    if (copy_from_user(&buf, ubuf, count)) {
        PRINTK_E("copy user data to kernel space fail,not reset task profile.\n");
    }

    vipdrv_task_dispatch_set((const char*)&buf, count);

    return count;
}

static int vipdrv_seq_task_dispatch_show(struct seq_file* s, void* v)
{
    return vipdrv_task_dispatch_get((void*)s, VIP_NULL);
}
#endif

#define seq_open(a)                                                           \
    static int vip_debugfs_##a##_open(struct inode* inode, struct file* file) \
    {                                                                         \
        return single_open(file, &vipdrv_seq_##a##_show, inode->i_private);   \
    }

#define debugfs_ops(a)                                            \
    static const struct file_operations vip_debugfs_##a##_ops = { \
                .owner = THIS_MODULE,                             \
                .open = vip_debugfs_##a##_open,                   \
                .read = seq_read,                                 \
                .write = vip_debugfs_##a##_write,                 \
                .llseek = seq_lseek,                              \
                .release = seq_release,                           \
    };

// clang-format off
#define unroll_debugfs_file(a)   \
    seq_open(a)                  \
    debugfs_ops(a)

unroll_debugfs_file(core_loading)
unroll_debugfs_file(vip_info)
unroll_debugfs_file(mem_profile)
unroll_debugfs_file(mem_mapping)
#if vpmdENABLE_MMU
unroll_debugfs_file(dump_mmu_table)
#endif
#if vpmdENABLE_HANG_DUMP
unroll_debugfs_file(hang_dump)
#endif
unroll_debugfs_file(vip_freq)
#if vpmdENABLE_SUSPEND_RESUME
unroll_debugfs_file(suspend)
#endif
#if vpmdENABLE_DEBUG_LOG > 2
unroll_debugfs_file(rt_log)
#endif
#if 0
unroll_debugfs_file(multi_vip)
#endif
unroll_debugfs_file(register_rw)
unroll_debugfs_file(vip_pc_value)
unroll_debugfs_file(rt_net_profile)
#if vpmdENABLE_BW_PROFILING
unroll_debugfs_file(rt_bw_profile)
#endif
#if vpmdENABLE_CNN_PROFILING
unroll_debugfs_file(rt_cnn_profile)
#endif
unroll_debugfs_file(rt_hal_capture)
unroll_debugfs_file(rt_hang_capture)
#if vpmdTASK_DISPATCH_DEBUG
unroll_debugfs_file(task_dispatch)
#endif
            // clang-format on

            /* brief Creat debugfs profile dir and file */
            static vip_status_e vipdrv_debug_create_debugfs(vipdrv_vipcore_device_t* vipcore_dev)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t index = 0;
    char dev_root_name[255] = {'\0'};
    debug_node_t* logi_dev_node = VIP_NULL;
    struct dentry* logi_dev_root = VIP_NULL;

    if (node == VIP_NULL) {
        node = kzalloc(sizeof(debug_node_t) * vipcore_dev->logi_dev_cnt, GFP_KERNEL);
    }
    if (!node) {
        PRINTK("create node fail for debugfs\n");
        return VIP_ERROR_FAILURE;
    }

    memset(node, 0, sizeof(debug_node_t) * vipcore_dev->logi_dev_cnt);

    debugfs_root = debugfs_create_dir("viplite", NULL);
    if (!debugfs_root) {
        PRINTK("create viplite debugfs dir failed.\n");
        status = VIP_ERROR_FAILURE;
        return status;
    }
    for (index = 0; index < vipcore_dev->logi_dev_cnt; index++) {
        sprintf(dev_root_name, "dev%u", index);
        logi_dev_root = debugfs_create_dir(dev_root_name, debugfs_root);
        if (!logi_dev_root) {
            PRINTK("create debugfs dev%u dir failed\n", index);
            status = VIP_ERROR_FAILURE;
            goto exit;
        }
        logi_dev_node = node + index;
        logi_dev_node->logi_dev_idx = index;
        debugfs_create_file("vip_info", 0644, logi_dev_root, logi_dev_node, &vip_debugfs_vip_info_ops);
        debugfs_create_file("vip_freq", 0644, logi_dev_root, logi_dev_node, &vip_debugfs_vip_freq_ops);
        debugfs_create_file("core_loading", 0644, logi_dev_root, logi_dev_node,
                            &vip_debugfs_core_loading_ops);
        debugfs_create_file("mem_profile", 0644, logi_dev_root, logi_dev_node, &vip_debugfs_mem_profile_ops);
        debugfs_create_file("mem_mapping", 0644, logi_dev_root, logi_dev_node, &vip_debugfs_mem_mapping_ops);
        debugfs_create_file("register_rw", 0644, logi_dev_root, logi_dev_node, &vip_debugfs_register_rw_ops);
        debugfs_create_file("vip_pc_value", 0644, logi_dev_root, logi_dev_node,
                            &vip_debugfs_vip_pc_value_ops);
#if vpmdENABLE_DEBUG_LOG > 2
        debugfs_create_file("rt_log", 0644, logi_dev_root, logi_dev_node, &vip_debugfs_rt_log_ops);
#endif
#if vpmdENABLE_BW_PROFILING
        debugfs_create_file("rt_bw_profile", 0644, logi_dev_root, logi_dev_node,
                            &vip_debugfs_rt_bw_profile_ops);
#endif
#if vpmdENABLE_CNN_PROFILING
        debugfs_create_file("rt_cnn_profile", 0644, logi_dev_root, logi_dev_node,
                            &vip_debugfs_rt_cnn_profile_ops);
#endif
        debugfs_create_file("rt_hal_capture", 0644, logi_dev_root, logi_dev_node,
                            &vip_debugfs_rt_hal_capture_ops);
        debugfs_create_file("rt_hang_capture", 0644, logi_dev_root, logi_dev_node,
                            &vip_debugfs_rt_hang_capture_ops);
#if 0
        debugfs_create_file("multi_vip", 0644, logi_dev_root, logi_dev_node, &vip_debugfs_multi_vip_ops);
#endif
#if vpmdENABLE_MMU
        debugfs_create_file("dump_mmu_table", 0644, logi_dev_root, logi_dev_node,
                            &vip_debugfs_dump_mmu_table_ops);
#endif
#if vpmdENABLE_HANG_DUMP
        debugfs_create_file("hang_dump", 0644, logi_dev_root, logi_dev_node, &vip_debugfs_hang_dump_ops);
#endif
#if vpmdENABLE_SUSPEND_RESUME
        debugfs_create_file("suspend", 0644, logi_dev_root, logi_dev_node, &vip_debugfs_suspend_ops);
#endif
        debugfs_create_file("rt_net_profile", 0644, logi_dev_root, logi_dev_node,
                            &vip_debugfs_rt_net_profile_ops);
#if vpmdTASK_DISPATCH_DEBUG
        debugfs_create_file("task_dispatch", 0644, logi_dev_root, logi_dev_node,
                            &vip_debugfs_task_dispatch_ops);
#endif
    }
    return status;
exit:
    if (debugfs_root != VIP_NULL) {
        debugfs_remove_recursive(debugfs_root);
        debugfs_root = VIP_NULL;
    }
    return status;
}

/*
@brief Destroy debugfs profile dir and file
*/
static vip_status_e vipdrv_debug_destroy_debugfs(void)
{
    if (debugfs_root != VIP_NULL) {
        debugfs_remove_recursive(debugfs_root);
        debugfs_root = VIP_NULL;
    }

    if (node != VIP_NULL) {
        kfree(node);
    }

    return VIP_SUCCESS;
}

#undef vip_debugfs_write
#undef seq_ops
#undef seq_open
#undef debugfs_ops
#undef undef_debugfs_file

#else
static ssize_t vip_info_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr, char* buf,
                             loff_t off, size_t count)
{
    loff_t len = 0;
    sys_param param;

    SYSFS_GET_LOGI_IDX

    param.buf = buf;
    param.offset = off;
    len = (loff_t)vipdrv_vipinfo_show((void*)(&param), VIP_NULL, logi_dev_idx);

    return (len >= off ? len - off : 0);
}

static ssize_t vip_freq_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr, char* buf,
                             loff_t off, size_t count)
{
    loff_t len = 0;
    sys_param param;

    SYSFS_GET_LOGI_IDX

    param.buf = buf;
    param.offset = off;

    len = (loff_t)vipdrv_vipfreq_show((void*)(&param), VIP_NULL, logi_dev_idx);

    return (len >= off ? len - off : 0);
}

static ssize_t vip_freq_store(struct file* filp, struct kobject* kobj, struct bin_attribute* attr, char* buf,
                              loff_t off, size_t count)
{
    SYSFS_GET_LOGI_IDX

    return vipdrv_vipfreq_set(buf, count, logi_dev_idx);
}

static ssize_t core_loading_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                 char* buf, loff_t off, size_t count)
{
    loff_t len = 0;
    sys_param param;

    SYSFS_GET_LOGI_IDX

    param.buf = buf;
    param.offset = off;
    len = (loff_t)vipdrv_core_loading_get((void*)(&param), VIP_NULL, logi_dev_idx);

    return (len >= off ? len - off : 0);
}
static ssize_t core_loading_store(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                  char* buf, loff_t off, size_t count)
{
    return vipdrv_core_loading_set(buf, count);
}

static ssize_t mem_profile_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                char* buf, loff_t off, size_t count)
{
    loff_t len = 0;
    sys_param param;
    param.buf = buf;
    param.offset = off;
    len = (loff_t)vipdrv_mem_profile((void*)(&param), VIP_NULL);

    return (len >= off ? len - off : 0);
}
static ssize_t mem_profile_store(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                 char* buf, loff_t off, size_t count)
{
    ssize_t ret = 0;
    mutex_lock(&debugfs_mutex);
    ret = (ssize_t)vipdrv_mem_profile_set(buf, count);
    mutex_unlock(&debugfs_mutex);
    return ret;
}

static ssize_t mem_mapping_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                char* buf, loff_t off, size_t count)
{
    loff_t len = 0;
    sys_param param;
    param.buf = buf;
    param.offset = off;
    if (0 == off)
        mutex_lock(&debugfs_mutex);
    len = (loff_t)vipdrv_mem_mapping((void*)(&param), VIP_NULL);
    if (off >= len)
        mutex_unlock(&debugfs_mutex);

    return (len >= off ? len - off : 0);
}

static ssize_t vip_pc_value_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                 char* buf, loff_t off, size_t count)
{
    loff_t len = 0;
    sys_param param;

    SYSFS_GET_LOGI_IDX

    param.buf = buf;
    param.offset = off;
    if (0 == off)
        mutex_lock(&debugfs_mutex);
    len = (loff_t)vipdrv_vip_pc_value_get((void*)(&param), VIP_NULL, logi_dev_idx);
    if (off >= len)
        mutex_unlock(&debugfs_mutex);

    return (len >= off ? len - off : 0);
}

#if vpmdENABLE_MMU
static ssize_t dump_mmu_table_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                   char* buf, loff_t off, size_t count)
{
    loff_t len = 0;
    sys_param param;

    SYSFS_GET_LOGI_IDX

    param.buf = buf;
    param.offset = off;
    if (0 == off)
        mutex_lock(&debugfs_mutex);
    len = (loff_t)vipdrv_dump_mmu_table((void*)(&param), VIP_NULL, logi_dev_idx);
    if (off >= len)
        mutex_unlock(&debugfs_mutex);

    return (len >= off ? len - off : 0);
}
#endif

#if vpmdENABLE_HANG_DUMP
static ssize_t hang_dump_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr, char* buf,
                              loff_t off, size_t count)
{
    loff_t len = 0;
    sys_param param;

    SYSFS_GET_LOGI_IDX

    param.buf = buf;
    param.offset = off;
    if (0 == off)
        mutex_lock(&debugfs_mutex);
    len = (loff_t)vipdrv_get_hang_dump((void*)(&param), VIP_NULL, logi_dev_idx);
    if (off >= len)
        mutex_unlock(&debugfs_mutex);

    return (len >= off ? len - off : 0);
}
#endif

#if vpmdENABLE_SUSPEND_RESUME
static ssize_t suspend_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr, char* buf,
                            loff_t off, size_t count)
{
    loff_t len = 0;
    len += fs_printf(buf, "suspend vip command: echo 1 > /sys/devices/platform/xxx/suspend\n");
    len += fs_printf(buf + len, "resume vip command: echo 0 > /sys/devices/platform/xxx/suspend\n");
    return (len >= off ? len - off : 0);
}
static ssize_t suspend_store(struct file* filp, struct kobject* kobj, struct bin_attribute* attr, char* buf,
                             loff_t off, size_t count)
{
    vip_uint32_t* initialize = (vip_uint32_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_INITED);

    SYSFS_GET_LOGI_IDX

    if (0 == *initialize) {
        PRINTK_E("vip not working, fail to set suspend\n");
        return count;
    }
    return vipdrv_suspend_set(buf, count, logi_dev_idx);
}
#endif
#if vpmdENABLE_DEBUG_LOG > 2
static ssize_t rt_log_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr, char* buf,
                           loff_t off, size_t count)
{
    loff_t len = 0;
    len += fs_printf(buf, "rt_log = %d.\n", g_rt_log_level & 0x7f);
    return (len >= off ? len - off : 0);
}
static ssize_t rt_log_store(struct file* filp, struct kobject* kobj, struct bin_attribute* attr, char* buf,
                            loff_t off, size_t count)
{
    return vipdrv_rt_log_set(buf, count);
}
#endif

#if vpmdENABLE_BW_PROFILING
static ssize_t rt_bw_profile_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                  char* buf, loff_t off, size_t count)
{
    loff_t len = 0;
    len += fs_printf(buf, "rt_bw_profile = %d.\n", g_rt_bw_profile);
    return (len >= off ? len - off : 0);
}

static ssize_t rt_bw_profile_store(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                   char* buf, loff_t off, size_t count)
{
    return vipdrv_rt_bw_profile_set(buf, count);
}
#endif

#if vpmdENABLE_CNN_PROFILING
static ssize_t rt_cnn_profile_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                   char* buf, loff_t off, size_t count)
{
    loff_t len = 0;
    len += fs_printf(buf, "rt_cnn_profile = %d.\n", g_rt_cnn_profile);
    return (len >= off ? len - off : 0);
}

static ssize_t rt_cnn_profile_store(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                    char* buf, loff_t off, size_t count)
{
    return vipdrv_rt_cnn_profile_set(buf, count);
}
#endif

static ssize_t rt_hal_capture_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                   char* buf, loff_t off, size_t count)
{
    loff_t len = 0;
    len += fs_printf(buf, "rt_hal_capture = %d.\n", g_rt_hal_capture);
    return (len >= off ? len - off : 0);
}

static ssize_t rt_hal_capture_store(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                    char* buf, loff_t off, size_t count)
{
    return vipdrv_rt_hal_capture_set(buf, count);
}

static ssize_t rt_hang_capture_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                    char* buf, loff_t off, size_t count)
{
    loff_t len = 0;
    len += fs_printf(buf, "rt_hang_capture = %d.\n", g_rt_hang_capture);
    return (len >= off ? len - off : 0);
}

static ssize_t rt_hang_capture_store(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                     char* buf, loff_t off, size_t count)
{
    return vipdrv_rt_hang_capture_set(buf, count);
}

#if 0
static ssize_t multi_vip_show(
    struct file *filp,
    struct kobject *kobj,
    struct bin_attribute *attr,
    char *buf,
    loff_t off,
    size_t count)
{
    loff_t len = 0, i = 0;
    vipdrv_phy_device_t *phy_dev = vipdrv_get_phy_device(MULTI_DEVICE_ENABLE_ID);
    len += fs_printf(buf, "current config: {");
    for (i = 0; i < phy_dev->vendor->core_count; i++) {
        if (0 < i) {
            len += fs_printf(buf + len, ", ");
        }
        len += fs_printf(buf + len, "%d", phy_dev->vendor->device_core_number[i]);
    }
    len += fs_printf(buf + len, "}\n");
    len += fs_printf(buf + len, "config multi-vip: echo {");
    for (i = 0; i < phy_dev->vendor->core_count; i++) {
        if (0 < i) {
            len += fs_printf(buf + len, ", ");
        }
        len += fs_printf(buf + len, "1");
    }
    len += fs_printf(buf + len, "} > /sys/devices/platform/xxx/multi_vip\n");
    return (len >= off ? len - off : 0);
}
static ssize_t multi_vip_store(
    struct file *filp,
    struct kobject *kobj,
    struct bin_attribute *attr,
    char *buf,
    loff_t off,
    size_t count)
{
    return vipdrv_multi_vip_set(buf, count);
}
#endif

static ssize_t rt_net_profile_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                   char* buf, loff_t off, size_t count)
{
    loff_t len = 0;
    sys_param param;
    param.buf = buf;
    param.offset = off;
    len = (loff_t)vipdrv_rt_net_profile((void*)(&param), VIP_NULL);

    return (len >= off ? len - off : 0);
}
static ssize_t rt_net_profile_store(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                    char* buf, loff_t off, size_t count)
{
    return vipdrv_rt_net_profile_set(buf, count);
}

#if vpmdTASK_DISPATCH_DEBUG
static ssize_t task_dispatch_show(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                  char* buf, loff_t off, size_t count)
{
    loff_t len = 0;
    sys_param param;
    param.buf = buf;
    param.offset = off;
    len = (loff_t)vipdrv_task_dispatch_get((void*)(&param), VIP_NULL);

    return (len >= off ? len - off : 0);
}

static ssize_t task_dispatch_store(struct file* filp, struct kobject* kobj, struct bin_attribute* attr,
                                   char* buf, loff_t off, size_t count)
{
    return vipdrv_task_dispatch_set(buf, count);
}
#endif

// clang-format off
#define sysfs_RW(a)                                        \
    static struct bin_attribute sysfs_##a##_attr = { \
        .attr = {                                          \
        .name = #a,                                        \
            .mode = S_IRUGO | S_IWUSR,                     \
        },                                                 \
        .read = a##_show,                                  \
        .write = a##_store                                 \
    };

#define sysfs_RO(a)                                        \
    static struct bin_attribute sysfs_##a##_attr = { \
        .attr = {                                          \
        .name = #a,                                        \
            .mode = S_IRUGO,                               \
        },                                                 \
        .read = a##_show                                   \
    };
// clang-format on

sysfs_RO(vip_info);
sysfs_RW(vip_freq);
sysfs_RW(core_loading);
sysfs_RW(mem_profile);
sysfs_RO(mem_mapping);
sysfs_RO(vip_pc_value);
#if vpmdENABLE_MMU
sysfs_RO(dump_mmu_table);
#endif
#if vpmdENABLE_HANG_DUMP
sysfs_RO(hang_dump);
#endif
#if vpmdENABLE_SUSPEND_RESUME
sysfs_RW(suspend);
#endif
#if vpmdENABLE_DEBUG_LOG > 2
sysfs_RW(rt_log);
#endif
#if 0
sysfs_RW(multi_vip);
#endif
sysfs_RW(rt_net_profile);
#if vpmdENABLE_BW_PROFILING
sysfs_RW(rt_bw_profile);
#endif
#if vpmdENABLE_CNN_PROFILING
sysfs_RW(rt_cnn_profile);
#endif
sysfs_RW(rt_hal_capture);
sysfs_RW(rt_hang_capture);
#if vpmdTASK_DISPATCH_DEBUG
sysfs_RW(task_dispatch);
#endif

static vip_status_e vipdrv_debug_create_sysfs(vipdrv_vipcore_device_t* vipcore_dev)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t index = 0, offset = 0;
    char dev_root_name[255] = {'\0'};
    struct device* device;
    debug_node_t* logi_dev_node = VIP_NULL;
    vipdrv_logi_device_t* logi_dev = VIP_NULL;

#define MAX_NODE_FOR_ONE_DEV 100
#define UNROLL_SYSFS(name)                                                              \
    memcpy(attr_array + offset, &sysfs_##name##_attr, sizeof(struct bin_attribute));    \
    attr_array[offset].private = (void*)logi_dev_node;                                  \
    status |= sysfs_create_bin_file(logi_dev_node->dev_root_kobj, attr_array + offset); \
    offset++;

    if (node == VIP_NULL) {
        node = kzalloc(sizeof(debug_node_t) * vipcore_dev->logi_dev_cnt, GFP_KERNEL);
    }
    if (!node) {
        PRINTK("create node fail for sysfs\n");
        return VIP_ERROR_FAILURE;
    }
    memset(node, 0, sizeof(debug_node_t) * vipcore_dev->logi_dev_cnt);

    if (attr_array == VIP_NULL) {
        attr_array = kzalloc(sizeof(struct bin_attribute) * vipcore_dev->logi_dev_cnt * MAX_NODE_FOR_ONE_DEV,
                             GFP_KERNEL);
    }
    if (!attr_array) {
        PRINTK("create attr array fail for sysfs\n");
        return VIP_ERROR_FAILURE;
    }
    memset(attr_array, 0, sizeof(struct bin_attribute) * vipcore_dev->logi_dev_cnt);

    for (index = 0; index < vipcore_dev->logi_dev_cnt; index++) {
        sprintf(dev_root_name, "dev%u", index);
        logi_dev_node = node + index;
        logi_dev_node->logi_dev_idx = index;
        logi_dev = &vipcore_dev->logi_dev[index];
        device = logi_dev->phy_dev->device;

        /*create devX floder on device kobj*/
        logi_dev_node->dev_root_kobj = kobject_create_and_add(dev_root_name, &device->kobj);

        UNROLL_SYSFS(vip_info)
        UNROLL_SYSFS(vip_freq)
        UNROLL_SYSFS(core_loading)
        UNROLL_SYSFS(mem_profile)
        UNROLL_SYSFS(mem_mapping)
        UNROLL_SYSFS(vip_pc_value)
#if vpmdENABLE_MMU
        UNROLL_SYSFS(dump_mmu_table)
#endif
#if vpmdENABLE_HANG_DUMP
        UNROLL_SYSFS(hang_dump)
#endif
#if vpmdENABLE_SUSPEND_RESUME
        UNROLL_SYSFS(suspend)
#endif
#if vpmdENABLE_DEBUG_LOG > 2
        UNROLL_SYSFS(rt_log)
#endif
#if 0
        UNROLL_SYSFS(multi_vip)
#endif
        UNROLL_SYSFS(rt_net_profile)
#if vpmdENABLE_BW_PROFILING
        UNROLL_SYSFS(rt_bw_profile)
#endif
#if vpmdENABLE_CNN_PROFILING
        UNROLL_SYSFS(rt_cnn_profile)
#endif
        UNROLL_SYSFS(rt_hal_capture)
        UNROLL_SYSFS(rt_hang_capture)
#if vpmdTASK_DISPATCH_DEBUG
        UNROLL_SYSFS(task_dispatch)
#endif
    }

    return status;
}

static vip_status_e vipdrv_debug_destroy_sysfs(vipdrv_vipcore_device_t* vipcore_dev)
{
    vip_uint32_t index = 0;
    debug_node_t* logi_dev_node = VIP_NULL;

    for (index = 0; index < vipcore_dev->logi_dev_cnt; index++) {
        logi_dev_node = node + index;
        if (logi_dev_node->dev_root_kobj != VIP_NULL) {
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_vip_info_attr);
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_vip_freq_attr);
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_core_loading_attr);
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_mem_profile_attr);
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_mem_mapping_attr);
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_vip_pc_value_attr);
#if vpmdENABLE_MMU
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_dump_mmu_table_attr);
#endif
#if vpmdENABLE_HANG_DUMP
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_hang_dump_attr);
#endif
#if vpmdENABLE_SUSPEND_RESUME
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_suspend_attr);
#endif
#if vpmdENABLE_DEBUG_LOG > 2
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_rt_log_attr);
#endif
#if 0
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_multi_vip_attr);
#endif
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_rt_net_profile_attr);
#if vpmdENABLE_BW_PROFILING
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_rt_bw_profile_attr);
#endif
#if vpmdENABLE_CNN_PROFILING
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_rt_cnn_profile_attr);
#endif
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_rt_hal_capture_attr);
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_rt_hang_capture_attr);
#if vpmdTASK_DISPATCH_DEBUG
            sysfs_remove_bin_file(logi_dev_node->dev_root_kobj, &sysfs_task_dispatch_attr);
#endif
            kobject_put(logi_dev_node->dev_root_kobj);
        }
    }

    if (node != VIP_NULL) {
        kfree(node);
    }
    if (attr_array != VIP_NULL) {
        kfree(attr_array);
    }

    return VIP_SUCCESS;
}
#endif

vip_status_e vipdrv_debug_create_fs(vipdrv_vipcore_device_t* vipcore_dev)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t i = 0, size = 0;

    for (i = 0; i < vipcore_dev->logi_dev_cnt; i++) {
        debugfs_core_cnt += vipcore_dev->logi_dev[i].core_cnt;
    }
    size = debugfs_core_cnt * sizeof(vipdrv_core_loading_profile_t);
    vipdrv_os_allocate_memory(size, (void**)&core_loading);
    vipdrv_os_zero_memory((void*)core_loading, size);
    PRINTK_D("debugfs dev cnt = %u, core cnt=%d\n", vipcore_dev->logi_dev_cnt, debugfs_core_cnt);

#if vpmdUSE_DEBUG_FS
    status = vipdrv_debug_create_debugfs(vipcore_dev);
#else
    status = vipdrv_debug_create_sysfs(vipcore_dev);
#endif
    return status;
}

vip_status_e vipdrv_debug_destroy_fs(vipdrv_vipcore_device_t* vipcore_dev)
{
    vip_status_e status = VIP_SUCCESS;
#if vpmdUSE_DEBUG_FS
    status = vipdrv_debug_destroy_debugfs();
#else
    status = vipdrv_debug_destroy_sysfs(vipcore_dev);
#endif

    if (core_loading != VIP_NULL) {
        vipdrv_os_free_memory((void*)core_loading);
        core_loading = VIP_NULL;
    }

    return status;
}

vip_status_e vipdrv_debug_profile_start(void)
{
    vip_uint32_t i = 0;
    vip_status_e status = VIP_SUCCESS;
    vip_uint64_t time = vipdrv_os_get_time();
    if (VIP_NULL == core_loading) {
        return status;
    }

    for (i = 0; i < debugfs_core_cnt; i++) {
        core_loading[i].init_time = time;
        core_loading[i].destory_time = 0;
        core_loading[i].submit_time = 0;
        core_loading[i].infer_time = 0;
    }

    video_mem_data.video_memory = 0;
    video_mem_data.video_peak = 0;
    video_mem_data.video_allocs = 0;
    video_mem_data.video_frees = 0;

    return status;
}

vip_status_e vipdrv_debug_profile_end(void)
{
    vip_uint32_t i = 0;
    vip_status_e status = VIP_SUCCESS;
    vip_uint64_t time = vipdrv_os_get_time();
    if (VIP_NULL == core_loading) {
        return status;
    }

    for (i = 0; i < debugfs_core_cnt; i++) {
        core_loading[i].destory_time = time;
    }

    return status;
}

#endif
