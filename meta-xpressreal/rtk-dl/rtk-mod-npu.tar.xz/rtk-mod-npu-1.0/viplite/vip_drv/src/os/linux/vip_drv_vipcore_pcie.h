/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#ifndef _VIP_DRV_VIPCORE_PCIE_H
#define _VIP_DRV_VIPCORE_PCIE_H

#include <linux/mman.h>
#include <linux/pci.h>
#include <vip_drv_os_port.h>
#include "vip_drv_vipcore_type.h"

/* LINUX platform device driver source code */

/*
 * there are 4 type of scenarios vip in system:
 *  1.vip is a real platform device. register it in dts. using platform_drv->driver.of_match_table to match.
 *      call function vipdrv_platform_device_auto_probe to implement it.
 *
 *  2.vip is a PCIe device. using pci_register_driver to match. then kernel call the probe callback to do probe.
 *      call function vipdrv_pcie_device_auto_probe to implement it.
 *
 *  3.vip is a PCIe device. the pci_driver not in viplite. the pcie has been probed before insmod vipcore.
 *      just to call pci_get_device to get the PCIe device.
 *      call function vipdrv_pcie_device_dummy_probe to implement it.
 *
 *  4.vip not in any bus. viplite register virtual platform device to do probe.
 *      call function vipdrv_misc_device_init to implement it.
 */

/* query pcie bar information */
vip_int32_t vipdrv_pcie_query_bar_info(struct pci_dev* pdev, vip_uint64_t* bar_addr, vip_uint64_t* bar_size,
                                       vip_uint32_t bar_num);

/*
Auto probe pcie device to initialize vip-core platform
@param platform_drv: is the linux platform driver, will be register in module_drv_init func.
@param pcie_ids: the ids of PCIE card.
@param ids_cnt: the number of element for pcie_ids.
@param vendor_operations: IN, vendor device ops
@param vipcore_vendor: OUT, vip core platform struct.
*/
vip_int32_t vipdrv_pcie_device_auto_probe(const struct pci_device_id* vivpcie_ids, vip_uint32_t ids_cnt,
                                          vipdrv_vendor_operations_t* vendor_operations,
                                          vipdrv_vipcore_vendor_t* vipcore_vendor);

/* Auto remove pcie device */
vip_int32_t vipdrv_pcie_device_auto_remove(vipdrv_vipcore_vendor_t* vipcore_vendor);

/*
Dymmy probe pcie device to initialize vip-core platform. the pice has beend probed by others pcie driver.
@param platform_drv: IN, is the linux platform driver, will be register in module_drv_init func.
@param pcie_ids: IN,the ids of PCIE card.
@param ids_cnt: IN,the number of element for pcie_ids.
@param vendor_operations: IN, vendor device ops
@param vipcore_vendor: OUT, vip core platform struct.
*/
vip_int32_t vipdrv_pcie_device_dummy_probe(const struct pci_device_id* vivpcie_ids, vip_uint32_t ids_cnt,
                                           vipdrv_vendor_operations_t* vendor_operations,
                                           vipdrv_vipcore_vendor_t* vipcore_vendor);

/* remove Dummy pcie device. the pice has beend probed by others pcie driver */
vip_int32_t vipdrv_pcie_device_dummy_remove(vipdrv_vipcore_vendor_t* vipcore_vendor);

/*
Map the CPU logical for PCIE bar space. Used for NPU AHB register.
*/
vip_status_e vipdrv_pcie_bar_map(vipdrv_vendor_device_t* device, vip_uint32_t bar_num,
                                 vip_uint32_t register_offset, vip_uint32_t register_size, void** logical);

vip_status_e vipdrv_pcie_bar_unmap(vipdrv_vendor_device_t* device, void* logical);

#endif
