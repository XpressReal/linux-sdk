/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/
#undef VIPDRV_LOG_ZONE
#define VIPDRV_LOG_ZONE VIPDRV_LOG_ZONE_VIDEO_MEMORY

#include <vip_drv_mem_allocator.h>
#include <vip_drv_video_memory.h>
#include "vip_drv_mem_allocator_common.h"

vip_status_e allocator_init_dyn_segment_continue(vipdrv_allocator_t* allocator, vip_char_t* name,
                                                 vipdrv_allocator_type_e type);

#if vpmdENABLE_DEBUG_LOG > 0
static vip_char_t* page_str(vipdrv_mem_flag_e mem_flag)
{
    switch (mem_flag & VIPDRV_MEM_FLAG_CONTIGUOUS) {
    case VIPDRV_MEM_FLAG_16M_CONTIGUOUS:
        return "16M";
    case VIPDRV_MEM_FLAG_1M_CONTIGUOUS:
        return "1M";
    case VIPDRV_MEM_FLAG_64K_CONTIGUOUS:
        return "64K";
    default:
        return "None";
    }
}
#endif

static vip_uint32_t get_page_shift(vipdrv_mem_flag_e mem_flag)
{
    switch (mem_flag & VIPDRV_MEM_FLAG_CONTIGUOUS) {
    case VIPDRV_MEM_FLAG_16M_CONTIGUOUS:
        return 24;
    case VIPDRV_MEM_FLAG_1M_CONTIGUOUS:
        return 20;
    case VIPDRV_MEM_FLAG_64K_CONTIGUOUS:
        return 16;
    default:
        return 0;
    }
}

static vip_status_e vipdrv_kernel_logical_map_segment_continue(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vipdrv_allocator_t* allocator = ptr->allocator;
    vip_uint32_t device_index = vipdrv_mem_get_devindex(handle->device_vis);
    vip_physical_t physical = allocator->callback.phy_vip2cpu(device_index, ptr->physical_table[0]);
    vip_uint32_t offset = physical - (physical & PAGE_MASK);
    void* logical = VIP_NULL;
    vip_uint8_t* prt_tmp = VIP_NULL;
    struct page** pages = VIP_NULL;
    vip_bool_e no_cache = (VIPDRV_MEM_FLAG_NONE_CACHE & ptr->mem_flag) ? vip_true_e : vip_false_e;
    vip_uint32_t page_count = 0;

    vipdrv_get_page_count(ptr, &page_count);
    vipOnError(vipdrv_os_allocate_memory(sizeof(struct page*) * page_count, (void**)&pages));
    vipdrv_os_zero_memory(pages, sizeof(struct page*) * page_count);
    vipOnError(vipdrv_fill_pages(ptr, pages));
    vipOnError(vipdrv_map_kernel_page(page_count, pages, &logical, no_cache));
    vipdrv_os_free_memory(pages);

    prt_tmp = (vip_uint8_t*)logical;
    ptr->kerl_logical = (void*)(prt_tmp + offset);
    ptr->mem_flag |= VIPDRV_MEM_FLAG_MAP_KERNEL_LOGICAL;
    PRINTK_I("map logical kernel %s continue, address=0x%"PRPx",\n", page_str(allocator->mem_flag),
             ptr->kerl_logical);
    return status;
onError:
    PRINTK_E("map kernel logical %s continue\n", page_str(allocator->mem_flag));
    if (VIP_NULL != pages) {
        vipdrv_os_free_memory(pages);
        pages = VIP_NULL;
    }
    return status;
}

static vip_status_e vipdrv_kernel_logical_unmap_segment_continue(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;

    vipdrv_unmap_kernel_page(VIPDRV_UINT64_TO_PTR(VIPDRV_PTR_TO_UINT64(ptr->kerl_logical) & PAGE_MASK));
    ptr->kerl_logical = VIP_NULL;
    ptr->mem_flag &= ~VIPDRV_MEM_FLAG_MAP_KERNEL_LOGICAL;

    return status;
}

static vip_status_e vipdrv_user_logical_map_segment_continue(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vipdrv_allocator_t* allocator = ptr->allocator;
    vip_uint32_t device_index = vipdrv_mem_get_devindex(handle->device_vis);
    vip_physical_t physical = allocator->callback.phy_vip2cpu(device_index, ptr->physical_table[0]);
    vip_uint32_t page_offset = physical - (physical & PAGE_MASK);
    void* user_logical = VIP_NULL;
    struct page** pages = VIP_NULL;
    vip_bool_e no_cache = (VIPDRV_MEM_FLAG_NONE_CACHE & ptr->mem_flag) ? vip_true_e : vip_false_e;
    vip_uint32_t page_count = 0;

    vipdrv_get_page_count(ptr, &page_count);
    vipOnError(vipdrv_os_allocate_memory(sizeof(struct page*) * page_count, (void**)&pages));
    vipdrv_os_zero_memory(pages, sizeof(struct page*) * page_count);
    vipOnError(vipdrv_fill_pages(ptr, pages));
    vipOnError(vipdrv_map_user(page_count, pages, &user_logical, no_cache));
    vipdrv_os_free_memory(pages);

    ptr->user_logical = (void*)((vip_uint8_t*)user_logical + page_offset);
    ptr->mem_flag |= VIPDRV_MEM_FLAG_MAP_USER_LOGICAL;
    ptr->pid = vipdrv_os_get_pid();
    return status;
onError:
    PRINTK_E("map user logical %s continue\n", page_str(allocator->mem_flag));
    if (VIP_NULL != pages) {
        vipdrv_os_free_memory(pages);
        pages = VIP_NULL;
    }
    return status;
}

static vip_status_e vipdrv_user_logical_unmap_segment_continue(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vip_uint32_t page_count = 0;

    if (ptr->pid == vipdrv_os_get_pid()) {
        vipdrv_get_page_count(ptr, &page_count);
        vipdrv_unmap_user(page_count,
                          VIPDRV_UINT64_TO_PTR(VIPDRV_PTR_TO_UINT64(ptr->user_logical) & PAGE_MASK));
        ptr->user_logical = VIP_NULL;
        ptr->mem_flag &= ~VIPDRV_MEM_FLAG_MAP_USER_LOGICAL;
        ptr->pid = 0;
    }

    return status;
}

#if vpmdENABLE_FLUSH_CPU_CACHE
static vip_status_e vipdrv_flush_cache_segment_continue(vipdrv_video_mem_phy_handle_t* handle,
                                                        vip_uint8_t type)
{
    vip_status_e status = VIP_SUCCESS;
#if vpmdENABLE_VIDEO_MEMORY_CACHE
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    if (0x00 == (VIPDRV_MEM_FLAG_NONE_CACHE & ptr->mem_flag)) {
        status = flush_cache_pages(ptr->flush_handle, type);
    }
#endif
    return status;
}
#endif

static vip_status_e vipdrv_mem_alloc_segment_continue(vipdrv_video_mem_phy_handle_t* handle,
                                                      vipdrv_alloc_param_ptr param)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vipdrv_allocator_t* allocator = ptr->allocator;
    vipdrv_allocator_alloc_param_t* alloc_param = (vipdrv_allocator_alloc_param_t*)param;
    size_t num_pages_seg = 0;
    u32 gfp = GFP_KERNEL | __GFP_HIGHMEM | __GFP_NOWARN | __GFP_NORETRY;
    struct page** pages = VIP_NULL;
    struct page** PagesSeg = VIP_NULL;
    size_t i = 0;
    vip_uint32_t page_count = 0;
    vip_uint32_t page_shift = get_page_shift(allocator->mem_flag);
    vip_uint32_t page_size = (1 << page_shift);
    vip_uint32_t device_index = vipdrv_mem_get_devindex(handle->device_vis);

    ptr->size = alloc_param->size;
    ptr->align = alloc_param->align;
    ptr->mem_flag = alloc_param->mem_flag;

    num_pages_seg = (ptr->size + (page_size - 1)) >> page_shift;
    vipOnError(vipdrv_os_allocate_memory(sizeof(vip_physical_t) * num_pages_seg,
                                         (void**)&ptr->physical_table));
    vipdrv_os_zero_memory(ptr->physical_table, sizeof(vip_physical_t) * num_pages_seg);
    vipOnError(vipdrv_os_allocate_memory(sizeof(vip_size_t) * num_pages_seg, (void**)&ptr->size_table));
    vipOnError(vipdrv_os_allocate_memory(sizeof(struct page*) * num_pages_seg, (void**)&PagesSeg));

    /*In ARM64,there is no highmem zone*/
#if defined(__aarch64__) || defined(__riscv)
    gfp &= ~__GFP_HIGHMEM;
#endif
    /* remove __GFP_HIGHMEM bit, limit to 4G */
    if (VIPDRV_MEM_FLAG_4GB_ADDR_PA & ptr->mem_flag) {
        gfp &= ~__GFP_HIGHMEM;
/*add __GFP_DMA32 or __GFP_DMA bit */
#if defined(CONFIG_ZONE_DMA32) && LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 37)
        gfp |= __GFP_DMA32;
#else
        gfp |= __GFP_DMA;
#endif
    }

    for (i = 0; i < num_pages_seg; i++) {
        vip_physical_t cpu_physical = 0;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 27)
        {
            void* addr = alloc_pages_exact(page_size, gfp);
            PagesSeg[i] = addr ? virt_to_page(addr) : VIP_NULL;
        }
#else
        {
            int order = get_order(page_size);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 8, 0)
            if (order >= MAX_PAGE_ORDER)
#else
            if (order >= MAX_ORDER)
#endif
            {
#if DEBUG_ALLOCATOR
                PRINTK("alloc %s contiguous memory, get order=%d is more than max=%d\n",
                       page_str(allocator->mem_flag), order, MAX_ORDER);
#endif
                vipGoOnError(VIP_ERROR_IO);
            }
            PagesSeg[i] = alloc_pages(gfp, order);
        }
#endif

        if (VIP_NULL == PagesSeg[i]) {
            ptr->physical_num = i;
            vipGoOnError(VIP_ERROR_IO);
        }
        cpu_physical = page_to_phys(nth_page(PagesSeg[i], 0));
        if (0 == cpu_physical) {
#if DEBUG_ALLOCATOR
            PRINTK("error %s allocator cpu_physical address is 0\n", page_str(allocator->mem_flag));
            ptr->physical_num = i;
#endif
            vipGoOnError(VIP_ERROR_IO);
        }
        ptr->physical_table[i] = allocator->callback.phy_cpu2vip(device_index, cpu_physical);
        ptr->size_table[i] = page_size;
    }

    ptr->physical_num = num_pages_seg;

    vipdrv_get_page_count(ptr, &page_count);
    vipOnError(vipdrv_os_allocate_memory(sizeof(struct page*) * page_count, (void**)&pages));
    vipdrv_os_zero_memory(pages, sizeof(struct page*) * page_count);
    vipOnError(vipdrv_fill_pages(ptr, pages));
    vipOnError(flush_cache_init_pages(&ptr->flush_handle, pages, page_count, 0, page_count << PAGE_SHIFT));
    vipdrv_os_free_memory(pages);
    if (VIPDRV_MEM_FLAG_NONE_CACHE & ptr->mem_flag) {
        flush_cache_destroy_pages(ptr->flush_handle);
        ptr->flush_handle = VIP_NULL;
    }
    ptr->mem_flag |= (allocator->mem_flag & VIPDRV_MEM_FLAG_CONTIGUOUS);

    vipdrv_os_free_memory((void*)PagesSeg);

    return status;
onError:
    flush_cache_destroy_pages(ptr->flush_handle);
    ptr->flush_handle = VIP_NULL;
    /* free pages */
    for (i = 0; i < ptr->physical_num; i++) {
        if (PagesSeg != VIP_NULL) {
            if (PagesSeg[i]) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 27)
                free_pages_exact(page_address(PagesSeg[i]), page_size);
#else
                __free_pages(PagesSeg[i], get_order(page_size));
#endif
            }
        }
        if (ptr->size_table != VIP_NULL) {
            ptr->size_table[i] = 0;
        }
        if (ptr->physical_table != VIP_NULL) {
            ptr->physical_table[i] = 0;
        }
    }
    ptr->physical_num = 0;

    if (VIP_NULL != ptr->size_table) {
        vipdrv_os_free_memory((void*)ptr->size_table);
        ptr->size_table = VIP_NULL;
    }
    if (VIP_NULL != ptr->physical_table) {
        vipdrv_os_free_memory((void*)ptr->physical_table);
        ptr->physical_table = VIP_NULL;
    }
    if (VIP_NULL != pages) {
        vipdrv_os_free_memory(pages);
    }
    if (VIP_NULL != PagesSeg) {
        vipdrv_os_free_memory((void*)PagesSeg);
    }
#if DEBUG_ALLOCATOR
    PRINTK("allocate %s continue mem_flag=0x%x, size=%d\n", page_str(allocator->mem_flag),
           alloc_param->mem_flag, alloc_param->size);
#endif
    return status;
}

static vip_status_e vipdrv_mem_free_segment_continue(vipdrv_video_mem_phy_handle_t* handle)
{
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vipdrv_allocator_t* allocator = ptr->allocator;
    struct page* page = VIP_NULL;
    unsigned long pfn = 0;
    vip_uint32_t i = 0;
    vip_uint32_t page_shift = get_page_shift(allocator->mem_flag);
    vip_uint32_t page_size = (1 << page_shift);
    vip_uint32_t device_index = vipdrv_mem_get_devindex(handle->device_vis);

    if (VIP_NULL == ptr->physical_table) {
        return VIP_SUCCESS;
    }

    if (ptr->kerl_logical) {
        vipdrv_kernel_logical_unmap_segment_continue(handle);
    }

    if (ptr->user_logical) {
        vipdrv_user_logical_unmap_segment_continue(handle);
    }

    flush_cache_destroy_pages(ptr->flush_handle);
    ptr->flush_handle = VIP_NULL;

    PRINTK_D("dyn free %s contiguous memory handle=0x%"PRPx"\n", page_str(allocator->mem_flag), ptr);
    for (i = 0; i < ptr->physical_num; i++) {
        pfn = __phys_to_pfn(allocator->callback.phy_vip2cpu(device_index, ptr->physical_table[i]));
        page = pfn_to_page(pfn);
        if (page) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 27)
            free_pages_exact(page_address(page), page_size);
#else
            __free_pages(page, get_order(page_size));
#endif
        }
    }
    if (VIP_NULL != ptr->size_table) {
        vipdrv_os_free_memory((void*)ptr->size_table);
        ptr->size_table = VIP_NULL;
    }
    if (VIP_NULL != ptr->physical_table) {
        vipdrv_os_free_memory((void*)ptr->physical_table);
        ptr->physical_table = VIP_NULL;
    }

    return VIP_SUCCESS;
}

/*
@brief convert CPU physical to VIP physical.
@param cpu_physical. the physical address of CPU domain.
*/
static vip_physical_t vipdrv_dyna_segment_phy_cpu2vip(vip_uint32_t device_index, vip_physical_t cpu_physical)
{
    vip_physical_t vip_hysical = cpu_physical;
    return vip_hysical;
}

/*
@brief convert VIP physical to CPU physical.
@param vip_physical. the physical address of VIP domain.
*/
static vip_physical_t vipdrv_dyna_segment_phy_vip2cpu(vip_uint32_t device_index, vip_physical_t vip_physical)
{
    vip_physical_t cpu_hysical = vip_physical;
    return cpu_hysical;
}

/*
dynamic allocator:
    physical address are XXX bytes contiguous. dynamic alloc from system.
*/
vip_status_e allocator_init_dyn_segment_continue(vipdrv_allocator_t* allocator, vip_char_t* name,
                                                 vipdrv_allocator_type_e type)
{
    if (VIP_NULL == allocator) {
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    if (0 == vipdrv_os_strcmp(name, "dyn-64K-continue")) {
        allocator->mem_flag = VIPDRV_MEM_FLAG_64K_CONTIGUOUS;
    } else if (0 == vipdrv_os_strcmp(name, "dyn-1M-continue")) {
        allocator->mem_flag = VIPDRV_MEM_FLAG_1M_CONTIGUOUS;
    } else if (0 == vipdrv_os_strcmp(name, "dyn-16M-continue")) {
        allocator->mem_flag = VIPDRV_MEM_FLAG_16M_CONTIGUOUS;
    } else {
        PRINTK_E("%s can not use dyna segment allocator\n", name);
        return VIP_ERROR_INVALID_ARGUMENTS;
    }
    allocator->mem_flag |= VIPDRV_MEM_FLAG_4GB_ADDR_PA;
    allocator->name = name;
    allocator->alctor_type = type;
    allocator->device_vis = ~(vip_uint64_t)0;
    allocator->callback.allocate = vipdrv_mem_alloc_segment_continue;
    allocator->callback.free = vipdrv_mem_free_segment_continue;
    allocator->callback.map_kernel_logical = vipdrv_kernel_logical_map_segment_continue;
    allocator->callback.unmap_kernel_logical = vipdrv_kernel_logical_unmap_segment_continue;
    allocator->callback.map_user_logical = vipdrv_user_logical_map_segment_continue;
    allocator->callback.unmap_user_logical = vipdrv_user_logical_unmap_segment_continue;
#if vpmdENABLE_FLUSH_CPU_CACHE
    allocator->callback.flush_cache = vipdrv_flush_cache_segment_continue;
#endif
    allocator->callback.phy_vip2cpu = vipdrv_dyna_segment_phy_vip2cpu;
    allocator->callback.phy_cpu2vip = vipdrv_dyna_segment_phy_cpu2vip;

    return VIP_SUCCESS;
}
