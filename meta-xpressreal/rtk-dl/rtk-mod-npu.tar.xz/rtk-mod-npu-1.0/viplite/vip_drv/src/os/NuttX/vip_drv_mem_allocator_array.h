/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2014 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#ifndef _VIP_DRV_ALLOCATOR_ARRAY_H
#define _VIP_DRV_ALLOCATOR_ARRAY_H

#include <vip_lite_config.h>
#include <vip_drv_video_memory.h>

#if vpmdENABLE_VIDEO_MEMORY_HEAP
extern vip_status_e allocator_init_nuttx_heap(vipdrv_allocator_t* allocator, vip_char_t* name,
                                                 vipdrv_allocator_type_e type);
#endif
extern vip_status_e allocator_init_nuttx_wrap_physical(vipdrv_allocator_t* allocator, vip_char_t* name,
                                                          vipdrv_allocator_type_e type);
extern vip_status_e allocator_init_nuttx_wrap_memory(vipdrv_allocator_t* allocator, vip_char_t* name,
                                                        vipdrv_allocator_type_e type);
extern vip_status_e allocator_init_nuttx_dyna_continue(vipdrv_allocator_t* allocator, vip_char_t* name,
                                                          vipdrv_allocator_type_e type);

static vipdrv_allocator_desc_t video_mem_allocator_array[] = {
            VIPDRV_DEFINE_ALLOCATOR_DESC("wrap-user-phy", allocator_init_nuttx_wrap_physical,
                                         VIPDRV_ALLOCATOR_TYPE_WRAP_USER_PHYSICAL),
            VIPDRV_DEFINE_ALLOCATOR_DESC("wrap-user-mem", allocator_init_nuttx_wrap_memory,
                                         VIPDRV_ALLOCATOR_TYPE_WRAP_USER_LOGICAL),
#if vpmdENABLE_VIDEO_MEMORY_DYNAMIC
            VIPDRV_DEFINE_ALLOCATOR_DESC("dyn-continue", allocator_init_nuttx_dyna_continue,
                                         VIPDRV_ALLOCATOR_TYPE_DYN_ALLOC),
#endif

#if vpmdENABLE_VIDEO_MEMORY_HEAP
            VIPDRV_DEFINE_ALLOCATOR_DESC("heap-reserved", allocator_init_nuttx_heap,
                                         VIPDRV_ALLOCATOR_TYPE_VIDO_HEAP),
#endif
};
#endif
