/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/
#undef VIPDRV_LOG_ZONE
#define VIPDRV_LOG_ZONE VIPDRV_LOG_ZONE_VIDEO_MEMORY

#include <vip_drv_mem_allocator.h>
#if vpmdENABLE_VIDEO_MEMORY_HEAP
#include <vip_drv_video_memory.h>
#include "vip_drv_mem_allocator_common.h"

/* The structure used to store mirror memory object which alloc on Host DDR */
typedef struct _exclusive_dma_mirror_memory {
    /* video memory handle ptrt */
    vipdrv_video_mem_phy_handle_t* ptr;
    /* the number of physical_table element */
    vip_uint32_t physical_num;
    /* the VIP's phyiscal address of each page(segment) */
    vip_physical_t* physical_table;
    /* the size of each page table element */
    vip_size_t* size_table;

    /* the kernel space logical of NPU memory, as a dst address used to copy data to NPU memory */
    void* npu_kerl_logical;
} exclusive_dma_mirror_memory_t;

vip_status_e allocator_init_heap_exclusive_dma(vipdrv_allocator_t* allocator, vip_char_t* name,
                                               vipdrv_allocator_type_e type);

static vip_status_e exclusive_dma_mirror_memory_fill_pages(vip_physical_t* physical_table,
                                                           vip_size_t* size_table, vip_uint32_t physical_num,
                                                           struct page** pages)
{
    vip_status_e status = VIP_SUCCESS;
    struct page* page = VIP_NULL;
    unsigned long pfn = 0;
    vip_uint32_t i = 0;
    vip_physical_t physical = 0;

    for (i = 0; i < physical_num; i++) {
        physical = physical_table[i];
        pfn = __phys_to_pfn(physical);
        page = pfn_to_page(pfn);
        pages[i] = nth_page(page, 0);
    }

    return status;
}

static vip_status_e exclusive_dma_npu_memory_kernel_logical_map(vipdrv_video_mem_phy_handle_t* handle,
                                                                exclusive_dma_mirror_memory_t* mirror_memory)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vipdrv_allocator_t* allocator = ptr->allocator;
    vip_uint32_t device_index = vipdrv_mem_get_devindex(handle->device_vis);
    vip_physical_t physical = allocator->callback.phy_vip2cpu(device_index, ptr->physical_table[0]);
    vip_uint32_t offset = physical - (physical & PAGE_MASK);
    vip_uint8_t* logical = VIP_NULL;
    struct page** pages = VIP_NULL;
    vip_bool_e no_cache = vip_true_e;
    vip_uint32_t page_count = 0;

    if (mirror_memory->npu_kerl_logical != VIP_NULL) {
        return VIP_SUCCESS;
    }

    vipdrv_get_page_count(ptr, &page_count);
    vipOnError(vipdrv_os_allocate_memory(sizeof(struct page*) * page_count, (void**)&pages));
    vipdrv_os_zero_memory(pages, sizeof(struct page*) * page_count);
    vipOnError(vipdrv_fill_pages(ptr, pages));
    vipOnError(vipdrv_map_kernel_page(page_count, pages, (void**)&logical, no_cache));
    vipdrv_os_free_memory(pages);

    mirror_memory->npu_kerl_logical = (void*)(logical + offset);

    PRINTK_I("dma npu mem kernel logi address=0x%"PRPx", npu phy=0x%llx, size=0x%x\n",
             mirror_memory->npu_kerl_logical, physical, ptr->size);
    return status;
onError:
    PRINTK_E("map dma npu kernel logical exclusive\n");
    return status;
}

static vip_status_e
exclusive_dma_npu_memory_kernel_logical_unmap(exclusive_dma_mirror_memory_t* mirror_memory)
{
    vip_status_e status = VIP_SUCCESS;

    if (mirror_memory->npu_kerl_logical != VIP_NULL) {
        vip_uint64_t address = VIPDRV_PTR_TO_UINT64(mirror_memory->npu_kerl_logical) & PAGE_MASK;
        vipdrv_unmap_kernel_page(VIPDRV_UINT64_TO_PTR(address));
    }
    mirror_memory->npu_kerl_logical = VIP_NULL;

    return status;
}

static vip_status_e vipdrv_kernel_logical_map_exclusive_dma(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vip_uint32_t offset = 0;
    vip_uint8_t* logical = VIP_NULL;
    struct page** pages = VIP_NULL;
    vip_bool_e no_cache = (VIPDRV_MEM_FLAG_NONE_CACHE & ptr->mem_flag) ? vip_true_e : vip_false_e;
    vip_uint32_t page_count = 0;
    exclusive_dma_mirror_memory_t* m_memory = (exclusive_dma_mirror_memory_t*)ptr->alloc_handle_ext;

    if (VIP_NULL == m_memory) {
        PRINTK_E("alloc handle ext is null kernel logical\n");
        return VIP_ERROR_FAILURE;
    }

    page_count = m_memory->physical_num;
    vipOnError(vipdrv_os_allocate_memory(sizeof(struct page*) * page_count, (void**)&pages));
    vipdrv_os_zero_memory(pages, sizeof(struct page*) * page_count);
    vipOnError(exclusive_dma_mirror_memory_fill_pages(m_memory->physical_table, m_memory->size_table,
                                                      page_count, pages));
    vipOnError(vipdrv_map_kernel_page(page_count, pages, (void**)&logical, no_cache));
    vipdrv_os_free_memory(pages);

    ptr->kerl_logical = (void*)(logical + offset);
    ptr->mem_flag |= VIPDRV_MEM_FLAG_MAP_KERNEL_LOGICAL;

    PRINTK_I("heap dma map kernel logi address=0x%"PRPx", cpu phy=0x%llx, size=0x%x, page_count=%u\n",
             ptr->kerl_logical, m_memory->physical_table[0], m_memory->size_table[0], page_count);
    return status;
onError:
    PRINTK_E("map kernel logical dma\n");
    return status;
}

static vip_status_e vipdrv_kernel_logical_unmap_exclusive_dma(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;

    vipdrv_unmap_kernel_page(VIPDRV_UINT64_TO_PTR(VIPDRV_PTR_TO_UINT64(ptr->kerl_logical) & PAGE_MASK));

    ptr->kerl_logical = VIP_NULL;
    ptr->mem_flag &= ~VIPDRV_MEM_FLAG_MAP_KERNEL_LOGICAL;

    return status;
}

static vip_status_e vipdrv_user_logical_map_exclusive_dma(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vip_uint32_t page_offset = 0;
    void* user_logical = VIP_NULL;
    struct page** pages = VIP_NULL;
    vip_bool_e no_cache = (VIPDRV_MEM_FLAG_NONE_CACHE & ptr->mem_flag) ? vip_true_e : vip_false_e;
    vip_uint32_t page_count = 0;
    exclusive_dma_mirror_memory_t* m_memory = (exclusive_dma_mirror_memory_t*)ptr->alloc_handle_ext;

    if (VIP_NULL == m_memory) {
        PRINTK_E("alloc handle ext is null user logical\n");
        return VIP_ERROR_FAILURE;
    }

    page_count = m_memory->physical_num;
    vipOnError(vipdrv_os_allocate_memory(sizeof(struct page*) * page_count, (void**)&pages));
    vipdrv_os_zero_memory(pages, sizeof(struct page*) * page_count);
    vipOnError(exclusive_dma_mirror_memory_fill_pages(m_memory->physical_table, m_memory->size_table,
                                                      page_count, pages));
    vipOnError(vipdrv_map_user(page_count, pages, &user_logical, no_cache));
    vipdrv_os_free_memory(pages);

    ptr->user_logical = (void*)((vip_uint8_t*)user_logical + page_offset);
    ptr->mem_flag |= VIPDRV_MEM_FLAG_MAP_USER_LOGICAL;
    ptr->pid = vipdrv_os_get_pid();
    return status;
onError:
    PRINTK_E("map user logical dma\n");
    return status;
}

static vip_status_e vipdrv_user_logical_unmap_exclusive_dma(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vip_uint32_t page_count = 0;

    if (ptr->pid == vipdrv_os_get_pid()) {
        vipdrv_get_page_count(ptr, &page_count);
        vipdrv_unmap_user(page_count,
                          VIPDRV_UINT64_TO_PTR(VIPDRV_PTR_TO_UINT64(ptr->user_logical) & PAGE_MASK));
        ptr->user_logical = VIP_NULL;
        ptr->mem_flag &= ~VIPDRV_MEM_FLAG_MAP_USER_LOGICAL;
        ptr->pid = 0;
    }
    return status;
}

static vip_status_e vipdrv_flush_cache_exclusive_dma(vipdrv_video_mem_phy_handle_t* handle, vip_uint8_t type)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint8_t map_kernel_logic = 0;
    exclusive_dma_mirror_memory_t* m_memory = (exclusive_dma_mirror_memory_t*)handle->alloc_handle_ext;
    void* npu_kerl_logical = VIP_NULL;

    if (VIP_NULL == m_memory) {
        PRINTK_E("alloc handle ext is null flush\n");
        return VIP_ERROR_FAILURE;
    }

    /* Mapping mirror memory kernel logical if need */
    if (VIP_NULL == handle->kerl_logical) {
        vipOnError(vipdrv_kernel_logical_map_exclusive_dma(handle));
        map_kernel_logic = 1;
    }

    /* Mapping npu exclusive memory kernel logical
       Can be move to vipdrv_alloc_heap_exclusive_dma() if don't want to map the kernel logical again and again.
    */
    vipOnError(exclusive_dma_npu_memory_kernel_logical_map(handle, m_memory));

    /* For customer board:
          May used a DMA engine to copy data on mirror memory to NPU memory
       On VSI testing board:
          Used the memcpy to instead of DMA engine.
    */
    npu_kerl_logical = m_memory->npu_kerl_logical;
    if (VIPDRV_CACHE_INVALID == type) {
        /* Copy data from NPU memory to mirror memory */
        vipdrv_os_copy_memory(handle->kerl_logical, npu_kerl_logical, handle->size);
    } else {
        /* Copy data from mirror memory to NPU memory */
        vipdrv_os_copy_memory(npu_kerl_logical, handle->kerl_logical, handle->size);
    }

    if (1 == map_kernel_logic) {
        vipdrv_kernel_logical_unmap_exclusive_dma(handle);
    }

    exclusive_dma_npu_memory_kernel_logical_unmap(m_memory);

    return status;
onError:
    PRINTK_E("sync NPU data between mirror and NPU memory type=%d\n", type);
    return status;
}

static vip_status_e vipdrv_alloc_heap_exclusive_dma(vipdrv_video_mem_phy_handle_t* handle,
                                                    vipdrv_alloc_param_ptr param)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vip_uint32_t page_count = 0;
    u32 gfp = GFP_KERNEL | __GFP_HIGHMEM | __GFP_NOWARN;
    struct page** pages = VIP_NULL;
    struct page* page;
    size_t i = 0;
    exclusive_dma_mirror_memory_t* m_memory = VIP_NULL;

    /*In ARM64,there is no highmem zone*/
#if defined(__aarch64__) || defined(__riscv)
    gfp &= ~__GFP_HIGHMEM;
#endif
    vipOnError(vipdrv_os_allocate_memory(sizeof(exclusive_dma_mirror_memory_t), (void**)&m_memory));
    vipdrv_os_zero_memory(m_memory, sizeof(exclusive_dma_mirror_memory_t));

    /* Alloc mirror memory on host */
    page_count = GetPageCount(PAGE_ALIGN(ptr->size));
    vipOnError(vipdrv_os_allocate_memory(sizeof(vip_physical_t) * page_count,
                                         (void**)&m_memory->physical_table));
    vipdrv_os_zero_memory(m_memory->physical_table, sizeof(vip_physical_t) * page_count);
    vipOnError(vipdrv_os_allocate_memory(sizeof(vip_size_t) * page_count, (void**)&m_memory->size_table));
    vipOnError(vipdrv_os_allocate_memory(sizeof(struct page*) * page_count, (void**)&pages));
    vipdrv_os_zero_memory(pages, sizeof(struct page*) * page_count);

    for (i = 0; i < page_count; i++) {
        vip_physical_t cpu_physical = 0;
        page = alloc_page(gfp);
        if (!page) {
#if DEBUG_ALLOCATOR
            PRINTK("dma alloc mirror page..allocated=%d page, total=%dpage.\n", i, page_count);
#endif
            vipGoOnError(VIP_ERROR_IO);
        }
        pages[i] = page;
        cpu_physical = page_to_phys(page);
        m_memory->physical_table[i] = cpu_physical;
        m_memory->size_table[i] = PAGE_SIZE;
    }

    m_memory->physical_num = page_count;
    m_memory->ptr = ptr;

    if (VIP_NULL != pages) {
        vipdrv_os_free_memory(pages);
        pages = VIP_NULL;
    }
    ptr->flush_handle = VIP_NULL;
    ptr->alloc_handle_ext = (void*)m_memory;

    return status;
onError:
    /* free pages */
    for (i = 0; i < page_count; i++) {
        if ((VIP_NULL != pages) && (pages[i] != VIP_NULL)) {
            __free_page(pages[i]);
        }
        if (m_memory->size_table != VIP_NULL) {
            m_memory->size_table[i] = 0;
        }
        if (m_memory->physical_table != VIP_NULL) {
            m_memory->physical_table[i] = 0;
        }
    }
    m_memory->physical_num = 0;
    m_memory->npu_kerl_logical = VIP_NULL;

    if (VIP_NULL != m_memory->size_table) {
        vipdrv_os_free_memory((void*)m_memory->size_table);
        m_memory->size_table = VIP_NULL;
    }
    if (VIP_NULL != m_memory->physical_table) {
        vipdrv_os_free_memory((void*)m_memory->physical_table);
        m_memory->physical_table = VIP_NULL;
    }
    if (VIP_NULL != pages) {
        vipdrv_os_free_memory(pages);
        pages = VIP_NULL;
    }
    return status;
}

static vip_status_e vipdrv_free_heap_exclusive_dma(vipdrv_video_mem_phy_handle_t* handle)
{
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    exclusive_dma_mirror_memory_t* m_memory = (exclusive_dma_mirror_memory_t*)ptr->alloc_handle_ext;
    vip_uint32_t i = 0;
    unsigned long pfn = 0;
    struct page* page;

    if (VIP_NULL == m_memory) {
        PRINTK_E("alloc handle ext is null free\n");
        return VIP_ERROR_FAILURE;
    }

    m_memory->npu_kerl_logical = VIP_NULL;

    for (i = 0; i < m_memory->physical_num; i++) {
        pfn = __phys_to_pfn(m_memory->physical_table[i]);
        page = pfn_to_page(pfn);
        if (page != VIP_NULL) {
            __free_page(page);
        }
        if (m_memory->size_table != VIP_NULL) {
            m_memory->size_table[i] = 0;
        }
        m_memory->physical_table[i] = 0;
    }
    if (VIP_NULL != m_memory->size_table) {
        vipdrv_os_free_memory((void*)m_memory->size_table);
        m_memory->size_table = VIP_NULL;
    }
    if (VIP_NULL != m_memory->physical_table) {
        vipdrv_os_free_memory((void*)m_memory->physical_table);
        m_memory->physical_table = VIP_NULL;
    }
    if (VIP_NULL != ptr->alloc_handle_ext) {
        vipdrv_os_free_memory((void*)ptr->alloc_handle_ext);
        ptr->alloc_handle_ext = VIP_NULL;
    }

    return VIP_SUCCESS;
}

/*
@brief convert CPU physical to VIP physical.
@param cpu_physical. the physical address of CPU domain.
*/
static vip_physical_t vipdrv_exclusive_dma_phy_cpu2vip(vip_uint32_t device_index, vip_physical_t cpu_physical)
{
    vip_physical_t vip_hysical = cpu_physical;
    return vip_hysical;
}

/*
@brief convert VIP physical to CPU physical.
@param vip_physical. the physical address of VIP domain.
*/
static vip_physical_t vipdrv_exclusive_dma_phy_vip2cpu(vip_uint32_t device_index, vip_physical_t vip_physical)
{
    vip_physical_t cpu_hysical = vip_physical;
    return cpu_hysical;
}

/* heap allocator for NPU exclusive memory,
   the NPU memory can be used a DMA engine to copy data from host mirror memory to NPU memory.
   This memory has not manage by Linux system.
   exclusive memory should be:
       1. Device memory on PCIE card.
*/
vip_status_e allocator_init_heap_exclusive_dma(vipdrv_allocator_t* allocator, vip_char_t* name,
                                               vipdrv_allocator_type_e type)
{
    if (VIP_NULL == allocator) {
        return VIP_ERROR_INVALID_ARGUMENTS;
    }
    allocator->mem_flag = VIPDRV_MEM_FLAG_CONTIGUOUS | VIPDRV_MEM_FLAG_4GB_ADDR_PA;
    allocator->name = name;
    allocator->alctor_type = type;
    allocator->device_vis = ~(vip_uint64_t)0;
    allocator->callback.allocate = vipdrv_alloc_heap_exclusive_dma;
    allocator->callback.free = vipdrv_free_heap_exclusive_dma;
    allocator->callback.map_kernel_logical = vipdrv_kernel_logical_map_exclusive_dma;
    allocator->callback.unmap_kernel_logical = vipdrv_kernel_logical_unmap_exclusive_dma;
    allocator->callback.map_user_logical = vipdrv_user_logical_map_exclusive_dma;
    allocator->callback.unmap_user_logical = vipdrv_user_logical_unmap_exclusive_dma;
    allocator->callback.flush_cache = vipdrv_flush_cache_exclusive_dma;

    /* the phy_vip2cpu and phy_cpu2vip callback will be overwirte in vipdrv_alloc_mgt_heap_init() function
       if set heap_infos.ops.phy_cpu2vip/phy_vip2cpu in vipdrv_drv_get_memory_config().
    */
    allocator->callback.phy_vip2cpu = vipdrv_exclusive_dma_phy_vip2cpu;
    allocator->callback.phy_cpu2vip = vipdrv_exclusive_dma_phy_cpu2vip;

    return VIP_SUCCESS;
}
#endif
