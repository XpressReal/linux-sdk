/******************************************************************************\
|* Copyright (c) 2017 - 2026 by Vivante Corporation.  All Rights Reserved.      *|
|*                                                                            *|
|* The material in this file is confidential and contains trade secrets of    *|
|* of Vivante Corporation.  This is proprietary information owned by Vivante  *|
|* Corporation.  No part of this work may be disclosed, reproduced, copied,   *|
|* transmitted, or used in any way for any purpose, without the express       *|
|* written permission of Vivante Corporation.                                 *|
|*                                                                            *|
\******************************************************************************/
#include "FreeRTOS.h"
/* Calls the porting APIs of vip-hal
 * This file needs to be at the front, don't modify this order */
#include "vip_hal.h"
#include "semphr.h"
#include "timers.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "vip_drv_os_port.h"
#include "vip_drv_interface.h"
#include "vip_drv_vipcore_driver.h"
#include "vip_drv_vipcore_vendor.h"
#include "vip_drv_mem_heap.h"
#include "vip_drv_hardware.h"
#include "vip_drv_context.h"

#define DEFAULT_AI_TASK_NAME      "NPU-TASK"
#define DEFAULT_AI_TASK_STACK_SZ  2048
#define DEFAULT_AI_TASK_PRIO      5 /*(configMAX_PRIORITIES <96> 1)*/
#define NPU_FREERTOS_WAIT_FOREVER 0xFFFFFFFF

#if vpmdPOWER_OFF_TIMEOUT
static vip_uint32_t timer_index = 0;
#endif

#if FreeRTOS_POSIX
static vip_status_e millsecs_to_timespec(struct timespec* ts, long msecs)
{
    long add = 0, secs = 0;

    clock_gettime(CLOCK_REALTIME, ts);
    secs = msecs / 1000;
    msecs = msecs % 1000;
    msecs = msecs * 1000 * 1000 + ts->tv_nsec;
    add = msecs / (1000 * 1000 * 1000);
    ts->tv_sec += (add + secs);
    ts->tv_nsec = msecs % (1000 * 1000 * 1000);

    return VIP_SUCCESS;
}
#endif
/*
@brief Do some initialization works in VIPDRV_OS layer.
@param video_mem_size, the size of video memory heap.
*/
vip_status_e vipdrv_os_init(IN vip_uint32_t video_mem_size)
{
    vip_status_e status = VIP_SUCCESS;

    status = vipdrv_drv_init(video_mem_size);
    if (status != VIP_SUCCESS) {
        PRINTK_E("drv init\n");
    }

#if FreeRTOS_POSIX
    PRINTK_F("Used freeRTOS POSIX API\n");
#endif

#if vpmdPOWER_OFF_TIMEOUT
    timer_index = 0;
#endif
    return status;
}

/*
@brief Do some un-initialization works in VIPDRV_OS layer.
*/
vip_status_e vipdrv_os_close(void)
{
    vip_status_e status = VIP_SUCCESS;

    status = vipdrv_drv_exit();
    if (status != VIP_SUCCESS) {
        PRINTK_E("drv exit\n");
    }

    return status;
}

/*******************************NOTICE***********************************/
/************************************************************************/
/* *********************need to be ported functions**********************/
/************************************************************************/
/************************************************************************/
/************************************************************************/
/*
@brief Allocate system memory in vip drv space.
@param video_mem_size, the size of video memory heap.
@param size, Memory size to be allocated.
@param memory, Pointer to a variable that will hold the pointer to the memory.
*/
vip_status_e vipdrv_os_allocate_memory(IN vip_size_t size, OUT void** memory)
{
    vip_status_e status = VIP_SUCCESS;

    if (size == 0 || !memory) {
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    status = viphal_allocate_memory(size, memory);
    if (status != VIP_SUCCESS) {
        PRINTK_E("vipdrv alloc memory\n");
    }

    return status;
}

/*
@brief Free system memory in vip drv space.
@param memory, Memory to be freed.
*/
vip_status_e vipdrv_os_free_memory(IN void* memory)
{
    vip_status_e status = VIP_SUCCESS;

    if (!memory) {
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    viphal_free_memory(memory);

    return status;
}

/*
@brief Set memory to zero.
@param memory, Memory to be set to zero.
@param size, the size of memory.
*/
vip_status_e vipdrv_os_zero_memory(IN void* memory, IN vip_size_t size)
{
    viphal_zero_memory(memory, size);

    return VIP_SUCCESS;
}

/*
@brief copy src memory to dst memory.
@param dst, Destination memory.
@param src. Source memory
@param size, the size of memory should be copy.
*/
vip_status_e vipdrv_os_copy_memory(IN void* dst, IN const void* src, IN vip_size_t size)
{
    viphal_copy_memory(dst, src, size);

    return VIP_SUCCESS;
}

#if vpmdENABLE_AHB_LOG
static vip_status_e vipdrv_drv_get_hardware_index(IN volatile void* reg_base, OUT vip_uint32_t* dev,
                                                  OUT vip_uint32_t* core)
{
    vipdrv_hardware_info_t info = {0};
    vip_uint32_t i = 0, j = 0;
    vipdrv_drv_get_hardware_info(&info);
    for (i = 0; i < info.device_count; i++) {
        for (j = 0; j < info.device_info[i].core_count; j++) {
            if (reg_base == info.device_info[i].vip_reg[j]) {
                *dev = i;
                *core = j;
                return VIP_SUCCESS;
            }
        }
    }

    return VIP_SUCCESS;
}
#endif

/*
@brief Read a hardware register.
@param reg_base, the base address of hardware register.
@param address, read the register address.
@param data, the data of address be read.
*/
vip_status_e vipdrv_os_read_reg(IN volatile void* reg_base, IN vip_uint32_t address, OUT vip_uint32_t* data)
{
    vip_uint32_t* reg = (vip_uint32_t*)((vip_uint8_t*)reg_base + address);
    *data = *reg;

#if vpmdENABLE_AHB_LOG
    {
        vip_uint32_t dev = 0, core = 0;
        vipdrv_drv_get_hardware_index(reg_base, &dev, &core);
        PRINTK("@[register.read %u %u 0x%05X 0x%08X]\n", dev, core, address, *data);
    }
#endif

    return VIP_SUCCESS;
}

/*
@brief Write a hardware register.
@param reg_base, the base address of hardware register.
@param address, write the register address.
@param data, the data of address be wrote.
*/
vip_status_e vipdrv_os_write_reg(IN volatile void* reg_base, IN vip_uint32_t address, IN vip_uint32_t data)
{
    vip_uint32_t* reg = (vip_uint32_t*)((vip_uint8_t*)reg_base + address);
    *reg = data;

#if vpmdENABLE_AHB_LOG
    {
        vip_uint32_t dev = 0, core = 0;
        vipdrv_drv_get_hardware_index(reg_base, &dev, &core);
        PRINTK("@[register.write %u %u 0x%05X 0x%08X]\n", dev, core, address, data);
    }
#endif

    return VIP_SUCCESS;
}

/*
@brief Waiting for the hardware interrupt. wait interrupt function depend on the type of RTOS
@param irq_queue, the wait queue of interrupt handle.
@param irq_value, a flag for interrupt.
@param time_out, the timeout value of this wait. ms.
@param mask, mask data for interrupt.
*/
vip_status_e vipdrv_os_wait_interrupt(IN void* irq_queue, IN volatile vip_uint32_t* volatile irq_value,
                                      IN vip_uint32_t time_out, IN vip_uint32_t mask)
{
    vip_status_e status = VIP_SUCCESS;
    vipIsNULL(irq_value);

    if ((mask & *irq_value) == 0) {
        SemaphoreHandle_t* irq_queue_handle = (SemaphoreHandle_t*)irq_queue;
        if (xSemaphoreTake(*irq_queue_handle, pdMS_TO_TICKS(time_out)) != pdTRUE) {
            return VIP_ERROR_TIMEOUT;
        }
    } else {
        PRINTK_I("not wait, may interrupt is returned, irq_value=0x%x\n", *irq_value);
    }

onError:
    return status;
}

vip_status_e vipdrv_os_wakeup_interrupt(IN void* irq_queue)
{
    vip_status_e status = VIP_SUCCESS;
    portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
    SemaphoreHandle_t* irq_queue_handle = (SemaphoreHandle_t*)irq_queue;
    xSemaphoreGiveFromISR(*irq_queue_handle, &xHigherPriorityTaskWoken);
    return status;
}

/*
@brief Delay execution of the current thread for a number of milliseconds.
@param ms, delay unit ms. Delay to sleep, specified in milliseconds.
*/
void vipdrv_os_delay(IN vip_uint32_t ms)
{
    if (ms > 0) {
#if FreeRTOS_POSIX
        usleep(1000 * ms);
#else
        vTaskDelay(pdMS_TO_TICKS(ms));
#endif
    }
}

/*
@brief Delay execution of the current thread for a number of microseconds.
@param ms, delay unit us. Delay to sleep, specified in microseconds.
*/
void vipdrv_os_udelay(IN vip_uint32_t us)
{
#if FreeRTOS_POSIX
    usleep(us);
#else
    vip_uint32_t ms = us / 1000 + 1;
    /* please replace vTaskDelay to delay us */
    vTaskDelay(pdMS_TO_TICKS(ms));
#endif
}

/*
@brief Print string on console.
@param msg, which message to be print.
*/
vip_status_e vipdrv_os_print(vip_log_level level, IN const char* message, ...)
{
    vip_status_e status = VIP_SUCCESS;

    status = viphal_os_print(level, message);

    return status;
}

/*
@brief Print string to buffer.
@param, size, the size of msg.
@param msg, which message to be print.
*/
vip_status_e vipdrv_os_snprint(IN vip_char_t* buffer, IN vip_uint32_t size, IN const vip_char_t* msg, ...)
{
    vip_status_e status = VIP_SUCCESS;

    status = viphal_os_snprint(buffer, size, msg);

    return status;
}

/*
@brief get the current system time.
*/
vip_uint64_t vipdrv_os_get_time(void)
{
    return viphal_os_get_time();
}

/*
@brief Get process id
*/
vip_uint32_t vipdrv_os_get_pid(void)
{
    return viphal_os_get_pid();
}

/*
@brief Get thread id
*/
vip_uint32_t vipdrv_os_get_tid(void)
{
    return viphal_os_get_tid();
}

/*
@brief Memory barrier function for memory consistency.
*/
vip_status_e vipdrv_os_memorybarrier(void)
{
    /* please make sure the memory barrier ASM can work well on you platform */

    __asm__ volatile("" ::: "memory");

    return VIP_SUCCESS;
}

#if vpmdENABLE_FLUSH_CPU_CACHE
/*
@brief Flush CPU cache for video memory which allocated from heap.
@param physical, the CPU physical address.
@param logical, the CPU logical address.
       loggical address only for Linux system or CPU MMU is enabled?.
       should be equal to physical address in RTOS?
@param size, the size of the memory should be flush.
@param type The type of operate cache. see vipdrv_cache_type_e.
*/
vip_status_e vipdrv_os_flush_cache(IN vip_physical_t physical, IN void* logical, IN vip_uint32_t size,
                                   IN vip_uint8_t type)
{
    vip_status_e status = VIP_SUCCESS;

    PRINTK_D("flush cache physical=0x%08X, size=0x%08X, type=%d\n", physical, size, type);
    if ((0 == physical) && (VIP_NULL == logical)) {
        PRINTK_E("flush cache physical=0x%x, logical=%p\n", physical, logical);
        return VIP_ERROR_FAILURE;
    }

    status = vipdrv_vendor_flush_cache(physical, logical, size, type);

    return status;
}
#endif

/*
@brief Create a mutex for multiple thread.
@param mutex, create mutex pointer.
*/
vip_status_e vipdrv_os_create_mutex(OUT vipdrv_mutex* mutex)
{
    return viphal_os_create_mutex(mutex);
}

vip_status_e vipdrv_os_lock_mutex(IN vipdrv_mutex mutex)
{
    return viphal_os_lock_mutex(mutex);
}

vip_status_e vipdrv_os_unlock_mutex(IN vipdrv_mutex mutex)
{
    return viphal_os_unlock_mutex(mutex);
}

/*
@brief Destroy a mutex which create in vipdrv_os_create_mutex..
@param mutex, create mutex pointer.
*/
vip_status_e vipdrv_os_destroy_mutex(IN vipdrv_mutex mutex)
{
    return viphal_os_destroy_mutex(mutex);
}

#if vpmdENABLE_MULTIPLE_TASK || vpmdPOWER_OFF_TIMEOUT
/*
@brief Create a thread.
@param func, the thread handle function.
@param parm, parameter for this thread.
@param name, the thread name.
@param handle, the handle for thread.
*/
vip_status_e vipdrv_os_create_thread(IN vipdrv_thread_func func, IN vip_ptr parm, IN vip_char_t* name,
                                     OUT vipdrv_thread* handle)
{
#if FreeRTOS_POSIX
    vip_int32_t error;
    if ((handle != VIP_NULL) && (func != VIP_NULL)) {
        error = pthread_create((pthread_t*)handle, VIP_NULL, (void*)func, parm);
        if (error != 0) {
            PRINTK("create thread\n");
            return VIP_ERROR_IO;
        }
    } else {
        PRINTK("create thread %s. parameter is NULL\n", name);
        *handle = VIP_NULL;
        return VIP_ERROR_INVALID_ARGUMENTS;
    }
    return VIP_SUCCESS;
#else
    if (pdTRUE == xTaskCreate((TaskFunction_t)func, DEFAULT_AI_TASK_NAME, DEFAULT_AI_TASK_STACK_SZ, parm,
                              DEFAULT_AI_TASK_PRIO, *handle)) {
        return VIP_SUCCESS;
    } else {
        PRINTK_E("create npu thread %s\n", name);
        return VIP_ERROR_FAILURE;
    }
#endif
}

vip_status_e vipdrv_os_destroy_thread(IN vipdrv_thread handle)
{
#if FreeRTOS_POSIX
    if (handle != VIP_NULL) {
        pthread_exit((void*)handle);
    } else {
        PRINTK("destroy thread");
        return VIP_ERROR_IO;
    }
#else
    if (handle != VIP_NULL) {
        vTaskDelete(handle);
    }
#endif
    return VIP_SUCCESS;
}
#endif

/*
@brief Create a atomic.
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_create_atomic(OUT vipdrv_atomic* atomic)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t* c_atomic = VIP_NULL;
    vipIsNULL(atomic);

    /* please add atomic implement in here if system supports atomic
        otherwise use below function to instead atmoic */

    status = vipdrv_os_allocate_memory(sizeof(vip_uint32_t), (void**)&c_atomic);
    if (status != VIP_SUCCESS) {
        PRINTK_E("allocate memory for atomic\n");
        return VIP_ERROR_IO;
    }

    *c_atomic = 0;
    *atomic = (vip_ptr)c_atomic;

onError:
    return status;
}

/*
@brief Destroy a atomic which create in vipdrv_os_create_atomic
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_destroy_atomic(IN vipdrv_atomic atomic)
{
    vip_status_e status = VIP_SUCCESS;
    vipIsNULL(atomic);

    vipdrv_os_free_memory(atomic);

onError:
    return status;
}

/*
@brief Set the 32-bit value protected by an atomic.
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_set_atomic(IN vipdrv_atomic atomic, IN vip_uint32_t value)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t* data = (vip_uint32_t*)atomic;
    vipIsNULL(atomic);

    *data = value;

onError:
    return status;
}

/*
@brief Get the 32-bit value protected by an atomic.
@param atomic, create atomic pointer.
*/
vip_uint32_t vipdrv_os_get_atomic(IN vipdrv_atomic atomic)
{
    vip_uint32_t value = 0xFFFFFFFE;
    vip_uint32_t* data = (vip_uint32_t*)atomic;
    if (VIP_NULL == atomic) {
        PRINTK_E("get atomic invalid arguments\n");
        return (VIP_ERROR_INVALID_ARGUMENTS);
    }

    value = *data;

    return value;
}

/*
@brief Increase the 32-bit value protected by an atomic.
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_inc_atomic(IN vipdrv_atomic atomic)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t* data = (vip_uint32_t*)atomic;
    vipIsNULL(atomic);

    *data += 1;

onError:
    return status;
}

/*
@brief Decrease the 32-bit value protected by an atomic.
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_dec_atomic(IN vipdrv_atomic atomic)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t* data = (vip_uint32_t*)atomic;
    vipIsNULL(atomic);

    *data -= 1;

onError:
    return status;
}

#if vpmdENABLE_MULTIPLE_TASK || vpmdENABLE_SUSPEND_RESUME || vpmdPOWER_OFF_TIMEOUT
#if FreeRTOS_POSIX
typedef struct _vipdrv_signal_t {
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    volatile vip_bool_e value;
} vipdrv_signal_t;
#else
typedef struct _vipdrv_signal_data {
    void* wait_signal;
    vipdrv_mutex lock;
    volatile vip_bool_e value;
} vipdrv_signal_data_t;
#endif

/*
@brief Create a signal.
@param handle, the handle for signal.
*/
vip_status_e vipdrv_os_create_signal(IN vipdrv_signal* handle)
{
#if FreeRTOS_POSIX
    vip_status_e status = VIP_SUCCESS;
    vipdrv_signal_t* sg = VIP_NULL;
    int error;

    if (handle == VIP_NULL) {
        vip_error("create signal, param is NULL\n");
        return VIP_ERROR_FAILURE;
    }

    /* Allocate the signal. */
    vipOnError(vipdrv_os_allocate_memory(sizeof(vipdrv_signal_t), (vip_ptr*)&sg));

    /* Copy the manual reset flag. */
    sg->value = vip_false_e;

    /* Initialize the mutex. */
    error = pthread_mutex_init(&sg->mutex, VIP_NULL);
    if (error != 0) {
        vip_error("init mutex for signal.\n");
        vipOnError(VIP_ERROR_FAILURE);
    }

    /* Initialize the condition. */
    error = pthread_cond_init(&sg->cond, VIP_NULL);
    if (error != 0) {
        vip_error("init cond for signal.\n");
        vipOnError(VIP_ERROR_FAILURE);
    }

    /* Return the signal. */
    *handle = (vipdrv_signal_t*)sg;
    return status;

onError:
    if (sg != VIP_NULL) {
        /* Destroy te mutex. */
        pthread_mutex_destroy(&sg->mutex);
        /* Destroy the condition. */
        pthread_cond_destroy(&sg->cond);
    }
    return status;
#else
    vip_status_e status = VIP_SUCCESS;
    vipdrv_signal_data_t* data = VIP_NULL;

    if (handle == VIP_NULL) {
        PRINTK_E("create signal, parameter is NULL\n");
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    vipOnError(vipdrv_os_allocate_memory(sizeof(vipdrv_signal_data_t), (vip_ptr*)&data));

    data->wait_signal = (void*)xSemaphoreCreateBinary();

    data->value = vip_false_e;

    /* init lock */
    vipdrv_os_create_mutex(&data->lock);

    *handle = (vipdrv_signal)data;

    return status;

onError:
    if (data != VIP_NULL) {
        vipdrv_os_free_memory(data);
    }
    return status;
#endif
}

vip_status_e vipdrv_os_destroy_signal(IN vipdrv_signal handle)
{
#if FreeRTOS_POSIX
    vip_status_e status = VIP_SUCCESS;
    int error;
    vipdrv_signal_t* sg = (vipdrv_signal_t*)handle;

    /* Destroy the mutex. */
    error = pthread_mutex_destroy(&sg->mutex);
    if (error != 0) {
        vip_error("destory mutex for signal.\n");
        vipOnError(VIP_ERROR_FAILURE);
    }

    /* Destroy the condition. */
    error = pthread_cond_destroy(&sg->cond);
    if (error != 0) {
        vip_error("destory cond for signal.\n");
        vipOnError(VIP_ERROR_FAILURE);
    }

    vipdrv_os_free_memory(handle);

    return status;

onError:
    return status;
#else
    vip_status_e status = VIP_SUCCESS;
    vipdrv_signal_data_t* data = (vipdrv_signal_data_t*)handle;

    if (data == VIP_NULL) {
        PRINTK_E("destory signal, parameter is NULL\n");
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    data->value = vip_false_e;
    vSemaphoreDelete((QueueHandle_t)data->wait_signal);
    if (data->lock != VIP_NULL) {
        vipdrv_os_destroy_mutex(data->lock);
    }
    vipdrv_os_free_memory(handle);

onError:
    return status;
#endif
}

/*
@brief Waiting for a signal.
@param handle, the handle for signal.
@param timeout, the timeout of waiting signal. unit ms. timeout is 0 or VIP_INFINITE, infinite wait signal.
*/
vip_status_e vipdrv_os_wait_signal(IN vipdrv_signal handle, IN vip_uint32_t timeout)
{
#if FreeRTOS_POSIX
    vip_status_e status = VIP_SUCCESS;
    int error;
    /* we use wait signal without timeout,
    you can try wait signal with tineout on your platfrom */
    timeout = 0;
    vipdrv_signal_t* sg = (vipdrv_signal_t*)handle;
    if (sg == VIP_NULL) {
        vip_error(" wait signal, parameter is NULL\n");
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    /* Lock the mutex. */
    error = pthread_mutex_lock(&sg->mutex);
    if (error != 0) {
        vip_error("lock mutex for signal.\n");
        vipOnError(VIP_ERROR_FAILURE);
    }

    if (sg->value) {
        /* Success. */
        status = VIP_SUCCESS;
    } else if (timeout == 0) {
        /* Wait for the condition. */
        error = pthread_cond_wait(&sg->cond, &sg->mutex);
        if (error != 0) {
            vip_error("wait cond for signal.\n");
            vipOnError(VIP_ERROR_FAILURE);
        }
    } else {
        struct timespec ts = {0};
        millsecs_to_timespec(&ts, timeout);
        /* Wait for the condition. */
        error = pthread_cond_timedwait(&sg->cond, &sg->mutex, &ts);
        if (error != 0) {
            vip_error("wait cond for signal.\n");
            vipOnError(VIP_ERROR_FAILURE);
        }
    }

    /* Unlock the mutex. */
    error = pthread_mutex_unlock(&sg->mutex);
    if (error != 0) {
        vip_error("unlock for signal.\n");
        vipOnError(VIP_ERROR_FAILURE);
    }

    return status;

onError:
    /* Unlock the mutex. */
    pthread_mutex_unlock(&sg->mutex);
    return status;
#else
    vip_status_e status = VIP_SUCCESS;
    vipdrv_signal_data_t* data = (vipdrv_signal_data_t*)handle;
    vip_int32_t ret = 0;

    vipdrv_os_lock_mutex(data->lock);
    if (!data->value) {
        /* Wait for the condition. */
        vipdrv_os_unlock_mutex(data->lock);

        if (VIP_INFINITE == timeout) {
            while (1) {
                ret = xSemaphoreTake((QueueHandle_t)data->wait_signal, portMAX_DELAY);
                if (pdFALSE == ret) {
                    continue;
                }
                break;
            }
        } else {
            ret = xSemaphoreTake((QueueHandle_t)data->wait_signal, pdMS_TO_TICKS(timeout));
            if (pdFALSE == ret) {
                PRINTK_I("wait signal handle=0x%"PRPx", timeout=%dms\n", handle, timeout);
                status = VIP_ERROR_TIMEOUT;
            }
        }
    } else {
        vipdrv_os_unlock_mutex(data->lock);
    }

    return status;
#endif
}

/*
@brief wake up wait signal.
     state is true, wake up all waiting signal and chane the signal state to SET.
     state is false, change the signal to RESET so the vipdrv_os_wait_signal will block until
     the signal state changed to SET. block waiting signal function.
@param handle, the handle for signal.
*/
vip_status_e vipdrv_os_set_signal(IN vipdrv_signal handle, IN vip_bool_e state)
{
#if FreeRTOS_POSIX
    vip_status_e status = VIP_SUCCESS;
    vip_bool_e locked = vip_false_e;
    int error;

    vipdrv_signal_t* sg = (vipdrv_signal_t*)handle;
    if (sg == VIP_NULL) {
        vip_error("wait signal, parameter is NULL\n");
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    /* Lock the mutex. */
    error = pthread_mutex_lock(&sg->mutex);
    if (error != 0) {
        vip_error("lock for signal.\n");
        vipOnError(VIP_ERROR_FAILURE);
    }
    locked = vip_true_e;

    sg->value = state;
    if (state) {
        /* Unlock the semaphore. */
        error = pthread_cond_signal(&sg->cond);
        if (error != 0) {
            vip_error("lock for signal.\n");
            vipOnError(VIP_ERROR_FAILURE);
        }
    }
    /* Unlock the mutex. */
    error = pthread_mutex_unlock(&sg->mutex);
    if (error != 0) {
        vip_error("unlock for signal.\n");
        vipOnError(VIP_ERROR_FAILURE);
    }
    locked = vip_false_e;

    return status;

onError:
    if (locked) {
        /* Unlock the mutex. */
        pthread_mutex_unlock(&sg->mutex);
    }
    return status;
#else
    vip_status_e status = VIP_SUCCESS;
    vipdrv_signal_data_t* data = (vipdrv_signal_data_t*)handle;

    if (data == VIP_NULL) {
        PRINTK_E("set signal, parameter is NULL\n");
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    vipdrv_os_lock_mutex(data->lock);
    if (vip_true_e == state) {
        data->value = vip_true_e;
        xSemaphoreGive((QueueHandle_t)data->wait_signal);
    } else {
        data->value = vip_false_e;
    }
    vipdrv_os_unlock_mutex(data->lock);

onError:
    return status;
#endif
}
#endif

#if vpmdPOWER_OFF_TIMEOUT
typedef struct _vipdrv_timer {
#if FreeRTOS_POSIX
    timer_t timer_id;
    vip_uint32_t time_out; /* ms */
#else
    /* The handle of xTimer */
    TimerHandle_t timer;
#endif
    vipdrv_timer_func callback;
    vip_ptr callback_params;
} vipdrv_timer_t;

#define MAX_TIMER_NUM 20

static vipdrv_timer_t timer_wrapper[MAX_TIMER_NUM];

static vipdrv_timer_t* get_timer_warpper(vip_uint32_t index)
{
    return &timer_wrapper[index];
}

#if FreeRTOS_POSIX
static void TimerCallbackPOSIX(union sigval time_idx)
{
    vipdrv_timer_t* timer = VIP_NULL;

    timer = get_timer_warpper(time_idx.sival_int);

    PRINTK_I("npu freertos posix timer idx = %u callback is running...\n", time_idx.sival_int);

    timer->callback(timer->callback_params);
}
#else
static void TimerCallback(TimerHandle_t pxTimer)
{
    vip_uint32_t timer_id;
    vipdrv_timer_t* timer = VIP_NULL;

    configASSERT(pxTimer);

    timer_id = *(vip_uint32_t*)pvTimerGetTimerID(pxTimer);

    timer = get_timer_warpper(timer_id);

    PRINTK_I("npu freertos timer id = %u callback is running...\n", timer_id);

    timer->callback(timer->callback_params);
}
#endif

/*
@brief create a system timer callback.
@param func, the callback function of this timer.
@param callback_param, theparamete of the timer callback function.
@pram time_out, time out value of this timer, milliseconds(ms).
@pram timers, the handle of time
*/
vip_status_e vipdrv_os_create_timer(IN vipdrv_timer_func callback, IN vip_ptr callback_param,
                                    IN vip_uint32_t time_out, OUT vipdrv_timer* timers)
{
    vipdrv_timer_t* timer = VIP_NULL;

    if (MAX_TIMER_NUM < timer_index) {
        PRINTK_E("create timer cnt=%d more than max cnt=%d\n", timer_index, MAX_TIMER_NUM);
        return VIP_ERROR_FAILURE;
    }

    timer = get_timer_warpper(timer_index);
    timer->callback = callback;
    timer->callback_params = callback_param;

#if FreeRTOS_POSIX
    {
        timer_t timer_id = NULL;
        int ret = 0;
        struct sigevent evp;
        vipdrv_os_zero_memory(&evp, sizeof(evp));
        evp.sigev_notify = SIGEV_THREAD;
        evp.sigev_value.sival_int = timer_index;
        evp.sigev_notify_function = TimerCallbackPOSIX;
        evp.sigev_notify_attributes = NULL;
        ret = timer_create(CLOCK_REALTIME, &evp, &timer_id);
        if (ret < 0) {
            PRINTK_E("timer create ret=%d\n", ret);
            return VIP_ERROR_FAILURE;
        }
        timer->timer_id = timer_id;
    }
#else
    {
        TimerHandle_t oneshot_timer = VIP_NULL;
        vip_bool_e uxAutoReload = pdFALSE;
        vip_uint32_t pvTimerID = timer_index;
        const vip_char_t* pcTimerName = "npu_timer";
        TickType_t xTimerPeriodInTicks = pdMS_TO_TICKS(time_out);
        oneshot_timer = xTimerCreate(pcTimerName, xTimerPeriodInTicks, uxAutoReload, (void*)&pvTimerID,
                                     TimerCallback);
        timer->timer = oneshot_timer;
        if (timer->timer == VIP_NULL) {
            PRINTK_E("create timer fail\n");
            return VIP_ERROR_FAILURE;
        }
    }
#endif

    *timers = (void*)timer;
    timer_index++;

    return VIP_SUCCESS;
}

vip_status_e vipdrv_os_start_timer(IN vipdrv_timer timers)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_timer_t* timer = timers;
    vipIsNULL(timer);

#if FreeRTOS_POSIX
    int ret = 0;
    struct itimerspec ts;
    ts.it_interval.tv_sec = 0;
    ts.it_interval.tv_nsec = 0;
    ts.it_value.tv_sec = timer->time_out / 1000;                  /* second */
    ts.it_value.tv_nsec = (timer->time_out % 1000) * 1000 * 1000; /* ns */
    /* Used the relative timeout. */
    ret = timer_settime(timer->timer_id, 0, &ts, NULL);
    if (ret < 0) {
        vipGoOnError(VIP_ERROR_FAILURE);
    }
#else
    xTimerStart(timer->timer, 0);
#endif

    return status;
onError:
    PRINTK_E("start timer\n");
    return status;
}

vip_status_e vipdrv_os_stop_timer(IN vipdrv_timer timers)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_timer_t* timer = timers;
    vipIsNULL(timer);

#if FreeRTOS_POSIX
    int ret = 0;
    struct itimerspec ts;
    ts.it_interval.tv_sec = 0;
    ts.it_interval.tv_nsec = 0;
    ts.it_value.tv_sec = 0;
    ts.it_value.tv_nsec = 0;
    ret = timer_settime(timer->timer_id, 0, &ts, NULL);
    if (ret < 0) {
        vipGoOnError(VIP_ERROR_FAILURE);
    }
#else
    xTimerStop(timer->timer, 0);
#endif
    return status;
onError:
    PRINTK_E("stop timer\n");
    return status;
}

/*
@brief destroy a system timer
*/
vip_status_e vipdrv_os_destroy_timer(IN vipdrv_timer timers)
{
    vipdrv_timer_t* timer = timers;

#if FreeRTOS_POSIX
    timer_delete(timer->timer_id);
#else
    xTimerDelete(timer->timer, 0);
#endif
    return VIP_SUCCESS;
}
#endif

vip_int32_t vipdrv_os_strcmp(const vip_char_t* s1, const vip_char_t* s2)
{
    return viphal_os_strcmp(s1, s2);
}
