/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2014 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/
#include <sched.h>
#include <nuttx/semaphore.h>
#include <nuttx/mqueue.h>
#include <nuttx/timers/timer.h>
#include <nuttx/cache.h>
#include <nuttx/irq.h>
#include <nuttx/arch.h>
#include "vip_lite_config.h"
#include "vip_drv_vipcore_vendor.h"

vip_status_e vipdrv_vendor_init(void)
{
    vip_status_e status = VIP_SUCCESS;
    /* you can do something on your platfrom */

    up_disable_dcache();

    return status;
}

vip_status_e vipdrv_vendor_unint(void)
{
    vip_status_e status = VIP_SUCCESS;
    /* do nothing, you can do something on your platfrom */

    up_enable_dcache();

    return status;
}

/*
@brief NPU HW reset and power on
@param core_id, the index of core of this NPU device.
*/
vip_status_e vipdrv_vendor_power_on(vip_uint32_t core_id)
{
    vip_status_e status = VIP_SUCCESS;

    /* HW reset NPU */

    /* Supply power and clock for NPU  */

    return status;
}

/*
@brief power off NPU
@param core_id, the index of core of this NPU device.
*/
vip_status_e vipdrv_vendor_power_off(vip_uint32_t core_id)
{
    vip_status_e status = VIP_SUCCESS;

    /* powe down NPU  */

    return status;
}

/*
@brief register NPU irq to freeRTOS
*/
vip_status_e vipdrv_vendor_register_irq(vip_uint32_t irq_line, void* handler, void* handler_params)
{
    vip_status_e status = VIP_SUCCESS;
    vip_int32_t ret;

    if (handler == VIP_NULL) {
        PRINTK_E("invalid params for register irq\n");
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    ret = irq_attach(irq_line, (xcpt_t)handler, handler_params);
    if (ret == OK) {
        up_enable_irq(irq_line);
    } else {
        PRINTK_E("Fail register intr\n");
        status = VIP_ERROR_FAILURE;
    }

    return status;
}

vip_status_e vipdrv_vendor_unregister_irq(vip_uint32_t irq_line)
{
    vip_status_e status = VIP_SUCCESS;

    up_disable_irq(irq_line);
    irq_detach(irq_line);

    return status;
}

/*
@brief fluch CPU cache for video memory
*/
#if vpmdENABLE_FLUSH_CPU_CACHE
vip_status_e vipdrv_vendor_flush_cache(IN vip_physical_t physical, IN void* logical, IN vip_uint32_t size,
                                       IN vip_uint8_t type)
{
    vip_status_e status = VIP_SUCCESS;
    char *end = (char *)logical + size;

    if (logical == VIP_NULL) {
        PRINTK_E("invalid params flush cache\n");
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    switch (type) {
    case VIPDRV_CACHE_CLEAN:
    case VIPDRV_CACHE_FLUSH:
        up_flush_dcache((uintptr_t)logical, (uintptr_t)end);
        break;
    case VIPDRV_CACHE_INVALID:
        up_invalidate_dcache((uintptr_t)logical, (uintptr_t)end);
        break;
    default:
        PRINTK_E("not support this flush cache type=%d\n", type);
        status = VIP_ERROR_INVALID_ARGUMENTS;
        break;
    }

    logical = logical;

    return status;
}
#endif
