/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2014 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#ifndef __VIP_DRV_VIPCORE_VENDOR_H__
#define __VIP_DRV_VIPCORE_VENDOR_H__

#include <vip_lite_config.h>
#include <vip_drv_os_port.h>

vip_status_e vipdrv_vendor_init(void);

vip_status_e vipdrv_vendor_unint(void);
/*
@brief NPU HW reset and power on
@param core_id, the index of core of this NPU device.
*/
vip_status_e vipdrv_vendor_power_on(vip_uint32_t core_id);

/*
@brief power off NPU
@param core_id, the index of core of this NPU device.
*/
vip_status_e vipdrv_vendor_power_off(vip_uint32_t core_id);

/*
@brief register NPU irq to freeRTOS
*/
vip_status_e vipdrv_vendor_register_irq(vip_uint32_t irq_line, void* handler, void* handler_params);

vip_status_e vipdrv_vendor_unregister_irq(vip_uint32_t irq_line);

/*
@brief fluch CPU cache for video memory
*/
#if vpmdENABLE_FLUSH_CPU_CACHE
vip_status_e vipdrv_vendor_flush_cache(IN vip_physical_t physical, IN void* logical, IN vip_uint32_t size,
                                       IN vip_uint8_t type);
#endif

#endif
