/******************************************************************************\
|* Copyright (c) 2017 - 2026 by Vivante Corporation.  All Rights Reserved.      *|
|*                                                                            *|
|* The material in this file is confidential and contains trade secrets of    *|
|* of Vivante Corporation.  This is proprietary information owned by Vivante  *|
|* Corporation.  No part of this work may be disclosed, reproduced, copied,   *|
|* transmitted, or used in any way for any purpose, without the express       *|
|* written permission of Vivante Corporation.                                 *|
|*                                                                            *|
\******************************************************************************/

#ifndef __VIP_DRV_VIPCORE_VENDOR_H__
#define __VIP_DRV_VIPCORE_VENDOR_H__

#include <vip_lite_config.h>
#include <vip_drv_os_port.h>

vip_status_e vipdrv_vendor_init(void);

vip_status_e vipdrv_vendor_unint(void);
/*
@brief NPU HW reset and power on
@param core_id, the index of core of this NPU device.
*/
vip_status_e vipdrv_vendor_power_on(vip_uint32_t core_id);

/*
@brief power off NPU
@param core_id, the index of core of this NPU device.
*/
vip_status_e vipdrv_vendor_power_off(vip_uint32_t core_id);

/*
@brief register NPU irq to freeRTOS
*/
vip_status_e vipdrv_vendor_register_irq(vip_uint32_t irq_line, void* handler, void* handler_params);

vip_status_e vipdrv_vendor_unregister_irq(vip_uint32_t irq_line);

/*
@brief fluch CPU cache for video memory
*/
#if vpmdENABLE_FLUSH_CPU_CACHE
vip_status_e vipdrv_vendor_flush_cache(IN vip_physical_t physical, IN void* logical, IN vip_uint32_t size,
                                       IN vip_uint8_t type);
#endif

#endif
