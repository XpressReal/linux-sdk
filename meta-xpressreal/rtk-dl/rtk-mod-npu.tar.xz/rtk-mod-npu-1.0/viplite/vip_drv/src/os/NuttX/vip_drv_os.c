/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2014 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/
#include <sched.h>
#include <nuttx/semaphore.h>
#include <nuttx/mqueue.h>
#include <nuttx/timers/timer.h>
#include <pthread.h>
#include <arch/barriers.h>
#include <nuttx/wdog.h>
#include <nuttx/clock.h>
#include <assert.h>
/* Calls the porting APIs of vip-hal
 * This file needs to be at the front, don't modify this order */
#include "vip_hal.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "vip_drv_os_port.h"
#include "vip_drv_interface.h"
#include "vip_drv_vipcore_driver.h"
#include "vip_drv_vipcore_vendor.h"
#include "vip_drv_mem_heap.h"
#include "vip_drv_hardware.h"
#include "vip_drv_context.h"

#define DEFAULT_AI_TASK_NAME      "NPU-TASK"
#define DEFAULT_AI_TASK_STACK_SZ  2048
#define DEFAULT_AI_TASK_PRIO      5 /*(configMAX_PRIORITIES <96> 1)*/
#define NPU_FREERTOS_WAIT_FOREVER 0xFFFFFFFF

#if vpmdPOWER_OFF_TIMEOUT
static vip_uint32_t timer_index = 0;
#endif

/*
@brief Do some initialization works in VIPDRV_OS layer.
@param video_mem_size, the size of video memory heap.
*/
vip_status_e vipdrv_os_init(IN vip_uint32_t video_mem_size)
{
    vip_status_e status = VIP_SUCCESS;

    status = vipdrv_drv_init(video_mem_size);
    if (status != VIP_SUCCESS) {
        PRINTK_E("drv init\n");
    }

#if vpmdPOWER_OFF_TIMEOUT
    timer_index = 0;
#endif
    return status;
}

/*
@brief Do some un-initialization works in VIPDRV_OS layer.
*/
vip_status_e vipdrv_os_close(void)
{
    vip_status_e status = VIP_SUCCESS;

    status = vipdrv_drv_exit();
    if (status != VIP_SUCCESS) {
        PRINTK_E("drv exit\n");
    }

    return status;
}

/*******************************NOTICE***********************************/
/************************************************************************/
/* *********************need to be ported functions**********************/
/************************************************************************/
/************************************************************************/
/************************************************************************/
/*
@brief Allocate system memory in vip drv space.
@param video_mem_size, the size of video memory heap.
@param size, Memory size to be allocated.
@param memory, Pointer to a variable that will hold the pointer to the memory.
*/
vip_status_e vipdrv_os_allocate_memory(IN vip_size_t size, OUT void** memory)
{
    vip_status_e status = VIP_SUCCESS;

    if (size == 0 || !memory) {
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    status = viphal_allocate_memory(size, memory);
    if (status != VIP_SUCCESS) {
        PRINTK_E("vipdrv alloc memory\n");
    }

    return status;
}

/*
@brief Free system memory in vip drv space.
@param memory, Memory to be freed.
*/
vip_status_e vipdrv_os_free_memory(IN void* memory)
{
    vip_status_e status = VIP_SUCCESS;

    if (!memory) {
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    viphal_free_memory(memory);

    return status;
}

/*
@brief Set memory to zero.
@param memory, Memory to be set to zero.
@param size, the size of memory.
*/
vip_status_e vipdrv_os_zero_memory(IN void* memory, IN vip_size_t size)
{
    viphal_zero_memory(memory, size);

    return VIP_SUCCESS;
}

/*
@brief copy src memory to dst memory.
@param dst, Destination memory.
@param src. Source memory
@param size, the size of memory should be copy.
*/
vip_status_e vipdrv_os_copy_memory(IN void* dst, IN const void* src, IN vip_size_t size)
{
    viphal_copy_memory(dst, src, size);

    return VIP_SUCCESS;
}

#if vpmdENABLE_AHB_LOG
static vip_status_e vipdrv_drv_get_hardware_index(IN volatile void* reg_base, OUT vip_uint32_t* dev,
                                                  OUT vip_uint32_t* core)
{
    vipdrv_hardware_info_t info = {0};
    vip_uint32_t i = 0, j = 0;
    vipdrv_drv_get_hardware_info(&info);
    for (i = 0; i < info.device_count; i++) {
        for (j = 0; j < info.device_info[i].core_count; j++) {
            if (reg_base == info.device_info[i].vip_reg[j]) {
                *dev = i;
                *core = j;
                return VIP_SUCCESS;
            }
        }
    }

    return VIP_SUCCESS;
}
#endif

/*
@brief Read a hardware register.
@param reg_base, the base address of hardware register.
@param address, read the register address.
@param data, the data of address be read.
*/
vip_status_e vipdrv_os_read_reg(IN volatile void* reg_base, IN vip_uint32_t address, OUT vip_uint32_t* data)
{
    vip_uint32_t* reg = (vip_uint32_t*)((vip_uint8_t*)reg_base + address);
    *data = *reg;

#if vpmdENABLE_AHB_LOG
    {
        vip_uint32_t dev = 0, core = 0;
        vipdrv_drv_get_hardware_index(reg_base, &dev, &core);
        PRINTK("@[register.read %u %u 0x%05X 0x%08X]\n", dev, core, address, *data);
    }
#endif

    return VIP_SUCCESS;
}

/*
@brief Write a hardware register.
@param reg_base, the base address of hardware register.
@param address, write the register address.
@param data, the data of address be wrote.
*/
vip_status_e vipdrv_os_write_reg(IN volatile void* reg_base, IN vip_uint32_t address, IN vip_uint32_t data)
{
    vip_uint32_t* reg = (vip_uint32_t*)((vip_uint8_t*)reg_base + address);
    *reg = data;

#if vpmdENABLE_AHB_LOG
    {
        vip_uint32_t dev = 0, core = 0;
        vipdrv_drv_get_hardware_index(reg_base, &dev, &core);
        PRINTK("@[register.write %u %u 0x%05X 0x%08X]\n", dev, core, address, data);
    }
#endif

    return VIP_SUCCESS;
}

/*
@brief Waiting for the hardware interrupt. wait interrupt function depend on the type of RTOS
@param irq_queue, the wait queue of interrupt handle.
@param irq_value, a flag for interrupt.
@param time_out, the timeout value of this wait. ms.
@param mask, mask data for interrupt.
*/
vip_status_e vipdrv_os_wait_interrupt(IN void* irq_queue, IN volatile vip_uint32_t* volatile irq_value,
                                      IN vip_uint32_t time_out, IN vip_uint32_t mask)
{
    vip_status_e status = VIP_SUCCESS;
    vipIsNULL(irq_value);

    if ((mask & *irq_value) == 0) {
        sem_t* irq_queue_handle = (sem_t*)irq_queue;

        if (time_out == 0) {
            if (sem_wait(irq_queue_handle) != 0) {
                status = VIP_ERROR_TIMEOUT;
            }
        } else {
            struct timespec ts;
            if (clock_gettime(CLOCK_REALTIME, &ts) == 0) {
                ts.tv_sec += time_out / 1000;
                ts.tv_nsec += (time_out % 1000) * 1000000;
                if (ts.tv_nsec >= 1000000000) {
                    ts.tv_sec++;
                    ts.tv_nsec -= 1000000000;
                }

                if (sem_timedwait(irq_queue_handle, &ts) != 0) {
                    if (errno == ETIMEDOUT) {
                        status = VIP_ERROR_TIMEOUT;
                    } else {
                        status = -errno;
                    }
                }
            } else {
                status = -errno;
            }
        }
    } else {
        PRINTK("not wait, may interrupt is returned, irq_value=0x%x\n", *irq_value);
    }

onError:
    return status;
}

vip_status_e vipdrv_os_wakeup_interrupt(IN void* irq_queue)
{
    vip_status_e status = VIP_SUCCESS;
    sem_t* irq_queue_handle = (sem_t*)irq_queue;

    int ret = nxsem_post(irq_queue_handle);
    if (ret != 0) {
        status = -ret;
    }
    return status;
}

/*
@brief Delay execution of the current thread for a number of milliseconds.
@param ms, delay unit ms. Delay to sleep, specified in milliseconds.
*/
void vipdrv_os_delay(IN vip_uint32_t ms)
{
    if (ms > 0) {
        nxsig_usleep(ms * 1000);
    }
}

/*
@brief Delay execution of the current thread for a number of microseconds.
@param ms, delay unit us. Delay to sleep, specified in microseconds.
*/
void vipdrv_os_udelay(IN vip_uint32_t us)
{
    nxsig_usleep(us);
}

/*
@brief Print string on console.
@param msg, which message to be print.
*/
vip_status_e vipdrv_os_print(vip_log_level level, IN const char* message, ...)
{
    vip_status_e status = VIP_SUCCESS;

    status = viphal_os_print(level, message);

    return status;
}

/*
@brief Print string to buffer.
@param, size, the size of msg.
@param msg, which message to be print.
*/
vip_status_e vipdrv_os_snprint(IN vip_char_t* buffer, IN vip_uint32_t size, IN const vip_char_t* msg, ...)
{
    vip_status_e status = VIP_SUCCESS;

    status = viphal_os_snprint(buffer, size, msg);

    return status;
}

/*
@brief get the current system time.
*/
vip_uint64_t vipdrv_os_get_time(void)
{
    return viphal_os_get_time();
}

/*
@brief Get process id
*/
vip_uint32_t vipdrv_os_get_pid(void)
{
    return viphal_os_get_pid();
}

/*
@brief Get thread id
*/
vip_uint32_t vipdrv_os_get_tid(void)
{
    return viphal_os_get_tid();
}

/*
@brief Memory barrier function for memory consistency.
*/
vip_status_e vipdrv_os_memorybarrier(void)
{
    /* please make sure the memory barrier ASM can work well on you platform */

    /*__asm__ volatile("" ::: "memory");*/

    UP_MB();

    return VIP_SUCCESS;
}

#if vpmdENABLE_FLUSH_CPU_CACHE
/*
@brief Flush CPU cache for video memory which allocated from heap.
@param physical, the CPU physical address.
@param logical, the CPU logical address.
       loggical address only for Linux system or CPU MMU is enabled?.
       should be equal to physical address in RTOS?
@param size, the size of the memory should be flush.
@param type The type of operate cache. see vipdrv_cache_type_e.
*/
vip_status_e vipdrv_os_flush_cache(IN vip_physical_t physical, IN void* logical, IN vip_uint32_t size,
                                   IN vip_uint8_t type)
{
    vip_status_e status = VIP_SUCCESS;

    PRINTK_D("flush cache physical=0x%08X, size=0x%08X, type=%d\n", physical, size, type);
    if ((0 == physical) && (VIP_NULL == logical)) {
        PRINTK_E("flush cache physical=0x%x, logical=%p\n", physical, logical);
        return VIP_ERROR_FAILURE;
    }

    status = vipdrv_vendor_flush_cache(physical, logical, size, type);

    return status;
}
#endif

/*
@brief Create a mutex for multiple thread.
@param mutex, create mutex pointer.
*/
vip_status_e vipdrv_os_create_mutex(OUT vipdrv_mutex* mutex)
{
    return viphal_os_create_mutex(mutex);
}

vip_status_e vipdrv_os_lock_mutex(IN vipdrv_mutex mutex)
{
    return viphal_os_lock_mutex(mutex);
}

vip_status_e vipdrv_os_unlock_mutex(IN vipdrv_mutex mutex)
{
    return viphal_os_unlock_mutex(mutex);
}

/*
@brief Destroy a mutex which create in vipdrv_os_create_mutex..
@param mutex, create mutex pointer.
*/
vip_status_e vipdrv_os_destroy_mutex(IN vipdrv_mutex mutex)
{
    return viphal_os_destroy_mutex(mutex);
}

#if vpmdENABLE_MULTIPLE_TASK || vpmdPOWER_OFF_TIMEOUT
/*
@brief Create a thread.
@param func, the thread handle function.
@param parm, parameter for this thread.
@param name, the thread name.
@param handle, the handle for thread.
*/
vip_status_e vipdrv_os_create_thread(IN vipdrv_thread_func func, IN vip_ptr parm, IN vip_char_t* name,
                                     OUT vipdrv_thread* handle)
{
    struct sched_param param;
    pthread_attr_t attr;
    int ret;
    pthread_t *myhandle = (pthread_t *)handle;

    if (handle == VIP_NULL) {
        return VIP_ERROR_FAILURE;
    }

    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, DEFAULT_AI_TASK_STACK_SZ);
    param.sched_priority = DEFAULT_AI_TASK_PRIO;
    pthread_attr_setschedparam(&attr, &param);

    ret = pthread_create(myhandle, &attr, (pthread_startroutine_t)func, parm);
    pthread_attr_destroy(&attr);

    if (ret == 0) {
        pthread_setname_np(*myhandle, name);
        return VIP_SUCCESS;
    } else {
        PRINTK("create nuttx pthread %s failed: %s\n", name, strerror(errno));
        return VIP_ERROR_FAILURE;
    }
}

vip_status_e vipdrv_os_destroy_thread(IN vipdrv_thread handle)
{
    if (handle != VIP_NULL) {
        int ret = pthread_cancel((pthread_t)handle);
        if (ret != 0) {
            PRINTK("destroy thread failed: %s\n", strerror(errno));
            return VIP_ERROR_FAILURE;
        }
        pthread_join((pthread_t)handle, NULL);
    }
    return VIP_SUCCESS;
}
#endif

/*
@brief Create a atomic.
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_create_atomic(OUT vipdrv_atomic* atomic)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t* c_atomic = VIP_NULL;
    vipIsNULL(atomic);

    /* please add atomic implement in here if system supports atomic
        otherwise use below function to instead atmoic */

    status = vipdrv_os_allocate_memory(sizeof(vip_uint32_t), (void**)&c_atomic);
    if (status != VIP_SUCCESS) {
        PRINTK_E("allocate memory for atomic\n");
        return VIP_ERROR_IO;
    }

    *c_atomic = 0;
    *atomic = (vip_ptr)c_atomic;

onError:
    return status;
}

/*
@brief Destroy a atomic which create in vipdrv_os_create_atomic
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_destroy_atomic(IN vipdrv_atomic atomic)
{
    vip_status_e status = VIP_SUCCESS;
    vipIsNULL(atomic);

    vipdrv_os_free_memory(atomic);

onError:
    return status;
}

/*
@brief Set the 32-bit value protected by an atomic.
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_set_atomic(IN vipdrv_atomic atomic, IN vip_uint32_t value)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t* data = (vip_uint32_t*)atomic;
    vipIsNULL(atomic);

    *data = value;

onError:
    return status;
}

/*
@brief Get the 32-bit value protected by an atomic.
@param atomic, create atomic pointer.
*/
vip_uint32_t vipdrv_os_get_atomic(IN vipdrv_atomic atomic)
{
    vip_uint32_t value = 0xFFFFFFFE;
    vip_uint32_t* data = (vip_uint32_t*)atomic;
    if (VIP_NULL == atomic) {
        PRINTK_E("get atomic invalid arguments\n");
        return (VIP_ERROR_INVALID_ARGUMENTS);
    }

    value = *data;

    return value;
}

/*
@brief Increase the 32-bit value protected by an atomic.
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_inc_atomic(IN vipdrv_atomic atomic)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t* data = (vip_uint32_t*)atomic;
    vipIsNULL(atomic);

    *data += 1;

onError:
    return status;
}

/*
@brief Decrease the 32-bit value protected by an atomic.
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_dec_atomic(IN vipdrv_atomic atomic)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t* data = (vip_uint32_t*)atomic;
    vipIsNULL(atomic);

    *data -= 1;

onError:
    return status;
}

#if vpmdENABLE_MULTIPLE_TASK || vpmdENABLE_SUSPEND_RESUME || vpmdPOWER_OFF_TIMEOUT
typedef struct _vipdrv_signal_data {
    sem_t wait_signal;
    vipdrv_mutex lock;
    volatile vip_bool_e value;
} vipdrv_signal_data_t;

/*
@brief Create a signal.
@param handle, the handle for signal.
*/
vip_status_e vipdrv_os_create_signal(IN vipdrv_signal* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_signal_data_t* data = NULL;

    if (handle == VIP_NULL) {
        vip_error("create signal, parameter is NULL\n");
        return VIP_ERROR_FAILURE;
    }

    vipOnError(vipdrv_os_allocate_memory(sizeof(vipdrv_signal_data_t), (vip_ptr*)&data));

    if (sem_init(&data->wait_signal, 0, 0) != 0) {
        vip_error("create signal: sem_init failed, errno=%d\n", errno);
        status = VIP_ERROR_IO;
        goto onError;
    }

    data->value = vip_false_e;

    status = vipdrv_os_create_mutex((vip_ptr*)&data->lock);
    if (status != VIP_SUCCESS) {
        vip_error("create signal: create mutex failed\n");
        sem_destroy(&data->wait_signal);
        goto onError;
    }

    *handle = (vipdrv_signal)data;
    return status;

onError:
    if (data != NULL) {
        vipdrv_os_free_memory(data);
    }
    return status;
}

vip_status_e vipdrv_os_destroy_signal(IN vipdrv_signal handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_signal_data_t* data = (vipdrv_signal_data_t*)handle;

    if (data == VIP_NULL) {
        PRINTK_E("destory signal, parameter is NULL\n");
        vipGoOnError(VIP_ERROR_FAILURE);
    }
    data->value = vip_false_e;
    sem_destroy(&data->wait_signal);
    if (data->lock != VIP_NULL) {
        vipdrv_os_destroy_mutex(data->lock);
    }
    vipdrv_os_free_memory(handle);

onError:
    return status;
}

/*
@brief Waiting for a signal.
@param handle, the handle for signal.
@param timeout, the timeout of waiting signal. unit ms. timeout is 0 or VIP_INFINITE, infinite wait signal.
*/
vip_status_e vipdrv_os_wait_signal(IN vipdrv_signal handle, IN vip_uint32_t timeout)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_signal_data_t* data = (vipdrv_signal_data_t*)handle;
    vip_int32_t ret = 0;

    if (data == NULL) {
        vip_error("wait signal, parameter is NULL\n");
        return VIP_ERROR_FAILURE;
    }

    vipdrv_os_lock_mutex(data->lock);
    if (!data->value) {
        /* Wait for the condition. */
        vipdrv_os_unlock_mutex(data->lock);

        if (VIP_INFINITE == timeout){
            ret = sem_wait(&data->wait_signal);
        }
        else{
            struct timespec ts;
            clock_gettime(CLOCK_REALTIME, &ts);
            ts.tv_sec += timeout / 1000;
            ts.tv_nsec += (timeout % 1000) * 1000000;
            if (ts.tv_nsec >= 1000000000) {
                ts.tv_sec++;
                ts.tv_nsec -= 1000000000;
            }

            ret = sem_timedwait(&data->wait_signal, &ts);
        }

        if (ret != 0) {
            if (errno == ETIMEDOUT) {
                vip_error("wait signal handle=0x%p, timeout=%u\n", handle, timeout);
                status = VIP_ERROR_TIMEOUT;
            } else {
                vip_error("wait signal failed, errno=%d\n", errno);
                status = VIP_ERROR_IO;
            }
        }
    } else {
        vipdrv_os_unlock_mutex(data->lock);
    }

    return status;
}

/*
@brief wake up wait signal.
     state is true, wake up all waiting signal and chane the signal state to SET.
     state is false, change the signal to RESET so the vipdrv_os_wait_signal will block until
     the signal state changed to SET. block waiting signal function.
@param handle, the handle for signal.
*/
vip_status_e vipdrv_os_set_signal(IN vipdrv_signal handle, IN vip_bool_e state)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_signal_data_t* data = (vipdrv_signal_data_t*)handle;

    if (data == VIP_NULL) {
        PRINTK_E("set signal, parameter is NULL\n");
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    vipdrv_os_lock_mutex(data->lock);
    if (vip_true_e == state) {
        data->value = vip_true_e;
        sem_post(&data->wait_signal);
    } else {
        data->value = vip_false_e;
    }
    vipdrv_os_unlock_mutex(data->lock);

onError:
    return status;
}
#endif

#if vpmdPOWER_OFF_TIMEOUT
typedef struct _vipdrv_timer {
    struct wdog_s wdog;
    uint32_t timer_id;
    vip_uint32_t time_out; /* ms */
    vipdrv_timer_func callback;
    vip_ptr callback_params;
} vipdrv_timer_t;

#define MAX_TIMER_NUM 20

static vipdrv_timer_t timer_wrapper[MAX_TIMER_NUM];

static vipdrv_timer_t* get_timer_warpper(vip_uint32_t index)
{
    if (index >= MAX_TIMER_NUM) {
        return NULL;
    }
    return &timer_wrapper[index];
}

static void TimerCallback(wdparm_t arg)
{
    vipdrv_timer_t *timer = (vipdrv_timer_t *)arg;

    if (timer && timer->callback) {
        timer->callback(timer->callback_params);
    }
}

/*
@brief create a system timer callback.
@param func, the callback function of this timer.
@param callback_param, theparamete of the timer callback function.
@pram time_out, time out value of this timer, milliseconds(ms).
@pram timers, the handle of time
*/
vip_status_e vipdrv_os_create_timer(IN vipdrv_timer_func callback, IN vip_ptr callback_param,
                                    IN vip_uint32_t time_out, OUT vipdrv_timer *timers)
{
    vipdrv_timer_t* timer = VIP_NULL;

    if (MAX_TIMER_NUM < timer_index) {
        PRINTK_E("create timer cnt=%d more than max cnt=%d\n", timer_index, MAX_TIMER_NUM);
        return VIP_ERROR_FAILURE;
    }

    timer = get_timer_warpper(timer_index);
    timer->callback = callback;
    timer->callback_params = callback_param;

    {
        timer->timer_id = timer_index;
        memset(&timer->wdog, 0, sizeof(struct wdog_s));
    }

    *timers = (void*)timer;
    timer_index++;

    return VIP_SUCCESS;
}

vip_status_e vipdrv_os_start_timer(IN vipdrv_timer timers)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_timer_t* timer = (vipdrv_timer_t*)timers;
    vipIsNULL(timer);

    clock_t ticks = MSEC2TICK(timer->time_out);
    int ret = wd_start(&timer->wdog, ticks, TimerCallback, (wdparm_t)timer);

    if (ret != OK) {
        PRINTK_E("start timer failed\n");
        status = VIP_ERROR_FAILURE;
    }

    return status;
onError:
    PRINTK_E("start timer\n");
    return status;
}

vip_status_e vipdrv_os_stop_timer(IN vipdrv_timer timers)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_timer_t* timer = (vipdrv_timer_t*)timers;
    vipIsNULL(timer);

    wd_cancel(&timer->wdog);

    return status;
onError:
    PRINTK_E("stop timer\n");
    return status;
}

/*
@brief destroy a system timer
*/
vip_status_e vipdrv_os_destroy_timer(IN vipdrv_timer timers)
{
    vipdrv_timer_t* timer = (vipdrv_timer_t*)timers;

    wd_cancel(&timer->wdog);
    return VIP_SUCCESS;
}
#endif

vip_int32_t vipdrv_os_strcmp(const vip_char_t* s1, const vip_char_t* s2)
{
    return viphal_os_strcmp(s1, s2);
}
