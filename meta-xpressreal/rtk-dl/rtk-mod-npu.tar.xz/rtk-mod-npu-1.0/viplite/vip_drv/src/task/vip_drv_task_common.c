/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/
#undef VIPDRV_LOG_ZONE
#define VIPDRV_LOG_ZONE VIPDRV_LOG_ZONE_TASK

#include <vip_drv_task_common.h>
#include <vip_drv_debug.h>
#include <vip_drv_context.h>
#include <vip_drv_task_descriptor.h>
#include <vip_drv_mmu.h>
#include <vip_drv_pm.h>
#include <vip_drv_mem_heap.h>

/*
    INIT_TASK_QUEUE_DEPTH is the initial number of task supported in task queue.
    32 is default value when task queue is enabled.
*/
#define INIT_TASK_QUEUE_DEPTH 32

#if vpmdTASK_QUEUE_USED
static vip_status_e wake_up_user_wait(void* element)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_task_control_block_t* tskTCB = (vipdrv_task_control_block_t*)element;
    vipdrv_os_set_signal(tskTCB->wait_signal, vip_true_e);
    return status;
}

static vip_status_e free_TCB_resource(void* element)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_task_control_block_t* tskTCB = (vipdrv_task_control_block_t*)element;
    if (VIP_NULL != tskTCB->wait_signal) {
        vipdrv_os_destroy_signal(tskTCB->wait_signal);
        tskTCB->wait_signal = VIP_NULL;
    }
    if (VIP_NULL != tskTCB->queue_data) {
        vipdrv_os_free_memory((void*)tskTCB->queue_data);
        tskTCB->queue_data = VIP_NULL;
    }
    if (VIP_NULL != tskTCB->cancel_mutex) {
        vipdrv_os_destroy_mutex(tskTCB->cancel_mutex);
        tskTCB->cancel_mutex = VIP_NULL;
    }
    return status;
}

vip_status_e vipdrv_task_tcb_init(void)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_hashmap_t* tskTCB_hashmap = (vipdrv_hashmap_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TCB);

    VIPDRV_LOOP_DEVICE_START
    status = vipdrv_queue_initialize(&dev->tskTCB_queue, dev->device_index,
                                     (dev->hardware_count + 1) * dev->hardware_count / 2);
    if (status != VIP_SUCCESS) {
        PRINTK_E("create queue for supporting multi-thread\n");
        vipGoOnError(VIP_ERROR_IO);
    }
    VIPDRV_LOOP_DEVICE_END
    vipOnError(vipdrv_hashmap_init(tskTCB_hashmap, INIT_TASK_QUEUE_DEPTH, sizeof(vipdrv_task_control_block_t),
                                   "tskTCB", (void*)wake_up_user_wait, VIP_NULL, (void*)free_TCB_resource));
    PRINTK_D("tskTCB_hashmap=0x%"PRPx"\n", tskTCB_hashmap);
onError:
    return status;
}

vip_status_e vipdrv_task_tcb_uninit(void)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_hashmap_t* tskTCB_hashmap = (vipdrv_hashmap_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TCB);
    vipdrv_hashmap_destroy(tskTCB_hashmap);
    VIPDRV_LOOP_DEVICE_START
    vipdrv_queue_destroy(&dev->tskTCB_queue);
    VIPDRV_LOOP_DEVICE_END

    return status;
}

vip_status_e vipdrv_task_tcb_submit(vipdrv_device_t* device, vipdrv_submit_task_param_t* sbmt_para)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t task_id = sbmt_para->task_id + sbmt_para->subtask_index;
    vipdrv_hashmap_t* tskTCB_hashmap = VIP_NULL;

    if (vip_true_e == device->tskTCB_thread_running) {
        vipdrv_task_descriptor_t* tsk_desc = VIP_NULL;
        vipdrv_task_control_block_t* tskTCB = VIP_NULL;
        vip_bool_e ret = vip_true_e;
        vip_uint32_t tcb_index = 0;
        vip_uint32_t tsk_desc_index = vipdrv_task_desc_id2index(task_id);
        vip_uint32_t queue_id = 0;
        tskTCB_hashmap = &device->context->tskTCB_hashmap;

Expand:
        if (vip_true_e == vipdrv_hashmap_full(tskTCB_hashmap)) {
            status = vipdrv_hashmap_expand(tskTCB_hashmap);
            if (VIP_SUCCESS != status) {
                PRINTK_E("multi thread is full, not support so many threads\n");
                vipGoOnError(VIP_ERROR_FAILURE);
            }
        }

        /* get an index from task TCB hashmap and put the cmd_handle into the hashmap */
        status = vipdrv_hashmap_insert(tskTCB_hashmap, (vip_uint64_t)task_id, &tcb_index);
        if (VIP_SUCCESS != status) {
            if (VIP_ERROR_OUT_OF_RESOURCE == status) {
                goto Expand;
            } else {
                PRINTK_E("The duplicate commands 0x%x can't be submitted\n", task_id);
                vipGoOnError(status);
            }
        }
        status = vipdrv_hashmap_get_by_index(tskTCB_hashmap, tcb_index, (void**)&tskTCB);
        if (VIP_NULL == tskTCB) {
            PRINTK_E("get task %d status=%d\n", tcb_index);
            vipGoOnError(status);
        }

        if (VIP_NULL == tskTCB->wait_signal) {
            status = vipdrv_os_create_signal((vipdrv_signal*)&tskTCB->wait_signal);
            if (status != VIP_SUCCESS) {
                PRINTK_E("create a signal wait signal\n");
                vipdrv_hashmap_remove_by_index(tskTCB_hashmap, tcb_index, vip_false_e);
                vipdrv_hashmap_unuse(tskTCB_hashmap, tcb_index, vip_false_e);
                vipGoOnError(VIP_ERROR_IO);
            }
            vipdrv_os_set_signal(tskTCB->wait_signal, vip_false_e);
        }

        if (VIP_NULL == tskTCB->cancel_mutex) {
            status = vipdrv_os_create_mutex((vipdrv_mutex*)&tskTCB->cancel_mutex);
            if (status != VIP_SUCCESS) {
                PRINTK_E("create mutex for cancel task.\n");
                vipdrv_hashmap_remove_by_index(tskTCB_hashmap, tcb_index, vip_false_e);
                vipdrv_hashmap_unuse(tskTCB_hashmap, tcb_index, vip_false_e);
                vipGoOnError(VIP_ERROR_IO);
            }
        }

        if (VIP_NULL == tskTCB->queue_data) {
            status = vipdrv_os_allocate_memory(sizeof(vipdrv_queue_data_t), (void**)&tskTCB->queue_data);
            if (VIP_SUCCESS != status) {
                PRINTK_E("submit, allocate queue_data fail\n");
                vipdrv_hashmap_remove_by_index(tskTCB_hashmap, tcb_index, vip_false_e);
                vipdrv_hashmap_unuse(tskTCB_hashmap, tcb_index, vip_false_e);
                vipGoOnError(VIP_ERROR_IO);
            }
            vipdrv_os_zero_memory((void*)tskTCB->queue_data, sizeof(vipdrv_queue_data_t));
        }

        vipdrv_os_lock_mutex(tskTCB->cancel_mutex);
        if (vip_true_e == vipdrv_hashmap_check_remove(tskTCB_hashmap, tcb_index)) {
            PRINTK_E("task has been cancelled during submitting\n");
            vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
            vipdrv_hashmap_unuse(tskTCB_hashmap, tcb_index, vip_false_e);
            vipGoOnError(VIP_ERROR_CANCELED);
        }

        tskTCB->status = VIPDRV_TASK_READY;
        tskTCB->task.task_id = task_id;
        tskTCB->task.subtask_index = sbmt_para->subtask_index;
        tskTCB->task.subtask_count = sbmt_para->subtask_cnt;
        tskTCB->task.device = device;
        tskTCB->task.core_index = sbmt_para->core_index;
        tskTCB->task.core_cnt = sbmt_para->core_cnt;
#if vpmdENABLE_PREEMPTION
        tskTCB->queue_data->priority = sbmt_para->priority;
#endif
        tskTCB->queue_data->v1 = tcb_index;
        tskTCB->queue_data->v2 = VIP_ERROR_FAILURE;
        tskTCB->queue_data->res_mask = 0;
        VIPDRV_LOOP_HARDWARE_IN_TASK_START(&tskTCB->task)
        tskTCB->queue_data->res_mask |= (1 << hw->core_id);
        VIPDRV_LOOP_HARDWARE_IN_TASK_END

#if vpmdENABLE_L2_SCHEDULE
        tskTCB->queue_data->l2_size = tskTCB->l2_size;
#endif
        if (VIP_SUCCESS ==
            vipdrv_database_use(&device->context->tskDesc_database, tsk_desc_index, (void**)&tsk_desc)) {
            tskTCB->queue_data->time = tsk_desc->subtasks[sbmt_para->subtask_index].avg_time;
            tskTCB->time_out = tsk_desc->timeout;
            vipdrv_database_unuse(&device->context->tskDesc_database, tsk_desc_index);
        }
        PRINTK_D("user put task_id=0x%x into TCB index=%d, status=0x%x\n", task_id, tcb_index,
                 tskTCB->status);

        vipdrv_os_set_signal(tskTCB->wait_signal, vip_false_e);
        VIPDRV_SHOW_DEV_CORE_INFO(device->device_index, sbmt_para->core_cnt, sbmt_para->core_index,
                                  "submit to queue", 0);
        /* assume there are 4 cores, so there are 10 kinds of tasks.
           0    1    2    3
           01   12   23
           012  123
           0123
           if current task use core 1&2, the queue index is 5. */
        queue_id = (vip_uint32_t)((2 * device->hardware_count - sbmt_para->core_cnt + 2) *
                                              (sbmt_para->core_cnt - 1) / 2 +
                                  sbmt_para->core_index);
        ret = vipdrv_queue_write(&device->tskTCB_queue, tskTCB->queue_data, queue_id);
        vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
        if (!ret) {
            PRINTK_E("write task into queue\n");
            tskTCB->status = VIPDRV_TASK_EMPTY;
            vipdrv_hashmap_remove_by_index(tskTCB_hashmap, tcb_index, vip_false_e);
            vipdrv_hashmap_unuse(tskTCB_hashmap, tcb_index, vip_false_e);
            vipGoOnError(VIP_ERROR_FAILURE);
        }
        vipdrv_hashmap_unuse(tskTCB_hashmap, tcb_index, vip_false_e);
        vipdrv_os_set_signal(device->tskTCB_submit_signal, vip_true_e);
    } else {
        PRINTK_E("multi task thread is not running\n");
        vipGoOnError(VIP_ERROR_NOT_SUPPORTED);
    }

    return status;
onError:
    PRINTK_E("task tcb submit status=%d\n", status);
    return status;
}

vip_status_e vipdrv_task_tcb_wait(vipdrv_wait_task_param_t* wait_para)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_task_control_block_t* tskTCB = VIP_NULL;
    vip_uint32_t tcb_index = 0;
    vip_uint32_t task_id = wait_para->task_id + wait_para->subtask_index;
    vipdrv_hashmap_t* tskTCB_hashmap = (vipdrv_hashmap_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TCB);

    vipdrv_hashmap_get_by_handle(tskTCB_hashmap, (vip_uint64_t)task_id, &tcb_index, (void**)&tskTCB);
    if (0 < tcb_index) {
        vipdrv_device_t* device = tskTCB->task.device;
        vip_uint32_t i = 0;
        vip_uint32_t timeout = wait_para->timeout;
        if (vip_false_e == device->tskTCB_thread_running) {
            PRINTK_D("bypass wait irq, mt_thread=%d, device_idle=%s, task_id=0x%x\n",
                     device->tskTCB_thread_running,
                     (vipdrv_os_get_atomic(device->hardware[0].idle)) ? "true" : "false", task_id);
            vipdrv_hashmap_unuse(tskTCB_hashmap, tcb_index, vip_false_e);
            return VIP_ERROR_FAILURE;
        }

        vipdrv_os_lock_mutex(tskTCB->cancel_mutex);
        if (VIP_ERROR_CANCELED == tskTCB->queue_data->v2) {
            /* the tskTCB has been canceled.
              1. don't need waiting for task inference done.
              2. don't need clean up mem_handle.
            */
            PRINTK_I("user end do wait device%d, task_id=0x%x, task_status=0x%x\n", device->device_index,
                     task_id, tskTCB->status);
            vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
            vipdrv_hashmap_remove_by_index(tskTCB_hashmap, tcb_index, vip_false_e);
            vipdrv_hashmap_unuse(tskTCB_hashmap, tcb_index, vip_false_e);
            return VIP_ERROR_CANCELED;
        }
        vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);

        i = 0;
        while (1) {
            vip_uint32_t wait_time = timeout < WAIT_SIGNAL_TIMEOUT ? timeout : WAIT_SIGNAL_TIMEOUT;
            timeout -= wait_time;
            status = vipdrv_os_wait_signal(tskTCB->wait_signal, wait_time);
            if (VIP_SUCCESS == status) {
                break;
            }
            if (0 == timeout) {
                status = VIP_ERROR_NOT_FINISH;
                break;
            }
            PRINTK_D("wait task timeout loop index=%d\n", i);
            i++;
        }
        vipdrv_os_set_signal(tskTCB->wait_signal, vip_false_e);
        if (status != VIP_SUCCESS) {
            vipdrv_hashmap_unuse(tskTCB_hashmap, tcb_index, vip_false_e);
            vipGoOnError(status);
        }
        tskTCB->task.subtask_count = 0;
        tskTCB->status = VIPDRV_TASK_EMPTY;
        status = tskTCB->queue_data->v2;
        vipdrv_hashmap_remove_by_index(tskTCB_hashmap, tcb_index, vip_false_e);
        vipdrv_hashmap_unuse(tskTCB_hashmap, tcb_index, vip_false_e);
        if ((status != VIP_SUCCESS) && (status != VIP_ERROR_CANCELED)) {
            PRINTK_E("do wait mt thread fail, task_id=0x%x, status=%d\n", task_id, status);
            vipGoOnError(status);
        }
    } else {
        PRINTK_D("bypass wait irq, task_id=0x%x\n", task_id);
        status = VIP_ERROR_CANCELED;
    }

onError:
    return status;
}

#if vpmdENABLE_CANCELATION
vip_status_e vipdrv_task_tcb_cancel(vipdrv_cancel_task_param_t* cancel)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t task_id = cancel->task_id + cancel->subtask_index;
    vip_bool_e hw_cancel = vip_false_e;
    vipdrv_task_control_block_t* tskTCB = VIP_NULL;
    vip_uint32_t i = 0;
    vipdrv_hashmap_t* tskTCB_hashmap = (vipdrv_hashmap_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TCB);

    PRINTK_I("user start do cancel task_id=0x%x\n", task_id);
    if (VIP_SUCCESS ==
        vipdrv_hashmap_get_by_handle(tskTCB_hashmap, (vip_uint64_t)task_id, &i, (void**)&tskTCB)) {
        vipdrv_device_t* device = tskTCB->task.device;
        hw_cancel = vipdrv_context_query_featureDB(device->device_index, VIP_FEATURE_JOB_CANCEL);
#if vpmdTASK_PARALLEL_ASYNC
        vipdrv_os_wait_signal(device->tskTCB_recover_signal, VIP_INFINITE);
        vipdrv_os_inc_atomic(device->disable_recover);
#endif

        vipdrv_os_lock_mutex(tskTCB->cancel_mutex);
        if (tskTCB->status == VIPDRV_TASK_READY) {
            tskTCB->queue_data->v2 = VIP_ERROR_CANCELED;
            tskTCB->status = VIPDRV_TASK_CANCELED;
            vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
            if (VIP_SUCCESS == vipdrv_queue_clean(&device->tskTCB_queue, VIPDRV_QUEUE_CLEAN_ONE,
                                                  (void*)&tskTCB->queue_data->v1)) {
                /* clean up mem_handle */
                vipdrv_hashmap_remove_by_index(tskTCB_hashmap, i, vip_false_e);
                vipdrv_hashmap_unuse(tskTCB_hashmap, i, vip_true_e);
            } else {
                vipdrv_hashmap_unuse(tskTCB_hashmap, i, vip_false_e);
            }
            PRINTK_I("task_id=0x%x is marked cancel in queue, not be executed.\n", task_id);
        } else if (tskTCB->status == VIPDRV_TASK_INFER_START) {
            vipdrv_hardware_t* hardware = &device->hardware[tskTCB->task.core_index];
            VIPDRV_CHECK_NULL(hardware);

            if (vip_false_e == hw_cancel) {
                vip_uint32_t wait_time = 300; /* 300ms */
                if (tskTCB->time_out != vpmdHARDWARE_TIMEOUT) {
                    wait_time = tskTCB->time_out;
                }
#if vpmdFPGA_BUILD
                else {
                    wait_time = 3000;
                }
#endif
                vipdrv_device_wait_idle(device, wait_time, vip_true_e);
                PRINTK_I("user end do cancel on device%d, hw_cancel=%d.\n", device->device_index, hw_cancel);
                vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
                vipdrv_hashmap_unuse(tskTCB_hashmap, i, vip_false_e);
            } else {
                vipdrv_os_set_signal(device->tskTCB_recover_signal, vip_false_e);
                hardware->irq_local_value = IRQ_VALUE_CANCEL;
#if vpmdTASK_PARALLEL_ASYNC
                *device->irq_value |= IRQ_VALUE_FLAG;
#else
                *hardware->irq_value |= IRQ_VALUE_FLAG;
#endif
#if !vpmdENABLE_POLLING
                vipdrv_os_inc_atomic(*hardware->irq_count);
#if vpmdTASK_PARALLEL_ASYNC
                vipdrv_os_wakeup_interrupt(device->irq_queue);
#else
                vipdrv_os_wakeup_interrupt(hardware->irq_queue);
#endif
#endif
                vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
                /* wait recover done */

#if vpmdTASK_PARALLEL_ASYNC
                vipdrv_os_dec_atomic(device->disable_recover);
#endif
                vipdrv_os_wait_signal(device->tskTCB_recover_signal, VIP_INFINITE);
                if (VIP_ERROR_CANCELED != tskTCB->queue_data->v2) {
                    status = tskTCB->queue_data->v2;
                    PRINTK_E("cancel task_id=0x%x, status=%d\n", task_id, status);
                }
                vipdrv_hashmap_remove_by_index(tskTCB_hashmap, i, vip_false_e);
                vipdrv_hashmap_unuse(tskTCB_hashmap, i, vip_false_e);
                PRINTK_I("task_id=0x%x is cancelled during executing.\n", task_id);
                vipGoOnError(status);
            }
        } else {
            vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
            vipdrv_hashmap_remove_by_index(tskTCB_hashmap, i, vip_false_e);
            vipdrv_hashmap_unuse(tskTCB_hashmap, i, vip_false_e);
            PRINTK_I("task_id=0x%x already forward done\n", task_id);
        }
#if vpmdTASK_PARALLEL_ASYNC
        vipdrv_os_dec_atomic(device->disable_recover);
#endif
    } else {
        PRINTK_E("bypass cancel, can not find cancel task_id=0x%x\n", task_id);
    }
onError:
    PRINTK_I("user end do cancel task_id=0x%x, status=%d\n", task_id, status);
    return status;
}
#endif
#endif

static vip_status_e vipdrv_task_check_error(vipdrv_hardware_t* hardware)
{
    vip_status_e status = VIP_SUCCESS;

    /* check hw nan or inf error */
    if (0) {
        vip_uint32_t error_value = 0, data = 0;
        vipdrv_read_register(hardware, 0x00348, &error_value);
        if ((((((vip_uint32_t) (error_value)) >> (0 ? 1:1)) & ((vip_uint32_t) ((((1 ? 1:1) - (0 ? 1:1) + 1) == 32) ? ~0U : (~0U & ((1U << (((1 ? 1:1) - (0 ? 1:1) + 1))) - 1U))))) )) {
            status = VIP_ERROR_NAN_INF;
        }
        data = ((((vip_uint32_t) (error_value)) & ~(((vip_uint32_t) (((vip_uint32_t) ((((1 ?
 1:1) - (0 ?
 1:1) + 1) == 32) ?
 ~0U : (~0U & ((1U << (((1 ?
 1:1) - (0 ?
 1:1) + 1))) - 1U)))))) << (0 ?
 1:1))) | (((vip_uint32_t) ((vip_uint32_t) (1) & ((vip_uint32_t) ((((1 ?
 1:1) - (0 ?
 1:1) + 1) == 32) ?
 ~0U : (~0U & ((1U << (((1 ? 1:1) - (0 ? 1:1) + 1))) - 1U)))))) << (0 ? 1:1)));
        vipdrv_write_register(hardware, 0x00348, data);
    }

    return status;
}

#if vpmdENABLE_RECOVERY || vpmdENABLE_CANCELATION
vip_status_e vipdrv_task_recover(vipdrv_device_t* device, vip_uint8_t* recover_mask)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t i = 0;
    vip_char_t info_t[256];
    vip_char_t* tmp = info_t;

    vipdrv_os_snprint(tmp, 255, "start recover dev%2d recover_mask", device->device_index);
    tmp += 32;
    VIPDRV_DATA_TO_STRING(tmp, recover_mask, vipdMP_NUM);
    PRINTK_F("%s\n", info_t);

    /* cancel hardware */
    if (vip_true_e == vipdrv_context_query_featureDB(device->device_index, VIP_FEATURE_JOB_CANCEL)) {
        status = vipdrv_hw_cancel(device, recover_mask);
        if (VIP_SUCCESS != status) {
            PRINTK_E("cancel hardware %d, status=%d.\n", status);
            vipGoOnError(status);
        }

#if vpmdFLEXA_DMA
        for (i = 0; i < device->hardware_count; i++) {
            if (recover_mask[i]) {
                vipdrv_hardware_t* hardware = &device->hardware[i];
                VIPDRV_CHECK_NULL(hardware);
                status = vipdrv_flexa_dma_hw_reset_part(hardware);
                if (VIP_SUCCESS != status) {
                    PRINTK_E("reset hardware t3d dma fail, status=%d.\n", status);
                    vipGoOnError(status);
                }
            }
        }
#endif

        for (i = 0; i < device->hardware_count; i++) {
            if (recover_mask[i]) {
                vipdrv_hardware_t* hardware = &device->hardware[i];
                VIPDRV_CHECK_NULL(hardware);

#if vpmdENABLE_POWER_MANAGEMENT
                vipdrv_pm_send_evnt(hardware, VIPDRV_PWR_EVNT_END, VIP_NULL);
                vipdrv_pm_send_evnt(hardware, VIPDRV_PWR_EVNT_CLK_ON, VIP_NULL);
#endif

#if 1
                status = vipdrv_hw_init(hardware);
                if (status != VIP_SUCCESS) {
                    PRINTK_E("initialize hardware, status=%d.\n", status);
                    vipGoOnError(status);
                }
#else
                status = vipdrv_hw_submit_initcmd(hardware);
                if (status != VIP_SUCCESS) {
                    PRINTK_E("submit init cmd, status=%d.\n", status);
                    vipGoOnError(status);
                }
#endif

#if vpmdENABLE_POWER_MANAGEMENT
                vipdrv_pm_send_evnt(hardware, VIPDRV_PWR_EVNT_CLK_OFF, VIP_NULL);
#endif
            }
        }
    } else {
        vipOnError(vipdrv_pm_device_recover(device, recover_mask));
    }

onError:
    return status;
}
#endif

/*
@ brief Insert flush mmu cache load states
physical. flush mmu command link to the physical address
size. the size of command will be linked.
*/
#if vpmdENABLE_MMU
static vip_status_e vipdrv_task_flush_mmu(vipdrv_task_t* task, vip_virtual_t* physical, vip_uint32_t* size)
{
    vipdrv_hardware_t* hardware = &task->device->hardware[task->core_index];
    vip_uint8_t* flush_logical_end = VIP_NULL;
    vip_status_e status = VIP_SUCCESS;
#if vpmdTASK_PARALLEL_ASYNC
    vipdrv_mmu_cmd_t* MMU_flush = &hardware->MMU_flush_table[hardware->wl_end_index];
#else
    vipdrv_mmu_cmd_t* MMU_flush = &hardware->MMU_flush;
#endif
    flush_logical_end = (vip_uint8_t*)MMU_flush->logical + FLUSH_MMU_STATES_SIZE;
    /* link flush mmu states and command buffer */
    cmd_link(hardware, (vip_uint32_t*)flush_logical_end, *physical, *size);
    *physical = MMU_flush->virtual;
    *size = MMU_flush->size;

#if vpmdENABLE_VIDEO_MEMORY_CACHE
    vipdrv_mem_flush_cache(task->device->mem_prop->mmu_flush_mem.mem_id, VIPDRV_CACHE_FLUSH);
#endif

    return status;
}
#endif

#if !vpmdENABLE_POLLING
vip_status_e vipdrv_task_check_irq_value(vipdrv_hardware_t* hardware)
{
    vip_uint32_t irq_value = *hardware->irq_value | hardware->irq_local_value;
    vip_status_e status = VIP_SUCCESS;
    VIPDRV_CHECK_NULL(hardware);

    PRINTK_D("dev%d hw%d, irq value=0x%x, irq_count=%d\n", hardware->device->device_index,
             hardware->core_index, irq_value, vipdrv_os_get_atomic(*hardware->irq_count));
    if (0 == irq_value) {
        PRINTK_E("dev%d hw%d, fail irq_value is 0\n", hardware->device->device_index, hardware->core_index);
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    if (irq_value & IRQ_VALUE_CANCEL) {
        status = VIP_ERROR_CANCELED;
        PRINTK_I("dev%d hw%d, Execute canceled, irq_value=0x%x.\n", hardware->device->device_index,
                 hardware->core_index, irq_value);
    }

    if (irq_value & IRQ_VALUE_AXI) {
        PRINTK_I("dev%d hw%d, AXI BUS ERROR...\n", hardware->device->device_index, hardware->core_index);
        status = VIP_ERROR_TIMEOUT; /* need recover */
    }

    if (irq_value & IRQ_VALUE_MMU) {
        vip_uint32_t mmu_status = 0;
        vipdrv_read_register(hardware, 0x00388, &mmu_status);
        if (mmu_status & 0x01) {
            PRINTK_I("MMU exception...\n");
        } else {
            PRINTK_I("MMU exception, then MMU is disabled\n");
        }
        status = VIP_ERROR_TIMEOUT; /* need recover */
    }

#if vpmdENABLE_FLEXA_DMA_INTERRUPT
    if (irq_value & IRQ_VALUE_DMA) {
        vip_uint32_t mmu_raw_status = 0, intr_status = 0;
        PRINTK_I("flexa_dma: network SPI to SBI irq returns irq_value=0x%x.\n", irq_value);
        vipdrv_read_subsys_register(0x0336C, &mmu_raw_status);
        vipdrv_read_subsys_register(0x03370, &intr_status);
        PRINTK_I("FLEXA DMA MMU raw status=0x%x\n", mmu_raw_status);
        PRINTK_I("FLEXA T3D MMU intr status=0x%x\n", intr_status);
    }
#endif

#if vpmdENABLE_FUSA
    if (irq_value & IRQ_VALUE_ERROR_FUSA) {
        vipdrv_fusa_check_irq_value(hardware);
        status = VIP_ERROR_FUSA;
    }
#endif

    /* error check again */
    if (VIP_SUCCESS == status) {
        status = vipdrv_task_check_error(hardware);
    }

    return status;
}
#endif

/*
submit the task to hardware
 command order:
 flush cache -> task init cmd -> preload cmd -> subtask_0 cmd -> subtask_n cmd
*/
static vip_status_e vipdrv_task_submit_bottom_half(vipdrv_task_t* task)
{
    vip_virtual_t trigger_physical = 0;
    vip_uint32_t trigger_size = 0;
    vip_status_e status = VIP_SUCCESS;
    vip_bool_e init_done = vip_true_e;
    vip_uint32_t pid = 0;
    vip_uint32_t task_id = 0;
    vip_uint32_t tsk_index = vipdrv_task_desc_id2index(task->task_id);
    vipdrv_context_t* context = task->device->context;
    vipdrv_task_descriptor_t* tsk_desc = VIP_NULL;
#if vpmdPRELOAD_COEFF > 1
    vip_bool_e need_preload = vip_false_e;
#endif

    if (VIP_SUCCESS != vipdrv_database_use(&context->tskDesc_database, tsk_index, (void**)&tsk_desc)) {
        PRINTK_E("get tsk desc task_id=0x%x, index=0x%x\n", task->task_id, tsk_index);
        return VIP_ERROR_FAILURE;
    }

#if vpmdENABLE_CNN_PROFILING || (vpmdPRELOAD_COEFF > 1)
    VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
    vip_uint32_t last_task_id = hw->previous_task_id[(hw->pre_end_index + TASK_HISTORY_RECORD_COUNT - 1) %
                                                     TASK_HISTORY_RECORD_COUNT];
#if (vpmdPRELOAD_COEFF > 1)
    if (tsk_desc->preload_vipsram) {
        if (vipdrv_task_desc_id2index(last_task_id) != vipdrv_task_desc_id2index(task->task_id)) {
            /* need re-preload coeff to vip-sram */
            need_preload = vip_true_e;
        }
    }
#endif

#if vpmdENABLE_CNN_PROFILING
    /* the subtasks of CNN profile network should executed consecutively */
    if ((tsk_desc->cnnprofile_enable) && (task->subtask_index > 0)) {
        if (vipdrv_task_desc_id2index(last_task_id) != vipdrv_task_desc_id2index(task->task_id)) {
            PRINTK_E("cnn profile, subtask_index=%u, last_task_id=0x%x, task_id=0x%x\n", task->subtask_index,
                     last_task_id, task->task_id);
            vipGoOnError(VIP_ERROR_NOT_SUPPORTED);
        }
    }
#endif
    VIPDRV_LOOP_HARDWARE_IN_TASK_END
#endif

    vipOnError(vipdrv_task_desc_get_cmdbuf(tsk_desc, task, VIPDRV_TASK_CMD_SUBTASK, task->subtask_index,
                                           VIP_NULL, VIP_NULL, &trigger_physical, &trigger_size, &pid,
                                           &task_id));
    /* have append some command at the end network command buffer(stall, link, end,...) */
    trigger_size += APPEND_COMMAND_SIZE;

#if vpmdENABLE_MMU
    VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
    vipOnError(vipdrv_mmu_page_switch(hw, gen_mmu_id(pid, task_id, hw->device->mem_prop->index)));
    VIPDRV_LOOP_HARDWARE_IN_TASK_END
#endif

    VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
    if (vip_false_e == hw->init_done) {
        init_done = vip_false_e;
    }
#if vpmdENABLE_POWER_MANAGEMENT
    vipOnError(vipdrv_pm_hw_submit(hw));
#else
    vipdrv_os_set_atomic(hw->idle, vip_false_e);
#endif
    VIPDRV_LOOP_HARDWARE_IN_TASK_END

#if vpmdPRELOAD_COEFF > 1
    if (vip_true_e == need_preload) {
        vip_uint8_t* logical_tmp = VIP_NULL;
        vip_uint32_t cmd_size_tmp = 0;
        vip_virtual_t physical_tmp = 0;
        vip_uint32_t handle_tmp = 0;
        vipdrv_hardware_t* hw = &(task->device->hardware[task->core_index]);
        if (VIP_SUCCESS == vipdrv_task_desc_get_cmdbuf(tsk_desc, task, VIPDRV_TASK_CMD_PRELOAD, 0,
                                                       &handle_tmp, &logical_tmp, &physical_tmp,
                                                       &cmd_size_tmp, VIP_NULL, VIP_NULL)) {
            cmd_link(hw, (vip_uint32_t*)(logical_tmp + cmd_size_tmp), trigger_physical, trigger_size);
#if vpmdENABLE_VIDEO_MEMORY_CACHE
            vipdrv_mem_flush_cache(handle_tmp, VIPDRV_CACHE_FLUSH);
#endif
            trigger_physical = physical_tmp;
            trigger_size = cmd_size_tmp + LINK_SIZE;
            PRINTK_I("preload physical=0x%x, size=0x%x\n", physical_tmp, trigger_size);
        }
    }
#endif

    if (vip_false_e == init_done) {
        vip_uint8_t* logical_tmp = VIP_NULL;
        vip_uint32_t cmd_size_tmp = 0;
        vip_virtual_t physical_tmp = 0;
        vip_uint32_t handle_tmp = 0;
        vipdrv_hardware_t* hardware = &(task->device->hardware[task->core_index]);
        if (VIP_SUCCESS == vipdrv_task_desc_get_cmdbuf(tsk_desc, task, VIPDRV_TASK_CMD_INIT, 0, &handle_tmp,
                                                       &logical_tmp, &physical_tmp, &cmd_size_tmp, VIP_NULL,
                                                       VIP_NULL)) {
            cmd_link(hardware, (vip_uint32_t*)(logical_tmp + cmd_size_tmp), trigger_physical, trigger_size);
#if vpmdENABLE_VIDEO_MEMORY_CACHE
            vipdrv_mem_flush_cache(handle_tmp, VIPDRV_CACHE_FLUSH);
#endif
            trigger_physical = physical_tmp;
            trigger_size = cmd_size_tmp + LINK_SIZE;

            PRINTK_I("init cmd physical=0x%x, size=0x%x\n", physical_tmp, trigger_size);
#if vpmdTASK_CMD_DUMP
            PRINTK("task-init-cmd-running\n");
#endif
        }
        VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
        hw->init_done = vip_true_e;
        VIPDRV_LOOP_HARDWARE_IN_TASK_END
    }

#if vpmdTASK_PARALLEL_ASYNC
    {
        vip_uint32_t mem_id = 0;
        vip_uint8_t* buffer = VIP_NULL;
        vip_uint32_t size = 0;
        vipOnError(vipdrv_task_desc_get_cmdbuf(tsk_desc, task, VIPDRV_TASK_CMD_SUBTASK,
                                               task->subtask_index + task->subtask_count - 1, &mem_id,
                                               &buffer, VIP_NULL, &size, VIP_NULL, VIP_NULL));
        buffer += size + SEMAPHORE_STALL;
#if vpmdFLEXA_DMA
        buffer += FLEXA_DMA_APPEND_CMD_SIZE;
#endif

        VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
        vip_uint32_t start_index = 0;
        vip_uint32_t end_index = 0;

        start_index = hw->wl_end_index;
        end_index = (hw->wl_end_index + 1) % WL_TABLE_COUNT;

        cmd_wait(hw, (vip_uint32_t*)(hw->wl_table[end_index].logical), WAIT_TIME_EXE);
        if (0 == hw_index) {
            /* enable irq */
            buffer += cmd_append_irq(buffer, hw->core_id, start_index);
        }
        buffer += cmd_chip_enable((vip_uint32_t*)buffer, hw->core_id, vip_false_e);
        buffer += cmd_link(hw, (vip_uint32_t*)buffer, hw->wl_table[end_index].physical, WAIT_LINK_SIZE);
        VIPDRV_LOOP_HARDWARE_IN_TASK_END

#if vpmdENABLE_VIDEO_MEMORY_CACHE
        vipdrv_mem_flush_cache(mem_id, VIPDRV_CACHE_FLUSH);
#endif
    }
#endif

#if vpmdENABLE_MMU
    {
        vip_bool_e flush_mmu = vip_false_e;
        VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
        if (vip_true_e == hw->flush_mmu) {
            flush_mmu = vip_true_e;
            hw->flush_mmu = vip_false_e;
        }
        VIPDRV_LOOP_HARDWARE_IN_TASK_END
        if (vip_true_e == flush_mmu) {
            vipdrv_task_flush_mmu(task, &trigger_physical, &trigger_size);
        }
    }
#endif

    VIPDRV_SHOW_TASK_INFO(task, "submit to hw", 0);
#if vpmdENABLE_TASK_PROFILE && (!vpmdTASK_PARALLEL_ASYNC)
    VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
    vipdrv_hw_profile_reset(hw);
    VIPDRV_LOOP_HARDWARE_IN_TASK_END
#endif
    vipdrv_task_profile_start(task);

    VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
#if vpmdHARDWARE_BYPASS_MODE
    if (tsk_desc->bypass_sbmit) {
        if (0 == hw_index) {
            HARDWARE_BYPASS_SUBMIT()
        }
    } else
#endif
    {
        /* submit to hardware */
#if vpmdTASK_PARALLEL_ASYNC
        vip_uint32_t start_index = hw->wl_end_index;
        cmd_link(hw, (vip_uint32_t*)(hw->wl_table[start_index].logical), trigger_physical, trigger_size);
        PRINTK_D("submit task_id=0x%x, link to core%d wl index=0x%x\n", task->task_id, hw->core_id,
                 start_index);
#else
        vipOnError(vipdrv_hw_trigger(hw, trigger_physical, trigger_size));
#endif
    }
    VIPDRV_LOOP_HARDWARE_IN_TASK_END

    vipdrv_database_unuse(&context->tskDesc_database, tsk_index);

    return status;
onError:
    vipdrv_database_unuse(&context->tskDesc_database, tsk_index);
    PRINTK_E("task submit bottom half dev%d task_id=0x%x\n", task->device->device_index, task->task_id);
    return status;
}

vip_status_e vipdrv_task_submit(vipdrv_task_t* task)
{
    vip_status_e status = VIP_SUCCESS;
    if (0 == task->task_id) {
        vipGoOnError(VIP_ERROR_INVALID_ARGUMENTS);
    }
#if vpmdENABLE_RECOVERY
    VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
    if (0 > hw->recovery_times) {
        PRINTK_E("device %d recover fail last time\n", task->device->device_index);
        vipGoOnError(VIP_ERROR_FAILURE);
    }
    VIPDRV_LOOP_HARDWARE_IN_TASK_END
#endif

#if vpmdENABLE_USER_CONTROL_POWER
    VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
    VIPDRV_CHECK_USER_PM_STATUS();
    VIPDRV_LOOP_HARDWARE_IN_TASK_END
#endif

#if vpmdENABLE_SUSPEND_RESUME || vpmdPOWER_OFF_TIMEOUT
    VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
    status = vipdrv_pm_check_power(hw);
    if (status != VIP_SUCCESS) {
        PRINTK_E("check power in submit status=%d\n", status);
        vipGoOnError(status);
    }
    VIPDRV_LOOP_HARDWARE_IN_TASK_END
#endif

    PRINTK_D("dev%d submit task_id=0x%x, subtask_index[%d ~ %d]\n", task->device->device_index, task->task_id,
             task->subtask_index, task->subtask_index + task->subtask_count);

    vipOnError(vipdrv_task_submit_bottom_half(task));

    vipdrv_task_history_record(task);

    return status;
onError:
    PRINTK_E("submit cmds to hardware status=%d\n", status);
    vipdrv_task_desc_dump(task);
    return status;
}

#if vpmdENABLE_POLLING
/*
@brief poll to waiting hardware going to idle.
@param timeout the number of milliseconds this waiting.
*/
vip_status_e vipdrv_task_wait_poll(vipdrv_task_t* task, vip_uint32_t timeout)
{
#define POLL_SPACE 5 /* 5ms */
    vip_status_e status = VIP_SUCCESS;
    vip_int32_t count = 0, max_count = 0;
    vip_uint32_t idle_reg = 0;
    vip_int32_t try_wait_cnt = 3;

    VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
    max_count = (vip_int32_t)timeout / POLL_SPACE;

    PRINTK_D("dev%d hw%d max polling count=%d...\n", dev->device_index, hw->core_index, max_count);
    if (vip_true_e == vipdrv_os_get_atomic(hw->idle)) {
        PRINTK_I("dev%d hw%d  wait poll is in idle status\n", dev->device_index, hw->core_index);
        continue;
    }

    while (try_wait_cnt > 0) {
        count = 0;
        vipdrv_read_register(hw, 0x00004, &idle_reg);
        while (((idle_reg & EXPECT_IDLE_VALUE_ALL_MODULE) != EXPECT_IDLE_VALUE_ALL_MODULE) &&
               (0 == hw->irq_local_value) && (count <= max_count)) {
            vipdrv_os_delay(POLL_SPACE);
            vipdrv_read_register(hw, 0x00004, &idle_reg);
            count++;
            vipOnError(vipdrv_task_check_error(hw));

#if vpmdENABLE_FUSA
            vipOnError(vipdrv_fusa_polling(hw));
#endif
        }

        if (count >= max_count) {
            PRINTK_E("dev%d hw%d polling timeout=%d, idle status=0x%x\n", dev->device_index, hw->core_index,
                     timeout, idle_reg);
            break;
        }

        try_wait_cnt--;
    }

    if (hw->irq_local_value) {
        PRINTK_E("dev%d hw%d irq local value of hardware=0x%x\n", dev->device_index, hw->core_index,
                 hw->irq_local_value);
        break;
    }
    PRINTK_D("dev%d hw%d real polling count=%d...\n", dev->device_index, hw->core_index, count);

    if (try_wait_cnt > 0) {
        vipGoOnError(VIP_ERROR_TIMEOUT);
        break;
    }

    VIPDRV_LOOP_HARDWARE_IN_TASK_END

onError:
    return status;
}
#endif

#if vpmdTASK_SERIAL_SYNC || vpmdTASK_PARALLEL_SYNC
vip_status_e vipdrv_task_wait(vipdrv_task_t* task, vipdrv_wait_param_t* wait_param)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t timeout = wait_param->time_out;
    vipdrv_device_t* device = VIP_NULL;
    vipdrv_hardware_t* hardware = VIP_NULL;
    if (0 == task->task_id) {
        vipGoOnError(VIP_ERROR_INVALID_ARGUMENTS);
    }
    device = task->device;
    hardware = &device->hardware[task->core_index];

    if (vip_false_e == vipdrv_os_get_atomic(hardware->idle)) {
        PRINTK_I("dev%d wait task_id=0x%x start\n", device->device_index, task->task_id);
#if vpmdENABLE_POLLING
        status = vipdrv_task_wait_poll(task, timeout);
        if (status == VIP_ERROR_TIMEOUT) {
            VIPDRV_DUMP_STACK();
            VIPDRV_SHOW_TASK_INFO(task, "wait task irq", 1);
            PRINTK_E("dev%d wait task_id=0x%x timeout=%ums\n", device->device_index, task->task_id, timeout);
            goto Exception;
        }
#else
        /* wait interrupt on first core */
        if ((VIP_NULL == hardware->irq_queue) || (VIP_NULL == hardware->irq_value)) {
            PRINTK_E("wait interrupt. int queue or int falg is NULL\n");
            return VIP_ERROR_OUT_OF_MEMORY;
        }
#if vpmdFLEXA_DMA
wait_irq:
#endif
        status = vipdrv_os_wait_interrupt(hardware->irq_queue, hardware->irq_value, timeout,
                                          wait_param->mask);
        *hardware->irq_value &= (~IRQ_VALUE_FLAG);
        vipdrv_os_dec_atomic(*hardware->irq_count);
#if vpmdFLEXA_DMA
        {
            vip_bool_e continue_mode;
            vip_uint32_t task_desc_index;
            vipdrv_task_descriptor_t* task_desc = VIP_NULL;
            vipdrv_context_t* context = task->device->context;
            task_desc_index = vipdrv_task_desc_id2index(task->task_id);

            if (VIP_SUCCESS ==
                vipdrv_database_use(&context->tskDesc_database, task_desc_index, (void**)&task_desc)) {
                continue_mode = task_desc->continue_mode;
                vipdrv_database_unuse(&context->tskDesc_database, task_desc_index);
            }
            if (continue_mode) {
                PRINTK_I("taskid:0x%x,continue mode=%s\n", task->task_id,
                         continue_mode == 1 ? "enable" : "disable");
                vipdrv_os_delay(10);
                timeout = ~0;
                goto wait_irq;
            }
        }
#endif

        if (status == VIP_ERROR_TIMEOUT) {
            VIPDRV_DUMP_STACK();
            VIPDRV_SHOW_TASK_INFO(task, "wait task irq", 1);
            PRINTK_E("dev%d wait task_id=0x%x timeout=%ums\n", device->device_index, task->task_id, timeout);
            goto Exception;
        } else {
            status = vipdrv_task_check_irq_value(hardware);
            if (status == VIP_ERROR_TIMEOUT) {
                PRINTK_E("check task irq value=0x%x\n", *hardware->irq_value);
                goto Exception;
            } else if (status == VIP_ERROR_CANCELED) {
                goto Exception;
            } else if ((status != VIP_SUCCESS) && (status != VIP_ERROR_RECOVERY)) {
                PRINTK_E("dev%d check irq value status=%d\n", device->device_index, status);
                vipGoOnError(status);
            }
        }
#endif

        vipdrv_task_profile_end(task);

        /* Then link back to the WL commands for letting vip going to idle. */
        VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
        if (VIP_SUCCESS != vipdrv_hw_idle(hw)) {
            PRINTK_E("hw%d not idle.\n", hw->core_id);
            vipGoOnError(VIP_ERROR_FAILURE)
        }
#if vpmdENABLE_RECOVERY
        hw->recovery_times = MAX_RECOVERY_TIMES;
#endif
        VIPDRV_LOOP_HARDWARE_IN_TASK_END

        PRINTK_I("dev%d wait task_id=0x%x done\n", device->device_index, task->task_id);
    }
    return status;

Exception:
    VIPDRV_SHOW_TASK_INFO_IMPL(task, "wait task exception", 1);
#if vpmdENABLE_HANG_DUMP
    if (VIP_ERROR_TIMEOUT == status) {
        vipdrv_hang_dump(task);
    }
#endif

#if (!vpmdENABLE_RECOVERY) && vpmdENABLE_CANCELATION
    if (VIP_ERROR_TIMEOUT == status) {
        PRINTK_E("dev%d, sys_time=0x%"PRIx64", error wait irq hardware hang.\n", device->device_index,
                 vipdrv_os_get_time());
    } else
#endif
#if vpmdENABLE_RECOVERY || vpmdENABLE_CANCELATION
    {
        vip_uint8_t recover_flag[vipdMP_NUM] = {0};
        vip_uint32_t i = 0;
        vip_status_e recover_status = VIP_SUCCESS;
        for (i = 0; i < task->core_cnt; i++) {
            recover_flag[task->core_index + i] = 1;
        }
        recover_status = vipdrv_task_recover(device, recover_flag);
        if (VIP_SUCCESS == recover_status) {
            if (VIP_ERROR_TIMEOUT == status) {
                status = VIP_ERROR_RECOVERY;
            } else {
                status = VIP_ERROR_CANCELED;
            }
        }

        for (i = 0; i < task->core_cnt; i++) {
            hardware = &device->hardware[i];
            VIPDRV_CHECK_NULL(hardware);
            hardware->hw_submit_count = 0;
            hardware->user_submit_count = 0;
#if vpmdENABLE_RECOVERY
            if (VIP_ERROR_TIMEOUT == status) {
                hardware->recovery_times--;
            }
#endif
            PRINTK_F("dev%d hw%d task_id=0x%x recovery done.\n", hardware->device->device_index,
                     hardware->core_index, task->task_id);
        }
    }
#endif
onError:
    PRINTK_E("wait task_id=0x%x complete status=%d\n", task->task_id, status);
    return status;
}
#endif

#if vpmdENABLE_L2_SCHEDULE
vip_status_e vipdrv_task_alloc_L2(vipdrv_mem_heap_t* l2_sram_heap, vip_uint32_t l2_size,
                                  vip_uint32_t* l2_addr)
{
    vip_status_e status = VIP_SUCCESS;

    status = vipdrv_mem_heap_alloc(l2_sram_heap, l2_size, l2_addr);
    if (status != VIP_SUCCESS) {
        PRINTK_E("l2 sram heap allocate error\n");
        return VIP_ERROR_FAILURE;
    }
    /* TODO: Modify command */

    return status;
}

vip_status_e vipdrv_task_free_L2(vipdrv_mem_heap_t* l2_sram_heap, vip_uint32_t* l2_addr)
{
    vip_status_e status = VIP_SUCCESS;

    if (0 != (*l2_addr)) {
        status = vipdrv_mem_heap_free(l2_sram_heap, *l2_addr);
        *l2_addr = 0;
    }
    return status;
}

vip_status_e vipdrv_task_patch_L2(vipdrv_task_control_block_t* tskTCB)
{
    vip_status_e status = VIP_SUCCESS;

    vip_uint8_t* logical = VIP_NULL;
    vipdrv_task_t* task = VIP_NULL;
    vip_uint32_t i = 0, j = 0, k = 0;
    vip_uint32_t* command = VIP_NULL;
    vip_uint32_t task_index = 0, states_count = 0;
    vipdrv_context_t* context = VIP_NULL;
    vipdrv_task_descriptor_t* tsk_desc = VIP_NULL;
    vipdrv_subtask_info_t* sub_task = VIP_NULL;
    /*gdma, edma*/
    vip_uint32_t region_base_cmd[L2_REGION_ID_TYPE] = {0x08017B0A, 0x08017B25};

    task = &tskTCB->task;
    context = task->device->context;
    task_index = vipdrv_task_desc_id2index(task->task_id);

    status = vipdrv_database_use(&context->tskDesc_database, task_index, (void**)&tsk_desc);
    if (VIP_SUCCESS != status) {
        return status;
    }

    /* patch for l2 sram region base */
    for (i = 0; i < task->subtask_count; i++) {
        sub_task = &tsk_desc->subtasks[i + task->subtask_index];
        vipOnError(vipdrv_mem_get_info(context, sub_task->cmd.mem_id, &logical, VIP_NULL, VIP_NULL, VIP_NULL,
                                       VIP_NULL, VIP_NULL));
        for (j = 0; j < sub_task->patch_cnt; j++) {
            vipdrv_subtask_patch_info_t* patch_info = &sub_task->patch_info[j];
            switch (patch_info->type) {
            case VIPDRV_TASK_PATCH_L2SRAM: {
                command = (vip_uint32_t*)(logical + patch_info->offset);
                for (k = 0; k < L2_REGION_ID_CNT; k++) {
                    /* gmda */
                    command[states_count++] = L2_REGION_ID_BASE + region_base_cmd[0] + k;
                    command[states_count++] = tskTCB->l2_addr;
                    /* edma */
                    command[states_count++] = L2_REGION_ID_BASE + region_base_cmd[1] + k;
                    command[states_count++] = tskTCB->l2_addr;
                }
                if (L2_REGION_ID_CNT * ONE_CMD_SIZE * L2_REGION_ID_TYPE > patch_info->size) {
                    PRINTK_E("patch l2 error, max patch cmd size=%d\n", patch_info->size);
                    vipGoOnError(VIP_ERROR_FAILURE);
                }
            } break;

            default:
                break;
            }
        }
#if vpmdENABLE_VIDEO_MEMORY_CACHE
        vipdrv_mem_flush_cache(sub_task->cmd.mem_id, VIPDRV_CACHE_FLUSH);
#endif
    }

onError:
    return status;
}
#endif
