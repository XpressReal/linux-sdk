/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/
#undef VIPDRV_LOG_ZONE
#define VIPDRV_LOG_ZONE VIPDRV_LOG_ZONE_TASK

#include <vip_drv_task_descriptor.h>
#include <vip_drv_context.h>
#include <vip_drv_task_common.h>
#include <vip_drv_debug.h>
#include <vip_drv_task_schedule.h>
#if vpmdENABLE_MMU
#include <vip_drv_mmu.h>
#endif


static vip_status_e free_task_descriptor(void* element)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_task_descriptor_t* tsk_desc = (vipdrv_task_descriptor_t*)element;
    if (VIP_NULL != tsk_desc->subtasks) {
#if vpmdTASK_SCHEDULE
        vip_uint32_t i = 0;
        for (i = 0; i < tsk_desc->subtask_count; i++) {
            if (VIP_NULL != tsk_desc->subtasks[i].patch_info) {
                vipdrv_os_free_memory(tsk_desc->subtasks[i].patch_info);
                tsk_desc->subtasks[i].patch_info = VIP_NULL;
            }
        }
#endif
        vipdrv_os_free_memory(tsk_desc->subtasks);
        tsk_desc->subtasks = VIP_NULL;
    }
    tsk_desc->pid = 0;
    tsk_desc->subtask_count = 0;

    return status;
}

vip_status_e vipdrv_task_desc_init(void)
{
    vipdrv_database_t* tskDesc_database =
                (vipdrv_database_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TASK_DESC);
    return vipdrv_database_init(tskDesc_database, 16, sizeof(vipdrv_task_descriptor_t), "task-desc",
                                free_task_descriptor);
}

vip_status_e vipdrv_task_desc_uninit(void)
{
    vipdrv_database_t* tskDesc_database =
                (vipdrv_database_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TASK_DESC);
    vipdrv_database_destroy(tskDesc_database);
    return VIP_SUCCESS;
}

static vip_bool_e task_descriptor_check_skip(vip_uint32_t task_id)
{
    vipdrv_database_t* tskDesc_database =
                (vipdrv_database_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TASK_DESC);
    vipdrv_task_descriptor_t* tsk_desc = VIP_NULL;
    vip_uint32_t index = vipdrv_task_desc_id2index(task_id);
    vip_bool_e skip = vip_true_e;
    if (VIP_SUCCESS == vipdrv_database_use(tskDesc_database, index, (void**)&tsk_desc)) {
        if (tsk_desc->pid == vipdrv_os_get_pid() && /* each process submit own task */
            !tsk_desc->skip) {                      /* set by debugfs */
            skip = vip_false_e;
        }
        vipdrv_database_unuse(tskDesc_database, index);
    }
    return skip;
}

static vip_status_e vipdrv_task_desc_submit_param_check(vipdrv_device_t* device,
                                                        vipdrv_submit_task_param_t* sbmt_para)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t task_id = sbmt_para->task_id;
    vipdrv_database_t* tskDesc_database =
                (vipdrv_database_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TASK_DESC);
    vipdrv_task_descriptor_t* tsk_desc = VIP_NULL;
    vip_uint32_t index = vipdrv_task_desc_id2index(task_id);

    if (sbmt_para->core_index + sbmt_para->core_cnt > device->hardware_count) {
        PRINTK_E("device core cnt=%d, but commit need core [%d, %d)\n", device->hardware_count,
                 sbmt_para->core_index, sbmt_para->core_index + sbmt_para->core_cnt);
        vipGoOnError(VIP_ERROR_OUT_OF_RESOURCE);
    }

    status = vipdrv_database_use(tskDesc_database, index, (void**)&tsk_desc);
    if (VIP_SUCCESS == status) {
        /* each process submit own task */
        if (tsk_desc->pid != vipdrv_os_get_pid()) {
            PRINTK_E("tsk_desc pid=0x%x not match cur pid\n", tsk_desc->pid);
            vipdrv_database_unuse(tskDesc_database, index);
            vipGoOnError(VIP_ERROR_NOT_SUPPORTED);
        }
        if ((sbmt_para->subtask_index + sbmt_para->subtask_cnt) > tsk_desc->subtask_count) {
            vipdrv_database_unuse(tskDesc_database, index);
            vipGoOnError(VIP_ERROR_NOT_SUPPORTED);
        }

/* update submit params info to task-desc.*/
#if !vpmdTASK_SCHEDULE
        {
            vip_uint32_t i = 0;
            for (i = 0; i < sbmt_para->subtask_cnt; i++) {
                vipdrv_subtask_info_t* subtask = &tsk_desc->subtasks[i + sbmt_para->subtask_index];
                subtask->core_index = sbmt_para->core_index;
            }
        }
#endif

        vipdrv_database_unuse(tskDesc_database, index);
    } else {
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    return status;
onError:
    PRINTK_E("check task submit param\n");
    vipdrv_task_submit_parameter_dump(sbmt_para);
    return status;
}

/* Get the command buffer video memory information of vipdrv_task_cmd_type_e in the task
physical: the base address of command buffer
size: the real size of command buffer, not include APPEND cmd.
*/
vip_status_e vipdrv_task_desc_get_cmdbuf(vipdrv_task_descriptor_t* tsk_desc, vipdrv_task_t* task,
                                         vipdrv_task_cmd_type_e type, vip_uint32_t subtask_index,
                                         vip_uint32_t* mem_id, vip_uint8_t** logical, vip_virtual_t* physical,
                                         vip_uint32_t* size, vip_uint32_t* pid, vip_uint32_t* task_id)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_context_t* context = task->device->context;
    vip_physical_t mem_phy = 0;
    vip_size_t mem_size = 0;
    vip_uint32_t cmd_size = 0;
    vip_uint32_t cmd_mem_id = 0;

    switch (type) {
    case VIPDRV_TASK_CMD_SUBTASK: {
        if (subtask_index >= tsk_desc->subtask_count) {
            status = VIP_ERROR_OUT_OF_MEMORY;
            PRINTK_E("subtask index=%d out of range\n", subtask_index);
        } else {
            cmd_mem_id = tsk_desc->subtasks[subtask_index].cmd.mem_id;
            cmd_size = tsk_desc->subtasks[subtask_index].cmd.size;
            vipOnError(vipdrv_mem_get_info(context, cmd_mem_id, logical, &mem_phy, VIP_NULL, &mem_size, pid,
                                           task_id));
        }
    } break;

    case VIPDRV_TASK_CMD_INIT: {
        if (0 != tsk_desc->init_cmd.mem_id) {
            cmd_mem_id = tsk_desc->init_cmd.mem_id;
            cmd_size = tsk_desc->init_cmd.size;
            vipOnError(vipdrv_mem_get_info(context, cmd_mem_id, logical, &mem_phy, VIP_NULL, &mem_size, pid,
                                           task_id));
        } else {
            vipGoOnError(VIP_ERROR_FAILURE);
        }
    } break;

    case VIPDRV_TASK_CMD_PRELOAD: {
        if (0 != tsk_desc->preload_cmd.mem_id) {
            cmd_mem_id = tsk_desc->preload_cmd.mem_id;
            cmd_size = tsk_desc->preload_cmd.size;
            vipOnError(vipdrv_mem_get_info(context, cmd_mem_id, logical, &mem_phy, VIP_NULL, &mem_size, pid,
                                           task_id));
        } else {
            vipGoOnError(VIP_ERROR_FAILURE);
        }
    } break;

    default:
        PRINTK_E("not implement this type=%d\n", type);
        status = VIP_ERROR_NOT_SUPPORTED;
        break;
    }

    if (!vipdrv_context_query_featureDB(task->device->device_index, VIP_FEATURE_FE_40BIT_ADDRESS)) {
        if (mem_phy & 0xFFFFFFFF00000000ULL) {
            PRINTK_E("get cmd info phy add=0x%"PRIx64"\n", mem_phy);
            vipGoOnError(VIP_ERROR_OUT_OF_RESOURCE);
        }
    }

    if (cmd_size > (vip_uint32_t)mem_size) {
        PRINTK_E("get cmdbuf type=%d overflow cmd_size=0x%x mem_id=0x%x mem_size=0x%x\n", type, cmd_size,
                 cmd_mem_id, (vip_uint32_t)mem_size);
        vipGoOnError(VIP_ERROR_OUT_OF_RESOURCE);
    }

    if (VIP_NULL != physical) {
        *physical = (vip_virtual_t)mem_phy;
    }
    if (VIP_NULL != mem_id) {
        *mem_id = cmd_mem_id;
    }
    if (VIP_NULL != size) {
        *size = cmd_size;
    }

onError:
    return status;
}

vip_status_e vipdrv_task_desc_submit(vipdrv_submit_task_param_t* sbmt_para)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_device_t* device = VIP_NULL;

    device = vipdrv_get_device(sbmt_para->device_index);
    vipIsNULL(device);

#if (vpmdENABLE_DEBUG_LOG >= 4) && (VIPDRV_LOG_ZONE_ENABLED & VIPDRV_LOG_ZONE_TASK)
    if (*(vip_uint8_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_LOG_LEVEL) >= 4) {
        vipdrv_task_submit_parameter_dump(sbmt_para);
    }
#endif

    vipOnError(vipdrv_task_desc_submit_param_check(device, sbmt_para));
    vipOnError(vipdrv_task_schedule(device, sbmt_para));

#if vpmdENABLE_USER_CONTROL_POWER
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_MtoN_START(device, sbmt_para->core_index, sbmt_para->core_cnt)
    VIPDRV_CHECK_USER_PM_STATUS();
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_MtoN_END
#endif

    if (vip_true_e == task_descriptor_check_skip(sbmt_para->task_id)){
        PRINTK_I("user do submit skip task_id=0x%x\n", sbmt_para->task_id);
    } else {
        vipOnError(vipdrv_task_tcb_submit(device, sbmt_para));
    }

    VIPDRV_LOOP_HARDWARE_IN_DEVICE_MtoN_START(device, sbmt_para->core_index, sbmt_para->core_cnt)
                hw->user_submit_count++;
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_MtoN_END

    PRINTK_I("user end do submit task_id=0x%x device%d\n", sbmt_para->task_id,
             device->device_index);
    return status;
onError:
    PRINTK_E("submit task desc task_id=0x%x status=%d\n", sbmt_para->task_id, status);
    return status;
}

vip_status_e vipdrv_task_desc_wait(vipdrv_wait_task_param_t* wait_para)
{
    vip_status_e status = VIP_SUCCESS;
    PRINTK_I("user start do wait task_id=0x%x, subtsk_idex=%d, timeout=%u\n", wait_para->task_id,
             wait_para->subtask_index, wait_para->timeout);

    if (vip_true_e == task_descriptor_check_skip(wait_para->task_id)) {
        PRINTK_I("user do wait skip task_id=0x%x subtsk_idex=%d\n", wait_para->task_id,
                 wait_para->subtask_index);
    } else {
        vipOnError(vipdrv_task_tcb_wait(wait_para));
    }
    PRINTK_I("user end do wait task_id=0x%x subtsk_idex=%d\n", wait_para->task_id, wait_para->subtask_index);

onError:
    return status;
}

/* the index of task descriptor database to task_id */
vip_uint32_t vipdrv_task_desc_index2id(vip_uint32_t index)
{
    vip_uint32_t task_id = TASK_MAGIC_DATA + (vip_uint32_t)(index << TASK_INDEX_SHIFT);

    return task_id;
}

/* covert task_id to index of task descriptor database */
vip_uint32_t vipdrv_task_desc_id2index(vip_uint32_t task_id)
{
    vip_uint32_t index = -1;
    if (task_id >= TASK_MAGIC_DATA) {
        index = (task_id - TASK_MAGIC_DATA) >> TASK_INDEX_SHIFT;
    }

    return index;
}

vip_status_e vipdrv_task_desc_valid_check(vip_uint32_t task_id)
{
    vip_status_e status = VIP_SUCCESS;

    if (0 != task_id) {
        if (-1 == (vip_int32_t)vipdrv_task_desc_id2index(task_id)) {
            PRINTK_E("invalid task id=0x%x\n", task_id);
            vipGoOnError(VIP_ERROR_INVALID_ARGUMENTS);
        }
    }

onError:
    return status;
}

vip_status_e vipdrv_task_desc_create(vipdrv_create_task_param_t* tsk_param)
{
    vipdrv_database_t* tskDesc_database =
                (vipdrv_database_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TASK_DESC);
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t db_index = 0, j = 0;
    vipdrv_task_descriptor_t* tsk_desc = VIP_NULL;

    if (0 == tsk_param->subtask_count) {
        PRINTK_E("task should have one sub-task at least\n");
        vipGoOnError(VIP_ERROR_NOT_SUPPORTED);
    }
    if (tsk_param->subtask_count > (1 << TASK_INDEX_SHIFT)) {
        PRINTK_E("max support subtsk cnt=%d, cur cnt=%d\n", 1 << TASK_INDEX_SHIFT, tsk_param->subtask_count);
        vipGoOnError(VIP_ERROR_NOT_SUPPORTED);
    }

    status = vipdrv_database_insert(tskDesc_database, &db_index);
    if (VIP_SUCCESS != status) {
        PRINTK_E("task desc create insert database status=%d\n", status);
        vipGoOnError(status);
    }

    tsk_param->task_id = vipdrv_task_desc_index2id(db_index);
    vipOnError(vipdrv_database_use(tskDesc_database, db_index, (void**)&tsk_desc));
    vipdrv_os_zero_memory((void*)tsk_desc, sizeof(vipdrv_task_descriptor_t));
    tsk_desc->subtask_count = tsk_param->subtask_count;
    tsk_desc->pid = vipdrv_os_get_pid();
    tsk_desc->timeout = vpmdHARDWARE_TIMEOUT;
    vipdrv_os_snprint(tsk_desc->task_name, TASK_NAME_LENGTH, tsk_param->task_name);
    status = vipdrv_os_allocate_memory(sizeof(vipdrv_subtask_info_t) * tsk_desc->subtask_count,
                                       (void**)&tsk_desc->subtasks);
    if (VIP_SUCCESS != status) {
        PRINTK_E("create task, allocate fail\n");
        vipdrv_database_remove(tskDesc_database, db_index, vip_false_e);
        vipdrv_database_unuse(tskDesc_database, db_index);
        vipGoOnError(status);
    }
    vipdrv_os_zero_memory(tsk_desc->subtasks, sizeof(vipdrv_subtask_info_t) * tsk_desc->subtask_count);
    for (j = 0; j < tsk_desc->subtask_count; j++) {
        tsk_desc->subtasks[j].avg_time = DEFAULT_INFER_TIME;
    }
    PRINTK_D("create task name=%s, pid=0x%x, task_id=0x%x, max subtask cnt=%d\n", tsk_desc->task_name,
             tsk_desc->pid, tsk_param->task_id, tsk_param->subtask_count);
    vipdrv_database_unuse(tskDesc_database, db_index);

    return status;
onError:
    PRINTK_E("create task desc property name=%s status=%d\n", tsk_param->task_name, status);
    return status;
}

vip_status_e vipdrv_task_desc_set_property(vipdrv_set_task_property_t* task_property)
{
    vipdrv_database_t* tskDesc_database =
                (vipdrv_database_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TASK_DESC);
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t index = vipdrv_task_desc_id2index(task_property->task_id);
    vipdrv_task_descriptor_t* tsk_desc = VIP_NULL;

    vipOnError(vipdrv_database_use(tskDesc_database, index, (void**)&tsk_desc));
    if (task_property->index >= tsk_desc->subtask_count) {
        PRINTK_E("set task_id=0x%x, subtask index=%d is out of range [0, %d)\n", task_property->task_id,
                 task_property->index, tsk_desc->subtask_count);
        vipdrv_database_unuse(tskDesc_database, index);
        vipGoOnError(VIP_ERROR_OUT_OF_RESOURCE);
    }

    switch (task_property->property) {
#if vpmdTASK_SCHEDULE
    case VIPDRV_TASK_PROP_PATCH_INFO: {
        vipdrv_subtask_info_t* subtask = &tsk_desc->subtasks[task_property->index];
        vip_uint32_t patch_index = task_property->param.patch_info.patch_index;
        if (patch_index < subtask->patch_cnt) {
            subtask->patch_info[patch_index].core_index = task_property->param.patch_info.core_index;
            subtask->patch_info[patch_index].core_count = task_property->param.patch_info.core_count;
            subtask->patch_info[patch_index].offset = task_property->param.patch_info.offset;
            subtask->patch_info[patch_index].size = task_property->param.patch_info.size;
            subtask->patch_info[patch_index].type = task_property->param.patch_info.type;
        }
    } break;

    case VIPDRV_TASK_PROP_PATCH_INFO_DUP: {
        vip_uint32_t dup_tsk_index = vipdrv_task_desc_id2index(task_property->param.dup_info.task_id);
        vip_uint32_t dup_subtsk_index = task_property->param.dup_info.index;
        vip_uint32_t subtsk_index = task_property->index;
        vip_uint32_t size = 0;
        vipdrv_task_descriptor_t* tsk_desc_dup = VIP_NULL;
        if (subtsk_index >= tsk_desc->subtask_count) {
            PRINTK_E("patch in dup subtsk_idx=%d, subtask_cnt=%d\n", subtsk_index, tsk_desc->subtask_count);
            vipdrv_database_unuse(tskDesc_database, index);
            vipGoOnError(VIP_ERROR_OUT_OF_RESOURCE);
        }
        size = sizeof(vipdrv_subtask_patch_info_t) * tsk_desc->subtasks[subtsk_index].patch_cnt;
        if ((size != 0) &&
            (VIP_SUCCESS == vipdrv_database_use(tskDesc_database, dup_tsk_index, (void**)&tsk_desc_dup))) {
            if ((dup_subtsk_index < tsk_desc_dup->subtask_count) &&
                (tsk_desc_dup->subtasks[dup_subtsk_index].patch_cnt ==
                 tsk_desc->subtasks[subtsk_index].patch_cnt)) {
                vipdrv_os_copy_memory(tsk_desc->subtasks[subtsk_index].patch_info,
                                      tsk_desc_dup->subtasks[dup_subtsk_index].patch_info, size);
            }
            vipdrv_database_unuse(tskDesc_database, dup_tsk_index);
        }
    } break;
#endif
    case VIPDRV_TASK_PROP_CMD_INFO: {
        switch (task_property->param.cmd_info.type) {
        case VIPDRV_TASK_CMD_SUBTASK: {
            vipdrv_subtask_info_t* subtask = &tsk_desc->subtasks[task_property->index];
#if vpmdTASK_SCHEDULE
            vip_uint32_t patch_cnt = task_property->param.cmd_info.patch_count;
            vip_uint32_t mem_size = sizeof(vipdrv_subtask_patch_info_t) * patch_cnt;
            if (0 != patch_cnt && patch_cnt != subtask->patch_cnt) {
                if (VIP_NULL != subtask->patch_info) {
                    vipdrv_os_free_memory(subtask->patch_info);
                    subtask->patch_info = VIP_NULL;
                    subtask->patch_cnt = 0;
                }

                status = vipdrv_os_allocate_memory(mem_size, (void**)&subtask->patch_info);
                if (VIP_SUCCESS != status) {
                    PRINTK_E("create patch info for subtask, patch_cnt=%u\n", patch_cnt);
                    vipdrv_database_unuse(tskDesc_database, index);
                    vipGoOnError(VIP_ERROR_OUT_OF_RESOURCE);
                }
                vipdrv_os_zero_memory(subtask->patch_info, mem_size);
                subtask->patch_cnt = patch_cnt;
            }
            subtask->core_index = task_property->param.cmd_info.core_index;
#endif

            subtask->cmd.mem_id = task_property->param.cmd_info.cmd_id;
            subtask->cmd.size = task_property->param.cmd_info.size;
        } break;

        case VIPDRV_TASK_CMD_INIT: {
            tsk_desc->init_cmd.mem_id = task_property->param.cmd_info.cmd_id;
            tsk_desc->init_cmd.size = task_property->param.cmd_info.size;
        } break;

        case VIPDRV_TASK_CMD_PRELOAD: {
            tsk_desc->preload_cmd.mem_id = task_property->param.cmd_info.cmd_id;
            tsk_desc->preload_cmd.size = task_property->param.cmd_info.size;
        } break;

        default:
            PRINTK_E("task_id=0x%x, not implement this cmd type=%d\n", task_property->task_id,
                     task_property->param.cmd_info.type);
            break;
        }
    } break;

    case VIPDRV_TASK_PROP_ATTRIBUTE: {
        /* cycle */
        vip_uint64_t init_time = task_property->param.attr.cycle;
        if (0 < init_time) {
            vip_uint32_t i = 0;
            /* init_time: millisecond(ms) */
            VIPDRV_DO_DIV64(init_time + (vpmdVIP_FREQUENCY - 1), (vip_uint64_t)(vpmdVIP_FREQUENCY),
                            init_time);
            for (i = 0; i < tsk_desc->subtask_count; i++) {
                tsk_desc->subtasks[i].avg_time = init_time * 1000;
            }
            if (0 == tsk_desc->timeout_specify) {
                tsk_desc->timeout = (vip_uint32_t)init_time * TASK_TIMEOUT_FACTOR;
                if (tsk_desc->timeout < 2000) {
                    tsk_desc->timeout = 2000;
                }
            }
            PRINTK_D("task_id=0x%x, cyc=%"PRId64", timeout=%ums\n", task_property->task_id,
                     task_property->param.attr.cycle, tsk_desc->timeout);
        } else {
            if (0 == tsk_desc->timeout_specify) {
                tsk_desc->timeout = vpmdHARDWARE_TIMEOUT;
            }
        }

        tsk_desc->vip_sram_size = task_property->param.attr.vip_sram_size;
    } break;

    case VIPDRV_TASK_PROP_TIMEOUT: {
        tsk_desc->timeout = (vip_uint32_t)task_property->param.value_info;
        tsk_desc->timeout_specify = 1;
    } break;

    case VIPDRV_TASK_PROP_FEATURE_BIT: {
        tsk_desc->cnnprofile_enable = task_property->param.feature_bit.cnn_profile;
        tsk_desc->bypass_sbmit = task_property->param.feature_bit.bypass_sbmit;
        tsk_desc->preload_vipsram = task_property->param.feature_bit.preload_vipsram;
        tsk_desc->app_profile = task_property->param.feature_bit.app_profile;
        tsk_desc->bw_profile = task_property->param.feature_bit.bw_profile;
    } break;

#if vpmdFLEXA_DMA
    case VIPDRV_TASK_PROP_FLEXA_DMA: {
        tsk_desc->continue_mode = task_property->param.value_info;
        PRINTK_I("set task:0x%x,continue mode to %s\n", task_property->task_id,
                 tsk_desc->continue_mode == 1 ? "enable" : "disable");
    } break;
#endif
    default:
        PRINTK_E("task_id=0x%x, create subtask not implement this type=%d\n", task_property->task_id,
                 task_property->property);
        break;
    }
    vipdrv_database_unuse(tskDesc_database, index);

    return status;
onError:
    PRINTK_E("set task desc index=%d property status=%d\n", index, status);
    return status;
}

static vip_status_e destroy_task(vip_uint32_t index)
{
    vipdrv_database_t* tskDesc_database =
                (vipdrv_database_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TASK_DESC);
    vipdrv_database_remove(tskDesc_database, index, vip_false_e);
    PRINTK_D("destroy task index=0x%x\n", vipdrv_task_desc_index2id(index));
    return VIP_SUCCESS;
}

vip_status_e vipdrv_task_desc_destroy(vipdrv_destroy_task_param_t* param)
{
    vip_uint32_t index = vipdrv_task_desc_id2index(param->task_id);
#if vpmdENABLE_MMU
    vip_uint32_t i = 0;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    for (i = 0; i < context->mem_prop_cnt; i++) {
        vipdrv_mmu_page_uninit(gen_mmu_id(vipdrv_os_get_pid(), param->task_id, i));
    }
#endif
    return destroy_task(index);
}

vip_status_e vipdrv_task_desc_force_destroy(vip_uint32_t pid)
{
    vip_uint32_t i = 0, j = 0;
    vipdrv_database_t* tskDesc_database =
                (vipdrv_database_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TASK_DESC);
#if vpmdTASK_QUEUE_USED
    vipdrv_hashmap_t* tskTCB_hashmap = (vipdrv_hashmap_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TCB);
#endif
    vipdrv_task_descriptor_t* tsk_desc = VIP_NULL;

    for (i = 1; i < vipdrv_database_free_pos(tskDesc_database); i++) {
        if (VIP_SUCCESS == vipdrv_database_use(tskDesc_database, i, (void**)&tsk_desc)) {
            if (tsk_desc->pid == pid) {
                vip_bool_e support_cancel = vip_false_e;
                for (j = 0; j < tsk_desc->subtask_count; j++) {
                    vip_uint32_t task_id = j + vipdrv_task_desc_index2id(i);
                    vipdrv_task_control_block_t* tskTCB = VIP_NULL;

#if vpmdTASK_QUEUE_USED
                    vip_uint32_t index = 0;
                    if (VIP_SUCCESS != vipdrv_hashmap_get_by_handle(tskTCB_hashmap, (vip_uint64_t)task_id,
                                                                    &index, (void**)&tskTCB)) {
                        continue;
                    }
#else
                    vip_bool_e valid = vip_false_e;
                    VIPDRV_LOOP_DEVICE_START
                    tskTCB = &dev->tskTCB;
                    if (task_id == tskTCB->task.task_id) {
                        valid = vip_true_e;
                        break;
                    }
                    VIPDRV_LOOP_DEVICE_END
                    if (vip_false_e == valid) {
                        continue;
                    }
#endif

                    if (VIPDRV_TASK_INFER_START == tskTCB->status) {
                        support_cancel = vipdrv_context_query_featureDB(tskTCB->task.device->device_index,
                                                                        VIP_FEATURE_JOB_CANCEL);
                        /* still in inference */
                        if (vip_true_e == support_cancel) {
                            vip_uint8_t cancel_flag[vipdMP_NUM] = {0};
                            vip_uint32_t core_index = 0;
                            for (core_index = 0; core_index < tskTCB->task.core_cnt; core_index++) {
                                cancel_flag[core_index + tskTCB->task.core_index] = 1;
                            }
                            if (VIP_SUCCESS != vipdrv_hw_cancel(tskTCB->task.device, cancel_flag)) {
                                PRINTK_E("dev%d cancel failed during destroy\n",
                                         tskTCB->task.device->device_index);
                            }
                        } else {
                            vipdrv_task_t* task = &tskTCB->task;
                            VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
                            if (VIP_SUCCESS !=
                                vipdrv_hw_wait_idle(hw, 1000, vip_false_e, EXPECT_IDLE_VALUE_ALL_MODULE)) {
                                PRINTK_E("hw%d not idle during destroy\n", hw->core_id);
                            }
                            VIPDRV_LOOP_HARDWARE_IN_TASK_END
                        }
                    }

#if vpmdTASK_QUEUE_USED
                    tskTCB->status = VIPDRV_TASK_EMPTY;
                    if (VIP_NULL != tskTCB->queue_data) {
                        tskTCB->queue_data->v2 = VIP_ERROR_CANCELED;
                    }
                    vipdrv_hashmap_remove_by_index(tskTCB_hashmap, index, vip_false_e);
                    vipdrv_hashmap_unuse(tskTCB_hashmap, index, vip_false_e);
#endif
                }

                destroy_task(i);
            }
            vipdrv_database_unuse(tskDesc_database, i);
        }
    }

    return VIP_SUCCESS;
}

vip_status_e vipdrv_task_desc_query(vipdrv_query_task_param_t* param)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_database_t* tskDesc_database =
                (vipdrv_database_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_TASK_DESC);
    vip_uint32_t task_index = vipdrv_task_desc_id2index(param->task_id);
    vipdrv_task_descriptor_t* tsk_desc = VIP_NULL;
    vipdrv_subtask_info_t* sub_task = VIP_NULL;
    status = vipdrv_database_use(tskDesc_database, task_index, (void**)&tsk_desc);
    if (VIP_SUCCESS != status) {
        PRINTK_E("query task-id=0x%x\n", param->task_id);
        return status;
    }

    if (tsk_desc->subtasks != VIP_NULL) {
        sub_task = &tsk_desc->subtasks[0];
        param->core_index = sub_task->core_index;
    }

    vipdrv_database_unuse(tskDesc_database, task_index);

    return status;
}
