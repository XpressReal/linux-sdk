/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#undef VIPDRV_LOG_ZONE
#define VIPDRV_LOG_ZONE VIPDRV_LOG_ZONE_TASK

#define VIP_LOG_TAG "NPU-tm-sgl"

#include <vip_drv_task_common.h>
#if vpmdTASK_SINGLE
#include <vip_drv_context.h>
#include <vip_drv_debug.h>
#include <vip_drv_task_descriptor.h>

static vip_status_e vipdrv_cmd_timeout_handle(vipdrv_task_t* task)
{
    vip_status_e status = VIP_SUCCESS;
#if vpmdENABLE_RECOVERY
    vipdrv_device_t* device = task->device;
    vip_uint8_t recover_flag[vipdMP_NUM] = {0};
    vip_uint32_t i = 0;
#endif
#if vpmdENABLE_HANG_DUMP
    vipdrv_hang_dump(task);
#endif

#if vpmdENABLE_RECOVERY
    for (i = 0; i < task->core_cnt; i++) {
        vipdrv_hardware_t* hardware = &device->hardware[i];
        recover_flag[task->core_index + i] = 1;
        hardware->recovery_times--;
    }
    status = vipdrv_task_recover(device, recover_flag);
    if (status != VIP_SUCCESS) {
        PRINTK_E("recover\n");
        vipGoOnError(status);
    } else {
        vipGoOnError(VIP_ERROR_RECOVERY);
    }
    PRINTK_I("dev%d task_id=0x%x recovery done, return %d for app use.\n", device->device_index,
             task->task_id, status);
#else
    PRINTK_E("dev%d, sys_time=0x%"PRIx64", error hw hang wait irq.\n", task->device->device_index,
             vipdrv_os_get_time());
    vipGoOnError(VIP_ERROR_TIMEOUT);
#endif

onError:
    return status;
}

/*
@brief wait hardware interrupt return.
*/
vip_status_e vipdrv_task_wait(vipdrv_task_t* task, vipdrv_wait_param_t* wait_parm)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t timeout = wait_parm->time_out;
    vipdrv_device_t* device = VIP_NULL;
    vipdrv_hardware_t* hardware = VIP_NULL;
    if (0 == task->task_id) {
        vipGoOnError(VIP_ERROR_INVALID_ARGUMENTS);
    }
    device = task->device;
    hardware = &device->hardware[task->core_index];

    if (vip_false_e == vipdrv_os_get_atomic(hardware->idle)) {
        PRINTK_I("dev%d wait task_id=0x%x start\n", device->device_index, task->task_id);
#if vpmdENABLE_POLLING
        status = vipdrv_task_wait_poll(task, timeout);
        if (status == VIP_ERROR_TIMEOUT) {
            status = vipdrv_cmd_timeout_handle(task);
            vipGoOnError(status);
        }
#else
        /* wait interrupt on first core */
        if ((VIP_NULL == hardware->irq_queue) || (VIP_NULL == hardware->irq_value)) {
            PRINTK_E("wait interrupt. int queue or int falg is NULL\n");
            return VIP_ERROR_OUT_OF_MEMORY;
        }
        status = vipdrv_os_wait_interrupt(hardware->irq_queue, hardware->irq_value, timeout, wait_parm->mask);
        *hardware->irq_value &= (~IRQ_VALUE_FLAG);
        vipdrv_os_dec_atomic(*hardware->irq_count);

        if (status == VIP_ERROR_TIMEOUT) {
            if (vip_false_e == wait_parm->handle_timeout) {
                /* still have time */
                return VIP_ERROR_NOT_FINISH;
            }
            VIPDRV_DUMP_STACK();
            PRINTK_E("wait interrupt, timeout=%ums....\n", timeout);
            status = vipdrv_cmd_timeout_handle(task);
            vipGoOnError(status);
        } else {
            status = vipdrv_task_check_irq_value(hardware);
            if (status == VIP_ERROR_TIMEOUT) {
                status = vipdrv_cmd_timeout_handle(task);
                vipGoOnError(status);
            } else if ((status != VIP_SUCCESS) && (status != VIP_ERROR_RECOVERY) &&
                       (status != VIP_ERROR_CANCELED)) {
                PRINTK_E("dev%d check irq value status=%d\n", device->device_index, status);
                vipGoOnError(status);
            }
        }
#endif

        vipdrv_task_profile_end(task);

        /* Then link back to the WL commands for letting vip going to idle. */
        VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)
        if (VIP_SUCCESS != vipdrv_hw_idle(hw)) {
            PRINTK_E("hw%d idle.\n", hw->core_id);
            vipGoOnError(VIP_ERROR_FAILURE)
        }
#if vpmdENABLE_RECOVERY
        hw->recovery_times = MAX_RECOVERY_TIMES;
#endif
        VIPDRV_LOOP_HARDWARE_IN_TASK_END

        PRINTK_I("dev%d wait task_id=0x%x done\n", device->device_index, task->task_id);
    }

    return status;
onError:
    PRINTK_E("wait command complete status=%d\n", status);
    return status;
}

#if vpmdENABLE_CANCELATION
static vip_status_e vipdrv_task_do_cancel(vipdrv_task_control_block_t* tskTCB, vipdrv_device_t* device)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint8_t recover_flag[vipdMP_NUM] = {0};
    vipdrv_task_t* task = &tskTCB->task;
    vip_uint32_t i = 0;
    vipdrv_hardware_t* hardware = VIP_NULL;

    for (i = 0; i < task->core_cnt; i++) {
        recover_flag[task->core_index + i] = 1;
    }
    status = vipdrv_task_recover(device, recover_flag);
    tskTCB->status = VIPDRV_TASK_CANCELED;
    hardware = &device->hardware[task->core_index];
    hardware->irq_local_value = IRQ_VALUE_CANCEL;
    *hardware->irq_value |= IRQ_VALUE_FLAG;
#if !vpmdENABLE_POLLING
    vipdrv_os_inc_atomic(*hardware->irq_count);
    vipdrv_os_wakeup_interrupt(hardware->irq_queue);
#endif
    vipdrv_os_udelay(200);
    *hardware->irq_value &= ~IRQ_VALUE_FLAG;

    PRINTK_I("cancel wait irq done, task status=%d\n", tskTCB->status);
    return status;
}
#endif

vip_status_e vipdrv_task_init(void)
{
    vip_status_e status = VIP_SUCCESS;

    VIPDRV_LOOP_DEVICE_START
    status = vipdrv_os_create_mutex((vipdrv_mutex*)&dev->tskTCB.cancel_mutex);
    if (status != VIP_SUCCESS) {
        PRINTK_E("create mutex for cancel task.\n");
        vipGoOnError(VIP_ERROR_IO);
    }
    VIPDRV_LOOP_DEVICE_END

onError:
    return status;
}

vip_status_e vipdrv_task_pre_uninit(void)
{
    vip_status_e status = VIP_SUCCESS;

    return status;
}

vip_status_e vipdrv_task_uninit(void)
{
    vip_status_e status = VIP_SUCCESS;
    VIPDRV_LOOP_DEVICE_START
    if (VIP_NULL != dev->tskTCB.cancel_mutex) {
        vipdrv_os_destroy_mutex(dev->tskTCB.cancel_mutex);
        dev->tskTCB.cancel_mutex = VIP_NULL;
    }
    VIPDRV_LOOP_DEVICE_END

    return status;
}

vip_status_e vipdrv_task_tcb_init(void)
{
    return VIP_SUCCESS;
}

vip_status_e vipdrv_task_tcb_uninit(void)
{
    return VIP_SUCCESS;
}

vip_status_e vipdrv_task_tcb_submit(vipdrv_device_t* device, vipdrv_submit_task_param_t* sbmt_para)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t task_id = sbmt_para->task_id + sbmt_para->subtask_index;
    vipdrv_task_control_block_t* tskTCB = &device->tskTCB;
    vipdrv_task_descriptor_t* tsk_desc = VIP_NULL;
    vip_uint32_t tsk_desc_index = vipdrv_task_desc_id2index(task_id);

    VIPDRV_LOOP_DEVICE_START
    vipdrv_os_lock_mutex(dev->tskTCB.cancel_mutex);
    if (task_id == dev->tskTCB.task.task_id && VIPDRV_TASK_INFER_START == tskTCB->status) {
        PRINTK("pls wait task=0x%x has done on device=%d\n", tskTCB->task.task_id, dev->device_index);
        vipdrv_os_unlock_mutex(dev->tskTCB.cancel_mutex);
        vipGoOnError(status);
    }
    vipdrv_os_unlock_mutex(dev->tskTCB.cancel_mutex);
    VIPDRV_LOOP_DEVICE_END

    vipdrv_os_lock_mutex(tskTCB->cancel_mutex);
    if (VIPDRV_TASK_INFER_START == tskTCB->status) {
        /* only allow one task on this device */
        PRINTK_E("pls submit when last task=0x%x has done\n", tskTCB->task.task_id);
        vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
        vipGoOnError(VIP_ERROR_NOT_SUPPORTED);
    }
    tskTCB->status = VIPDRV_TASK_READY;
    tskTCB->task.subtask_count = sbmt_para->subtask_cnt;
    tskTCB->task.subtask_index = sbmt_para->subtask_index;
    tskTCB->task.task_id = task_id;
    tskTCB->task.device = device;
    tskTCB->task.core_index = sbmt_para->core_index;
    tskTCB->task.core_cnt = sbmt_para->core_cnt;
    if (VIP_SUCCESS ==
        vipdrv_database_use(&device->context->tskDesc_database, tsk_desc_index, (void**)&tsk_desc)) {
        tskTCB->time_out = tsk_desc->timeout;
        vipdrv_database_unuse(&device->context->tskDesc_database, tsk_desc_index);
    }
    vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);

#if vpmdENABLE_POWER_MANAGEMENT
    /* make sure other thread can not change power state during submit */
    vipdrv_pm_lock_device_hw(device, sbmt_para->core_index, sbmt_para->core_cnt);
#endif
    vipdrv_os_lock_mutex(tskTCB->cancel_mutex);
    if (VIPDRV_TASK_CANCELED == tskTCB->status) {
        PRINTK_E("submit is canceled, not submit.\n");
        vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
#if vpmdENABLE_POWER_MANAGEMENT
        vipdrv_pm_unlock_device_hw(device, sbmt_para->core_index, sbmt_para->core_cnt);
#endif
        vipGoOnError(VIP_ERROR_CANCELED);
    }
    status = vipdrv_task_submit(&tskTCB->task);
    if (status != VIP_SUCCESS) {
        PRINTK_E("submit cmd in single TM.\n");
        vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
#if vpmdENABLE_POWER_MANAGEMENT
        vipdrv_pm_unlock_device_hw(device, sbmt_para->core_index, sbmt_para->core_cnt);
#endif
        vipGoOnError(status);
    }
    tskTCB->status = VIPDRV_TASK_INFER_START;
    vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
#if vpmdENABLE_POWER_MANAGEMENT
    vipdrv_pm_unlock_device_hw(device, sbmt_para->core_index, sbmt_para->core_cnt);
#endif

onError:
    return status;
}

vip_status_e vipdrv_task_tcb_wait(vipdrv_wait_task_param_t* wait_para)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_wait_param_t wait_param = {0};
    vipdrv_hardware_t* hardware = VIP_NULL;
    vipdrv_task_control_block_t* tskTCB = VIP_NULL;
    vipdrv_device_t* device = VIP_NULL;
    vipdrv_task_descriptor_t* tsk_desc = VIP_NULL;
    vip_uint32_t tsk_desc_index = vipdrv_task_desc_id2index(wait_para->task_id + wait_para->subtask_index);

    VIPDRV_LOOP_DEVICE_START
    vipdrv_os_lock_mutex(dev->tskTCB.cancel_mutex);
    if (wait_para->task_id + wait_para->subtask_index == dev->tskTCB.task.task_id) {
        tskTCB = &dev->tskTCB;
        device = dev;
        break;
    }
    vipdrv_os_unlock_mutex(dev->tskTCB.cancel_mutex);
    VIPDRV_LOOP_DEVICE_END
    if (VIP_NULL == tskTCB) {
        PRINTK_E("wait TCB is null, wait task_id=0x%x, subtask_index=%d\n", wait_para->task_id,
                 wait_para->subtask_index);
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    if (VIPDRV_TASK_CANCELED == tskTCB->status) {
        PRINTK_E("submit is canceled.\n");
        vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
        vipGoOnError(VIP_ERROR_CANCELED);
    }
    vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);

#if vpmdENABLE_USER_CONTROL_POWER
    VIPDRV_LOOP_HARDWARE_IN_TASK_START(&tskTCB->task)
    VIPDRV_CHECK_USER_PM_STATUS();
    VIPDRV_LOOP_HARDWARE_IN_TASK_END
#endif

    wait_param.mask = IRQ_VALUE_FLAG;
    if (VIP_SUCCESS ==
        vipdrv_database_use(&device->context->tskDesc_database, tsk_desc_index, (void**)&tsk_desc)) {
        vip_uint64_t time = vipdrv_os_get_time();
        VIPDRV_SUB(time, tsk_desc->subtasks[wait_para->subtask_index].cur_time, time, vip_uint64_t);
        VIPDRV_DO_DIV64(time, 1000, time);
        if (tskTCB->time_out > time) {
            time = tskTCB->time_out - time;
            wait_param.time_out = time < wait_para->timeout ? time : wait_para->timeout;
            wait_param.handle_timeout = time < wait_para->timeout ? vip_true_e : vip_false_e;
        } else {
            wait_param.time_out = 0;
            wait_param.handle_timeout = vip_true_e;
        }
        vipdrv_database_unuse(&device->context->tskDesc_database, tsk_desc_index);
    } else {
        wait_param.time_out = 0;
        wait_param.handle_timeout = vip_true_e;
    }
    status = vipdrv_task_wait(&tskTCB->task, &wait_param);
    if (VIP_ERROR_NOT_FINISH == status) {
        vipGoOnError(status);
    }
    if ((status != VIP_SUCCESS) && (status != VIP_ERROR_CANCELED)) {
        PRINTK_E("wait task done, status=%d, task_id=0x%x\n", status, tskTCB->task.task_id);
    }
    vipdrv_os_lock_mutex(tskTCB->cancel_mutex);
    tskTCB->status = VIPDRV_TASK_INFER_END;
    hardware = &tskTCB->task.device->hardware[tskTCB->task.core_index];
    hardware->irq_local_value = 0;
    *hardware->irq_value &= ~IRQ_VALUE_FLAG;
    vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);

onError:
    return status;
}

#if vpmdENABLE_CANCELATION
vip_status_e vipdrv_task_tcb_cancel(vipdrv_cancel_task_param_t* cancel)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_device_t* device = VIP_NULL;
    vip_uint32_t task_id = cancel->task_id + cancel->subtask_index;
    vip_bool_e hw_cancel = vip_false_e;
    vipdrv_task_control_block_t* tskTCB = VIP_NULL;

    VIPDRV_LOOP_DEVICE_START
    vipdrv_os_lock_mutex(dev->tskTCB.cancel_mutex);
    if (task_id == dev->tskTCB.task.task_id) {
        tskTCB = &dev->tskTCB;
        vipdrv_os_unlock_mutex(dev->tskTCB.cancel_mutex);
        break;
    }
    vipdrv_os_unlock_mutex(dev->tskTCB.cancel_mutex);
    VIPDRV_LOOP_DEVICE_END
    if (VIP_NULL == tskTCB) {
        PRINTK_E("cancel TCB is null, wait task_id=0x%x, subtask_index=%d\n", cancel->task_id,
                 cancel->subtask_index);
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    device = tskTCB->task.device;
    vipIsNULL(device);
    hw_cancel = vipdrv_context_query_featureDB(device->device_index, VIP_FEATURE_JOB_CANCEL);

    PRINTK_I("user start do cancel on device%d, hw_cancel=%d.\n", device->device_index, hw_cancel);
    if (vip_false_e == hw_cancel) {
        vip_uint32_t wait_time = 300; /* 300ms */
        if (tskTCB->time_out != vpmdHARDWARE_TIMEOUT) {
            wait_time = tskTCB->time_out;
        }
#if vpmdFPGA_BUILD
        else {
            wait_time = 3000;
        }
#endif
        /* wait hw idle */
        vipdrv_device_wait_idle(device, wait_time, vip_true_e);
        PRINTK_I("user end do cancel on device%d, hw_cancel=%d.\n", device->device_index, hw_cancel);
        return status;
    }

    vipdrv_os_lock_mutex(tskTCB->cancel_mutex);
    if (task_id == tskTCB->task.task_id) {
        if (tskTCB->status < VIPDRV_TASK_INFER_START) {
            tskTCB->status = VIPDRV_TASK_CANCELED;
            PRINTK_I("task_id=0x%x is marked cancel in queue, not be executed.\n", task_id);
        } else if (tskTCB->status == VIPDRV_TASK_INFER_START) {
            if (VIP_SUCCESS != vipdrv_task_do_cancel(tskTCB, device)) {
                vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
                PRINTK_E("hardware cancel job failed.\n");
                vipGoOnError(VIP_ERROR_FAILURE);
            }
        } else if (tskTCB->status == VIPDRV_TASK_INFER_END) {
            PRINTK_I("task_id=0x%x already forward done\n", task_id);
        }
    } else {
        PRINTK_D("bypass cancel, task_id=0x%x\n", task_id);
    }
    vipdrv_os_unlock_mutex(tskTCB->cancel_mutex);
    PRINTK_I("user end do cancel device%d, task_id=0x%x\n", device->device_index, task_id);
onError:
    return status;
}
#endif

#endif
