/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/
#ifndef _VIP_DRV_TASK_SCHEDULE_H
#define _VIP_DRV_TASK_SCHEDULE_H
#include <vip_drv_type.h>
#include <vip_drv_share.h>

#if vpmdTASK_QUEUE_USED
typedef struct vipdrv_core_load {
    /* the number of task on this core */
    vip_uint32_t task_count;
    /* The time required to complete all tasks on this core */
    vip_uint64_t estimated_time;
} vipdrv_core_load_t;
#endif

vip_status_e vipdrv_task_schedule(vipdrv_device_t* device, vipdrv_submit_task_param_t* sbmt_para);
#endif
