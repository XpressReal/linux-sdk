/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#ifndef _VIP_DRV_DEBUG_H
#define _VIP_DRV_DEBUG_H

#include <vip_drv_vipcore_driver.h>
#include <vip_drv_type.h>
#include <vip_drv_share.h>
#include <vip_drv_task_debug.h>

#if vpmdENABLE_HANG_DUMP
vip_status_e vipdrv_dump_axi_register(vipdrv_hardware_t* hardware);

vip_status_e vipdrv_dump_states(vipdrv_task_t* task);

vip_status_e vipdrv_hang_dump(vipdrv_task_t* task);

#if vpmdTASK_PARALLEL_ASYNC
vip_status_e vipdrv_dump_waitlink_table(vipdrv_task_t* task);
#endif

vip_status_e vipdrv_dump_PC_value(vipdrv_hardware_t* hardware);
#endif

#if (vpmdENABLE_DEBUG_LOG > 3) || vpmdENABLE_DEBUGFS
void vipdrv_report_clock(void);

vip_status_e vipdrv_get_clock(vipdrv_hardware_t* hardware, vip_uint64_t* clk_MC);
#endif

vip_status_e vipdrv_dump_options(void);

vip_status_e vipdrv_register_dump_wrapper(vip_status_e (*func)(va_list args), ...);

#if vpmdENABLE_CAPTURE || (vpmdENABLE_HANG_DUMP > 1)
vip_status_e vipdrv_register_dump_init(vipdrv_context_t* context);

vip_status_e vipdrv_register_dump_uninit(vipdrv_context_t* context);

vip_status_e vipdrv_register_dump_action(vipdrv_register_dump_type_e type, vipdrv_hardware_t* hardware,
                                         vip_uint32_t address, vip_uint32_t expect, vip_uint32_t data);
#endif

vip_status_e vipdrv_dump_data(vip_uint32_t* data, vip_address_t physical, vip_uint32_t size);

#if vpmdFLEXA_DMA
#if vpmdENABLE_FLEXA_DMA_DUMP
vip_status_e vipdrv_uninit_flexa_dma_dump_thread(vipdrv_hardware_t* hardware);
vip_status_e vipdrv_init_flexa_dma_dump_info(vipdrv_hardware_t* hardware);
#endif
#endif

#endif
