/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#ifndef __VIP_DRV_DEVICE_H__
#define __VIP_DRV_DEVICE_H__

#include <vip_drv_type.h>
#include <vip_drv_hardware.h>
#include <vip_drv_task_common.h>

/*
@brief define loop fun for getting each vip core in device
*/
#define VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)                          \
    {                                                                         \
        vip_uint32_t hw_index = 0;                                            \
        for (hw_index = 0; hw_index < (device)->hardware_count; hw_index++) { \
            vipdrv_hardware_t* hw = &(device)->hardware[hw_index];            \
            if (hw != VIP_NULL) {
#define VIPDRV_LOOP_HARDWARE_IN_DEVICE_END \
    }                                      \
    }                                      \
    }

/*
@brief define loop fun for getting each vip core in device from M_index to N_index
*/
#define VIPDRV_LOOP_HARDWARE_IN_DEVICE_MtoN_START(device, start, cnt)        \
    {                                                                        \
        vip_uint32_t hw_index = 0;                                           \
        for (hw_index = 0; hw_index < (cnt); hw_index++) {                   \
            vipdrv_hardware_t* hw = &(device)->hardware[(start) + hw_index]; \
            if (hw != VIP_NULL) {
#define VIPDRV_LOOP_HARDWARE_IN_DEVICE_MtoN_END \
    }                                           \
    }                                           \
    }

/*
@brief define loop fun for getting each vip hardware in task
*/
#define VIPDRV_LOOP_HARDWARE_IN_TASK_START(task)                                     \
    {                                                                                \
        vip_uint32_t hw_index = 0;                                                   \
        vipdrv_device_t* dev = (task)->device;                                       \
        for (hw_index = 0; hw_index < (task)->core_cnt; hw_index++) {                \
            vipdrv_hardware_t* hw = &(dev->hardware[(task)->core_index + hw_index]); \
            if (hw != VIP_NULL) {
#define VIPDRV_LOOP_HARDWARE_IN_TASK_END \
    }                                    \
    }                                    \
    }

struct _vipdrv_device {
    /* index of logical device in context */
    vip_uint32_t device_index;
    /* the number of VIP cored in this device */
    vip_uint32_t hardware_count;
    vipdrv_hardware_t* hardware;
    /* belong to which context */
    vipdrv_context_t* context;

    vip_uint32_t chip_ver1;
    vip_uint32_t chip_ver2;
    vip_uint32_t chip_cid;
    vip_uint32_t chip_date;

    vip_hardware_type_e hw_type;
    union {
        vip_hw_feature_db_t* vip_database;
        vipllm_hw_feature_db_t* vipllm_database;
    } feature_db;

    /* init command in vip-drv */
    vipdrv_video_memory_t init_command;
    vip_uint32_t init_command_size;
#if vpmdTASK_QUEUE_USED
    vipdrv_queue_t tskTCB_queue;
    /* atomic object for reading TCB from tskTCB_queue thread is running */
    volatile vip_bool_e tskTCB_thread_running;
    /* a signal for sending to read TCB from tskTCB_queue thread */
    vipdrv_signal tskTCB_submit_signal;
    /* a signal for job cancellation the taskTCB */
    vipdrv_signal tskTCB_recover_signal;

    /* thread handle object for reading tskTCB from tskTCB_queue and send task to next stage */
    void* submit_thread_handle;
    /* signal for destroy task submitting thread */
    vipdrv_signal submit_thread_exit_signal;
#if vpmdTASK_PARALLEL_ASYNC
    /* thread object. task waiting thread process handle */
    void* wait_thread_handle;
    /* signal for destroy task waiting thread */
    vipdrv_signal wait_thread_exit_signal;
    /* indicate how many thread not allow recover yet */
    vipdrv_atomic disable_recover;
    void* irq_queue;
    volatile vip_uint32_t* irq_value;
#endif
#else
    vipdrv_task_control_block_t tskTCB;
#endif
#if vpmdTASK_DISPATCH_DEBUG
#if vpmdTASK_PARALLEL_SYNC
    volatile vip_uint32_t read_queue_cnt;
    volatile vip_uint32_t send_notify_cnt;
#elif vpmdTASK_SERIAL_SYNC
    volatile vip_uint32_t read_queue_cnt;
    volatile vip_uint32_t submit_hw_cnt;
    volatile vip_uint32_t wait_hw_cnt;
#elif vpmdTASK_PARALLEL_ASYNC
    volatile vip_uint32_t read_queue_cnt;
    volatile vip_uint32_t recover_done_cnt;
    volatile vip_uint32_t submit_hw_cnt;
#endif
#endif
#if vpmdENABLE_MMU
    vipdrv_mem_property_t* mem_prop;
#endif
    /* A bitmap indicates that this device can share video memory with which devices */
    vip_uint64_t share_mem_device_vis;
};

/*
@brief Get hardware object from device.
*/
vipdrv_hardware_t* vipdrv_get_hardware(vipdrv_device_t* device, vip_uint32_t core_index);

vipdrv_device_t* vipdrv_get_device(vip_uint32_t device_index);

vip_status_e vipdrv_device_hw_reset(vipdrv_device_t* device);

vip_status_e vipdrv_device_hw_init(vipdrv_device_t* device);

/*
@brief To run any initial commands once in the beginning.
*/
vip_status_e vipdrv_device_prepare_initcmd(vipdrv_device_t* device);

vip_status_e vipdrv_device_wait_idle(vipdrv_device_t* device, vip_uint32_t timeout, vip_uint8_t is_fast);
#endif
