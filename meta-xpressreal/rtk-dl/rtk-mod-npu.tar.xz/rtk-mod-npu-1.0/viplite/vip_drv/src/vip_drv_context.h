/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#ifndef __VIP_DRV_CONTEXT_H__
#define __VIP_DRV_CONTEXT_H__

#include <vip_drv_type.h>
#include <vip_drv_hardware.h>
#include <vip_drv_device.h>

#if vpmdFPGA_BUILD
/* FPGA have 2000 times more delay than silicon
   can modify it according to the frequency of NPU. eg: silicon=1GHZ, FPGA=500KHZ */
#define VIPDRV_DELAY(time)               \
    {                                    \
        vip_uint32_t time_ms = time * 2; \
        vipdrv_os_delay(time_ms);        \
    }
#else
#define VIPDRV_DELAY(time) vipdrv_os_udelay(time);
#endif

#define VIPDRV_CHECK_NULL(object)                                                \
    if (VIP_NULL == object) {                                                    \
        PRINTK_E("%s[%d] %s object is NULL\n", __FUNCTION__, __LINE__, #object); \
        return VIP_ERROR_INVALID_ARGUMENTS;                                      \
    }

#define VIPDRV_CHECK_CORE(core)                                                                    \
    {                                                                                              \
        vip_uint32_t* c_cnt = (vip_uint32_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_HARDWARE_CNT); \
        if ((core) > *cnt) {                                                                       \
            PRINTK_E("core=%d is larger than core count=%d\n", core, *cnt);                        \
            VIPDRV_DUMP_STACK();                                                                   \
            vipGoOnError(VIP_ERROR_FAILURE);                                                       \
        }                                                                                          \
    }

#define VIPDRV_CHECK_DEV(dev)                                                                    \
    {                                                                                            \
        vip_uint32_t* d_cnt = (vip_uint32_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_DEVICE_CNT); \
        if ((dev) >= *cnt) {                                                                     \
            PRINTK_E("device id =%d is larger than device count=%d\n", dev, *cnt);               \
            VIPDRV_DUMP_STACK();                                                                 \
            vipGoOnError(VIP_ERROR_FAILURE);                                                     \
        }                                                                                        \
    }

#if (vpmdENABLE_DEBUG_LOG >= 4)
#define VIPDRV_SHOW_DEV_CORE_INFO(dev_idx, core_count, core_idx, string, flag)                                     \
if ((*(vip_uint8_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_LOG_LEVEL) >= 4) || flag) \
    {                                                                                                        \
        vip_char_t info_t[256];                                                                              \
        vip_char_t* tmp = info_t;                                                                            \
        vip_uint32_t itr = 0;                                                                                \
        vipdrv_os_snprint(tmp, 255, "%s, dev_idx=%d, core_count=%d, core_id[", string, dev_idx, core_count); \
        tmp += 34 + sizeof(string);                                                                          \
        for (itr = 0; itr < core_count; itr++) {                                                             \
            vipdrv_os_snprint(tmp, 255, "%02d ", (core_idx + itr));                                          \
            tmp += 3;                                                                                        \
        }                                                                                                    \
        vipdrv_os_snprint(tmp, 255, "]\n");                                                                  \
        PRINTK_F("%s", info_t);                                                                              \
    }
#else
#define VIPDRV_SHOW_DEV_CORE_INFO(dev_idx, core_count, core_idx, string, flag)
#endif

/*
@brief define loop fun for each vip device
*/
#define VIPDRV_LOOP_DEVICE_START                                                                         \
    {                                                                                                    \
        vip_uint32_t dev_index = 0;                                                                      \
        vipdrv_context_t* vipdrv_cntxt = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL); \
        for (dev_index = 0; dev_index < vipdrv_cntxt->device_count; dev_index++) {                       \
            vipdrv_device_t* dev = &vipdrv_cntxt->device[dev_index];

#define VIPDRV_LOOP_DEVICE_END \
    }                          \
    }

/*
@brief define loop fun for each vip core
*/
#define VIPDRV_LOOP_HARDWARE_START                                                                       \
    {                                                                                                    \
        vip_uint32_t dev_index = 0, hw_index = 0;                                                        \
        vipdrv_context_t* vipdrv_cntxt = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL); \
        for (dev_index = 0; dev_index < vipdrv_cntxt->device_count; dev_index++) {                       \
            vipdrv_device_t* dev = &vipdrv_cntxt->device[dev_index];                                     \
            for (hw_index = 0; hw_index < dev->hardware_count; hw_index++) {                             \
                vipdrv_hardware_t* hw = &dev->hardware[hw_index];                                        \
                if (hw != VIP_NULL) {
#define VIPDRV_LOOP_HARDWARE_END \
    }                            \
    }                            \
    }                            \
    }

#define VIPDRV_DATA_TO_STRING(str_ptr, data_ptr, count)                  \
    {                                                                    \
        vip_uint32_t tmp_idx = 0;                                        \
        vipdrv_os_snprint(str_ptr, 2, "[");                              \
        str_ptr += 1;                                                    \
        for (tmp_idx = 0; tmp_idx < count; tmp_idx++) {                  \
            vipdrv_os_snprint(str_ptr, 255, "%04d ", data_ptr[tmp_idx]); \
            str_ptr += 5;                                                \
        }                                                                \
        vipdrv_os_snprint(str_ptr, 2, "]");                              \
        str_ptr += 1;                                                    \
    }

typedef struct _vipdrv_address_value {
    vip_uint32_t low;
    vip_uint32_t high;
} vipdrv_address_value_t;

typedef enum _vipdrv_context_property_e {
    VIPDRV_CONTEXT_PROP_ALL = 0,
    VIPDRV_CONTEXT_PROP_TASK_DESC = 1,
    VIPDRV_CONTEXT_PROP_TCB = 2,
    VIPDRV_CONTEXT_PROP_INITED = 3,
    VIPDRV_CONTEXT_PROP_DEVICE_CNT = 4,
    VIPDRV_CONTEXT_PROP_HARDWARE_CNT = 5,
    VIPDRV_CONTEXT_PROP_LOG_LEVEL = 6,
    VIPDRV_CONTEXT_PROP_MAX
} vipdrv_context_property_e;

/* vip-drv global context. */
struct _vipdrv_context {
    volatile vip_int32_t initialize;
    vipdrv_hashmap_t process_id;

    /* the real number of vip core */
    vip_uint32_t core_count;
    /* the logical vip device number */
    vip_uint32_t device_count;
    vipdrv_device_t* device;

#if vpmdENABLE_SYS_MEMORY_HEAP
    /* the size of system heap memory */
    vip_uint32_t sys_heap_size;
#endif
#if vpmdENABLE_RESERVE_PHYSICAL
    vip_physical_t reserve_phy_base;
    vip_uint32_t reserve_phy_size;
    vip_virtual_t reserve_virtual;
#endif
    vip_uint32_t mem_prop_cnt;
    /* video memory heap property for mmu page table management */
    vipdrv_mem_property_t* mem_props;
#if vpmdENABLE_MMU
    vipdrv_hashmap_t mmu_hashmap;
#endif
    /* the size of vip-sram for per-core */
    vip_uint32_t vip_sram_size[vipdMP_NUM * vipdMAX_DEVICE_NUM];
    /* the remap address or VIP's virtual address of VIP SRAM */
    vip_virtual_t vip_sram_address;
    /* the size of axi sram for per-core */
    vip_uint32_t axi_sram_size[vipdMAX_DEVICE_NUM];
#if (vpmdENABLE_BW_PROFILING || vpmdENABLE_CNN_PROFILING)
    /* feature configuration from debugfs */
    vipdrv_feature_config_t func_config;
#endif
    /* MMU enabled: the VIP's virtual address of AXI-SRAM
       MMU disabled: the VIP's physical address of AXI-SRAM */
    vip_virtual_t axi_sram_address;
    /* the NPU physical address of AXI SRAM */
    vip_physical_t axi_sram_physical;

    vip_uint32_t l2_sram_address;
    vip_uint32_t l2_sram_size;

#if vpmdENABLE_L2_SCHEDULE
    vipdrv_mem_heap_t* l2_sram_heap;
#endif
#if vpmdENABLE_MULTIPLE_TASK
    /* mutex for initialize vip-drv */
    vipdrv_mutex initialize_mutex;
#endif
    vipdrv_database_t mem_database;

#if vpmdENABLE_CAPTURE || (vpmdENABLE_HANG_DUMP > 1)
    vipdrv_video_memory_t register_dump_buffer;
    vip_uint32_t register_dump_count;
#endif
    vipdrv_database_t tskDesc_database;
#if vpmdTASK_QUEUE_USED
    vipdrv_hashmap_t tskTCB_hashmap;
#endif
    /* video memory allocator instance list */
    vipdrv_allocator_t* alloc_list_head;
#if vpmdENABLE_FLEXA_DMA_DUMP
    vip_uint32_t* flexa_dma_irq_queue;
    void* flexa_dma_thread_handle;
    volatile vip_bool_e flexa_dma_thread_running;
    vip_bool_e is_manual_exit;
    volatile vipdrv_flexa_dma_irq_t* volatile flexa_dma_irq;
#endif
    volatile void* subsys_reg_base;
#if vpmdENABLE_SUBSYSTEM
#if vpmdENABLE_MULTIPLE_TASK
    /* mutex for read/write subsys register */
    vipdrv_mutex subsys_reg_mutex;
#endif
#endif
};

/*
@brief Get vip-drv context object.
*/
void* vipdrv_get_context(vipdrv_context_property_e prop);

vip_status_e vipdrv_context_init(vipdrv_context_t* context);

vip_status_e vipdrv_context_uninit(vipdrv_context_t* context);

vip_status_e vipdrv_context_select_featureDB(vipdrv_context_t* context);

vip_uint32_t vipdrv_context_query_featureDB(vip_uint32_t device_index, vip_hardware_feature_e feature);
#endif
