/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2026 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#ifndef _VIP_DRV_INTERFACE_H
#define _VIP_DRV_INTERFACE_H

#include <vip_drv_share.h>

/************ EXPOSED vip-drv APIs ***************/

/*
@brief Destroy vip-drv resource.
       This function only use on Linux/Andorid system when used ctrl+c to force kill processor
       to exit application or application crash happend.
       When the appliction exits abnormally, vipdrv_destroy() used
       to free all kenerl space resource.
*/
vip_status_e vipdrv_destroy(void);

/*
@brief  initialize driver. it's equivalent to vipdrv_interface_call(VIPDRV_INTRFACE_INIT).
*/
vip_status_e vipdrv_init(vipdrv_initialize_t* init_data);

/*
@brief  dispatch vip_drv command
@param  command, command type.
@param  data, the data for command type.
*/
vip_status_e vipdrv_interface_call(vipdrv_intrface_e command, void* data);

#endif
