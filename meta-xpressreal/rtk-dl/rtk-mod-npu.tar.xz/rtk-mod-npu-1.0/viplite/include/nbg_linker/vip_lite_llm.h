/****************************************************************************
*
*    Copyright 2017 - 2026 Vivante Corporation, Santa Clara, California.
*    All Rights Reserved.
*
*    Permission is hereby granted, free of charge, to any person obtaining
*    a copy of this software and associated documentation files (the
*    'Software'), to deal in the Software without restriction, including
*    without limitation the rights to use, copy, modify, merge, publish,
*    distribute, sub license, and/or sell copies of the Software, and to
*    permit persons to whom the Software is furnished to do so, subject
*    to the following conditions:
*
*    The above copyright notice and this permission notice (including the
*    next paragraph) shall be included in all copies or substantial
*    portions of the Software.
*
*    THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND,
*    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
*    IN NO EVENT SHALL VIVANTE AND/OR ITS SUPPLIERS BE LIABLE FOR ANY
*    CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
*    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
*    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#ifndef _VIP_LITE_LLM_H
#define _VIP_LITE_LLM_H

#include "vip_lite_common.h"
#include "vip_lite.h"

/* \brief The header file expose APIs for running Large language model with VIPLite
*/

#ifdef __cplusplus
extern "C" {
#endif

#define LM_HEAD_MAX_INFO 64
typedef struct _vip_llm_task* vip_llm_task;

/* \brief The list of properties of a llm_task.
  * \ingroup llm_task
 */
typedef enum _vip_llm_task_property_e {
    /* query llm_task */
    /*!< \brief The llm_task profling data, the returned value is vip_inference_profile_t */
    VIP_LLM_TASK_PROP_PROFILING = 0,

    /* set llm_task for VIPLLM */
    VIP_LLM_TASK_PROP_SEQUENCE_LENGTH = 128,
    VIP_LLM_TASK_PROP_INPUT_OFFSET = 129,
} vip_llm_task_property_e;

/* \brief The list of properties of a vip_network added into llm_task.
  * \ingroup llm_task
 */
typedef enum _vip_llm_network_property_e {
    /* query vip_network added into llm_task */
    /*!< \brief The pointer of the query coef and coef size, the returned value is _vip_llm_lm_head_coeff_info*/
    VIP_LLM_NETWORK_PROP_LM_HEAD_COEF_INFO = 0,
    /*!< \brief The lm head decompress info, the returned value is _vip_llm_coeff_decompress_info*/
    VIP_LLM_NETWORK_PROP_COEFF_DECOMPRESS_INFO = 1,
} vip_llm_network_property_e;

/*! \brief the coef ptr and coef size
*/
typedef struct _vip_llm_lm_head_coeff_info {
    vip_uint8_t* coef_ptr[LM_HEAD_MAX_INFO];
    vip_size_t coef_size[LM_HEAD_MAX_INFO];
    vip_size_t coef_info_cnt;
} vip_llm_lm_head_coeff_info_t;

/*! \brief the kernel info saved in cmd
*/
typedef struct _vip_llm_coeff_decompress_info {
    /* the KernelZSize of the kernel*/
    vip_uint32_t kernel_z_size[LM_HEAD_MAX_INFO];
    /* the kpc of the kernel */
    vip_uint32_t kernel_per_core[LM_HEAD_MAX_INFO];
    vip_uint32_t nn_core_count;
    vip_uint32_t vz_group_bits;
    vip_uint32_t dp_number;
} vip_llm_coeff_decompress_info_t;

/*
@brief set input buffer for network or change network input buffer.
@param index The index of network inputs.
@param input The input buffer of network.
@param offset The offset on input based on origin buffer.
       for llm, app could allocate a large buffer, and use the part of buffer as input or output.
       such as kv output come from kv cache.
*/
VIP_API
vip_status_e vip_llm_set_input(IN vip_network network, IN vip_uint32_t index, IN vip_buffer input,
                               IN vip_uint32_t offset);

/*
@brief set output buffer for network or change network output buffer.
@param index The index of network outputs.
@param output The output buffer of network.
@param offset The offset on output based on origin buffer.
       for llm, app could allocate a large buffer, and use the part of buffer as output or output.
       such as kv output come from kv cache.
*/
VIP_API
vip_status_e vip_llm_set_output(IN vip_network network, IN vip_uint32_t index, IN vip_buffer output,
                                IN vip_uint32_t offset);

/*
@brief Create a vip_llm_task object to run multiple tasks(network) and
       without interrupt between each networkc.
@param count The maximum number of tasks supports by this llm task.
@param llm_task Return vip_llm_task object be created.
*/
VIP_API
vip_status_e vip_llm_create_task(IN vip_uint32_t count, OUT vip_llm_task* llm_task);

/*
@brief Destroy llm task object which created by vip_llm_create_task.
@param llm task vip_group object.
*/
VIP_API
vip_status_e vip_llm_destroy_task(IN vip_llm_task llm_task);

/*
@brief add a vip_network object into llm_task.
@param llm_task object, network be added into llm_task.
@param network vip_network added into llm_task.
*/
VIP_API
vip_status_e vip_llm_add_network(IN vip_llm_task llm_task, IN vip_network network);

/*
@brief query task information.
@param llm task vip_llm_task object
*/
VIP_API
vip_status_e vip_llm_query_task(IN vip_llm_task llm_task, IN vip_enum property, OUT void* value);

/*
@brief set task information.
@param llm task vip_llm_task object
*/
VIP_API
vip_status_e vip_llm_set_task(IN vip_llm_task llm_task, IN vip_enum property, OUT void* value);

/*
@brief run tasks in llm task. ony issue a interrupt after tasks complete.
@param llm task vip_llm_task object
*/
VIP_API
vip_status_e vip_llm_run_task(IN vip_llm_task llm_task);

/*
@brief Query a property of the network object.
@param [in] network vip_network added into llm_task.
@param [in] property A property vip_llm_network_property_e to be queried.
@param [out] value A pointer to memory to store the return value, different property could return different type/size
             of value.
*/
VIP_API
vip_status_e vip_llm_query_network(IN vip_network network, IN vip_enum property, OUT void* value);
#ifdef __cplusplus
}
#endif

#endif
