#ifndef __GST_RTK_SUBTITLE_POOL_H__
#define __GST_RTK_SUBTITLE_POOL_H__

#include <gst/gst.h>

#include <gst/video/video.h>

G_BEGIN_DECLS

#define GST_BUFFER_POOL_OPTION_RTK_SUBTITLE_META "GstBufferPoolOptionVRtkSubtitleMeta"

#define GST_BUFFER_POOL_OPTION_RTK_SUBTITLE_ALIGNMENT "GstBufferPoolOptionRtkSubtitleAlignment"

/* setting a bufferpool config */

GST_VIDEO_API
void             gst_buffer_pool_config_set_rtk_subtitle_alignment  (GstStructure *config, const GstVideoAlignment *align);

GST_VIDEO_API
gboolean         gst_buffer_pool_config_get_rtk_subtitle_alignment  (GstStructure *config, GstVideoAlignment *align);

/* video bufferpool */
typedef struct _GstRtkSubtitlePool GstRtkSubtitlePool;
typedef struct _GstRtkSubtitlePoolClass GstRtkSubtitlePoolClass;
typedef struct _GstRtkSubtitlePoolPrivate GstRtkSubtitlePoolPrivate;

#define GST_TYPE_RTK_SUBTITLE_POOL      (gst_rtk_subtitle_pool_get_type())
#define GST_IS_RTK_SUBTITLE_POOL(obj)   (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GST_TYPE_RTK_SUBTITLE_POOL))
#define GST_RTK_SUBTITLE_POOL(obj)      (G_TYPE_CHECK_INSTANCE_CAST ((obj), GST_TYPE_RTK_SUBTITLE_POOL, GstRtkSubtitlePool))
#define GST_RTK_SUBTITLE_POOL_CAST(obj) ((GstRtkSubtitlePool*)(obj))

struct _GstRtkSubtitlePool
{
  GstBufferPool bufferpool;

  GstRtkSubtitlePoolPrivate *priv;
};

struct _GstRtkSubtitlePoolClass
{
  GstBufferPoolClass parent_class;
};

GST_VIDEO_API
GType             gst_rtk_subtitle_pool_get_type      (void);

GST_VIDEO_API
GstBufferPool *   gst_rtk_subtitle_pool_new           (void);

GST_VIDEO_API
void gst_rtk_subtitle_pool_reset_pool(GstBufferPool *pool);

GST_VIDEO_API
void gst_rtk_subtitle_pool_release_and_clear(GstBufferPool *pool, gboolean enable);

G_DEFINE_AUTOPTR_CLEANUP_FUNC(GstRtkSubtitlePool, gst_object_unref)

G_END_DECLS

#endif /* __GST_RTK_SUBTITLE_POOL_H__ */
