# Changelog

All notable changes to this project will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [1.2.2] - 2026-07-30

### Fixed
- Fix FBC reconstructed frame buffer allocation using incorrect size from src_buf_size instead of compressed frame map layout
- Fix encoder inst_index collision by assigning from firmware instead of driver-side allocation
- Fix rtkve4_wait_busy() busy-spin; use proper polling interval and log PC on timeout
- Fix codeBase physical address truncation by using dma_addr_t

### Changed
- Narrow ve4_hw_mutex to only the actual FW commands to reduce serialization between concurrent instances
- Read and log W6_RET_CQ_FLAG and W6_RET_FW_VERSION during initialization
- Set protection mode before SET_FB / header operations

**Firmware:**
- Stark VE1: `f0777291d3cb4b37cf702c4101ffa983`
- Stark VE2: `1825cc230310ded861c8119e202d099b`
- Stark VE3: `fe8952272303f2cb0424b8762ab81bd6`
- Kent  VE1: `8cc04d89659ccafd369b7f7704baa6fb`
- Kent  VE2: `225e96d5e4266fd8e32e730e41e1a184`
- Kent  VE4: `8af770688d77d202acd41d326039bd55`
- Prince VE1: `8cc04d89659ccafd369b7f7704baa6fb`
- Prince VE2: `ab6bdde93eada4d1c33b52d384e6c8b9`
- Prince VE3: `fe7ce98904ae91dbce164a706215d498`

---

## [1.2.1] - 2026-07-20

### Added
- Add crop offset support to VE2 pre-parse

### Fixed
- Fix spurious -EBUSY on DEC_CMD_START after drain
- Fix cmprs_lu_size miscalculation causing decompress error
- Revert VP8 TIMEOUT fix that caused regression on CMD_STOP / SOURCE_CHANGE
- Add physical address validation for VE2 DMA buffers (reject reserved/boundary-crossing/over-limit regions)
- Fix ve4 encoder inst_index collision caused by monotonically incrementing counter without proper slot reuse

### Changed
- Reduce ve1 OUTPUT buffers from 4 to 2
- Set EXTRA_DEC_PIC_BUF to 0 for ve1 to reduce decoded frame buffer reservation

### Performance
- ve1_v4l2: save extra map/unmap overhead on VB2_MEMORY_DMABUF buffers

**Firmware:**
- Stark VE1: `f0777291d3cb4b37cf702c4101ffa983`
- Stark VE2: `1825cc230310ded861c8119e202d099b`
- Stark VE3: `fe8952272303f2cb0424b8762ab81bd6`
- Kent  VE1: `8cc04d89659ccafd369b7f7704baa6fb`
- Kent  VE2: `225e96d5e4266fd8e32e730e41e1a184`
- Kent  VE4: `8af770688d77d202acd41d326039bd55`
- Prince VE1: `8cc04d89659ccafd369b7f7704baa6fb`
- Prince VE2: `ab6bdde93eada4d1c33b52d384e6c8b9`
- Prince VE3: `fe7ce98904ae91dbce164a706215d498`

---

## [1.2.0] - 2026-06-12

### Added
- Support H.264 VUI SAR for ve4 encoder
- Advertise V4L2_PIX_FMT_RTKC pixel format when enhance-lossy mode active
- Set maximum DMA segment size and DMA mask for ve4 encoder
- Error out on mid-stream visual resolution change

### Fixed
- Fix v4l2-compliance failures for JPEG encoder/decoder
- Fix kent lossy grey screen issue
- Fix VP8 TIMEOUT races on CMD_STOP and SOURCE_CHANGE
- Fix ve2 CAP DQBUF blocked on firmware fatal decode error
- Fix ve2 EOS not signaled on CAP restart after CMD_STOP drain

### Changed
- Replace ve2rpc/ve3rpc with vpu_legacy/ve3_enc device nodes
- Replace polling with interrupt for decoded frame notification
- Use unified rtk_ve1 ops to replace rtd16xxb_ve1 and kent_ve1
- Fix profile/level/stride handling for ve4 encoder

---

## [1.1.20] - 2026-05-21

### Added
- JPEG decoder scale support with 64-byte alignment
- JPEG encoder output buffer size adjustment

### Fixed
- Fix ve1/ve2 null pointer dereference issues
- Fix memory leak issues in ve1/ve2/driver interface
- Fix ve1 blocking issue (mutex held across wait_for_completion)
- Fix kernel stack overflow in ve2_cc_wrapper_write
- Fix use-after-free in ve2_send_rpc()
- Fix heap overflow via unchecked RPC parameter size
- Fix DPB state corruption and ring buffer issues

### Changed
- Refine the size of CAPTURE buffer while lossy compress

### Performance
- Optimize spinlock usage (remove irqlock, reduce contention)
- Fix dmabuf reference leak and buffer slot leak

### Code Cleanup
- Fix static analysis warnings (Coverity, smatch, Coccinelle)

---

## [1.1.19] - 2026-05-12

### Added
- jcodec: JPEG decoder supports 64-align output

---

## [1.1.18] - 2026-05-06

### Added
- jcodec: Add user controls to support rotate and scale

### Changed
- jcodec: Adjust encoder bytesperline alignment
- jcodec: Adjust JPEG output buffer sizeimage to w×h×3/2
- jcodec: Adjust encoder alignment for decoder scaling case
- hevc/vp9/av1 encoder: Reduce OUTPUT buffers from 4 to 2
- ve1 decoder: Reduce latency (remove usleep_range and wakeup threadcap)

### Fixed
- jcodec: Fixed alignment issue; set MAX WIDTH/HEIGHT to 8192×8192

---

## [1.1.17] - 2026-04-15

### Fixed
- Fix ve4 encoding error in transcoding case
- Fix compile issues for k6.12 and k5.10

---

## [1.1.16] - 2026-04-10

### Changed
- Change METADATA from PREPEND to APPEND

---

## [1.1.15] - 2026-04-09

### Added
- Support k6.12 Prince

### Changed
- Modify sequence change flow to meet Chrome browser V4L2 flow

### Fixed
- Fixed vb2_set_plane_payload 0 issue

---

## [1.1.14] - 2026-03-27

### Added
- JPEG driver supports iPhone 4032×3024

### Changed
- Reduce output queue min buffer count

### Fixed
- Fix CtsMediaCodecTestCases issue

---

## [1.1.13] - 2026-03-25

### Added
- Add configs for each codec
- Get the status of DPB buffer from VFW

---

## [1.1.12] - 2026-03-19

### Changed
- Replace dsb with dma_wmb/dma_rmb/dma_mb and remove volatile

---

## [1.1.11] - 2026-03-03

### Added
- Support V4L2 JPEG decode/encode for Kent and Prince

---

## [1.1.10] - 2026-02-23

### Changed
- Use PTS2 to store timestamp and PTSH to store index

### Fixed
- Fix the testFlushNative item in CtsMediaV2TestCases
- Fix the way to handle timestamp for interlace VC1

---

## [1.1.9] - 2026-02-06

### Added
- Add v4l2 set_enhance_mode control

### Changed
- Reduce sleep interval to improve performance
- Reduce the size of BS ring buffer

### Fixed
- Decoder handles HEVC NALU header
- Fix JPEG memcpy overflow issue
- Fix ve1 causing VFW crash
- Fix ve1 sometimes blocking
- Fix fluster CAMANL1_TOSHIBA_B issue

---

## [1.1.8] - 2025-12-19

### Fixed
- Fix ve1 vpu_try_fmt returning zero issue
- Fix ve3 flush issues

---

## [1.1.7] - 2025-12-02

### Added
- Add PID and process name in instance_info

### Changed
- Pass v4l2-compliance for ve3 encoder

### Fixed
- Fix JPEG RGB888 format transcoding with scaling down failure

---

> **Note:** Versions 1.1.4, 1.1.5, and 1.1.6 are not documented in this changelog.

---

## [1.1.3] - 2025-11-04

### Added
- Add ve4 encoder for Kent
- ve1 supports tile mode

### Changed
- Pass v4l2-compliance 1.28.1

---

## [1.1.2] - 2025-10-28

### Changed
- Add error handling while malloc fails

### Fixed
- Fix video frozen issue after seeking

---

## [1.1.1] - 2025-10-16

### Fixed
- Fix memory leakage while RPC timeout

---

## [1.1.0] - 2025-10-13

### Added
- Support Sorenson Spark Codec (FLV1)

### Changed
- Use memcpy instead of memcpy_toio to improve performance

### Fixed
- Fix kernel crash while there is no CMA

---

## [1.0.4] - 2025-10-03

### Changed
- Refine start_streaming while the BS is over spec

---

## [1.0.3] - 2025-09-27

### Added
- Add get ve1 status

### Fixed
- Fix incorrect ve1 instances number

---

## [1.0.2] - 2025-09-23

### Added
- Add debug information for stateful V4L2 ve2 codec

### Fixed
- Fix ve1 memory leakage issues

---

## [1.0.1] - 2025-09-16

### Fixed
- Fixed an occasional decoding hang issue on VE1
- Fixed kernel crash due to allocation failure for both decoder and encoder

---

## [1.0.0] - 2025-09-12

### Added
- Support V4L2_CID_MPEG_VIDEO_FORCE_KEY_FRAME
- Support MJPEG decode/encode
- Support H.263 codec decode
- Support suspend/resume of decoder

### Fixed
- Fixed v4l2-compliance issues for encoder
- Fixed memory leakage issues while transcoding
- Fixed vdec component crash when booting
- Fixed interlace stream decode issues
- Fixed kernel crash due to allocation failure for decoder
- Fixed Ctrl+C got stuck issues
- Fixed VE2 decoding hang on over-spec streams

**Firmware:**
- stark vfw: `834be943113af8491c4add99bbdcc33d`
- kent vfw: `c668b131b7be84ec411da5ad821c6ce5`
- ve3fw: `4d857974fe0ed96fbe318906fb63b9d2`

---

## [Unreleased] - 2025-03-18

### Added
- Support H.264/H.265 encode for 2K video
- Support MPEG-1/VC-1 (WVC1) decode
- Support screen capture

**Firmware:**
- vfw: `60ee44bc943dc757ca4d3f3957f0df79`
- ve3fw: `78a3f4e6001efb871013a954e6b3327e`

---

## [Unreleased] - 2024-12-27

### Added
- Support HDR (HDR10, HDR10+, HLG)
- Prepend metadata at the CAPTURE buffer

### Fixed
- Fix AV1 RPC timeout with av1C codec data

**Firmware:**
- vfw: `48f479e42b041e5b416602bee6c8f4f4`

---

## [Unreleased] - 2024-10-23

### Added
- Support 4K vertical video

### Changed
- Refine V4L2 release flow

### Fixed
- Pass H.264/H.265/VP8/VP9/AV1 video_decode_accelerator_tests
- Fix memory leakage issue
- Fix video roll back issue
- Fix specific VP9 decode failure issue
- Fix YouTube trick play failure issue

**Firmware:**
- vfw: `add19bcc5084103409fa6896d75bd1592a01136d`
