// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * Coda multi-standard codec IP - JPEG support functions
 *
 * Copyright (C) 2014 Philipp Zabel, Pengutronix
 */
#include <linux/version.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 8, 0)
#include <linux/unaligned.h>
#else
#include <asm/unaligned.h>
#endif
#include <linux/irqreturn.h>
#include <linux/kernel.h>
#include <linux/ktime.h>
#include <linux/slab.h>
#include <linux/swab.h>
#include <linux/videodev2.h>

#include <media/v4l2-ioctl.h>
#include <media/v4l2-event.h>
#include <media/v4l2-common.h>
#include <media/v4l2-fh.h>
#include <media/v4l2-jpeg.h>
#include <media/v4l2-mem2mem.h>
#include <media/videobuf2-core.h>
#include <media/videobuf2-dma-contig.h>
//#include <media/videobuf2-vmalloc.h> //fix vb2_vmalloc_memops build err

#include "rtk_jcodec_drv.h"
#include "rtk_jcodec_regs.h"
//#include "trace.h"

#include "ve_common.h"
#define METADATA_OFFSET (2048)

#define SOI_MARKER 0xffd8
#define APP9_MARKER 0xffe9
#define APP14_MARKER 0xffee
#define DRI_MARKER 0xffdd
#define DQT_MARKER 0xffdb
#define DHT_MARKER 0xffc4
#define SOF_MARKER 0xffc0
#define SOS_MARKER 0xffda
#define EOI_MARKER 0xffd9

#define RTK_REG_BIT_RD_PTR(x) (BIT_RD_PTR + 8 * (x))
#define RTK_REG_BIT_WR_PTR(x) (BIT_WR_PTR + 8 * (x))

struct rtk_huff_tab {
	u8 luma_dc[16 + 12];
	u8 chroma_dc[16 + 12];
	u8 luma_ac[16 + 162];
	u8 chroma_ac[16 + 162];

	/* DC Luma, DC Chroma, AC Luma, AC Chroma */
	s16 min[4 * 16];
	s16 max[4 * 16];
	s8 ptr[4 * 16];
};

#define RTK_JPEG_ENC_HUFF_DATA_SIZE (256 + 256 + 16 + 16)

//#define RTKJPU_DUMP_CAPBUF_EN
#if defined(RTKJPU_DUMP_CAPBUF_EN)
static int gCapbufDumpSerial = 0;
static int gCapbufDumpMaxNum = 0;
#endif

/*
 * Typical Huffman tables for 8-bit precision luminance and
 * chrominance from JPEG ITU-T.81 (ISO/IEC 10918-1) Annex K.3
 */

static const unsigned char luma_dc[16 + 12] = {
	/* bits */
	0x00,
	0x01,
	0x05,
	0x01,
	0x01,
	0x01,
	0x01,
	0x01,
	0x01,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	/* values */
	0x00,
	0x01,
	0x02,
	0x03,
	0x04,
	0x05,
	0x06,
	0x07,
	0x08,
	0x09,
	0x0a,
	0x0b,
};

static const unsigned char chroma_dc[16 + 12] = {
	/* bits */
	0x00,
	0x03,
	0x01,
	0x01,
	0x01,
	0x01,
	0x01,
	0x01,
	0x01,
	0x01,
	0x01,
	0x00,
	0x00,
	0x00,
	0x00,
	0x00,
	/* values */
	0x00,
	0x01,
	0x02,
	0x03,
	0x04,
	0x05,
	0x06,
	0x07,
	0x08,
	0x09,
	0x0a,
	0x0b,
};

static const unsigned char luma_ac[16 + 162 + 2] = {
	/* bits */
	0x00, 0x02, 0x01, 0x03, 0x03, 0x02, 0x04, 0x03, 0x05, 0x05, 0x04, 0x04,
	0x00, 0x00, 0x01, 0x7d,
	/* values */
	0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06,
	0x13, 0x51, 0x61, 0x07, 0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xa1, 0x08,
	0x23, 0x42, 0xb1, 0xc1, 0x15, 0x52, 0xd1, 0xf0, 0x24, 0x33, 0x62, 0x72,
	0x82, 0x09, 0x0a, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x25, 0x26, 0x27, 0x28,
	0x29, 0x2a, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44, 0x45,
	0x46, 0x47, 0x48, 0x49, 0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59,
	0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x73, 0x74, 0x75,
	0x76, 0x77, 0x78, 0x79, 0x7a, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89,
	0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3,
	0xa4, 0xa5, 0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6,
	0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7, 0xc8, 0xc9,
	0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda, 0xe1, 0xe2,
	0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf1, 0xf2, 0xf3, 0xf4,
	0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa, /* padded to 32-bit */
};

static const unsigned char chroma_ac[16 + 162 + 2] = {
	/* bits */
	0x00, 0x02, 0x01, 0x02, 0x04, 0x04, 0x03, 0x04, 0x07, 0x05, 0x04, 0x04,
	0x00, 0x01, 0x02, 0x77,
	/* values */
	0x00, 0x01, 0x02, 0x03, 0x11, 0x04, 0x05, 0x21, 0x31, 0x06, 0x12, 0x41,
	0x51, 0x07, 0x61, 0x71, 0x13, 0x22, 0x32, 0x81, 0x08, 0x14, 0x42, 0x91,
	0xa1, 0xb1, 0xc1, 0x09, 0x23, 0x33, 0x52, 0xf0, 0x15, 0x62, 0x72, 0xd1,
	0x0a, 0x16, 0x24, 0x34, 0xe1, 0x25, 0xf1, 0x17, 0x18, 0x19, 0x1a, 0x26,
	0x27, 0x28, 0x29, 0x2a, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44,
	0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58,
	0x59, 0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x73, 0x74,
	0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
	0x88, 0x89, 0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a,
	0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4,
	0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7,
	0xc8, 0xc9, 0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda,
	0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf2, 0xf3, 0xf4,
	0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa, /* padded to 32-bit */
};

/*
 * Quantization tables for luminance and chrominance components in
 * zig-zag scan order from the Freescale i.MX VPU libraries
 */

static unsigned char luma_q[64] = {
	0x06, 0x04, 0x04, 0x04, 0x05, 0x04, 0x06, 0x05, 0x05, 0x06, 0x09,
	0x06, 0x05, 0x06, 0x09, 0x0b, 0x08, 0x06, 0x06, 0x08, 0x0b, 0x0c,
	0x0a, 0x0a, 0x0b, 0x0a, 0x0a, 0x0c, 0x10, 0x0c, 0x0c, 0x0c, 0x0c,
	0x0c, 0x0c, 0x10, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c,
	0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c,
	0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c,
};

static unsigned char chroma_q[64] = {
	0x07, 0x07, 0x07, 0x0d, 0x0c, 0x0d, 0x18, 0x10, 0x10, 0x18, 0x14,
	0x0e, 0x0e, 0x0e, 0x14, 0x14, 0x0e, 0x0e, 0x0e, 0x0e, 0x14, 0x11,
	0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x11, 0x11, 0x0c, 0x0c, 0x0c, 0x0c,
	0x0c, 0x0c, 0x11, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c,
	0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c,
	0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c, 0x0c,
};

static const unsigned char jpeg_app14[] = { 0xFF, 0xEE, 0x00, 0x0E, 0x41, 0x64,
					    0x6F, 0x62, 0x65, 0x00, 0x64, 0x00,
					    0x00, 0x00, 0x00, 0x00 };
static const unsigned char width_align[] = {
	[RTK_JPEG_FORMAT_420] = 16, [RTK_JPEG_FORMAT_422] = 16,
	[RTK_JPEG_FORMAT_224] = 8,  [RTK_JPEG_FORMAT_444] = 8,
	[RTK_JPEG_FORMAT_400] = 8,
};

static const unsigned char height_align[] = {
	[RTK_JPEG_FORMAT_420] = 16, [RTK_JPEG_FORMAT_422] = 8,
	[RTK_JPEG_FORMAT_224] = 16, [RTK_JPEG_FORMAT_444] = 8,
	[RTK_JPEG_FORMAT_400] = 8,
};

static int rtk_jpeg_chroma_format(u32 pixfmt)
{
	switch (pixfmt) {
	case V4L2_PIX_FMT_YUV420:
	case V4L2_PIX_FMT_NV12:
		return RTK_JPEG_FORMAT_420;
	case V4L2_PIX_FMT_YUV422P:
	case V4L2_PIX_FMT_NV16:
		return RTK_JPEG_FORMAT_422;
	case V4L2_PIX_FMT_YUV444M:
	case V4L2_PIX_FMT_NV24:
	case V4L2_PIX_FMT_RGB24:
		return RTK_JPEG_FORMAT_444;
	case V4L2_PIX_FMT_GREY:
		return RTK_JPEG_FORMAT_400;
	}
	return -EINVAL;
}

static bool rtk_jpeg_check_buffer(struct rtk_jcodec_ctx *ctx, struct vb2_buffer *vb)
{
	void *vaddr = vb2_plane_vaddr(vb, 0);
	u16 soi, eoi;
	int len, i;

	soi = be16_to_cpup((__be16 *)vaddr);
	if (soi != SOI_MARKER)
		return false;

	len = vb2_get_plane_payload(vb, 0);
	vaddr += len - 2;
	for (i = 0; i < 32; i++) {
		eoi = be16_to_cpup((__be16 *)(vaddr - i));
		if (eoi == EOI_MARKER) {
			if (i > 0)
				vb2_set_plane_payload(vb, 0, len - i);
			return true;
		}
	}

	return false;
}

static int rtk_jpeg_gen_dec_huff_tab(struct rtk_jcodec_ctx *ctx, int tab_num);

static int rtk_jpeg_decode_header(struct rtk_jcodec_ctx *ctx, struct vb2_buffer *vb)
{
	struct rtk_jcodec_dev *dev = ctx->dev;
	u8 *buf = vb2_plane_vaddr(vb, 0);
	size_t len = vb2_get_plane_payload(vb, 0);
	struct v4l2_jpeg_scan_header scan_header;
	struct v4l2_jpeg_reference quantization_tables[4] = {};
	struct v4l2_jpeg_reference huffman_tables[4] = {};
	struct v4l2_jpeg_header header = {
		.scan = &scan_header,
		.quantization_tables = quantization_tables,
		.huffman_tables = huffman_tables,
	};
	struct rtk_q_data *q_data_src;
	struct rtk_huff_tab *huff_tab;
	int i, j, ret;
	int sampleFactor;

	size_t print_len = len < 30 ? len : 30;
	char hex_buf[90];
	memset(hex_buf, 0, sizeof(hex_buf));
	for (i = 0; i < print_len; i++) {
		snprintf(hex_buf + i * 3, 4, "%02x ", buf[i]);
	}
	rtk_jcodec_dbg(2, ctx, "First %zu bytes: %s\n", print_len,
		       hex_buf); //print bs buffer

	ret = v4l2_jpeg_parse_header(buf, len, &header);
	if (ret < 0) {
		v4l2_err(&dev->v4l2_dev, "failed to parse header\n");
		return ret;
	}

	ctx->params.jpeg_restart_interval = header.restart_interval;

	/* check frame header */
	if (header.frame.height > ctx->codec->max_h ||
	    header.frame.width > ctx->codec->max_w) {
		v4l2_err(&dev->v4l2_dev, "invalid dimensions: %dx%d\n",
			 header.frame.width, header.frame.height);
		return -EINVAL;
	}

	if (header.app14_tf == V4L2_JPEG_APP14_TF_CMYK_RGB) {
		ctx->params.rgb = 1;
	} else {
		ctx->params.rgb = 0;
	}

	for (i = 0; i < scan_header.num_components; i++) {
		ctx->params.jpeg_qmat_index[i] =
			header.frame.component[i].quantization_table_selector;

		rtk_jcodec_dbg(2, ctx, "  Component %d:\n", i);
		rtk_jcodec_dbg(2, ctx, "  ID: %d\n",
			       header.frame.component[i].component_identifier);
		rtk_jcodec_dbg(
			2, ctx, "  Sampling Factor: H=%d, V=%d\n",
			header.frame.component[i].horizontal_sampling_factor,
			header.frame.component[i].vertical_sampling_factor);
	}

	if (scan_header.num_components == 1)
		sampleFactor = SAMPLE_400;
	else
		sampleFactor =
			((header.frame.component[0].horizontal_sampling_factor &
			  3)
			 << 2) |
			(header.frame.component[0].vertical_sampling_factor &
			 3);

	switch (sampleFactor) {
	case SAMPLE_420:
		ctx->params.format = RTK_JPEG_FORMAT_420;
		break;
	case SAMPLE_H422:
		ctx->params.format = RTK_JPEG_FORMAT_422;
		break;
	case SAMPLE_V422:
		ctx->params.format = RTK_JPEG_FORMAT_224;
		break;
	case SAMPLE_444:
		ctx->params.format = RTK_JPEG_FORMAT_444;
		break;
	default: // 4:0:0
		ctx->params.format = RTK_JPEG_FORMAT_400;
	}

	q_data_src = get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);

	if (header.frame.height != q_data_src->height ||
	    header.frame.width != q_data_src->width) {
		v4l2_err(
			&dev->v4l2_dev,
			" frame dimensions don't match format: %dx%d q_data_src %dx%d\n",
			header.frame.width, header.frame.height,
			q_data_src->width, q_data_src->height);

		return -EINVAL;
	}

	if (header.frame.num_components != 3) {
		v4l2_err(&dev->v4l2_dev,
			 "unsupported number of components: %d\n",
			 header.frame.num_components);
		return -EINVAL;
	}

	/* install quantization tables */
	if (quantization_tables[3].start) {
		v4l2_err(&dev->v4l2_dev,
			 "only 3 quantization tables supported\n");
		return -EINVAL;
	}
	for (i = 0; i < 4; i++) {
		if (!quantization_tables[i].start)
			continue;
		if (quantization_tables[i].length != 64) {
			v4l2_err(&dev->v4l2_dev,
				 "only 8-bit quantization tables supported\n");
			continue;
		}
		if (!ctx->params.jpeg_qmat_tab[i]) {
			ctx->params.jpeg_qmat_tab[i] = kmalloc(64, GFP_KERNEL);
			if (!ctx->params.jpeg_qmat_tab[i])
				return -ENOMEM;
		}
		memcpy(ctx->params.jpeg_qmat_tab[i],
		       quantization_tables[i].start, 64);
	}

	/* install Huffman tables */
	for (i = 0; i < 4; i++) {
		if (!huffman_tables[i].start) {
			rtk_jcodec_dbg(2, ctx, "missing Huffman table %d \n",
				       i);
			//return -EINVAL;
			continue;
		}
		/* AC tables should be between 17 -> 178, DC between 17 -> 28 */
		if (huffman_tables[i].length < 17 ||
		    huffman_tables[i].length > 178 ||
		    ((i & 2) == 0 && huffman_tables[i].length > 28)) {
			v4l2_err(&dev->v4l2_dev,
				 "invalid Huffman table %d length: %zu\n", i,
				 huffman_tables[i].length);
			return -EINVAL;
		}
	}
	huff_tab = ctx->params.jpeg_huff_tab;
	if (!huff_tab) {
		huff_tab = kzalloc(sizeof(struct rtk_huff_tab), GFP_KERNEL);
		if (!huff_tab)
			return -ENOMEM;
		ctx->params.jpeg_huff_tab = huff_tab;
	}

	memset(huff_tab, 0, sizeof(*huff_tab));
	if (huffman_tables[0].start) {
		memcpy(huff_tab->luma_dc, huffman_tables[0].start,
		       huffman_tables[0].length);
	} else {
		memcpy(huff_tab->luma_dc, luma_dc, sizeof(luma_dc));
	}

	if (huffman_tables[1].start) {
		memcpy(huff_tab->chroma_dc, huffman_tables[1].start,
		       huffman_tables[1].length);
	} else {
		memcpy(huff_tab->chroma_dc, chroma_dc, sizeof(chroma_dc) - 2);
	}

	if (huffman_tables[2].start) {
		memcpy(huff_tab->luma_ac, huffman_tables[2].start,
		       huffman_tables[2].length);
	} else {
		memcpy(huff_tab->luma_ac, luma_ac, sizeof(luma_ac) - 2);
	}

	if (huffman_tables[3].start) {
		memcpy(huff_tab->chroma_ac, huffman_tables[3].start,
		       huffman_tables[3].length);
	} else {
		memcpy(huff_tab->chroma_ac, chroma_ac, sizeof(chroma_ac) - 2);
	}

	/* check scan header */
	for (i = 0; i < scan_header.num_components; i++) {
		struct v4l2_jpeg_scan_component_spec *scan_component;

		scan_component = &scan_header.component[i];
		for (j = 0; j < header.frame.num_components; j++) {
			if (header.frame.component[j].component_identifier ==
			    scan_component->component_selector)
				break;
		}
		if (j == header.frame.num_components)
			continue;

		ctx->params.jpeg_huff_dc_index[j] =
			scan_component->dc_entropy_coding_table_selector;
		ctx->params.jpeg_huff_ac_index[j] =
			scan_component->ac_entropy_coding_table_selector;
	}

	/* Generate Huffman table information */
	for (i = 0; i < 4; i++)
		rtk_jpeg_gen_dec_huff_tab(ctx, i);

	/* start of entropy coded segment */
	ctx->jpeg_ecs_offset = header.ecs_offset;

	switch (header.frame.subsampling) {
	case V4L2_JPEG_CHROMA_SUBSAMPLING_420:
	case V4L2_JPEG_CHROMA_SUBSAMPLING_422:
	case V4L2_JPEG_CHROMA_SUBSAMPLING_444:
		ctx->params.jpeg_chroma_subsampling = header.frame.subsampling;
		break;
	default:
		v4l2_err(&dev->v4l2_dev, "chroma subsampling not supported: %d",
			 header.frame.subsampling);
		return -EINVAL;
	}

	return 0;
}

static inline void rtk_jpeg_write_huff_values(struct rtk_jcodec_dev *dev,
					      u8 *bits, int num_values)
{
	s8 *values = (s8 *)(bits + 16);
	int huff_length, i;

	for (huff_length = 0, i = 0; i < 16; i++)
		huff_length += bits[i];
	for (i = huff_length; i < num_values; i++)
		values[i] = -1;
	for (i = 0; i < num_values; i++)
		rtk_jcodec_write(dev, (s32)values[i], RTK_REG_JPEG_HUFF_DATA);
}

static int rtk_jpeg_dec_huff_setup(struct rtk_jcodec_ctx *ctx)
{
	struct rtk_huff_tab *huff_tab = ctx->params.jpeg_huff_tab;
	struct rtk_jcodec_dev *dev = ctx->dev;
	s16 *huff_min = huff_tab->min;
	s16 *huff_max = huff_tab->max;
	s8 *huff_ptr = huff_tab->ptr;
	int i;

	/* MIN Tables */
	rtk_jcodec_write(dev, 0x003, RTK_REG_JPEG_HUFF_CTRL);
	rtk_jcodec_write(dev, 0x000, RTK_REG_JPEG_HUFF_ADDR);
	for (i = 0; i < 4 * 16; i++)
		rtk_jcodec_write(dev, (s32)huff_min[i], RTK_REG_JPEG_HUFF_DATA);

	/* MAX Tables */
	rtk_jcodec_write(dev, 0x403, RTK_REG_JPEG_HUFF_CTRL);
	rtk_jcodec_write(dev, 0x440, RTK_REG_JPEG_HUFF_ADDR);
	for (i = 0; i < 4 * 16; i++)
		rtk_jcodec_write(dev, (s32)huff_max[i], RTK_REG_JPEG_HUFF_DATA);

	/* PTR Tables */
	rtk_jcodec_write(dev, 0x803, RTK_REG_JPEG_HUFF_CTRL);
	rtk_jcodec_write(dev, 0x880, RTK_REG_JPEG_HUFF_ADDR);
	for (i = 0; i < 4 * 16; i++)
		rtk_jcodec_write(dev, (s32)huff_ptr[i], RTK_REG_JPEG_HUFF_DATA);

	/* VAL Tables: DC Luma, DC Chroma, AC Luma, AC Chroma */
	rtk_jcodec_write(dev, 0xc03, RTK_REG_JPEG_HUFF_CTRL);
	rtk_jpeg_write_huff_values(dev, huff_tab->luma_dc, 12);
	rtk_jpeg_write_huff_values(dev, huff_tab->chroma_dc, 12);
	rtk_jpeg_write_huff_values(dev, huff_tab->luma_ac, 162);
	rtk_jpeg_write_huff_values(dev, huff_tab->chroma_ac, 162);
	rtk_jcodec_write(dev, 0x000, RTK_REG_JPEG_HUFF_CTRL);
	return 0;
}

static inline void rtk_jpeg_write_qmat_tab(struct rtk_jcodec_dev *dev, u8 *qmat,
					   int index)
{
	int i;

	rtk_jcodec_write(dev, index | 0x3, RTK_REG_JPEG_QMAT_CTRL);
	for (i = 0; i < 64; i++)
		rtk_jcodec_write(dev, qmat[i], RTK_REG_JPEG_QMAT_DATA);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_QMAT_CTRL);
}

static void rtk_jpeg_qmat_setup(struct rtk_jcodec_ctx *ctx)
{
	struct rtk_jcodec_dev *dev = ctx->dev;
	int *qmat_index = ctx->params.jpeg_qmat_index;
	u8 **qmat_tab = ctx->params.jpeg_qmat_tab;

	rtk_jpeg_write_qmat_tab(dev, qmat_tab[qmat_index[0]], 0x00);
	rtk_jpeg_write_qmat_tab(dev, qmat_tab[qmat_index[1]], 0x40);
	rtk_jpeg_write_qmat_tab(dev, qmat_tab[qmat_index[2]], 0x80);
}

static void rtk_jpeg_dec_bbc_gbu_setup(struct rtk_jcodec_ctx *ctx,
				       struct vb2_buffer *buf, u32 ecs_offset)
{
	struct rtk_jcodec_dev *dev = ctx->dev;
	int page_ptr, word_ptr, bit_ptr;
	u32 bbc_base_addr, end_addr;
	int bbc_cur_pos;
	int ret, val;

	bbc_base_addr = vb2_dma_contig_plane_dma_addr(buf, 0);
	end_addr = bbc_base_addr + vb2_get_plane_payload(buf, 0);

	page_ptr = ecs_offset / 256;
	word_ptr = (ecs_offset % 256) / 4;

	if (page_ptr & 1)
		word_ptr += 64;
	bit_ptr = (ecs_offset % 4) * 8;
	if (word_ptr & 1)
		bit_ptr += 32;
	word_ptr &= ~0x1;

	rtk_jcodec_write(dev, end_addr, RTK_REG_JPEG_BBC_WR_PTR);
	rtk_jcodec_write(dev, bbc_base_addr, RTK_REG_JPEG_BBC_BAS_ADDR);

	/* Leave 3 256-byte page margin to avoid a BBC interrupt */
	rtk_jcodec_write(dev, end_addr + 256 * 3 + 256,
			 RTK_REG_JPEG_BBC_END_ADDR);
	val = DIV_ROUND_UP(vb2_plane_size(buf, 0), 256) + 3;
	rtk_jcodec_write(dev, BIT(31) | val, RTK_REG_JPEG_BBC_STRM_CTRL);

	bbc_cur_pos = page_ptr;
	rtk_jcodec_write(dev, bbc_cur_pos, RTK_REG_JPEG_BBC_CUR_POS);
	rtk_jcodec_write(dev, bbc_base_addr + (bbc_cur_pos << 8),
			 RTK_REG_JPEG_BBC_EXT_ADDR);
	rtk_jcodec_write(dev, (bbc_cur_pos & 1) << 6,
			 RTK_REG_JPEG_BBC_INT_ADDR);
	rtk_jcodec_write(
		dev, 64,
		RTK_REG_JPEG_BBC_DATA_CNT); // 64 * 4 byte == 32 * 8 byte
	rtk_jcodec_write(dev, (ctx->params.streamEndian << 1) | 0,
			 RTK_REG_JPEG_BBC_COMMAND);
	do {
		ret = rtk_jcodec_read(dev, RTK_REG_JPEG_BBC_BUSY);
	} while (ret == 1);

	bbc_cur_pos++;
	rtk_jcodec_write(dev, bbc_cur_pos, RTK_REG_JPEG_BBC_CUR_POS);
	rtk_jcodec_write(dev, bbc_base_addr + (bbc_cur_pos << 8),
			 RTK_REG_JPEG_BBC_EXT_ADDR);
	rtk_jcodec_write(dev, (bbc_cur_pos & 1) << 6,
			 RTK_REG_JPEG_BBC_INT_ADDR);
	rtk_jcodec_write(
		dev, 64,
		RTK_REG_JPEG_BBC_DATA_CNT); // 64 * 4 byte == 32 * 8 byte
	rtk_jcodec_write(dev, (ctx->params.streamEndian << 1) | 0,
			 RTK_REG_JPEG_BBC_COMMAND);
	do {
		ret = rtk_jcodec_read(dev, RTK_REG_JPEG_BBC_BUSY);
	} while (ret == 1);

	bbc_cur_pos++;
	rtk_jcodec_write(dev, bbc_cur_pos, RTK_REG_JPEG_BBC_CUR_POS);
	rtk_jcodec_write(dev, 1, RTK_REG_JPEG_BBC_CTRL);

	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_GBU_TT_CNT);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_GBU_TT_CNT + 4);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_PIC_ERRMB);
	rtk_jcodec_write(dev, word_ptr, RTK_REG_JPEG_GBU_WD_PTR);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_GBU_BBSR);
	rtk_jcodec_write(dev, 127, RTK_REG_JPEG_GBU_BBER);
	if (page_ptr & 1) {
		rtk_jcodec_write(dev, 0, RTK_REG_JPEG_GBU_BBIR);
		rtk_jcodec_write(dev, 0, RTK_REG_JPEG_GBU_BBHR);
	} else {
		rtk_jcodec_write(dev, 64, RTK_REG_JPEG_GBU_BBIR);
		rtk_jcodec_write(dev, 64, RTK_REG_JPEG_GBU_BBHR);
	}
	rtk_jcodec_write(dev, 4, RTK_REG_JPEG_GBU_CTRL);
	rtk_jcodec_write(dev, bit_ptr, RTK_REG_JPEG_GBU_FF_RPTR);
	rtk_jcodec_write(dev, 3, RTK_REG_JPEG_GBU_CTRL);
}

static const int bus_req_num[] = {
	[RTK_JPEG_FORMAT_420] = 2, [RTK_JPEG_FORMAT_422] = 3,
	[RTK_JPEG_FORMAT_224] = 3, [RTK_JPEG_FORMAT_444] = 4,
	[RTK_JPEG_FORMAT_400] = 4,
};

#define MCU_INFO(mcu_block_num, comp_num, comp0_info, comp1_info, comp2_info)  \
	(((mcu_block_num) << RTK_JPEG_MCU_BLOCK_NUM_OFFSET) |                  \
	 ((comp_num) << RTK_JPEG_COMP_NUM_OFFSET) |                            \
	 ((comp0_info) << RTK_JPEG_COMP0_INFO_OFFSET) |                        \
	 ((comp1_info) << RTK_JPEG_COMP1_INFO_OFFSET) |                        \
	 ((comp2_info) << RTK_JPEG_COMP2_INFO_OFFSET))

static const u32 mcu_info[] = {
	[RTK_JPEG_FORMAT_420] = MCU_INFO(6, 3, 10, 5, 5),
	[RTK_JPEG_FORMAT_422] = MCU_INFO(4, 3, 9, 5, 5),
	[RTK_JPEG_FORMAT_224] = MCU_INFO(4, 3, 6, 5, 5),
	[RTK_JPEG_FORMAT_444] = MCU_INFO(3, 3, 5, 5, 5),
	[RTK_JPEG_FORMAT_400] = MCU_INFO(1, 1, 5, 0, 0),
};
/*
 * Convert Huffman table specifcations to tables of codes and code lengths.
 * For reference, see JPEG ITU-T.81 (ISO/IEC 10918-1) [1]
 *
 * [1] https://www.w3.org/Graphics/JPEG/itu-t81.pdf
 */
static int rtk_jpeg_gen_enc_huff_tab(struct rtk_jcodec_ctx *ctx, int tab_num,
				     int *ehufsi, int *ehufco, int is_rgb)
{
	int i, j, k, lastk, si, code, maxsymbol;
	const u8 *bits, *huffval;
	int ret = -EINVAL;
	struct {
		int size[256];
		int code[256];
	} * huff;

	static const unsigned char *huff_tabs[4];
	if (!is_rgb) {
		huff_tabs[0] = luma_dc;
		huff_tabs[1] = luma_ac;
		huff_tabs[2] = chroma_dc;
		huff_tabs[3] = chroma_ac;
	} else {
		huff_tabs[0] = luma_dc;
		huff_tabs[1] = luma_ac;
		huff_tabs[2] = luma_dc;
		huff_tabs[3] = luma_ac;
	}


	huff = kzalloc(sizeof(*huff), GFP_KERNEL);
	if (!huff)
		return -ENOMEM;

	bits = huff_tabs[tab_num];
	huffval = huff_tabs[tab_num] + 16;

	maxsymbol = tab_num & 1 ? 256 : 16;

	/* Figure C.1 - Generation of table of Huffman code sizes */
	k = 0;
	for (i = 1; i <= 16; i++) {
		j = bits[i - 1];
		if (k + j > maxsymbol)
			goto out;
		while (j--)
			huff->size[k++] = i;
	}
	lastk = k;

	/* Figure C.2 - Generation of table of Huffman codes */
	k = 0;
	code = 0;
	si = huff->size[0];
	while (k < lastk) {
		while (huff->size[k] == si) {
			huff->code[k++] = code;
			code++;
		}
		if (code >= (1 << si))
			goto out;
		code <<= 1;
		si++;
	}

	/* Figure C.3 - Ordering procedure for encoding procedure code tables */
	for (k = 0; k < lastk; k++) {
		i = huffval[k];
		if (i >= maxsymbol || ehufsi[i])
			goto out;
		ehufco[i] = huff->code[k];
		ehufsi[i] = huff->size[k];
	}

	ret = 0;
out:
	kfree(huff);
	return ret;
}

#define DC_TABLE_INDEX0 0
#define AC_TABLE_INDEX0 1
#define DC_TABLE_INDEX1 2
#define AC_TABLE_INDEX1 3

static u8 *rtk_jpeg_get_huff_bits(struct rtk_jcodec_ctx *ctx, int tab_num)
{
	struct rtk_huff_tab *huff_tab = ctx->params.jpeg_huff_tab;

	if (!huff_tab)
		return NULL;

	switch (tab_num) {
	case DC_TABLE_INDEX0:
		return huff_tab->luma_dc;
	case AC_TABLE_INDEX0:
		return huff_tab->luma_ac;
	case DC_TABLE_INDEX1:
		return huff_tab->chroma_dc;
	case AC_TABLE_INDEX1:
		return huff_tab->chroma_ac;
	}

	return NULL;
}

static int rtk_jpeg_gen_dec_huff_tab(struct rtk_jcodec_ctx *ctx, int tab_num)
{
	int ptr_cnt = 0, huff_code = 0, zero_flag = 0, data_flag = 0;
	u8 *huff_bits;
	s16 *huff_max;
	s16 *huff_min;
	s8 *huff_ptr;
	int ofs;
	int i;

	huff_bits = rtk_jpeg_get_huff_bits(ctx, tab_num);
	if (!huff_bits)
		return -EINVAL;

	/* DC/AC Luma, DC/AC Chroma -> DC Luma/Chroma, AC Luma/Chroma */
	ofs = ((tab_num & 1) << 1) | ((tab_num >> 1) & 1);
	ofs *= 16;

	huff_ptr = ctx->params.jpeg_huff_tab->ptr + ofs;
	huff_max = ctx->params.jpeg_huff_tab->max + ofs;
	huff_min = ctx->params.jpeg_huff_tab->min + ofs;

	for (i = 0; i < 16; i++) {
		if (huff_bits[i]) {
			huff_ptr[i] = ptr_cnt;
			ptr_cnt += huff_bits[i];
			huff_min[i] = huff_code;
			huff_max[i] = huff_code + (huff_bits[i] - 1);
			data_flag = 1;
			zero_flag = 0;
		} else {
			huff_ptr[i] = -1;
			huff_min[i] = -1;
			huff_max[i] = -1;
			zero_flag = 1;
		}

		if (data_flag == 1) {
			if (zero_flag == 1)
				huff_code <<= 1;
			else
				huff_code = (huff_max[i] + 1) << 1;
		}
	}

	return 0;
}

static int rtk_jpeg_load_huff_tab(struct rtk_jcodec_ctx *ctx, int is_rgb)
{
	struct {
		int size[4][256];
		int code[4][256];
	} * huff;
	u32 *huff_data;
	int i, j;
	int ret;

	huff = kzalloc(sizeof(*huff), GFP_KERNEL);
	if (!huff)
		return -ENOMEM;

	/* Generate all four (luma/chroma DC/AC) code/size lookup tables */
	for (i = 0; i < 4; i++) {
		ret = rtk_jpeg_gen_enc_huff_tab(ctx, i, huff->size[i],
						huff->code[i], is_rgb);
		if (ret)
			goto out;
	}

	if (!ctx->params.jpeg_huff_data) {
		ctx->params.jpeg_huff_data = kzalloc(
			sizeof(u32) * RTK_JPEG_ENC_HUFF_DATA_SIZE, GFP_KERNEL);
		if (!ctx->params.jpeg_huff_data) {
			ret = -ENOMEM;
			goto out;
		}
	}
	huff_data = ctx->params.jpeg_huff_data;

	for (j = 0; j < 4; j++) {
		/* Store Huffman lookup tables in AC0, AC1, DC0, DC1 order */
		int t = (j == 0) ? AC_TABLE_INDEX0 :
				   (j == 1) ?
				   AC_TABLE_INDEX1 :
				   (j == 2) ? DC_TABLE_INDEX0 : DC_TABLE_INDEX1;
		/* DC tables only have 16 entries */
		int len = (j < 2) ? 256 : 16;

		for (i = 0; i < len; i++) {
			if (huff->size[t][i] == 0 && huff->code[t][i] == 0)
				*(huff_data++) = 0;
			else
				*(huff_data++) =
					((huff->size[t][i] - 1) << 16) |
					huff->code[t][i];
		}
	}

	ret = 0;
out:
	kfree(huff);
	return ret;
}

static void rtk_jpeg_write_huff_tab(struct rtk_jcodec_ctx *ctx)
{
	struct rtk_jcodec_dev *dev = ctx->dev;
	u32 *huff_data = ctx->params.jpeg_huff_data;
	int i;

	/* Write Huffman size/code lookup tables in AC0, AC1, DC0, DC1 order */
	rtk_jcodec_write(dev, 0x3, RTK_REG_JPEG_HUFF_CTRL);
	for (i = 0; i < RTK_JPEG_ENC_HUFF_DATA_SIZE; i++)
		rtk_jcodec_write(dev, *(huff_data++), RTK_REG_JPEG_HUFF_DATA);
	rtk_jcodec_write(dev, 0x0, RTK_REG_JPEG_HUFF_CTRL);
}

static inline void rtk_jpeg_write_qmat_quotients(struct rtk_jcodec_dev *dev,
						 u8 *qmat, int index)
{
	int i;

	rtk_jcodec_write(dev, index | 0x3, RTK_REG_JPEG_QMAT_CTRL);
	for (i = 0; i < 64; i++)
		rtk_jcodec_write(dev, 0x80000 / qmat[i],
				 RTK_REG_JPEG_QMAT_DATA);
	rtk_jcodec_write(dev, index, RTK_REG_JPEG_QMAT_CTRL);
}

static void rtk_jpeg_load_qmat_tab(struct rtk_jcodec_ctx *ctx)
{
	struct rtk_jcodec_dev *dev = ctx->dev;
	u8 *luma_tab;
	u8 *chroma_tab;

	struct rtk_q_data *q_data_src;
	int chroma_format;
	q_data_src = get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
	chroma_format = rtk_jpeg_chroma_format(q_data_src->fourcc);

	luma_tab = ctx->params.jpeg_qmat_tab[0];
	if (!luma_tab)
		luma_tab = luma_q;

	chroma_tab = ctx->params.jpeg_qmat_tab[1];

	if (!chroma_tab) {
		if (chroma_format == RTK_JPEG_FORMAT_444 &&
		    q_data_src->fourcc == V4L2_PIX_FMT_RGB24) {
			chroma_tab = luma_q;
		} else {
			chroma_tab = chroma_q;
		}
	}

	rtk_jpeg_write_qmat_quotients(dev, luma_tab, 0x00);
	rtk_jpeg_write_qmat_quotients(dev, chroma_tab, 0x40);
	rtk_jpeg_write_qmat_quotients(dev, chroma_tab, 0x80);
}

struct rtk_jpeg_stream {
	u8 *curr;
	u8 *end;
};

static inline int rtk_jpeg_put_byte(u8 byte, struct rtk_jpeg_stream *stream)
{
	if (stream->curr >= stream->end)
		return -EINVAL;

	*stream->curr++ = byte;

	return 0;
}

static inline int rtk_jpeg_put_word(u16 word, struct rtk_jpeg_stream *stream)
{
	if (stream->curr + sizeof(__be16) > stream->end)
		return -EINVAL;

	put_unaligned_be16(word, stream->curr);
	stream->curr += sizeof(__be16);

	return 0;
}

static int rtk_jpeg_put_table(u16 marker, u8 index, const u8 *table, size_t len,
			      struct rtk_jpeg_stream *stream)
{
	int i, ret;

	ret = rtk_jpeg_put_word(marker, stream);
	if (ret < 0)
		return ret;
	ret = rtk_jpeg_put_word(3 + len, stream);
	if (ret < 0)
		return ret;
	ret = rtk_jpeg_put_byte(index, stream);
	for (i = 0; i < len && ret == 0; i++)
		ret = rtk_jpeg_put_byte(table[i], stream);

	return ret;
}

static int rtk_jpeg_define_quantization_table(struct rtk_jcodec_ctx *ctx,
					      u8 index,
					      struct rtk_jpeg_stream *stream)
{
	return rtk_jpeg_put_table(DQT_MARKER, index,
				  ctx->params.jpeg_qmat_tab[index], 64, stream);
}

static int rtk_jpeg_define_huffman_table(u8 index, const u8 *table, size_t len,
					 struct rtk_jpeg_stream *stream)
{
	return rtk_jpeg_put_table(DHT_MARKER, index, table, len, stream);
}

static int rtk_jpeg_encode_header(struct rtk_jcodec_ctx *ctx, int len, u8 *buf)
{
	struct rtk_jpeg_stream stream = { buf, buf + len };
	struct rtk_q_data *q_data_src;
	int chroma_format, comp_num;
	int i, ret, pad;
	struct rtk_jcodec_dev *dev = ctx->dev;

	q_data_src = get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
	chroma_format = rtk_jpeg_chroma_format(q_data_src->fourcc);
	if (chroma_format < 0)
		return 0;

	/* Start Of Image */
	ret = rtk_jpeg_put_word(SOI_MARKER, &stream);
	if (ret < 0)
		return ret;

	if (chroma_format == RTK_JPEG_FORMAT_444 &&
	    q_data_src->fourcc == V4L2_PIX_FMT_RGB24) {
		for (i = 0; i < sizeof(jpeg_app14) && ret == 0; i++) {
			ret = rtk_jpeg_put_byte(jpeg_app14[i], &stream);
		}
		if (ret < 0)
			return ret;
	}

	/* Define Restart Interval */
	if (ctx->params.jpeg_restart_interval) {
		ret = rtk_jpeg_put_word(DRI_MARKER, &stream);
		if (ret < 0)
			return ret;
		ret = rtk_jpeg_put_word(4, &stream);
		if (ret < 0)
			return ret;
		ret = rtk_jpeg_put_word(ctx->params.jpeg_restart_interval,
					&stream);
		if (ret < 0)
			return ret;
	}

	/* Define Quantization Tables */
	ret = rtk_jpeg_define_quantization_table(ctx, 0x00, &stream);
	if (ret < 0)
		return ret;

	if (chroma_format == RTK_JPEG_FORMAT_444 &&
	    q_data_src->fourcc == V4L2_PIX_FMT_RGB24) {
		rtk_set_jpeg_compression_quality(ctx, ctx->params.jpeg_quality,
						 1);
	}

	if (chroma_format != RTK_JPEG_FORMAT_400) {
		//if(chroma_components){
		ret = rtk_jpeg_define_quantization_table(ctx, 0x01, &stream);
		if (ret < 0)
			return ret;
	}

	/* Define Huffman Tables */
	ret = rtk_jpeg_define_huffman_table(0x00, luma_dc, 16 + 12, &stream);
	if (ret < 0)
		return ret;
	ret = rtk_jpeg_define_huffman_table(0x10, luma_ac, 16 + 162, &stream);
	if (ret < 0)
		return ret;
	if (chroma_format != RTK_JPEG_FORMAT_400) {
		if (chroma_format == RTK_JPEG_FORMAT_444 &&
		    q_data_src->fourcc == V4L2_PIX_FMT_RGB24) {
			ret = rtk_jpeg_load_huff_tab(ctx, 1);
			if (ret < 0) {
				v4l2_err(&dev->v4l2_dev,
					 "error loading Huffman tables\n");
				return ret;
			}

			ret = rtk_jpeg_define_huffman_table(0x01, luma_dc,
							    16 + 12, &stream);
			if (ret < 0)
				return ret;
			ret = rtk_jpeg_define_huffman_table(0x11, luma_ac,
							    16 + 162, &stream);
			if (ret < 0)
				return ret;

		} else { //yuv
			ret = rtk_jpeg_define_huffman_table(0x01, chroma_dc,
							    16 + 12, &stream);
			if (ret < 0)
				return ret;
			ret = rtk_jpeg_define_huffman_table(0x11, chroma_ac,
							    16 + 162, &stream);
			if (ret < 0)
				return ret;
		}
	}

	/* Start Of Frame */
	ret = rtk_jpeg_put_word(SOF_MARKER, &stream);
	if (ret < 0)
		return ret;
	comp_num = (chroma_format == RTK_JPEG_FORMAT_400) ? 1 : 3;
	ret = rtk_jpeg_put_word(8 + comp_num * 3, &stream);
	if (ret < 0)
		return ret;
	ret = rtk_jpeg_put_byte(0x08, &stream);
	if (ret < 0)
		return ret;
	ret = rtk_jpeg_put_word(q_data_src->height, &stream);
	if (ret < 0)
		return ret;
	ret = rtk_jpeg_put_word(q_data_src->width, &stream);
	if (ret < 0)
		return ret;
	ret = rtk_jpeg_put_byte(comp_num, &stream);
	if (ret < 0)
		return ret;
	for (i = 0; i < comp_num; i++) {
		static unsigned char subsampling[5][3] = {
			[RTK_JPEG_FORMAT_420] = { 0x22, 0x11, 0x11 },
			[RTK_JPEG_FORMAT_422] = { 0x21, 0x11, 0x11 },
			[RTK_JPEG_FORMAT_224] = { 0x12, 0x11, 0x11 },
			[RTK_JPEG_FORMAT_444] = { 0x11, 0x11, 0x11 },
			[RTK_JPEG_FORMAT_400] = { 0x11 },
		};

		/* Component identifier, matches SOS */
		ret = rtk_jpeg_put_byte(i + 1, &stream);
		if (ret < 0)
			return ret;
		ret = rtk_jpeg_put_byte(subsampling[chroma_format][i], &stream);
		if (ret < 0)
			return ret;
		/* Chroma table index */
		ret = rtk_jpeg_put_byte((i == 0) ? 0 : 1, &stream);
		if (ret < 0)
			return ret;
	}

	/* Pad to multiple of 8 bytes */
	pad = (stream.curr - buf) % 8;
	if (pad) {
		pad = 8 - pad;
		while (pad--) {
			ret = rtk_jpeg_put_byte(0x00, &stream);
			if (ret < 0)
				return ret;
		}
	}

	return stream.curr - buf;
}

/*
 * Scale quantization table using nonlinear scaling factor
 * u8 qtab[64], scale [50,190]
 */
static void rtk_scale_quant_table(u8 *q_tab, int scale)
{
	unsigned int temp;
	int i;

	for (i = 0; i < 64; i++) {
		temp = DIV_ROUND_CLOSEST((unsigned int)q_tab[i] * scale, 100);
		if (temp <= 0)
			temp = 1;
		if (temp > 255)
			temp = 255;
		q_tab[i] = (unsigned char)temp;
	}
}

void rtk_set_jpeg_compression_quality(struct rtk_jcodec_ctx *ctx, int quality,
				      int is_rgb)
{
	unsigned int scale;

	ctx->params.jpeg_quality = quality;

	/* Clip quality setting to [5,100] interval */
	if (quality > 100)
		quality = 100;
	if (quality < 5)
		quality = 5;

	/*
	 * Non-linear scaling factor:
	 * [5,50] -> [1000..100], [51,100] -> [98..0]
	 */
	if (quality < 50)
		scale = 5000 / quality;
	else
		scale = 200 - 2 * quality;

	if (ctx->params.jpeg_qmat_tab[0]) {
		memcpy(ctx->params.jpeg_qmat_tab[0], luma_q, 64);
		rtk_scale_quant_table(ctx->params.jpeg_qmat_tab[0], scale);
	}
	if (ctx->params.jpeg_qmat_tab[1]) {
		if (!is_rgb) {
			memcpy(ctx->params.jpeg_qmat_tab[1], chroma_q, 64);
		} else {
			memcpy(ctx->params.jpeg_qmat_tab[1], luma_q, 64);
		}

		rtk_scale_quant_table(ctx->params.jpeg_qmat_tab[1], scale);
	}
}

/*
 * Encoder context operations
 */

static int rtk_jpeg_start_encoding(struct rtk_jcodec_ctx *ctx)
{
	struct rtk_jcodec_dev *dev = ctx->dev;
	int ret;

	ret = rtk_jpeg_load_huff_tab(ctx, 0);
	if (ret < 0) {
		v4l2_err(&dev->v4l2_dev, "error loading Huffman tables\n");
		return ret;
	}
	if (!ctx->params.jpeg_qmat_tab[0]) {
		ctx->params.jpeg_qmat_tab[0] = kmalloc(64, GFP_KERNEL);
		if (!ctx->params.jpeg_qmat_tab[0])
			return -ENOMEM;
	}
	if (!ctx->params.jpeg_qmat_tab[1]) {
		ctx->params.jpeg_qmat_tab[1] = kmalloc(64, GFP_KERNEL);
		if (!ctx->params.jpeg_qmat_tab[1])
			return -ENOMEM;
	}
	rtk_set_jpeg_compression_quality(ctx, ctx->params.jpeg_quality, 0);

	return 0;
}

static void rtk_set_packedFormat(struct rtk_jcodec_ctx *ctx, u32 fourcc)
{
	if (fourcc == V4L2_PIX_FMT_RGB24) {
		ctx->params.packedFormat = PACKED_FORMAT_444;
	} else {
		ctx->params.packedFormat = PACKED_FORMAT_NONE;
	}
}


static void  rtk_jpeg_cal_align(struct vb2_v4l2_buffer *src_buf,
				uint32_t fmt ,uint32_t width, uint32_t height,
				uint32_t *align_width, uint32_t *align_height)
{
	unsigned long size = vb2_get_plane_payload(&src_buf->vb2_buf, 0);
	int w_align[3] = {32, 64, 128};
	int h_align[3] = {32, 64, 128};
	int i = 0;
	for(i = 0; i < 3; i++) {
		*align_width = ALIGN(width, w_align[i]);
		*align_height = ALIGN(height, h_align[i]);

		if (fmt == V4L2_PIX_FMT_NV12 ||
			fmt == V4L2_PIX_FMT_YUV420) {
			if((*align_width) * (*align_height) * 3 /2 == size)
				return;
		} else if (fmt == V4L2_PIX_FMT_NV16 ||
				fmt == V4L2_PIX_FMT_YUV422P) {
			if((*align_width) * (*align_height) * 2 == size)
				return;
		} else if (fmt == V4L2_PIX_FMT_NV24 ||
				fmt == V4L2_PIX_FMT_YUV444M ||
				fmt == V4L2_PIX_FMT_RGB24) {
			if((*align_width) * (*align_height) * 3 == size)
				return;
		}
	}

	*align_width = width;
	*align_height = height;
}

static void rtk_jcodec_write_base(struct rtk_jcodec_ctx *ctx,
			   struct rtk_q_data *q_data,
			   struct vb2_v4l2_buffer *buf, int chroma_interleave,
			   unsigned int reg_y)
{
	u32 base_y = 0, base_cb = 0, base_cr = 0;
	u32 allocHeight = 0;
	u32 lumaSize, chrSize;
	int divX, divY;
	int chroma_format = rtk_jpeg_chroma_format(q_data->fourcc);
	u32 val;

	if (ctx->inst_type == RTK_JCODEC_CTX_ENCODER &&
	    V4L2_TYPE_IS_OUTPUT(buf->vb2_buf.type))
		base_y = vb2_dma_contig_plane_dma_addr(&buf->vb2_buf, 0) +
			 buf->planes[0].data_offset;
	else
		base_y = vb2_dma_contig_plane_dma_addr(&buf->vb2_buf, 0);

	if (ctx->params.rot_mode & RTK_ROT_90) {
		if (chroma_format == RTK_JPEG_FORMAT_422) {
			chroma_format = RTK_JPEG_FORMAT_224;
		} else if (chroma_format == RTK_JPEG_FORMAT_224) {
			chroma_format = RTK_JPEG_FORMAT_422;
		}
	}

	divX = chroma_format == RTK_JPEG_FORMAT_420 ||
			       chroma_format == RTK_JPEG_FORMAT_422 ?
		       2 :
		       1;
	divY = chroma_format == RTK_JPEG_FORMAT_420 ||
			       chroma_format == RTK_JPEG_FORMAT_224 ?
		       2 :
		       1;

	if (ctx->inst_type == RTK_JCODEC_CTX_DECODER)
		allocHeight = q_data->height;
	else {
		rtk_jpeg_cal_align(buf, q_data->fourcc,
				q_data->width, q_data->height, &q_data->bytesperline, &allocHeight);
		rtk_jcodec_dbg(1, ctx, "encoder bytesperline %d,allocHeight %d\n", q_data->bytesperline,allocHeight);
	}


	lumaSize = ((q_data->bytesperline + 1) / 2 * 2) *
				((allocHeight + 1) / 2 * 2);
	chrSize = lumaSize / divX / divY;

	switch (q_data->fourcc) {
	case V4L2_PIX_FMT_YUYV:
		/* Fallthrough: IN -H264-> CODA -NV12 MB-> VDOA -YUYV-> OUT */
	case V4L2_PIX_FMT_NV12:
	case V4L2_PIX_FMT_YUV420:
	case V4L2_PIX_FMT_YUV422P:
	case V4L2_PIX_FMT_NV16:
	case V4L2_PIX_FMT_YUV444M:
	case V4L2_PIX_FMT_NV24:
	case V4L2_PIX_FMT_RGB24:
	case V4L2_PIX_FMT_GREY:
		base_cb = base_y + lumaSize;
		base_cr = (chroma_interleave == 0) ? (base_cb + chrSize) : 0;
		break;
	case V4L2_PIX_FMT_YVU420:
		/* Switch Cb and Cr for YVU420 format */
		base_cr = base_y + lumaSize;
		base_cb = (chroma_interleave == 0) ? (base_cr + chrSize) : 0;
		break;
	default:
		base_cb = base_y + lumaSize;
		base_cr = (chroma_interleave == 0) ? (base_cb + chrSize) : 0;
		break;
	}

	rtk_jcodec_write(ctx->dev, base_y, reg_y);
	rtk_jcodec_write(ctx->dev, base_cb, reg_y + 4);
	rtk_jcodec_write(ctx->dev, base_cr, reg_y + 8);

	rtk_jcodec_write(ctx->dev, q_data->bytesperline,
			 RTK_REG_JPEG_DPB_YSTRIDE);

	val = (chroma_format == RTK_JPEG_FORMAT_420 ||
	       chroma_format == RTK_JPEG_FORMAT_422 ||
	       chroma_format == RTK_JPEG_FORMAT_400) ?
		      2 :
		      1;
	if (chroma_interleave > 0)
		rtk_jcodec_write(ctx->dev,
				 (q_data->bytesperline / (int)val) * 2,
				 RTK_REG_JPEG_DPB_CSTRIDE);
	else
		rtk_jcodec_write(ctx->dev, q_data->bytesperline / (int)val,
				 RTK_REG_JPEG_DPB_CSTRIDE);
}

static int rtk_jpeg_prepare_encode(struct rtk_jcodec_ctx *ctx)
{
	struct rtk_q_data *q_data_src;
	struct vb2_v4l2_buffer *src_buf, *dst_buf;
	struct rtk_jcodec_dev *dev = ctx->dev;
	u32 start_addr, end_addr;
	u16 aligned_width, aligned_height;
	bool chroma_interleave;
	int chroma_format;
	int header_len;

	src_buf = v4l2_m2m_next_src_buf(ctx->fh.m2m_ctx);
	dst_buf = v4l2_m2m_next_dst_buf(ctx->fh.m2m_ctx);
	q_data_src = get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);

	if (vb2_get_plane_payload(&src_buf->vb2_buf, 0) == 0)
		vb2_set_plane_payload(&src_buf->vb2_buf, 0,
				      vb2_plane_size(&src_buf->vb2_buf, 0));

	src_buf->sequence = ctx->osequence;
	dst_buf->sequence = ctx->osequence;
	ctx->osequence++;

	src_buf->flags |= V4L2_BUF_FLAG_KEYFRAME;
	src_buf->flags &= ~V4L2_BUF_FLAG_PFRAME;

	//coda_set_gdi_regs(ctx);

	start_addr = vb2_dma_contig_plane_dma_addr(&dst_buf->vb2_buf, 0);
	end_addr = start_addr + vb2_plane_size(&dst_buf->vb2_buf, 0);

	if (ctx->params.is_firt_frame == 0) {
		rtk_jcodec_write(dev, start_addr, RTK_REG_JPEG_BBC_WR_PTR);

		ctx->params.is_firt_frame = 1;
	}

	chroma_format = rtk_jpeg_chroma_format(q_data_src->fourcc);
	if (chroma_format < 0)
		return chroma_format;

	/* Round image dimensions to multiple of MCU size */
	aligned_width = round_up(q_data_src->width, width_align[chroma_format]);
	aligned_height =
		round_up(q_data_src->height, height_align[chroma_format]);
	if (q_data_src->fourcc == V4L2_PIX_FMT_RGB24) {
		if (aligned_width * 3 != q_data_src->bytesperline) {
			v4l2_err(&dev->v4l2_dev,
				 "wrong rgb stride: %d instead of %d\n",
				 aligned_width * 3, q_data_src->bytesperline);
		}
	} else {
		if (aligned_width != q_data_src->bytesperline) {
			v4l2_err(&dev->v4l2_dev,
				 "wrong stride: %d instead of %d\n",
				 aligned_width, q_data_src->bytesperline);
		}
	}
	header_len =
		rtk_jpeg_encode_header(ctx,
				       vb2_plane_size(&dst_buf->vb2_buf, 0),
				       vb2_plane_vaddr(&dst_buf->vb2_buf, 0));
	if (header_len < 0)
		return header_len;

	rtk_jcodec_write(
		dev, 0,
		RTK_REG_JPEG_CLP_INFO_REG); //off ROI enable due to not supported feature for encoder.

	rtk_jcodec_write(dev, start_addr + header_len,
			 RTK_REG_JPEG_BBC_BAS_ADDR);
	rtk_jcodec_write(dev, end_addr, RTK_REG_JPEG_BBC_END_ADDR);
	rtk_jcodec_write(dev, start_addr + header_len, RTK_REG_JPEG_BBC_WR_PTR);
	rtk_jcodec_write(dev, start_addr + header_len, RTK_REG_JPEG_BBC_RD_PTR);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_BBC_CUR_POS);
	/* 64 words per 256-byte page */
	rtk_jcodec_write(dev, 64, RTK_REG_JPEG_BBC_DATA_CNT);
	rtk_jcodec_write(dev, start_addr, RTK_REG_JPEG_BBC_EXT_ADDR);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_BBC_INT_ADDR);

	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_GBU_BT_PTR);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_GBU_WD_PTR);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_GBU_BBSR);
	rtk_jcodec_write(dev,
			 BIT(31) | ((end_addr - start_addr - header_len) / 256),
			 RTK_REG_JPEG_BBC_STRM_CTRL);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_GBU_CTRL);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_GBU_FF_RPTR);
	rtk_jcodec_write(dev, 127, RTK_REG_JPEG_GBU_BBER); //((256 / 4) * 2) - 1
	rtk_jcodec_write(dev, 64,
			 RTK_REG_JPEG_GBU_BBIR); // 64 * 4 byte == 32 * 8 byte
	rtk_jcodec_write(dev, 64,
			 RTK_REG_JPEG_GBU_BBHR); // 64 * 4 byte == 32 * 8 byte

	rtk_set_packedFormat(ctx, q_data_src->fourcc);

	if (q_data_src->fourcc == V4L2_PIX_FMT_NV12 ||
	    q_data_src->fourcc == V4L2_PIX_FMT_NV16 ||
	    q_data_src->fourcc == V4L2_PIX_FMT_NV24)
		chroma_interleave = 1;
	else if (q_data_src->fourcc == V4L2_PIX_FMT_NV21)
		chroma_interleave = 2;
	else {
		chroma_interleave = 0;
	}

	rtk_jcodec_write(
		dev,
		RTK_JPEG_PIC_CTRL_TC_DIRECTION |
			RTK_JPEG_PIC_CTRL_ENCODER_EN /*| pEncInfo->usePartial*/ |
			(0 << 2),
		RTK_REG_JPEG_PIC_CTRL); // 0x18 = RTK_JPEG_PIC_CTRL_TC_DIRECTION | RTK_JPEG_PIC_CTRL_ENCODER_EN
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_SCL_INFO);

	//rtk_jcodec_write(dev, chroma_interleave, RTK_REG_JPEG_DPB_CONFIG);
	if (ctx->params.packedFormat == PACKED_FORMAT_NONE) {
		rtk_jcodec_write(dev,
				 (ctx->params.frameEndian << 6) | (0 << 5) |
					 (0 << 4) | (0 << 2) |
					 ((chroma_interleave == 0) ?
						  0 :
						  (chroma_interleave == 1) ? 2 :
									     3),
				 RTK_REG_JPEG_DPB_CONFIG);
	} else if (ctx->params.packedFormat == PACKED_FORMAT_444) {
		rtk_jcodec_write(dev,
				 (ctx->params.frameEndian << 6) | (1 << 5) |
					 (0 << 4) | (0 << 2) |
					 ((chroma_interleave == 0) ?
						  0 :
						  (chroma_interleave == 1) ? 2 :
									     3),
				 RTK_REG_JPEG_DPB_CONFIG);
	} else {
		rtk_jcodec_write(
			dev,
			(ctx->params.frameEndian << 6) | (0 << 5) | (1 << 4) |
				((ctx->params.packedFormat - 1) << 2) |
				((chroma_interleave == 0) ?
					 0 :
					 (chroma_interleave == 1) ? 2 : 3),
			RTK_REG_JPEG_DPB_CONFIG);
	}

	rtk_jcodec_write(dev, ctx->params.jpeg_restart_interval,
			 RTK_REG_JPEG_RST_INTVAL);
	rtk_jcodec_write(dev, (ctx->params.streamEndian << 1) | 1,
			 RTK_REG_JPEG_BBC_CTRL);

	rtk_jcodec_write(
		dev,
		/*pEncInfo->partiallineNum << 16 | pEncInfo->partialBufNum << 3 | */
		bus_req_num[chroma_format], RTK_REG_JPEG_OP_INFO);

	rtk_jpeg_write_huff_tab(ctx);
	rtk_jpeg_load_qmat_tab(ctx);

	if (ctx->params.rot_mode & RTK_ROT_90) {
		aligned_width = aligned_height;
		aligned_height = q_data_src->bytesperline;
		if (chroma_format == RTK_JPEG_FORMAT_422) {
			chroma_format = RTK_JPEG_FORMAT_224;
		} else if (chroma_format == RTK_JPEG_FORMAT_224) {
			chroma_format = RTK_JPEG_FORMAT_422;
		}
	}
	/* These need to be multiples of MCU size */
	rtk_jcodec_write(dev, aligned_width << 16 | aligned_height,
			 RTK_REG_JPEG_PIC_SIZE);
	rtk_jcodec_write(dev,
			 ctx->params.rot_mode ?
				 (RTK_ROT_MIR_ENABLE | ctx->params.rot_mode) :
				 0,
			 RTK_REG_JPEG_ROT_INFO);

	rtk_jcodec_write(dev, mcu_info[chroma_format], RTK_REG_JPEG_MCU_INFO);

	rtk_jcodec_write(
		dev, ctx->params.stuffByteEnable << 3,
		RTK_REG_JPEG_GBU_CTRL); // stuffing "FF" data where frame end

	rtk_jcodec_write_base(ctx, q_data_src, src_buf, chroma_interleave,
			      RTK_REG_JPEG_DPB_BASE00);

	//coda_write(dev, 0, CODA9_REG_JPEG_DPB_BASE00);
	//coda_write(dev, 0, CODA9_GDI_CONTROL);
	//coda_write(dev, 1, CODA9_GDI_PIC_INIT_HOST);

	//coda_write(dev, 1, CODA9_GDI_WPROT_ERR_CLR);
	//coda_write(dev, 0, CODA9_GDI_WPROT_RGN_EN);

	//trace_coda_jpeg_run(ctx, src_buf);

	//JpuWriteReg(MJPEG_PIC_STATUS_REG, JpuReadReg(MJPEG_PIC_STATUS_REG));
	//if (pEncInfo->usePartial)
	//	JpuWriteReg(MJPEG_PIC_START_REG, (1<<JPG_START_PIC)|(1<<JPG_START_PARTIAL));
	//else
	rtk_jcodec_write(dev, 1, RTK_REG_JPEG_PIC_START);

	return 0;
}

static void rtk_m2m_buf_done(struct rtk_jcodec_ctx *ctx, struct vb2_v4l2_buffer *buf,
		      enum vb2_buffer_state state)
{
	const struct v4l2_event eos_event = { .type = V4L2_EVENT_EOS };

	if (buf->flags & V4L2_BUF_FLAG_LAST)
		v4l2_event_queue_fh(&ctx->fh, &eos_event);

	v4l2_m2m_buf_done(buf, state);
}

static void rtk_jpeg_finish_encode(struct rtk_jcodec_ctx *ctx)
{
	struct vb2_v4l2_buffer *src_buf, *dst_buf;
	struct rtk_jcodec_dev *dev = ctx->dev;
	u32 wr_ptr, start_ptr;
	u32 err_mb;

	if (ctx->aborting) {
		rtk_jcodec_write(ctx->dev, 0, RTK_REG_JPEG_BBC_FLUSH_CMD);
		return;
	}

	/*
	 * Lock to make sure that an encoder stop command running in parallel
	 * will either already have marked src_buf as last, or it will wake up
	 * the capture queue after the buffers are returned.
	 */
	mutex_lock(&ctx->wakeup_mutex);
	src_buf = v4l2_m2m_src_buf_remove(ctx->fh.m2m_ctx);
	dst_buf = v4l2_m2m_dst_buf_remove(ctx->fh.m2m_ctx);

	//trace_coda_jpeg_done(ctx, dst_buf);

	/*
	 * Set plane payload to the number of bytes written out
	 * by the JPEG processing unit
	 */
	start_ptr = vb2_dma_contig_plane_dma_addr(&dst_buf->vb2_buf, 0);
	wr_ptr = rtk_jcodec_read(dev, RTK_REG_JPEG_BBC_WR_PTR);
	vb2_set_plane_payload(&dst_buf->vb2_buf, 0, wr_ptr - start_ptr);

	err_mb = rtk_jcodec_read(dev, RTK_REG_JPEG_PIC_ERRMB);
	if (err_mb) {
		rtk_jcodec_dbg(2, ctx, "ERRMB: 0x%x\n", err_mb);
	}
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_BBC_FLUSH_CMD);

	dst_buf->flags &= ~(V4L2_BUF_FLAG_PFRAME | V4L2_BUF_FLAG_LAST);
	dst_buf->flags |= V4L2_BUF_FLAG_KEYFRAME;
	dst_buf->flags |= src_buf->flags & V4L2_BUF_FLAG_LAST;

	v4l2_m2m_buf_copy_metadata(src_buf, dst_buf, false);

	v4l2_m2m_buf_done(src_buf, VB2_BUF_STATE_DONE);
	rtk_m2m_buf_done(ctx, dst_buf,
			 /*err_mb ? VB2_BUF_STATE_ERROR :*/ VB2_BUF_STATE_DONE);
	mutex_unlock(&ctx->wakeup_mutex);

	rtk_jcodec_dbg(1, ctx, "job finished: encoded frame (%u)%s\n",
		       dst_buf->sequence,
		       (dst_buf->flags & V4L2_BUF_FLAG_LAST) ? " (last)" : "");

	/*
	 * Reset JPEG processing unit after each encode run to work
	 * around hangups when switching context between encoder and
	 * decoder.
	 */
	rtk_jcodec_hw_reset(dev);
}

static void rtk_jpeg_encode_timeout(struct rtk_jcodec_ctx *ctx)
{
	struct rtk_jcodec_dev *dev = ctx->dev;
	u32 end_addr, wr_ptr;

	/* Handle missing BBC overflow interrupt via timeout */
	end_addr = rtk_jcodec_read(dev, RTK_REG_JPEG_BBC_END_ADDR);
	wr_ptr = rtk_jcodec_read(dev, RTK_REG_JPEG_BBC_WR_PTR);
	if (wr_ptr >= end_addr - 256) {
		v4l2_err(&dev->v4l2_dev, "JPEG too large for capture buffer\n");
		rtk_jpeg_finish_encode(ctx);
		return;
	}

	rtk_jcodec_hw_reset(dev);
}
static void rtk_jpeg_release(struct rtk_jcodec_ctx *ctx)
{
	int i;

	if (ctx->params.jpeg_qmat_tab[0] == luma_q)
		ctx->params.jpeg_qmat_tab[0] = NULL;
	if (ctx->params.jpeg_qmat_tab[1] == chroma_q)
		ctx->params.jpeg_qmat_tab[1] = NULL;
	for (i = 0; i < 4; i++)
		kfree(ctx->params.jpeg_qmat_tab[i]);
	kfree(ctx->params.jpeg_huff_data);
	kfree(ctx->params.jpeg_huff_tab);
}

/*
 * Decoder context operations
 */

static int rtk_jpeg_start_decoding(struct rtk_jcodec_ctx *ctx)
{
	ctx->params.jpeg_qmat_index[0] = 0;
	ctx->params.jpeg_qmat_index[1] = 1;
	ctx->params.jpeg_qmat_index[2] = 1;
	ctx->params.jpeg_qmat_tab[0] = luma_q;
	ctx->params.jpeg_qmat_tab[1] = chroma_q;
	/* nothing more to do here */

	/* TODO: we could already scan the first header to get the chroma
	 * format.
	 */

	return 0;
}
static inline int rtk_jpeg_scale(int src, int dst)
{
	return (dst <= src / 8) ?
		       3 :
		       (dst <= src / 4) ? 2 : (dst <= src / 2) ? 1 : 0;
}

static void rtk_jpeg_dump_capbuf(struct rtk_jcodec_ctx *ctx,
	struct rtk_q_data *q_data,
	struct vb2_v4l2_buffer *buf)
{
#if defined(RTKJPU_DUMP_CAPBUF_EN)
	uint32_t sizeimage;
	struct vb2_buffer *vb2_buf = NULL;
	void *vb2_virt_addr = NULL;
	int filp_open_flags;
	ssize_t bytes = 0;
	loff_t pos = 0;

	sizeimage = q_data->sizeimage;
	vb2_buf = &(buf->vb2_buf);
	vb2_virt_addr = vb2_plane_vaddr(vb2_buf, 0);

	pr_info("%d.%s.v4l2_buf:0x%px.METADATA_OFFSET:%d.vb2_virt_addr:0x%px.size:%d\n",__LINE__,__func__,
	(void *)buf,METADATA_OFFSET,vb2_virt_addr,sizeimage);

	if (ctx->bNewCapbufDumpFile == 1) {
		ctx->bNewCapbufDumpFile = 0;
		gCapbufDumpMaxNum = 0;
		filp_open_flags = O_CREAT | O_WRONLY;
		memset(ctx->capbufDumpFileName, 0, sizeof(unsigned char)*256);
		snprintf(ctx->capbufDumpFileName, 256,
		"/mnt/capbuf_%d.yuv",
		gCapbufDumpSerial);
		gCapbufDumpSerial++;
		pr_info("%d.%s.create new capbuf dump:%s\n",__LINE__,__func__,
		ctx->capbufDumpFileName);
	} else {
		filp_open_flags = O_APPEND | O_WRONLY;
	}
	ctx->capbufDumpFile =
		(void *)filp_open(ctx->capbufDumpFileName, filp_open_flags, 0);
	if (IS_ERR((struct file *)ctx->capbufDumpFile)) {
		pr_info("%d.%s.filp_open %s fail\n",__LINE__,__func__,
		ctx->capbufDumpFileName);
	} else {
		//if (gCapbufDumpMaxNum >= 30) {
		//	return -1;
		//}
		//vpu_info("%d.%s.filp_open %s ok\n",__LINE__,__func__,
		//		ctx->capbufDumpFileName);
		bytes =
		kernel_write((struct file *)(ctx->capbufDumpFile),
			(void *)vb2_virt_addr, (size_t)sizeimage, &pos);
		//vpu_info("%d.%s.kernel_write bytes:%ld.pos:%lld\n",__LINE__,__func__,
		//		bytes, pos);
		filp_close((struct file *)(ctx->capbufDumpFile), NULL);
		//vpu_info("%d.%s.filp_close %s\n",__LINE__,__func__,
		//		ctx->capbufDumpFileName);
		ctx->capbufDumpFile = NULL;
		gCapbufDumpMaxNum++;
	}
#endif
}

static void rtk_jpeg_fill_frame_info(struct rtk_jcodec_ctx *ctx,
				     struct rtk_q_data *q_data,
				     struct vb2_v4l2_buffer *buf)
{
	if(buf->vb2_buf.memory == VB2_MEMORY_MMAP && q_data->fourcc == V4L2_PIX_FMT_NV12) {
		void *vb2_virt_addr = NULL;
		struct ve_frame_info *info = NULL;
		u32 base_addr;

		vb2_virt_addr = vb2_plane_vaddr(&buf->vb2_buf, 0) + vb2_get_plane_payload(&buf->vb2_buf,0) - METADATA_OFFSET;
		info = (struct ve_frame_info *)vb2_virt_addr;
		base_addr = vb2_dma_contig_plane_dma_addr(&buf->vb2_buf, 0);
		memset(info, 0, sizeof(struct ve_frame_info));

		info->yuvs.lumaOffTblAddr = 0xffffffff;
		info->yuvs.chromaOffTblAddr = 0xffffffff;
		info->yuvs.lumaOffTblAddrR = 0xffffffff;
		info->yuvs.chromaOffTblAddrR = 0xffffffff;
		info->yuvs.bufBitDepth = 8;
		info->yuvs.matrix_coefficients = 1;
		info->yuvs.tch_hdr_metadata[0] = -1;

		info->yuvs.Y_addr_Right = 0xffffffff;
		info->yuvs.U_addr_Right = 0xffffffff;
		info->yuvs.pLock_Right = 0xffffffff;
		info->rtk_meta_buf_id = 0x52544B6D; //RTKm

		info->yuvs.width = q_data->rect.width;
		info->yuvs.height = q_data->rect.height;
		info->yuvs.Y_addr = base_addr;
		info->yuvs.U_addr = base_addr + q_data->bytesperline * q_data->height;
		info->yuvs.Y_pitch = q_data->bytesperline;
		info->yuvs.C_pitch = q_data->bytesperline;
		info->yuvs.mode = CONSECUTIVE_FRAME;
	}
}

static int rtk_jpeg_prepare_decode(struct rtk_jcodec_ctx *ctx)
{
	struct rtk_jcodec_dev *dev = ctx->dev;
	int aligned_width, aligned_height;
	int chroma_format;
	int ret;
	u32 val, dst_fourcc;
	struct rtk_q_data *q_data_src, *q_data_dst;
	struct vb2_v4l2_buffer *src_buf, *dst_buf;
	int chroma_interleave;
	int scl_hor_mode, scl_ver_mode;
	int horizontal_factor = 1;

	src_buf = v4l2_m2m_next_src_buf(ctx->fh.m2m_ctx);
	if (!src_buf) {
		v4l2_m2m_job_finish(ctx->dev->m2m_dev, ctx->fh.m2m_ctx);
		rtk_jcodec_dbg(
			1, ctx,
			"rtk_jpeg_prepare_decode error: no available source buffer");
		return -EINVAL;
	}
	dst_buf = v4l2_m2m_next_dst_buf(ctx->fh.m2m_ctx);
	q_data_src = get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
	q_data_dst = get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);
	dst_fourcc = q_data_dst->fourcc;

	if(ctx->params.horizontal_factor)
		horizontal_factor = 2 << (ctx->params.horizontal_factor - 1);

	if(ctx->params.rot_mode == 0) {
		scl_hor_mode = ctx->params.horizontal_factor;
		scl_ver_mode = ctx->params.vertical_factor;
	} else {
		scl_hor_mode = 0;
		scl_ver_mode = 0;
	}

	if (vb2_get_plane_payload(&src_buf->vb2_buf, 0) == 0)
		vb2_set_plane_payload(&src_buf->vb2_buf, 0,
				      vb2_plane_size(&src_buf->vb2_buf, 0));

	chroma_format = rtk_jpeg_chroma_format(q_data_dst->fourcc);
	if (chroma_format < 0) {
		v4l2_m2m_job_finish(ctx->dev->m2m_dev, ctx->fh.m2m_ctx);
		return chroma_format;
	}

	if (q_data_src->sizeimage <
	    vb2_get_plane_payload(&src_buf->vb2_buf, 0)) {
		v4l2_err(&dev->v4l2_dev, "bs buffer too small: %d < %d \n",
			 q_data_src->sizeimage,
			 (int)vb2_get_plane_payload(&src_buf->vb2_buf, 0));
	}

	if (ctx->params.is_firt_frame == 0) {
		u32 bbc_base_addr =
			vb2_dma_contig_plane_dma_addr(&src_buf->vb2_buf, 0);
		u32 end_addr = bbc_base_addr + q_data_src->sizeimage;

		rtk_jcodec_write(dev, bbc_base_addr, RTK_REG_JPEG_BBC_BAS_ADDR);
		rtk_jcodec_write(dev, end_addr, RTK_REG_JPEG_BBC_END_ADDR);
		rtk_jcodec_write(dev, bbc_base_addr, RTK_REG_JPEG_BBC_RD_PTR);
		rtk_jcodec_write(dev, bbc_base_addr, RTK_REG_JPEG_BBC_WR_PTR);
		rtk_jcodec_write(dev, 0, RTK_REG_JPEG_BBC_STRM_CTRL);
		ctx->params.is_firt_frame = 1;
	}

	ret = rtk_jpeg_decode_header(ctx, &src_buf->vb2_buf);
	if (ret < 0) {
		v4l2_err(&dev->v4l2_dev, "failed to decode JPEG header: %d\n",
			 ret);
#if 0
		src_buf = v4l2_m2m_src_buf_remove(ctx->fh.m2m_ctx);
		dst_buf = v4l2_m2m_dst_buf_remove(ctx->fh.m2m_ctx);
		v4l2_m2m_buf_done(src_buf, VB2_BUF_STATE_DONE);

#if 0
		v4l2_m2m_buf_done(dst_buf, VB2_BUF_STATE_DONE);
		v4l2_m2m_job_finish(ctx->dev->m2m_dev, ctx->fh.m2m_ctx);
#else
		v4l2_m2m_buf_done(dst_buf, VB2_BUF_STATE_ERROR);
#endif
#else
		ctx->parsing_hdr_err = true;

#endif
		return ret;
	}

	if (chroma_format != ctx->params.format) {
		v4l2_err(&dev->v4l2_dev,
			 "error chroma_format mismatch: %d != %d\n",
			 chroma_format, ctx->params.format);
		//chroma_format = ctx->params.format;
		return -EINVAL;
	}

	/* Round image dimensions to multiple of MCU size */
	aligned_width = round_up(q_data_src->width, width_align[chroma_format]);
	aligned_height =
		round_up(q_data_src->height, height_align[chroma_format]);

	rtk_set_packedFormat(ctx, dst_fourcc);

	val = ctx->params.jpeg_huff_ac_index[0] << 12 |
	      ctx->params.jpeg_huff_ac_index[1] << 11 |
	      ctx->params.jpeg_huff_ac_index[2] << 10 |
	      ctx->params.jpeg_huff_dc_index[0] << 9 |
	      ctx->params.jpeg_huff_dc_index[1] << 8 |
	      ctx->params.jpeg_huff_dc_index[2] << 7;

	//always true
	if (ctx->params.jpeg_huff_tab)
		val |= RTK_JPEG_PIC_CTRL_USER_HUFFMAN_EN;

	//align jpu
	val |= (JPU_DEC_CHECK_WRITE_RESPONSE_BVALID_SIGNAL << 2);
	val |= 0;

	rtk_jcodec_write(dev, val, RTK_REG_JPEG_PIC_CTRL);

	rtk_jcodec_write(dev, aligned_width << 16 | aligned_height,
			 RTK_REG_JPEG_PIC_SIZE);

	//chroma_interleave = (dst_fourcc == V4L2_PIX_FMT_NV12 );
	if (dst_fourcc == V4L2_PIX_FMT_NV12 ||
	    dst_fourcc == V4L2_PIX_FMT_NV16 || dst_fourcc == V4L2_PIX_FMT_NV24)
		chroma_interleave = 1;
	else if (dst_fourcc == V4L2_PIX_FMT_NV21)
		chroma_interleave = 2;
	else {
		chroma_interleave = 0;
	}

	rtk_jcodec_write(dev,
		ctx->params.rot_mode ?
			(RTK_ROT_MIR_ENABLE | ctx->params.rot_mode) :
			0,
		RTK_REG_JPEG_ROT_INFO);
	//rtk_jcodec_write(dev, 0, RTK_REG_JPEG_ROT_INFO);
	rtk_jcodec_write(dev, bus_req_num[chroma_format], RTK_REG_JPEG_OP_INFO);
	rtk_jcodec_write(dev, mcu_info[chroma_format], RTK_REG_JPEG_MCU_INFO);

	if (scl_hor_mode || scl_ver_mode)
		val = RTK_JPEG_SCL_ENABLE | (scl_hor_mode << 2) | scl_ver_mode;
	else
		val = 0;
	rtk_jcodec_write(dev, val, RTK_REG_JPEG_SCL_INFO);

	//rtk_jcodec_write(dev, chroma_interleave, RTK_REG_JPEG_DPB_CONFIG);
	if (ctx->params.packedFormat == PACKED_FORMAT_NONE)
		rtk_jcodec_write(
			dev,
			(ctx->params.frameEndian << 6) | (0 << 5) | (0 << 4) |
				((chroma_interleave == 0) ?
					 0 :
					 (chroma_interleave == 1) ? 2 : 3),
			RTK_REG_JPEG_DPB_CONFIG);
	else if (ctx->params.packedFormat == PACKED_FORMAT_444)
		rtk_jcodec_write(dev,
				 (ctx->params.frameEndian << 6) | (1 << 5) |
					 (0 << 4) | (0 << 2) |
					 ((chroma_interleave == 0) ?
						  0 :
						  (chroma_interleave == 1) ? 2 :
									     3),
				 RTK_REG_JPEG_DPB_CONFIG);
	else
		rtk_jcodec_write(
			dev,
			(ctx->params.frameEndian << 6) | (0 << 5) | (1 << 4) |
				((ctx->params.packedFormat - 1) << 2) |
				((chroma_interleave == 0) ?
					 0 :
					 (chroma_interleave == 1) ? 2 : 3),
			RTK_REG_JPEG_DPB_CONFIG);

	rtk_jcodec_write(dev, ctx->params.jpeg_restart_interval,
			 RTK_REG_JPEG_RST_INTVAL);

	if (ctx->params.jpeg_huff_tab) {
		ret = rtk_jpeg_dec_huff_setup(ctx);
		if (ret < 0) {
			v4l2_err(&dev->v4l2_dev,
				 "failed to set up Huffman tables: %d\n", ret);
			v4l2_m2m_job_finish(ctx->dev->m2m_dev, ctx->fh.m2m_ctx);
			return ret;
		}
	}

	rtk_jpeg_qmat_setup(ctx);

	rtk_jpeg_dec_bbc_gbu_setup(ctx, &src_buf->vb2_buf,
				   ctx->jpeg_ecs_offset);

	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_RST_INDEX);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_RST_COUNT);

	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_DPCM_DIFF_Y);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_DPCM_DIFF_CB);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_DPCM_DIFF_CR);

	//rtk_jcodec_write(dev, 0, RTK_REG_JPEG_ROT_INFO);

	rtk_jcodec_write_base(ctx, q_data_dst, dst_buf, chroma_interleave,
			      RTK_REG_JPEG_DPB_BASE00);

	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_CLP_INFO_REG);

	rtk_jcodec_write(dev, 1, RTK_REG_JPEG_PIC_START);

	return 0;
}

static void rtk_jpeg_finish_decode(struct rtk_jcodec_ctx *ctx)
{
	struct rtk_jcodec_dev *dev = ctx->dev;
	struct vb2_v4l2_buffer *dst_buf, *src_buf;
	struct rtk_q_data *q_data_dst;
	u32 err_mb;

	err_mb = rtk_jcodec_read(dev, RTK_REG_JPEG_PIC_ERRMB);
	if (err_mb) {
		rtk_jcodec_dbg(2, ctx, "ERRMB: 0x%x\n", err_mb);
	}
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_BBC_FLUSH_CMD);

	/*
	 * Lock to make sure that a decoder stop command running in parallel
	 * will either already have marked src_buf as last, or it will wake up
	 * the capture queue after the buffers are returned.
	 */
	mutex_lock(&ctx->wakeup_mutex);
	src_buf = v4l2_m2m_src_buf_remove(ctx->fh.m2m_ctx);
	dst_buf = v4l2_m2m_dst_buf_remove(ctx->fh.m2m_ctx);
	dst_buf->sequence = ctx->osequence++;

	//trace_coda_jpeg_done(ctx, dst_buf);

	dst_buf->flags &= ~(V4L2_BUF_FLAG_PFRAME | V4L2_BUF_FLAG_LAST);
	dst_buf->flags |= V4L2_BUF_FLAG_KEYFRAME;
	dst_buf->flags |= src_buf->flags & V4L2_BUF_FLAG_LAST;

	v4l2_m2m_buf_copy_metadata(src_buf, dst_buf, false);

	q_data_dst = get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);

	rtk_jpeg_dump_capbuf(ctx, q_data_dst, dst_buf);
	rtk_jpeg_fill_frame_info(ctx, q_data_dst, dst_buf);

	v4l2_m2m_buf_done(src_buf, VB2_BUF_STATE_DONE);
#if 0
	rtk_m2m_buf_done(
		ctx, dst_buf,
		/* err_mb ? VB2_BUF_STATE_ERROR : */ VB2_BUF_STATE_DONE);
#else
	rtk_m2m_buf_done(ctx, dst_buf,
			 ctx->parsing_hdr_err ? VB2_BUF_STATE_ERROR :
						VB2_BUF_STATE_DONE);
#endif

	mutex_unlock(&ctx->wakeup_mutex);

	rtk_jcodec_dbg(1, ctx, "job finished: decoded frame (%u)%s\n",
		       dst_buf->sequence,
		       (dst_buf->flags & V4L2_BUF_FLAG_LAST) ? " (last)" : "");

	/*
	 * Reset JPEG processing unit after each decode run to work
	 * around hangups when switching context between encoder and
	 * decoder.
	 */
	rtk_jcodec_hw_reset(dev);
}

static int rtk_queue_setup(struct vb2_queue *vq, unsigned int *nbuffers,
			   unsigned int *nplanes, unsigned int sizes[],
			   struct device *alloc_devs[])
{
	struct rtk_jcodec_ctx *ctx = vb2_get_drv_priv(vq);
	struct rtk_q_data *q_data;
	bool needs_meta_bump;
	unsigned int size;

	q_data = rtk_get_q_data(ctx, vq->type);

	needs_meta_bump = ctx->inst_type == RTK_JCODEC_CTX_DECODER &&
			  V4L2_TYPE_IS_CAPTURE(vq->type) &&
			  vq->memory == VB2_MEMORY_MMAP;

	size = needs_meta_bump ? PAGE_ALIGN(q_data->sizeimage + METADATA_OFFSET)
			       : q_data->sizeimage;

	if (*nplanes) {
		/* CREATE_BUFS path: sizes[0] comes from G_FMT (content size only).
		 * Accept any size >= content size, then bump up to include the
		 * MMAP metadata area so buf_prepare does not reject the buffer.
		 * This driver always uses single-plane buffers; reject any other
		 * plane count so v4l2-compliance CREATE_BUFS validation passes.
		 */
		if (*nplanes != 1)
			return -EINVAL;
		if (sizes[0] < q_data->sizeimage)
			return -EINVAL;
		if (needs_meta_bump)
			sizes[0] = max_t(unsigned int, sizes[0],
					 PAGE_ALIGN(q_data->sizeimage + METADATA_OFFSET));
		return 0;
	}

	*nplanes = 1;
	sizes[0] = size;

	rtk_jcodec_dbg(1, ctx, "%s get %d buffer(s) of size %d each.\n",
		       v4l2_type_names[vq->type], *nbuffers, size);

	return 0;
}

static int rtk_buf_prepare(struct vb2_buffer *vb)
{
	struct vb2_v4l2_buffer *vbuf = to_vb2_v4l2_buffer(vb);
	struct rtk_jcodec_ctx *ctx = vb2_get_drv_priv(vb->vb2_queue);
	struct rtk_q_data *q_data;
	int sizeimages;

	q_data = rtk_get_q_data(ctx, vb->vb2_queue->type);
	if (V4L2_TYPE_IS_OUTPUT(vb->vb2_queue->type)) {
		if (vbuf->field == V4L2_FIELD_ANY)
			vbuf->field = V4L2_FIELD_NONE;

#ifndef RTK_INTERLACED
		if (vbuf->field != V4L2_FIELD_NONE) {
			v4l2_warn(&ctx->dev->v4l2_dev,
				  "%s error! field isn't supported\n",
				  __func__);
			return -EINVAL;
		}
#endif
	}

	rtk_jcodec_dbg(2, ctx, "%s buf prepare:\n",
		       v4l2_type_names[vb->vb2_queue->type]);
	//rtk_jcodec_dbg(2, ctx, "   vb2_plane_size : %d, q_data->sizeimage : %d\n",
	//		vb2_plane_size(vb, 0), q_data->sizeimage);

	if (ctx->inst_type == RTK_JCODEC_CTX_DECODER &&
	    V4L2_TYPE_IS_CAPTURE(vb->type) && vb->vb2_queue->memory == VB2_MEMORY_MMAP)
		sizeimages = PAGE_ALIGN(q_data->sizeimage + METADATA_OFFSET);
	else
		sizeimages = q_data->sizeimage;

	if (vb2_plane_size(vb, 0) < sizeimages) {
		v4l2_warn(&ctx->dev->v4l2_dev,
			  "%s data will not fit into plane (%lu < %lu)\n",
			  __func__, vb2_plane_size(vb, 0), (long)sizeimages);
		return -EINVAL;
	}

if (ctx->inst_type == RTK_JCODEC_CTX_DECODER &&
	V4L2_TYPE_IS_CAPTURE(vb->type)) {
	vb2_set_plane_payload(vb, 0, sizeimages);
}

	return 0;
}

static void rtk_buf_queue(struct vb2_buffer *vb)
{
	struct vb2_v4l2_buffer *vbuf = to_vb2_v4l2_buffer(vb);
	struct rtk_jcodec_ctx *ctx = vb2_get_drv_priv(vb->vb2_queue);
	struct vb2_queue *vq = vb->vb2_queue;
	struct rtk_q_data *q_data;

	q_data = rtk_get_q_data(ctx, vb->vb2_queue->type);

	/*
>------- * In the decoder case, immediately try to copy the buffer into the
>------- * bitstream ringbuffer and mark it as ready to be dequeued.
>------- */
	if (ctx->bitstream.size && V4L2_TYPE_IS_OUTPUT(vq->type)) {
		/*
>------->------- * For backwards compatibility, queuing an empty buffer marks
>------->------- * the stream end
>------->------- */

		if (vb2_get_plane_payload(vb, 0) == 0) {
			rtk_jcodec_dbg(1, ctx, "queuing an empty buffer\n");
			rtk_bitstream_end_flag(ctx);
		}

		mutex_lock(&ctx->bitstream_mutex);
		v4l2_m2m_buf_queue(ctx->fh.m2m_ctx, vbuf);
		if (vb2_is_streaming(vb->vb2_queue)) {
			/* This set buf->sequence = ctx->qsequence++ */
			rtk_feed_bitstream(ctx, NULL);
		}
		mutex_unlock(&ctx->bitstream_mutex);

	} else {
		if ((ctx->inst_type == RTK_JCODEC_CTX_ENCODER ||
		     !ctx->use_bit) &&
		    V4L2_TYPE_IS_OUTPUT(vq->type)) {
			vbuf->sequence = ctx->qsequence++;
			printk(KERN_INFO "[vbuf->sequence : %d]"
					 "[\x1b[33m%s\033[0m]\n",
			       vbuf->sequence, __func__);
		}

		v4l2_m2m_buf_queue(ctx->fh.m2m_ctx, vbuf);
	}
}

static int rtk_bitstream_queue(struct rtk_jcodec_ctx *ctx, const u8 *buf,
			       u32 size)
{
	u32 n = kfifo_in(&ctx->bitstream_fifo, buf, size);

	return (n < size) ? -ENOSPC : 0;
}

static u32 rtk_buffer_parse_headers(struct rtk_jcodec_ctx *ctx,
				    struct vb2_v4l2_buffer *src_buf,
				    u32 payload)
{
	//u8 *vaddr = vb2_plane_vaddr(&src_buf->vb2_buf, 0);
	u32 size = 0;

	printk(KERN_INFO
	       "[fn_name]:[\x1b[33m%s\033[0m], [line]: \x1b[33m%d\033[0m\n",
	       __func__, __LINE__);

	switch (ctx->codec->src_fourcc) {
	case V4L2_PIX_FMT_MPEG2:
		printk(KERN_INFO "[MPEG2][\x1b[33m%s\033[0m]\n", __func__);
		// size = coda_mpeg2_parse_headers(ctx, vaddr, payload);
		break;
	case V4L2_PIX_FMT_MPEG4:
		printk(KERN_INFO "[MPEG4][\x1b[33m%s\033[0m]\n", __func__);
		// size = coda_mpeg4_parse_headers(ctx, vaddr, payload);
		break;
	default:
		printk(KERN_INFO "[OTHER][\x1b[33m%s\033[0m]\n", __func__);
		break;
	}

	return size;
}

static void rtk_kfifo_sync_to_device_write(struct rtk_jcodec_ctx *ctx)
{
	struct __kfifo *kfifo = &ctx->bitstream_fifo.kfifo;
	//	struct rtk_jcodec_dev *dev = ctx->dev;
	u32 wr_ptr;

	wr_ptr = ctx->bitstream.paddr + (kfifo->in & kfifo->mask);

	//rtk_jcodec_write(dev, wr_ptr, RTK_REG_BIT_WR_PTR(ctx->reg_idx));
}

static bool rtk_bitstream_try_queue(struct rtk_jcodec_ctx *ctx,
				    struct vb2_v4l2_buffer *src_buf)
{
	unsigned long payload = vb2_get_plane_payload(&src_buf->vb2_buf, 0);
	u8 *vaddr = vb2_plane_vaddr(&src_buf->vb2_buf, 0);
	int ret;
	int i;

	rtk_jcodec_dbg(4, ctx, "[rtk_bitstream_try_queue]\n");
	//rtk_jcodec_dbg(4, ctx, "src_buf %d, payload %d, kfifo_len : %d\n",
	//	src_buf->vb2_buf.index, payload, rtk_get_bitstream_payload(ctx));

	if (rtk_get_bitstream_payload(ctx) + payload + 512 >=
	    ctx->bitstream.size) {
		v4l2_err(&ctx->dev->v4l2_dev, "over bitstream buffer size\n");
		return false;
	}

	if (!vaddr) {
		v4l2_err(&ctx->dev->v4l2_dev, "trying to queue empty buffer\n");
		return true;
	}

	if (ctx->qsequence == 0 && payload < 512) {
		/*
		 * Add padding after the first buffer, if it is too small to be
		 * fetched by the CODA, by repeating the headers. Without
		 * repeated headers, or the first frame already queued, decoder
		 * sequence initialization fails with error code 0x2000 on i.MX6
		 * or error code 0x1 on i.MX51.
		 */
		u32 header_size =
			rtk_buffer_parse_headers(ctx, src_buf, payload);

		if (header_size) {
			rtk_jcodec_dbg(1, ctx, "pad with %u-byte header\n",
				       header_size);
			for (i = payload; i < 512; i += header_size) {
				ret = rtk_bitstream_queue(ctx, vaddr,
							  header_size);
				if (ret < 0) {
					v4l2_err(&ctx->dev->v4l2_dev,
						 "bitstream buffer overflow\n");
					return false;
				}
				if (ctx->dev->devinfo->product == CODA_J10) {
					printk(KERN_ALERT
					       "[fn_name]:[\x1b[31m%s\033[0m], [line]: \x1b[33m%d\033[0m\n",
					       __func__, __LINE__);
					break;
				}
			}
		} else {
			rtk_jcodec_dbg(
				1, ctx,
				"could not parse header, sequence initialization might fail\n");
		}

		/* Add padding before the first buffer, if it is too small */
		//if (ctx->codec->src_fourcc == V4L2_PIX_FMT_H264)
		//	rtk_bitstream_h264_pad(ctx, 512 - payload);
	}

	//if (ctx->codec->src_fourcc == V4L2_PIX_FMT_VP8) {
	//	rtk_bitstream_vp8_pad(ctx, src_buf, payload);
	//}

	ret = rtk_bitstream_queue(ctx, vaddr, payload);
	if (ret < 0) {
		v4l2_err(&ctx->dev->v4l2_dev, "bitstream buffer overflow\n");
		return false;
	}

	src_buf->sequence = ctx->qsequence++;
	printk(KERN_INFO "[\x1b[33msrc_buf->sequence : %d\033[0m]\n",
	       src_buf->sequence);

	/* Sync read pointer to device */
	if (ctx == v4l2_m2m_get_curr_priv(ctx->dev->m2m_dev)) {
		rtk_kfifo_sync_to_device_write(ctx);
	}

	/* Set the stream-end flag after the last buffer is queued */
	if (src_buf->flags & V4L2_BUF_FLAG_LAST) {
		rtk_bitstream_end_flag(ctx);
	}

	ctx->hold = false;

	rtk_jcodec_dbg(1, ctx, "rtk_bitstream_try_queue success\n");

	//rtk_jcodec_dbg(4, ctx, "queue src_buf sequence %d \n",
	//	src_buf->sequence, (src_buf->flags & V4L2_BUF_FLAG_LAST) ?
	//			 " (last)" : "");

	return true;
}

static char rtk_frame_type(u32 flags)
{
	return (flags & V4L2_BUF_FLAG_KEYFRAME) ?
		       'I' :
		       (flags & V4L2_BUF_FLAG_PFRAME) ?
		       'P' :
		       (flags & V4L2_BUF_FLAG_BFRAME) ? 'B' : '?';
}

void rtk_feed_bitstream(struct rtk_jcodec_ctx *ctx,
			struct list_head *buffer_list)
{
	struct vb2_v4l2_buffer *src_buf;
	struct rtk_meta_buffer *meta;
	u32 start;

	if (ctx->bit_stream_param & RTK_BIT_STREAM_END_FLAG) {
		printk(KERN_INFO
		       "[fn_name]:[\x1b[31m%s\033[0m], [line]: \x1b[33m%d\033[0m\n",
		       __func__, __LINE__);
		rtk_jcodec_dbg(1, ctx, "bitstream end\n");
		return;
	}

	while (v4l2_m2m_num_src_bufs_ready(ctx->fh.m2m_ctx) > 0) {
		/*
		 * Only queue two JPEGs into the bitstream buffer to keep
		 * latency low. We need at least one complete buffer and the
		 * header of another buffer (for prescan) in the bitstream.
		 */
		if (ctx->codec->src_fourcc == V4L2_PIX_FMT_JPEG &&
		    ctx->num_metas > 1)
			break;

		if (ctx->num_frame_buffers &&
		    ctx->num_metas >= ctx->num_frame_buffers) {
			meta = list_first_entry(&ctx->meta_buffer_list,
						struct rtk_meta_buffer, list);
			/*
>------->------->------- * If we managed to fill in at least a full reorder
>------->------->------- * window of buffers (num_frame_buffers is a
>------->------->------- * conservative estimate for this) and the bitstream
>------->------->------- * prefetcher has at least 2 256 bytes periods beyond
>------->------->------- * the first buffer to fetch, we can safely stop queuing
>------->------->------- * in order to limit the decoder drain latency.
>------->------->------- */
			if (rtk_bitstream_can_fetch_past(ctx, meta->end)) {
				break;
			}
		}

		src_buf = v4l2_m2m_next_src_buf(ctx->fh.m2m_ctx);
		rtk_jcodec_dbg(4, ctx, "feed bitstream src buf %d\n",
			       src_buf->vb2_buf.index);

		/* Drop frames that do not start/end with a SOI/EOI markers */
		// TODO: refine later
		if (ctx->codec->src_fourcc == V4L2_PIX_FMT_JPEG &&
		    !rtk_jpeg_check_buffer(ctx, &src_buf->vb2_buf)) {
			v4l2_err(&ctx->dev->v4l2_dev,
				 "dropping invalid JPEG frame %d\n",
				 ctx->qsequence);
			src_buf = v4l2_m2m_src_buf_remove(ctx->fh.m2m_ctx);
			if (buffer_list) {
				struct v4l2_m2m_buffer *m2m_buf;
				m2m_buf = container_of(
					src_buf, struct v4l2_m2m_buffer, vb);
				list_add_tail(&m2m_buf->list, buffer_list);
			} else {
				v4l2_m2m_buf_done(src_buf, VB2_BUF_STATE_ERROR);
			}
			continue;
		}

		/* Dump empty buffers */
		if (!vb2_get_plane_payload(&src_buf->vb2_buf, 0)) {
			src_buf = v4l2_m2m_src_buf_remove(ctx->fh.m2m_ctx);
			v4l2_m2m_buf_done(src_buf, VB2_BUF_STATE_DONE);
			rtk_jcodec_dbg(4, ctx, "no plane payload\n");
			continue;
		}

		/* Buffer start position */
		start = ctx->bitstream_fifo.kfifo.in;

		if (rtk_bitstream_try_queue(ctx, src_buf)) {
			/*
>------->------->------- * Source buffer is queued in the bitstream ringbuffer;
>------->------->------- * queue the timestamp and mark source buffer as done
>------->------->------- */
			src_buf = v4l2_m2m_src_buf_remove(ctx->fh.m2m_ctx);
			rtk_jcodec_dbg(4, ctx, "remove bitstream src buf %d\n",
				       src_buf->vb2_buf.index);

			meta = kmalloc(sizeof(*meta), GFP_KERNEL);
			if (meta) {
				meta->sequence = src_buf->sequence;
				meta->timecode = src_buf->timecode;
				meta->timestamp = src_buf->vb2_buf.timestamp;
				meta->start = start;
				meta->end = ctx->bitstream_fifo.kfifo.in;
				meta->last =
					src_buf->flags & V4L2_BUF_FLAG_LAST;
				if (meta->last)
					rtk_jcodec_dbg(1, ctx,
						       "meta %d is last\n",
						       meta->sequence);

				spin_lock(&ctx->meta_buffer_lock);
				list_add_tail(&meta->list,
					      &ctx->meta_buffer_list);
				ctx->num_metas++;
				spin_unlock(&ctx->meta_buffer_lock);

				rtk_jcodec_dbg(
					4, ctx, "Add meta sequence  : %d%s\n",
					src_buf->sequence,
					(src_buf->flags & V4L2_BUF_FLAG_LAST) ?
						" (last)" :
						"");
				rtk_jcodec_dbg(4, ctx,
					       "meta timestamp : %lld\n",
					       meta->timestamp);
				rtk_jcodec_dbg(4, ctx,
					       "meta start     :"
					       " 0x%x, meta->end : 0x%x\n",
					       meta->start, meta->end);
				rtk_jcodec_dbg(4, ctx, "num_metas      : %d\n",
					       ctx->num_metas);
			}

			if (buffer_list) {
				struct v4l2_m2m_buffer *m2m_buf;

				m2m_buf = container_of(
					src_buf, struct v4l2_m2m_buffer, vb);
				list_add_tail(&m2m_buf->list, buffer_list);

				rtk_jcodec_dbg(
					4, ctx,
					"Add %c frame %d to m2m buf list\n",
					rtk_frame_type(src_buf->flags),
					src_buf->sequence);
			} else {
				v4l2_m2m_buf_done(src_buf, VB2_BUF_STATE_DONE);

				rtk_jcodec_dbg(4, ctx, "%c frame %d done\n",
					       rtk_frame_type(src_buf->flags),
					       src_buf->sequence);
			}
		} else {
			v4l2_err(&ctx->dev->v4l2_dev,
				 "rtk_bitstream_try_queue fail\n");
			break;
		}
	}
}

static int rtk_start_streaming(struct vb2_queue *q, unsigned int count)
{
	struct rtk_jcodec_ctx *ctx = vb2_get_drv_priv(q);
	struct rtk_q_data *q_data_src, *q_data_dst;
	struct v4l2_m2m_buffer *m2m_buf, *tmp;
	struct vb2_v4l2_buffer *buf;
	struct list_head list;
	int ret = 0;
	int horizontal_factor = 1 , vertical_factor = 1;
	int w_align = 1, h_align = 1;

	if (count < 1) {
		v4l2_err(&ctx->dev->v4l2_dev, "no buffer in queue\n");
		return -EINVAL;
	}

	rtk_jcodec_dbg(1, ctx, "start streaming %s\n",
		       v4l2_type_names[q->type]);

	INIT_LIST_HEAD(&list);

	if(ctx->params.horizontal_factor)
		horizontal_factor = 2 << (ctx->params.horizontal_factor -1);

	if(ctx->params.vertical_factor)
		vertical_factor = 2 << (ctx->params.vertical_factor -1);

	q_data_src = rtk_get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
	if (V4L2_TYPE_IS_OUTPUT(q->type)) {
		//use_bit = 0
		if (ctx->inst_type == RTK_JCODEC_CTX_DECODER && ctx->use_bit) {
			/* copy the buffers that were queued before streamon */
			mutex_lock(&ctx->bitstream_mutex);
			rtk_feed_bitstream(ctx, &list);
			mutex_unlock(&ctx->bitstream_mutex);

			// TODO: refine later
			// if (ctx->dev->devinfo->product != CODA_960 &&
			//     rtk_get_bitstream_payload(ctx) < 512) {
			// 	v4l2_err(v4l2_dev, "start payload < 512\n");
			// 	ret = -EINVAL;
			// 	goto err;
			// }

			if (!ctx->initialized) {
				/* Run sequence initialization */
				printk(KERN_INFO
				       "[fn_name]:[\x1b[33m%s\033[0m], [line]: \x1b[33m%d\033[0m\n",
				       __func__, __LINE__);
				rtk_jcodec_dbg(1, ctx,
					       "Run sequence initialization\n");
				if (ctx->ops->seq_init_work) {
					queue_work(ctx->dev->workqueue,
						   &ctx->seq_init_work);
					flush_work(&ctx->seq_init_work);
				}
			}
		}

		/*
		 * Check the first input JPEG buffer to determine chroma
		 * subsampling.
		 */
		if (q_data_src->fourcc == V4L2_PIX_FMT_JPEG) {
			buf = v4l2_m2m_next_src_buf(ctx->fh.m2m_ctx);
			ret = rtk_jpeg_decode_header(ctx, &buf->vb2_buf);

			/*
			 * We have to start streaming even if the first buffer
			 * does not contain a valid JPEG image. The error will
			 * be caught during device run and will be signalled
			 * via the capture buffer error flag.
			 */

			q_data_dst = get_q_data(
				ctx, V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);

			if (ctx->params.jpeg_chroma_subsampling ==
			    V4L2_JPEG_CHROMA_SUBSAMPLING_420) {
				w_align = 16;
				h_align = 16;
			} else if (ctx->params.jpeg_chroma_subsampling ==
				   V4L2_JPEG_CHROMA_SUBSAMPLING_422) {
				w_align = 16;
				h_align = 8;
			} else if (ctx->params.jpeg_chroma_subsampling ==
				   V4L2_JPEG_CHROMA_SUBSAMPLING_444) {
				w_align = 8;
				h_align = 8;
			}

			if (ctx->params.rot_mode & RTK_ROT_90) {
				q_data_dst->width = round_up(q_data_src->height, 64);
				q_data_dst->height = round_up(q_data_src->width, 64);
			} else {
				if(horizontal_factor == 1) {
					q_data_dst->width = round_up(q_data_src->width , 64);
					q_data_dst->height = round_up(q_data_src->height, 64);
				}
				else {
					q_data_dst->width = round_up(round_up(q_data_src->width , w_align) / horizontal_factor, 64);
					q_data_dst->height = round_up(round_up(q_data_src->height , h_align) / vertical_factor, 64);
				}
			}

			q_data_dst->bytesperline = q_data_dst->width;
			if (ctx->params.jpeg_chroma_subsampling ==
			    V4L2_JPEG_CHROMA_SUBSAMPLING_420) {
				q_data_dst->sizeimage =
					q_data_dst->bytesperline *
					q_data_dst->height * 3 / 2;
				if (q_data_dst->fourcc != V4L2_PIX_FMT_YUV420) {
					q_data_dst->fourcc = V4L2_PIX_FMT_NV12;
				}
			} else if (ctx->params.jpeg_chroma_subsampling ==
				   V4L2_JPEG_CHROMA_SUBSAMPLING_422) {
				q_data_dst->sizeimage =
					q_data_dst->bytesperline *
					q_data_dst->height * 2;
				q_data_dst->fourcc = V4L2_PIX_FMT_NV16;
			} else if (ctx->params.jpeg_chroma_subsampling ==
				   V4L2_JPEG_CHROMA_SUBSAMPLING_444) {
				if (ctx->params.rgb) {
					q_data_dst->fourcc = V4L2_PIX_FMT_RGB24;

					q_data_dst->bytesperline =
						q_data_dst->width * 3;

				} else {
					q_data_dst->fourcc = V4L2_PIX_FMT_NV24;
				}

				q_data_dst->sizeimage =
					q_data_dst->bytesperline *
					q_data_dst->height * 3;
			}

			q_data_dst->rect.left = 0;
			q_data_dst->rect.top = 0;

			if (ctx->params.rot_mode & RTK_ROT_90) {
				q_data_dst->rect.width = q_data_src->height;
				q_data_dst->rect.height = q_data_src->width;
			} else {
				if(horizontal_factor == 1)
					q_data_dst->rect.width = q_data_src->width;
				else
					q_data_dst->rect.width = round_up(q_data_src->width , w_align) / horizontal_factor;
				if(vertical_factor == 1)
					q_data_dst->rect.height = q_data_src->height;
				else
					q_data_dst->rect.height = round_up(q_data_src->height , h_align) / vertical_factor;
			}
		}

		ctx->streamon_out = 1;
	} else {
		ctx->streamon_cap = 1;
#if defined(RTKJPU_DUMP_CAPBUF_EN)
		ctx->bNewCapbufDumpFile = 1;
#endif
	}

	rtk_jcodec_dbg(1, ctx, "start streaming out(%d), cap(%d)\n",
		       ctx->streamon_out, ctx->streamon_cap);

	if (!(ctx->streamon_out && ctx->streamon_cap))
		goto out;

	q_data_dst = rtk_get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);

	rtk_jcodec_dbg(1, ctx, "src rect : %dx%d, dst : %dx%d\n",
		       q_data_src->rect.width, q_data_src->rect.height,
		       q_data_dst->width, q_data_dst->height);

	/* Allow BIT decoder device_run with no new buffers queued */
	if (ctx->inst_type == RTK_JCODEC_CTX_DECODER && ctx->use_bit)
		v4l2_m2m_set_src_buffered(ctx->fh.m2m_ctx, true);

	ctx->gopcounter = ctx->params.gop_size - 1;

	// TODO: refine later
	if (q_data_dst->fourcc == V4L2_PIX_FMT_JPEG)
		ctx->params.gop_size = 1;

	ctx->gopcounter = ctx->params.gop_size - 1;
	/* Only decoders have this control */
	if (ctx->mb_err_cnt_ctrl)
		v4l2_ctrl_s_ctrl(ctx->mb_err_cnt_ctrl, 0);

	ret = ctx->ops->start_streaming(ctx);
	if (ctx->inst_type == RTK_JCODEC_CTX_DECODER) {
		if (ret == -EAGAIN)
			goto out;
	}
	if (ret < 0)
		goto err;

out:
	if (V4L2_TYPE_IS_OUTPUT(q->type)) {
		list_for_each_entry_safe (m2m_buf, tmp, &list, list) {
			list_del(&m2m_buf->list);
			v4l2_m2m_buf_done(&m2m_buf->vb, VB2_BUF_STATE_DONE);
		}
	}

	return 0;

err:
	if (V4L2_TYPE_IS_OUTPUT(q->type)) {
		list_for_each_entry_safe (m2m_buf, tmp, &list, list) {
			list_del(&m2m_buf->list);
			v4l2_m2m_buf_done(&m2m_buf->vb, VB2_BUF_STATE_QUEUED);
		}
		while ((buf = v4l2_m2m_src_buf_remove(ctx->fh.m2m_ctx)))
			v4l2_m2m_buf_done(buf, VB2_BUF_STATE_QUEUED);
	} else {
		while ((buf = v4l2_m2m_dst_buf_remove(ctx->fh.m2m_ctx)))
			v4l2_m2m_buf_done(buf, VB2_BUF_STATE_QUEUED);
	}
	return ret;
}

static void rtk_stop_streaming(struct vb2_queue *q)
{
	struct rtk_jcodec_ctx *ctx = vb2_get_drv_priv(q);
	struct vb2_v4l2_buffer *buf;
	bool stop;

	stop = ctx->streamon_out && ctx->streamon_cap;

	rtk_jcodec_dbg(1, ctx, "stop streaming %s\n", v4l2_type_names[q->type]);

	if (V4L2_TYPE_IS_OUTPUT(q->type)) {
		ctx->streamon_out = 0;
		rtk_bitstream_end_flag(ctx);

		ctx->qsequence = 0;

		while ((buf = v4l2_m2m_src_buf_remove(ctx->fh.m2m_ctx))) {
			rtk_jcodec_dbg(1, ctx, "remove %d and set error\n",
				       buf->vb2_buf.index);
			v4l2_m2m_buf_done(buf, VB2_BUF_STATE_ERROR);
		}
	} else {
		ctx->streamon_cap = 0;

		ctx->osequence = 0;
		ctx->sequence_offset = 0;

		while ((buf = v4l2_m2m_dst_buf_remove(ctx->fh.m2m_ctx))) {
			rtk_jcodec_dbg(1, ctx, "remove %d and set error\n",
				       buf->vb2_buf.index);
			v4l2_m2m_buf_done(buf, VB2_BUF_STATE_ERROR);
		}
	}

	if (stop) {
		struct rtk_meta_buffer *meta;
		spin_lock(&ctx->meta_buffer_lock);
		while (!list_empty(&ctx->meta_buffer_list)) {
			meta = list_first_entry(&ctx->meta_buffer_list,
						struct rtk_meta_buffer, list);
			list_del(&meta->list);
			kfree(meta);
		}
		ctx->num_metas = 0;
		spin_unlock(&ctx->meta_buffer_lock);
		kfifo_init(&ctx->bitstream_fifo, ctx->bitstream.vaddr,
			   ctx->bitstream.size);
		ctx->runcounter = 0;
		ctx->aborting = 0;
		ctx->hold = false;
	}
	if (!ctx->streamon_out && !ctx->streamon_cap) {
		ctx->bit_stream_param &= ~RTK_BIT_STREAM_END_FLAG;
	}
}

static const struct vb2_ops rtk_qops = {
	.queue_setup = rtk_queue_setup,
	.buf_prepare = rtk_buf_prepare,
	.buf_queue = rtk_buf_queue,
	.start_streaming = rtk_start_streaming,
	.stop_streaming = rtk_stop_streaming,
	.wait_prepare = vb2_ops_wait_prepare,
	.wait_finish = vb2_ops_wait_finish,
};

static int rtk_jpeg_queue_init(struct rtk_jcodec_ctx *ctx, struct vb2_queue *vq)
{
	vq->drv_priv = ctx;
	vq->ops = &rtk_qops;
	vq->buf_struct_size = sizeof(struct v4l2_m2m_buffer);
	vq->timestamp_flags = V4L2_BUF_FLAG_TIMESTAMP_COPY;
	vq->lock = &ctx->dev->dev_mutex;
	/* One way to indicate end-of-stream for coda is to set the
	 * bytesused == 0. However by default videobuf2 handles bytesused
	 * equal to 0 as a special case and changes its value to the size
	 * of the buffer. Set the allow_zero_bytesused flag, so
	 * that videobuf2 will keep the value of bytesused intact.
	 */
	vq->allow_zero_bytesused = 1;
	/*
	 * We might be fine with no buffers on some of the queues, but that
	 * would need to be reflected in job_ready(). Currently we expect all
	 * queues to have at least one buffer queued.
	 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 8, 0)
	vq->min_buffers_needed = 1;
#endif
	/* below kernel 6.6 */
	//vq->min_queued_buffers = 1;

	vq->dev = ctx->dev->dev;
	return vb2_queue_init(vq);
}

static int rtk_encoder_queue_init(void *priv, struct vb2_queue *src_vq,
			   struct vb2_queue *dst_vq)
{
	int ret;

	src_vq->type = V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE;
	src_vq->io_modes = VB2_DMABUF | VB2_MMAP;
	src_vq->mem_ops = &vb2_dma_contig_memops;

	ret = rtk_jpeg_queue_init(priv, src_vq);
	if (ret)
		return ret;

	dst_vq->type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	dst_vq->io_modes = VB2_DMABUF | VB2_MMAP;
	dst_vq->mem_ops = &vb2_dma_contig_memops;

	return rtk_jpeg_queue_init(priv, dst_vq);
}
#if 0
int rtk_decoder_queue_init(void *priv, struct vb2_queue *src_vq,
			    struct vb2_queue *dst_vq)
{
	int ret;

	src_vq->type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
	src_vq->io_modes = VB2_DMABUF | VB2_MMAP | VB2_USERPTR;
	src_vq->mem_ops = &vb2_vmalloc_memops;

	ret = rtk_jpeg_queue_init(priv, src_vq);
	if (ret)
		return ret;

	dst_vq->type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	dst_vq->io_modes = VB2_DMABUF | VB2_MMAP;
	dst_vq->dma_attrs = DMA_ATTR_NO_KERNEL_MAPPING;
	dst_vq->mem_ops = &vb2_dma_contig_memops;

	return rtk_jpeg_queue_init(priv, dst_vq);
}
#endif
const struct rtk_context_ops rtk_jpeg_decode_ops = {
	.queue_init = rtk_encoder_queue_init, /* non-bitstream operation */
	.start_streaming = rtk_jpeg_start_decoding,
	.prepare_run = rtk_jpeg_prepare_decode,
	.finish_run = rtk_jpeg_finish_decode,
	.release = rtk_jpeg_release,
};
const struct rtk_context_ops rtk_jpeg_encode_ops = {
	.queue_init = rtk_encoder_queue_init,
	.start_streaming = rtk_jpeg_start_encoding,
	.prepare_run = rtk_jpeg_prepare_encode,
	.finish_run = rtk_jpeg_finish_encode,
	.run_timeout = rtk_jpeg_encode_timeout,
	.release = rtk_jpeg_release,
};
irqreturn_t rtk_jcodec_irq_handler(int irq, void *data)
{
	struct rtk_jcodec_dev *dev = data;
	struct rtk_jcodec_ctx *ctx;
	int status;
	int err_mb;

	status = rtk_jcodec_read(dev, RTK_REG_JPEG_PIC_STATUS);
	if (status == 0)
		return IRQ_HANDLED;
	rtk_jcodec_write(dev, status,
			 RTK_REG_JPEG_PIC_STATUS); //interrupt_reason

	if (status & RTK_JPEG_STATUS_OVERFLOW)
		v4l2_err(&dev->v4l2_dev, "JPEG overflow\n");

	if (status & RTK_JPEG_STATUS_BBC_INT)
		v4l2_err(&dev->v4l2_dev, "JPEG BBC interrupt\n");

	if (status & RTK_JPEG_STATUS_ERROR) {
		v4l2_err(&dev->v4l2_dev, "JPEG error\n");

		err_mb = rtk_jcodec_read(dev, RTK_REG_JPEG_PIC_ERRMB);
		if (err_mb) {
			v4l2_err(&dev->v4l2_dev,
				 "ERRMB: 0x%x: rst idx %d, mcu pos (%d,%d)\n",
				 err_mb, err_mb >> 24, (err_mb >> 12) & 0xfff,
				 err_mb & 0xfff);
		}
	}

	ctx = v4l2_m2m_get_curr_priv(dev->m2m_dev);
	if (!ctx) {
		v4l2_err(&dev->v4l2_dev,
			 "Instance released before the end of transaction\n");
		mutex_unlock(&dev->rtk_mutex);
		return IRQ_HANDLED;
	}

	complete(&ctx->completion);

	return IRQ_HANDLED;
}
