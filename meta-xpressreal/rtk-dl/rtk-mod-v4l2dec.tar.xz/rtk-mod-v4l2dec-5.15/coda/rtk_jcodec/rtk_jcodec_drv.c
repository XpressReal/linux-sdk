/*
 * Realtek video decoder v4l2 driver
 *
 * Copyright (c) 2024 Realtek Semiconductor Corp.
 *
 */

#include <linux/clk.h>
#include <linux/debugfs.h>
#include <linux/delay.h>
#include <linux/firmware.h>
#include <linux/gcd.h>
#include <linux/genalloc.h>
#include <linux/idr.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/irq.h>
#include <linux/kfifo.h>
#include <linux/module.h>
#include <linux/of_device.h>
#include <linux/platform_device.h>
#include <linux/pm_runtime.h>
#include <linux/slab.h>
#include <linux/videodev2.h>
#include <linux/of.h>
#include <linux/ratelimit.h>
#include <linux/reset.h>
#include <linux/version.h>

#include <media/v4l2-ctrls.h>
#include <media/v4l2-device.h>
#include <media/v4l2-event.h>
#include <media/v4l2-ioctl.h>
#include <media/v4l2-mem2mem.h>
#include <media/videobuf2-v4l2.h>
#include <media/videobuf2-dma-contig.h>
#include <media/videobuf2-vmalloc.h>

#include <linux/dma-map-ops.h>
#include <soc/realtek/memory.h>
#include <soc/realtek/rtk_media_heap.h>

#include "rtk_jcodec_drv.h"
#include "rtk_jcodec_regs.h"

#include <linux/of_address.h>

#define RTK_JCODEC_NAME "rtk-jcodec"
//#define RTKJPU_DUMP_REGISTER

#define RTK_JCODEC_MAX_FORMATS 10

#define RTK_COD_STD_DECODE_JPEG 0
#define RTK_COD_STD_ENCODE_JPEG 1

// TODO: reference to ve1_vdi.c
#define RTK_SRAM_SIZE 0x1D000
#define FRATE_RES_MASK 0xffff
#define FRATE_DIV_OFFSET 16

#define TEMP_BUF_SIZE (204 * 1024)
#define WORK_BUF_SIZE (80 * 1024)

#define MAX_WIDTH 8192
#define MAX_HEIGHT 8192

#define MAX_4K_WIDTH 4096
#define MAX_4K_HEIGHT 4096

#define MAX_2K_WIDTH 1920
#define MAX_2K_HEIGHT 1088

#define MIN_WIDTH 16
#define MIN_HEIGHT 16

#define MIN_W 48
#define MIN_H 16

#define S_ALIGN 0
#define W_ALIGN 0
#define H_ALIGN 0
//#define S_ALIGN 1 /* multiple of 2 */
//#define W_ALIGN 1 /* multiple of 2 */
//#define H_ALIGN 1 /* multiple of 2 */

#define CODA7_STREAM_BUF_PIC_FLUSH (1 << 3)
#define CODA9_FRAME_ENABLE_BWB (1 << 12)
#define RTK_REG_RESET_ENABLE (1 << 0)
#define RTK_REG_RUN_ENABLE (1 << 0)
#define RTK_REG_INT_CLEAR_ENABLE 0x1

#define VE_CTRL_REG (0x3000)
#define VE_CTI_GRP_REG (0x3004)
#define VE_MBIST_CTRL (0x3C08)
#define VE_BISR_POWER_RESET (0x3CB0)

#define RTK_COMMAND_FIRMWARE_GET 0xf

#define RTK_FIRMWARE_PRODUCT(x) (((x) >> 16) & 0xffff)
#define RTK_FIRMWARE_MAJOR(x) (((x) >> 12) & 0x0f)
#define RTK_FIRMWARE_MINOR(x) (((x) >> 8) & 0x0f)
#define RTK_FIRMWARE_RELEASE(x) ((x)&0xff)

// #define CODA_ROT_MIR_ENABLE	(1 << 4)
// #define CODA_ROT_0			(0x0 << 0)
// #define CODA_ROT_90			(0x1 << 0)
// #define CODA_ROT_180		(0x2 << 0)
// #define CODA_ROT_270		(0x3 << 0)
// #define CODA_MIR_NONE		(0x0 << 2)
#define CODA_MIR_VER (0x1 << 2)
#define CODA_MIR_HOR (0x2 << 2)
// #define CODA_MIR_VER_HOR	(0x3 << 2)

#define MIN_BITRATE (64)
#define MAX_BITRATE (40 * 1024 * 1024)
#define DEF_BITRATE (5 * 1024 * 1024)

static int dbus_en = 1;

#define fh_to_ctx(__fh) container_of(__fh, struct rtk_jcodec_ctx, fh)

int rtk_jcodec_debug;
module_param(rtk_jcodec_debug, int, 0644);
MODULE_PARM_DESC(rtk_jcodec_debug, "Debug level (0-2)");

static int disable_tiling;
module_param(disable_tiling, int, 0644);
MODULE_PARM_DESC(disable_tiling, "Disable tiled frame buffers");

static ssize_t get_instance_info(struct device *dev, struct device_attribute *attr,
			 char *buf);
static int rtk_try_fmt(struct rtk_jcodec_ctx *ctx,
		       const struct rtk_codec *codec, struct v4l2_format *f);
static void rtk_fill_colorspace(struct v4l2_pix_format_mplane *pix_mp,
				       u32 fourcc);
static DEVICE_ATTR(instance_info, S_IRUSR, get_instance_info, NULL);

#define RTK_CODEC(mode, src_fourcc, dst_fourcc, max_w, max_h)                  \
	{                                                                      \
		mode, src_fourcc, dst_fourcc, max_w, max_h                     \
	}

static const struct rtk_codec rtk_video_codecs[] = {
	RTK_CODEC(RTK_COD_STD_DECODE_JPEG, V4L2_PIX_FMT_JPEG, V4L2_PIX_FMT_NV12,
		  MAX_WIDTH, MAX_HEIGHT),
	RTK_CODEC(RTK_COD_STD_DECODE_JPEG, V4L2_PIX_FMT_JPEG, V4L2_PIX_FMT_NV16,
		  MAX_WIDTH, MAX_HEIGHT),
	RTK_CODEC(RTK_COD_STD_DECODE_JPEG, V4L2_PIX_FMT_JPEG, V4L2_PIX_FMT_NV24,
		  MAX_WIDTH, MAX_HEIGHT),
	RTK_CODEC(RTK_COD_STD_DECODE_JPEG, V4L2_PIX_FMT_JPEG,
		  V4L2_PIX_FMT_RGB24, MAX_WIDTH, MAX_HEIGHT),
	RTK_CODEC(RTK_COD_STD_ENCODE_JPEG, V4L2_PIX_FMT_YUV420,
		  V4L2_PIX_FMT_JPEG, MAX_WIDTH, MAX_HEIGHT),
	RTK_CODEC(RTK_COD_STD_ENCODE_JPEG, V4L2_PIX_FMT_NV12, V4L2_PIX_FMT_JPEG,
		  MAX_WIDTH, MAX_HEIGHT),
	RTK_CODEC(RTK_COD_STD_ENCODE_JPEG, V4L2_PIX_FMT_YUV422P,
		  V4L2_PIX_FMT_JPEG, MAX_WIDTH, MAX_HEIGHT),
	RTK_CODEC(RTK_COD_STD_ENCODE_JPEG, V4L2_PIX_FMT_NV16, V4L2_PIX_FMT_JPEG,
		  MAX_WIDTH, MAX_HEIGHT),
	RTK_CODEC(RTK_COD_STD_ENCODE_JPEG, V4L2_PIX_FMT_YUV444M,
		  V4L2_PIX_FMT_JPEG, MAX_WIDTH, MAX_HEIGHT),
	RTK_CODEC(RTK_COD_STD_ENCODE_JPEG, V4L2_PIX_FMT_NV24, V4L2_PIX_FMT_JPEG,
		  MAX_WIDTH, MAX_HEIGHT),
	RTK_CODEC(RTK_COD_STD_ENCODE_JPEG, V4L2_PIX_FMT_RGB24,
		  V4L2_PIX_FMT_JPEG, MAX_WIDTH, MAX_HEIGHT),
	RTK_CODEC(RTK_COD_STD_ENCODE_JPEG, V4L2_PIX_FMT_GREY, V4L2_PIX_FMT_JPEG,
		  MAX_WIDTH, MAX_HEIGHT),
};

struct rtk_video_device {
	const char *name;
	enum rtk_jcodec_ctx_type type;
	const struct rtk_context_ops *ops;
	bool direct;
	u32 src_formats[RTK_JCODEC_MAX_FORMATS];
	u32 dst_formats[RTK_JCODEC_MAX_FORMATS];
};

static const struct rtk_video_device rtk_jpeg_decoder = {
	.name = "rtk-jpeg-decoder",
	.type = RTK_JCODEC_CTX_DECODER,
	.ops = &rtk_jpeg_decode_ops,
	.direct = true,
	.src_formats = {
		V4L2_PIX_FMT_JPEG,
	},
	.dst_formats = {
		V4L2_PIX_FMT_NV12,
		V4L2_PIX_FMT_NV16,
		V4L2_PIX_FMT_NV24,
		V4L2_PIX_FMT_RGB24,
	},
};

static const struct rtk_video_device rtk_jpeg_encoder = {
	.name = "rtk-jpeg-encoder",
	.type = RTK_JCODEC_CTX_ENCODER,
	.ops = &rtk_jpeg_encode_ops,
	.direct = true,
	.src_formats = {
		V4L2_PIX_FMT_YUV420,
		//V4L2_PIX_FMT_YVU420,
		V4L2_PIX_FMT_NV12,
		V4L2_PIX_FMT_YUV422P,
		V4L2_PIX_FMT_NV16,
		V4L2_PIX_FMT_YUV444M,
		V4L2_PIX_FMT_NV24,
		V4L2_PIX_FMT_RGB24,
		V4L2_PIX_FMT_GREY,
	},
	.dst_formats = {
		V4L2_PIX_FMT_JPEG,
	},
};

static const struct rtk_video_device *rtk_video_devices[] = {
	&rtk_jpeg_decoder,
	&rtk_jpeg_encoder,
};

enum rtk_platform {
	RTK_STARK,
	RTK_KENT,
	RTK_PRINCE,
};

static const struct rtk_devinfo rtk_devdata[] = {
	[RTK_STARK] = {
		.product      = CODA_J10,
		.codecs       = rtk_video_codecs,
		.num_codecs   = ARRAY_SIZE(rtk_video_codecs),
		.vdevs        = rtk_video_devices,
		.num_vdevs    = ARRAY_SIZE(rtk_video_devices),
	},
	[RTK_KENT] = {
		.product      = CODA_J10,
		.codecs       = rtk_video_codecs,
		.num_codecs   = ARRAY_SIZE(rtk_video_codecs),
		.vdevs        = rtk_video_devices,
		.num_vdevs    = ARRAY_SIZE(rtk_video_devices),
	},
	[RTK_PRINCE] = {
		.product      = CODA_J10,
		.codecs       = rtk_video_codecs,
		.num_codecs   = ARRAY_SIZE(rtk_video_codecs),
		.vdevs        = rtk_video_devices,
		.num_vdevs    = ARRAY_SIZE(rtk_video_devices),
	},
};

static ssize_t get_instance_info(struct device *dev, struct device_attribute *attr,
			 char *buf)
{
	struct rtk_jcodec_dev *rdev = dev_get_drvdata(dev);
	struct rtk_jcodec_ctx *ctx = NULL;
	int len = 0;
	int dec_cnt = 0;
	int enc_cnt = 0;

	list_for_each_entry(ctx, &rdev->instances, list) {
		if (ctx) {
			struct rtk_q_data *q_data_src;

			q_data_src = get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
			if (ctx->inst_type == RTK_JCODEC_CTX_DECODER) {
				dec_cnt++;
				len += scnprintf(buf + len, PAGE_SIZE - len,
					"Dec instance %d: Codec MJPEG, Resolution %dx%d\n", dec_cnt,
					q_data_src->width, q_data_src->height);
			} else {
				enc_cnt++;
			}
		}
	}

	len += scnprintf(buf + len, PAGE_SIZE - len,
		"Dec total instance(MJPEG) %d\n", dec_cnt);
	len += scnprintf(buf + len, PAGE_SIZE - len,
		"Enc total instance(MJPEG) %d\n", enc_cnt);

	return len;
}

#if defined(RTKJPU_DUMP_REGISTER)
const char* get_register_name(unsigned int addr) {
	switch (addr) {
		case RTK_REG_JPEG_PIC_START: return "MJPEG_PIC_START_REG";
		case RTK_REG_JPEG_PIC_STATUS: return "MJPEG_PIC_STATUS_REG";
		case RTK_REG_JPEG_PIC_ERRMB: return "MJPEG_PIC_ERRMB_REG";
		//case RTK_REG_JPEG_PIC_SETMB: return "MJPEG_PIC_SETMB_REG";
		case RTK_REG_JPEG_PIC_CTRL: return "MJPEG_PIC_CTRL_REG";
		case RTK_REG_JPEG_PIC_SIZE: return "MJPEG_PIC_SIZE_REG";
		case RTK_REG_JPEG_MCU_INFO: return "MJPEG_MCU_INFO_REG";
		case RTK_REG_JPEG_ROT_INFO: return "MJPEG_ROT_INFO_REG";
		case RTK_REG_JPEG_SCL_INFO: return "MJPEG_SCL_INFO_REG";
		case RTK_REG_JPEG_IF_INFO: return "MJPEG_IF_INFO_REG";
		case RTK_REG_JPEG_CLP_INFO_REG: return "MJPEG_CLP_INFO_REG";
		case RTK_REG_JPEG_OP_INFO: return "MJPEG_OP_INFO_REG";
		case RTK_REG_JPEG_DPB_CONFIG: return "MJPEG_DPB_CONFIG_REG";
		case RTK_REG_JPEG_DPB_BASE00: return "MJPEG_DPB_BASE00_REG";
		case RTK_REG_JPEG_DPB_BASE01: return "MJPEG_DPB_BASE01_REG";
		case RTK_REG_JPEG_DPB_BASE02: return "MJPEG_DPB_BASE02_REG";
		case RTK_REG_JPEG_DPB_BASE10: return "MJPEG_DPB_BASE10_REG";
		case RTK_REG_JPEG_DPB_BASE11: return "MJPEG_DPB_BASE11_REG";
		case RTK_REG_JPEG_DPB_BASE12: return "MJPEG_DPB_BASE12_REG";
		case RTK_REG_JPEG_DPB_BASE20: return "MJPEG_DPB_BASE20_REG";
		case RTK_REG_JPEG_DPB_BASE21: return "MJPEG_DPB_BASE21_REG";
		case RTK_REG_JPEG_DPB_BASE22: return "MJPEG_DPB_BASE22_REG";
		case RTK_REG_JPEG_DPB_BASE30: return "MJPEG_DPB_BASE30_REG";
		case RTK_REG_JPEG_DPB_BASE31: return "MJPEG_DPB_BASE31_REG";
		case RTK_REG_JPEG_DPB_BASE32: return "MJPEG_DPB_BASE32_REG";
		case RTK_REG_JPEG_DPB_YSTRIDE: return "MJPEG_DPB_YSTRIDE_REG";
		case RTK_REG_JPEG_DPB_CSTRIDE: return "MJPEG_DPB_CSTRIDE_REG";
		case RTK_REG_JPEG_WRESP_CHECK: return "MJPEG_WRESP_CHECK_REG";
		case RTK_REG_JPEG_CLP_BASE: return "MJPEG_CLP_BASE_REG";
		case RTK_REG_JPEG_CLP_SIZE: return "MJPEG_CLP_SIZE_REG";
		case RTK_REG_JPEG_HUFF_CTRL: return "MJPEG_HUFF_CTRL_REG";
		case RTK_REG_JPEG_HUFF_ADDR: return "MJPEG_HUFF_ADDR_REG";
		case RTK_REG_JPEG_HUFF_DATA: return "MJPEG_HUFF_DATA_REG";
		case RTK_REG_JPEG_QMAT_CTRL: return "MJPEG_QMAT_CTRL_REG";
		case RTK_REG_JPEG_QMAT_ADDR: return "MJPEG_QMAT_ADDR_REG";
		case RTK_REG_JPEG_QMAT_DATA: return "MJPEG_QMAT_DATA_REG";
		//case RTK_REG_JPEG_COEF_CTRL: return "MJPEG_COEF_CTRL_REG";
		//case RTK_REG_JPEG_COEF_ADDR: return "MJPEG_COEF_ADDR_REG";
		//case RTK_REG_JPEG_COEF_DATA: return "MJPEG_COEF_DATA_REG";
		case RTK_REG_JPEG_RST_INTVAL: return "MJPEG_RST_INTVAL_REG";
		case RTK_REG_JPEG_RST_INDEX: return "MJPEG_RST_INDEX_REG";
		case RTK_REG_JPEG_RST_COUNT: return "MJPEG_RST_COUNT_REG";
		//case RTK_REG_JPEG_INTR_MASK: return "MJPEG_INTR_MASK_REG";
		//case RTK_REG_JPEG_CYCLE_INFO: return "MJPEG_CYCLE_INFO_REG";
		case RTK_REG_JPEG_DPCM_DIFF_Y: return "MJPEG_DPCM_DIFF_Y_REG";
		case RTK_REG_JPEG_DPCM_DIFF_CB: return "MJPEG_DPCM_DIFF_CB_REG";
		case RTK_REG_JPEG_DPCM_DIFF_CR: return "MJPEG_DPCM_DIFF_CR_REG";
		//case RTK_REG_JPEG_VERSION_INFO: return "MJPEG_VERSION_INFO_REG";
		case RTK_REG_JPEG_GBU_CTRL: return "MJPEG_GBU_CTRL_REG";
		//case RTK_REG_JPEG_GBU_PBIT_BUSY: return "MJPEG_GBU_PBIT_BUSY_REG";
		case RTK_REG_JPEG_GBU_BT_PTR: return "MJPEG_GBU_BT_PTR_REG";
		case RTK_REG_JPEG_GBU_WD_PTR: return "MJPEG_GBU_WD_PTR_REG";
		case RTK_REG_JPEG_GBU_TT_CNT: return "MJPEG_GBU_TT_CNT_REG";
		case RTK_REG_JPEG_GBU_TT_CNT+4: return "MJPEG_GBU_TT_CNT_REG+4";
		// case RTK_REG_JPEG_GBU_PBIT_08: return "MJPEG_GBU_PBIT_08_REG";
		// case RTK_REG_JPEG_GBU_PBIT_16: return "MJPEG_GBU_PBIT_16_REG";
		// case RTK_REG_JPEG_GBU_PBIT_24: return "MJPEG_GBU_PBIT_24_REG";
		// case RTK_REG_JPEG_GBU_PBIT_32: return "MJPEG_GBU_PBIT_32_REG";
		case RTK_REG_JPEG_GBU_BBSR: return "MJPEG_GBU_BBSR_REG";
		case RTK_REG_JPEG_GBU_BBER: return "MJPEG_GBU_BBER_REG";
		case RTK_REG_JPEG_GBU_BBIR: return "MJPEG_GBU_BBIR_REG";
		case RTK_REG_JPEG_GBU_BBHR: return "MJPEG_GBU_BBHR_REG";
		case RTK_REG_JPEG_GBU_BCNT: return "MJPEG_GBU_BCNT_REG";
		case RTK_REG_JPEG_GBU_FF_RPTR: return "MJPEG_GBU_FF_RPTR_REG";
		case RTK_REG_JPEG_GBU_FF_WPTR: return "MJPEG_GBU_FF_WPTR_REG";
		case RTK_REG_JPEG_BBC_END_ADDR: return "MJPEG_BBC_END_ADDR_REG";
		case RTK_REG_JPEG_BBC_WR_PTR: return "MJPEG_BBC_WR_PTR_REG";
		case RTK_REG_JPEG_BBC_RD_PTR: return "MJPEG_BBC_RD_PTR_REG";
		case RTK_REG_JPEG_BBC_EXT_ADDR: return "MJPEG_BBC_EXT_ADDR_REG";
		case RTK_REG_JPEG_BBC_INT_ADDR: return "MJPEG_BBC_INT_ADDR_REG";
		case RTK_REG_JPEG_BBC_DATA_CNT: return "MJPEG_BBC_DATA_CNT_REG";
		case RTK_REG_JPEG_BBC_COMMAND: return "MJPEG_BBC_COMMAND_REG";
		case RTK_REG_JPEG_BBC_BUSY: return "MJPEG_BBC_BUSY_REG";
		case RTK_REG_JPEG_BBC_CTRL: return "MJPEG_BBC_CTRL_REG";
		case RTK_REG_JPEG_BBC_CUR_POS: return "MJPEG_BBC_CUR_POS_REG";
		case RTK_REG_JPEG_BBC_BAS_ADDR: return "MJPEG_BBC_BAS_ADDR_REG";
		case RTK_REG_JPEG_BBC_STRM_CTRL: return "MJPEG_BBC_STRM_CTRL_REG";
		case RTK_REG_JPEG_BBC_FLUSH_CMD: return "MJPEG_BBC_FLUSH_CMD_REG";
		default: return "UNKNOWN_REGISTER";
	}
}
#endif

void rtk_jcodec_write(struct rtk_jcodec_dev *dev, u32 data, u32 reg)
{
#if defined(RTKJPU_DUMP_REGISTER)
	const char *reg_name = get_register_name(reg);
	pr_info("%s: writeReg %s, addr: 0x%x, data: 0x%x\n", __func__, reg_name , reg, data);
#endif
	writel(data, dev->regs_base + reg);
}

unsigned int rtk_jcodec_read(struct rtk_jcodec_dev *dev, u32 reg)
{
	u32 data;

	data = readl(dev->regs_base + reg);

	return data;
}

static int rtk_jcodec_check_firmware(struct rtk_jcodec_dev *dev)
{
	int ret;

	ret = clk_prepare_enable(dev->clk);
	if (ret)
		goto err_clk_per;
	clk_disable_unprepare(dev->clk);

	return 0;
err_clk_per:
	return ret;
}

#ifdef CONFIG_PM
static int rtk_jcodec_clk_enable(struct clk *clk)
{
	if (!(clk == NULL || IS_ERR(clk))) {
		return clk_prepare_enable(clk);
	}
	return 0;
}

static void rtk_jcodec_clk_disable(struct clk *clk)
{
	if (!(clk == NULL || IS_ERR(clk))) {
		clk_disable_unprepare(clk);
	}
}
#endif

/**
 * RTK jcodec hw operations
 */

static int rtk_jcodec_sw_reset(struct rtk_jcodec_dev *dev)
{
	u32 streamBufStartAddr;
	u32 streamBufEndAddr;
	u32 streamWrPtr;
	u32 streamRdPtr;
	u32 val;
	int ret = 0;

	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_BBC_BAS_ADDR);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_BBC_END_ADDR);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_BBC_RD_PTR);
	rtk_jcodec_write(dev, 0, RTK_REG_JPEG_BBC_WR_PTR);

	streamBufStartAddr = rtk_jcodec_read(dev, RTK_REG_JPEG_BBC_BAS_ADDR);
	streamBufEndAddr = rtk_jcodec_read(dev, RTK_REG_JPEG_BBC_END_ADDR);
	streamRdPtr = rtk_jcodec_read(dev, RTK_REG_JPEG_BBC_RD_PTR);
	streamWrPtr = rtk_jcodec_read(dev, RTK_REG_JPEG_BBC_WR_PTR);

	rtk_jcodec_write(dev, (1 << JPG_START_INIT), RTK_REG_JPEG_PIC_START);

	do {
		val = rtk_jcodec_read(dev, RTK_REG_JPEG_PIC_START);
	} while ((val & (1 << JPG_START_INIT)) == (1 << JPG_START_INIT));

	rtk_jcodec_write(dev, streamBufStartAddr, RTK_REG_JPEG_BBC_BAS_ADDR);
	rtk_jcodec_write(dev, streamBufEndAddr, RTK_REG_JPEG_BBC_END_ADDR);
	rtk_jcodec_write(dev, streamRdPtr, RTK_REG_JPEG_BBC_RD_PTR);
	rtk_jcodec_write(dev, streamWrPtr, RTK_REG_JPEG_BBC_WR_PTR);

	return ret;
}

int rtk_jcodec_hw_reset(struct rtk_jcodec_dev *dev)
{
	int ret = 0;
	unsigned int val;

	lockdep_assert_held(&dev->rtk_mutex);

	if (!dev->rstc) {
		return -ENOENT;
	}

	rtk_jcodec_clk_disable(dev->clk);

	reset_control_reset(dev->rstc);

	rtk_jcodec_clk_enable(dev->clk);

	val = rtk_jcodec_read(dev, RTK_REG_JPEG_DBUS);
	val |= (dbus_en << 0);
	val &= ~(1 << 1); //Disable idle gating, fix it later.
	rtk_jcodec_write(dev, val, RTK_REG_JPEG_DBUS);

	return ret;
}

static int rtk_jcodec_hw_init(struct rtk_jcodec_dev *dev)
{
	unsigned int val;
	int ret;

	ret = clk_prepare_enable(dev->clk);
	if (ret) {
		goto err_clk_jpeg;
	}

	reset_control_reset(dev->rstc);

	val = rtk_jcodec_read(dev, RTK_REG_JPEG_DBUS);
	val |= (dbus_en << 0);
	val &= ~(1 << 1); //Disable idle gating, fix it later.
	rtk_jcodec_write(dev, val, RTK_REG_JPEG_DBUS);

	rtk_jcodec_sw_reset(dev);

	clk_disable_unprepare(dev->clk);

	return 0;

err_clk_jpeg:
	return ret;
}

static void rtk_get_max_dimensions(struct rtk_jcodec_dev *dev,
				   const struct rtk_codec *codec, int *max_w,
				   int *max_h)
{
	const struct rtk_codec *codecs = dev->devinfo->codecs;
	int num_codecs = dev->devinfo->num_codecs;
	unsigned int w, h;
	int k;

	if (codec) {
		w = codec->max_w;
		h = codec->max_h;
	} else {
		for (k = 0, w = 0, h = 0; k < num_codecs; k++) {
			w = max(w, codecs[k].max_w);
			h = max(h, codecs[k].max_h);
		}
	}

	if (max_w)
		*max_w = w;
	if (max_h)
		*max_h = h;
}

static const struct rtk_video_device *
to_rtk_video_device(struct video_device *vdev)
{
	struct rtk_jcodec_dev *dev = video_get_drvdata(vdev);
	unsigned int i = vdev - dev->vfd;

	if (i >= dev->devinfo->num_vdevs)
		return NULL;

	return dev->devinfo->vdevs[i];
}

/**
 * RTK jcodec common operations
 */

static const char *rtk_jcodec_product_name(int product)
{
	static char buf[9];

	switch (product) {
	case CODA_J10:
		return "CODA_J10";
	default:
		snprintf(buf, sizeof(buf), "(0x%04x)", product);
		return buf;
	}
}

static const struct rtk_codec *rtk_jcodec_find_codec(struct rtk_jcodec_dev *dev,
						     int src_fourcc,
						     int dst_fourcc)
{
	const struct rtk_codec *codecs = dev->devinfo->codecs;
	int num_codecs = dev->devinfo->num_codecs;
	int k;

	if (src_fourcc == dst_fourcc)
		return NULL;

	for (k = 0; k < num_codecs; k++) {
		if (codecs[k].src_fourcc == src_fourcc &&
		    codecs[k].dst_fourcc == dst_fourcc)
			break;
	}

	if (k == num_codecs)
		return NULL;

	return &codecs[k];
}

static void rtk_jcodec_set_default_params(struct rtk_jcodec_ctx *ctx)
{
	unsigned int max_w, max_h;
	int i;

	ctx->codec = rtk_jcodec_find_codec(ctx->dev, ctx->cvd->src_formats[0],
					   ctx->cvd->dst_formats[0]);

	if (!ctx->codec) {
		v4l2_err(&ctx->dev->v4l2_dev, "failed to find codec\n");
		return;
	}

	max_w = min(ctx->codec->max_w, (unsigned int)MAX_WIDTH);
	max_h = min(ctx->codec->max_h, (unsigned int)MAX_HEIGHT);

	ctx->params.codec_mode = ctx->codec->mode;
	ctx->params.packedFormat = 0;
	ctx->params.frameEndian = JPU_FRAME_ENDIAN;
	ctx->params.streamEndian = JPU_STREAM_ENDIAN;
	ctx->params.stuffByteEnable = 0;
	ctx->params.is_firt_frame = 0;
	ctx->params.rgb = 0;
	ctx->params.horizontal_factor = 0;
	ctx->params.vertical_factor = 0;

	if (ctx->cvd->src_formats[0] == V4L2_PIX_FMT_JPEG ||
	    ctx->cvd->dst_formats[0] ==
		    V4L2_PIX_FMT_JPEG) { //jpeg deocder or jpeg encoder
		ctx->colorspace = V4L2_COLORSPACE_JPEG;
		ctx->xfer_func = V4L2_XFER_FUNC_SRGB;
		ctx->ycbcr_enc = V4L2_YCBCR_ENC_601;
		ctx->quantization = V4L2_QUANTIZATION_FULL_RANGE;
	} else {
		ctx->colorspace = V4L2_COLORSPACE_REC709;
		ctx->xfer_func = V4L2_XFER_FUNC_DEFAULT;
		ctx->ycbcr_enc = V4L2_YCBCR_ENC_DEFAULT;
		ctx->quantization = V4L2_QUANTIZATION_DEFAULT;
	}

	ctx->params.framerate = 30;
	/* Default formats for output and input queues */
	ctx->q_data[V4L2_M2M_SRC_Q_DATA].fourcc = ctx->cvd->src_formats[0];
	ctx->q_data[V4L2_M2M_SRC_Q_DATA].width = max_w;
	ctx->q_data[V4L2_M2M_SRC_Q_DATA].height = max_h;
	if (ctx->codec->src_fourcc != V4L2_PIX_FMT_JPEG) { // encoder
		ctx->q_data[V4L2_M2M_SRC_Q_DATA].bytesperline = max_w * 3;
		ctx->q_data[V4L2_M2M_SRC_Q_DATA].sizeimage =
			ctx->q_data[V4L2_M2M_SRC_Q_DATA].bytesperline * max_h *
			3;
	} else { // decoder
		ctx->q_data[V4L2_M2M_SRC_Q_DATA].bytesperline = 0;
		ctx->q_data[V4L2_M2M_SRC_Q_DATA].sizeimage = 0x700000;
		//ctx->q_data[V4L2_M2M_SRC_Q_DATA].sizeimage =coda_estimate_sizeimage(ctx, usize, max_w, max_h);
	}
	ctx->q_data[V4L2_M2M_SRC_Q_DATA].rect.width = max_w;
	ctx->q_data[V4L2_M2M_SRC_Q_DATA].rect.height = max_h;

	ctx->q_data[V4L2_M2M_DST_Q_DATA].fourcc = ctx->cvd->dst_formats[0];
	ctx->q_data[V4L2_M2M_DST_Q_DATA].width = max_w;
	ctx->q_data[V4L2_M2M_DST_Q_DATA].height = max_h;
	if (ctx->codec->src_fourcc != V4L2_PIX_FMT_JPEG) { // encoder
		ctx->q_data[V4L2_M2M_DST_Q_DATA].bytesperline = 0;
		ctx->q_data[V4L2_M2M_DST_Q_DATA].sizeimage = 0x700000;
		//ctx->q_data[V4L2_M2M_DST_Q_DATA].sizeimage =coda_estimate_sizeimage(ctx, usize, max_w, max_h);
	} else { // decoder
		ctx->q_data[V4L2_M2M_DST_Q_DATA].bytesperline = max_w * 3;
		ctx->q_data[V4L2_M2M_DST_Q_DATA].sizeimage =
			ctx->q_data[V4L2_M2M_DST_Q_DATA].bytesperline * max_h *
			3;
	}
	ctx->q_data[V4L2_M2M_DST_Q_DATA].rect.width = max_w;
	ctx->q_data[V4L2_M2M_DST_Q_DATA].rect.height = max_h;

	/*
	 * Normalize bytesperline/sizeimage via rtk_try_fmt so that G_FMT and
	 * TRY_FMT(G_FMT) return identical values (v4l2-compliance requirement).
	 */
	for (i = 0; i < 2; i++) {
		struct v4l2_format f = {0};

		f.type = (i == 0) ? V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE
				  : V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
		f.fmt.pix_mp.pixelformat = ctx->q_data[i].fourcc;
		f.fmt.pix_mp.width       = ctx->q_data[i].width;
		f.fmt.pix_mp.height      = ctx->q_data[i].height;
		f.fmt.pix_mp.field       = V4L2_FIELD_NONE;
		if (rtk_try_fmt(ctx, ctx->codec, &f) == 0) {
			ctx->q_data[i].bytesperline = f.fmt.pix_mp.plane_fmt[0].bytesperline;
			ctx->q_data[i].sizeimage    = f.fmt.pix_mp.plane_fmt[0].sizeimage;
		} else {
			v4l2_warn(&ctx->dev->v4l2_dev,
				"rtk_try_fmt failed for q_data[%d]; stale size values may remain\n",
				i);
		}
	}

	/*
	 * Since the RBC2AXI logic only supports a single chroma plane,
	 * macroblock tiling only works for to NV12 pixel format.
	 */
	ctx->tiled_map_type = RTK_LINEAR_FRAME_MAP;

	rtk_jcodec_dbg(2, ctx, "set default params :\n");
	rtk_jcodec_dbg(2, ctx, "codec_mode : %d\n", ctx->params.codec_mode);
	for (i = 0; i < 2; i++) {
		rtk_jcodec_dbg(2, ctx, "q_data[%d].fourcc : 0x%x\n", i,
			       ctx->q_data[i].fourcc);
		rtk_jcodec_dbg(2, ctx,
			       "q_data[%d].width : %d,"
			       " q_data[%d].height : %d\n",
			       i, ctx->q_data[i].width, i,
			       ctx->q_data[i].height);
		rtk_jcodec_dbg(2, ctx,
			       "q_data[%d].bytesperline :"
			       " %d, q_data[%d].sizeimage : %d\n",
			       i, ctx->q_data[i].bytesperline, i,
			       ctx->q_data[i].sizeimage);
		rtk_jcodec_dbg(2, ctx,
			       "q_data[%d].rect.width :"
			       " %d, q_data[%d].rect.height : %d\n",
			       i, ctx->q_data[i].rect.width, i,
			       ctx->q_data[i].rect.height);
	}
}

/*
 * RTK jcodec v4l2 ioctl operations
 */

static int rtk_jcodec_querycap(struct file *file, void *priv,
			       struct v4l2_capability *cap)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(priv);

	strscpy(cap->driver, RTK_JCODEC_NAME, sizeof(cap->driver));
	strscpy(cap->card, rtk_jcodec_product_name(ctx->dev->devinfo->product),
		sizeof(cap->card));
	strscpy(cap->bus_info, "platform:" RTK_JCODEC_NAME,
		sizeof(cap->bus_info));

	cap->device_caps = V4L2_CAP_VIDEO_M2M_MPLANE | V4L2_CAP_STREAMING;
	cap->capabilities = cap->device_caps | V4L2_CAP_DEVICE_CAPS;

	return 0;
}

static int rtk_jcodec_enum_fmt(struct file *file, void *priv,
			       struct v4l2_fmtdesc *f)
{
	struct video_device *vdev = video_devdata(file);
	const struct rtk_video_device *cvd = to_rtk_video_device(vdev);
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(priv);
	const u32 *formats;

	if (V4L2_TYPE_IS_OUTPUT(f->type)) {
		formats = cvd->src_formats;
	} else if (V4L2_TYPE_IS_CAPTURE(f->type)) {
		formats = cvd->dst_formats;
	} else {
		return -EINVAL;
	}

	if (f->index >= RTK_JCODEC_MAX_FORMATS || formats[f->index] == 0) {
		return -EINVAL;
	}

	f->pixelformat = formats[f->index];

	rtk_jcodec_dbg(2, ctx, "%d.%s.(%s) enum format: \n", __LINE__, __func__,
		       v4l2_type_names[f->type]);
	rtk_jcodec_dbg(2, ctx, "%d.%s.     formats[%d] : 0x%x\n", __LINE__,
		       __func__, f->index, formats[f->index]);

	return 0;
}

static int rtk_jcodec_g_fmt(struct file *file, void *priv,
			    struct v4l2_format *f)
{
	struct rtk_q_data *q_data;
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(priv);

	q_data = rtk_get_q_data(ctx, f->type);
	if (!q_data) {
		return -EINVAL;
	}

	f->fmt.pix_mp.field = V4L2_FIELD_NONE;

#ifdef RTK_INTERLACED
	if (q_data->fourcc == V4L2_PIX_FMT_JPEG)
		f->fmt.pix_mp.field = V4L2_FIELD_INTERLACED;
#endif

	f->fmt.pix_mp.pixelformat = q_data->fourcc;
	f->fmt.pix_mp.width = q_data->width;
	f->fmt.pix_mp.height = q_data->height;
	f->fmt.pix_mp.plane_fmt[0].bytesperline = q_data->bytesperline;

	f->fmt.pix_mp.plane_fmt[0].sizeimage = q_data->sizeimage;
	rtk_fill_colorspace(&f->fmt.pix_mp, q_data->fourcc);
	f->fmt.pix_mp.num_planes = 1;

	rtk_jcodec_dbg(2, ctx, "(%s) get format: \n", v4l2_type_names[f->type]);
	rtk_jcodec_dbg(2, ctx, "     pixelformat  : %4.4s, field : %d\n",
		       (char *)&f->fmt.pix_mp.pixelformat, f->fmt.pix_mp.field);
	rtk_jcodec_dbg(2, ctx, "     widthxheight : (%dx%d)\n",
		       f->fmt.pix_mp.width, f->fmt.pix_mp.height);
	rtk_jcodec_dbg(2, ctx, "     bytesperline : %d\n",
		       f->fmt.pix_mp.plane_fmt[0].bytesperline);
	rtk_jcodec_dbg(2, ctx, "     sizeimage    : %d\n",
		       f->fmt.pix_mp.plane_fmt[0].sizeimage);

	return 0;
}

static int rtk_try_pixelformat(struct rtk_jcodec_ctx *ctx,
			       struct v4l2_format *f)
{
	struct rtk_q_data *q_data;
	const u32 *formats;
	int i;

	if (V4L2_TYPE_IS_OUTPUT(f->type))
		formats = ctx->cvd->src_formats;
	else if (V4L2_TYPE_IS_CAPTURE(f->type))
		formats = ctx->cvd->dst_formats;
	else
		return -EINVAL;

	for (i = 0; i < RTK_JCODEC_MAX_FORMATS; i++) {
		if (formats[i] == f->fmt.pix_mp.pixelformat) {
			f->fmt.pix_mp.pixelformat = formats[i];
			return 0;
		}
	}

	/* Fall back to currently set pixelformat */
	q_data = rtk_get_q_data(ctx, f->type);
	f->fmt.pix_mp.pixelformat = q_data->fourcc;

	return 0;
}
#if 0
static unsigned int rtk_estimate_sizeimage(struct rtk_jcodec_ctx *ctx,
					   u32 sizeimage, u32 width, u32 height)
{
	/*
	 * This is a rough estimate for sensible compressed buffer
	 * sizes (between 1 and 16 bits per pixel). This could be
	 * improved by better format specific worst case estimates.
	 */
	return round_up(clamp(sizeimage, width * height / 8,
			      width * height * 2),
			PAGE_SIZE);
}
#endif

static void rtk_fill_colorspace(struct v4l2_pix_format_mplane *pix_mp,
					u32 fourcc)
{
	/* Secondary fields are DEFAULT (0) regardless of format */
	pix_mp->xfer_func    = V4L2_XFER_FUNC_DEFAULT;
	pix_mp->ycbcr_enc    = V4L2_YCBCR_ENC_DEFAULT;
	pix_mp->quantization = V4L2_QUANTIZATION_DEFAULT;
	pix_mp->colorspace   = (fourcc == V4L2_PIX_FMT_JPEG) ?
				V4L2_COLORSPACE_JPEG : V4L2_COLORSPACE_SRGB;
}

static int rtk_try_fmt(struct rtk_jcodec_ctx *ctx,
		       const struct rtk_codec *codec, struct v4l2_format *f)
{
	struct rtk_jcodec_dev *dev = ctx->dev;
	unsigned int max_w, max_h;
	enum v4l2_field field;

	field = f->fmt.pix_mp.field;

	if (field == V4L2_FIELD_ANY) { //V4L2_FIELD_ANY=0
		field = V4L2_FIELD_NONE; //V4L2_FIELD_NONE=1
	} else if (V4L2_FIELD_NONE != field) {
		return -EINVAL;
	}

#ifdef RTK_INTERLACED
	if (f->fmt.pix_mp.pixelformat == V4L2_PIX_FMT_JPEG)
		field = V4L2_FIELD_INTERLACED;
#endif

	/* V4L2 specification suggests the driver corrects the format struct
	 * if any of the dimensions is unsupported */
	f->fmt.pix_mp.field = field;

	rtk_get_max_dimensions(dev, codec, &max_w, &max_h);
	v4l_bound_align_image(&f->fmt.pix_mp.width, MIN_W, max_w, W_ALIGN,
			      &f->fmt.pix_mp.height, MIN_H, max_h, H_ALIGN,
			      S_ALIGN);

	switch (f->fmt.pix_mp.pixelformat) {
	case V4L2_PIX_FMT_NV12:
	case V4L2_PIX_FMT_YUV420:
	case V4L2_PIX_FMT_YVU420:
		/*
		 * Frame stride must be at least multiple of 8,
		 * but multiple of 16 for h.264 or JPEG 4:2:x
		 */
		f->fmt.pix_mp.plane_fmt[0].bytesperline =
			round_up(f->fmt.pix_mp.width, 16);
		f->fmt.pix_mp.plane_fmt[0].sizeimage =
			f->fmt.pix_mp.plane_fmt[0].bytesperline *
			f->fmt.pix_mp.height * 3 / 2;
		break;
	case V4L2_PIX_FMT_YUYV:
		f->fmt.pix_mp.plane_fmt[0].bytesperline =
			round_up(f->fmt.pix_mp.width, 16) * 2;
		f->fmt.pix_mp.plane_fmt[0].sizeimage =
			f->fmt.pix_mp.plane_fmt[0].bytesperline *
			f->fmt.pix_mp.height;
		break;
	case V4L2_PIX_FMT_YUV422P:
	case V4L2_PIX_FMT_NV16:
		f->fmt.pix_mp.plane_fmt[0].bytesperline =
			round_up(f->fmt.pix_mp.width, 16);
		f->fmt.pix_mp.plane_fmt[0].sizeimage =
			f->fmt.pix_mp.plane_fmt[0].bytesperline *
			f->fmt.pix_mp.height * 2;
		break;
	case V4L2_PIX_FMT_YUV444M:
	case V4L2_PIX_FMT_NV24:
		f->fmt.pix_mp.plane_fmt[0].bytesperline =
			round_up(f->fmt.pix_mp.width, 16);
		f->fmt.pix_mp.plane_fmt[0].sizeimage =
			f->fmt.pix_mp.plane_fmt[0].bytesperline *
			f->fmt.pix_mp.height * 3;
		break;
	case V4L2_PIX_FMT_RGB24:
		f->fmt.pix_mp.plane_fmt[0].bytesperline =
			round_up(f->fmt.pix_mp.width, 16) * 3;
		f->fmt.pix_mp.plane_fmt[0].sizeimage =
			f->fmt.pix_mp.plane_fmt[0].bytesperline *
			f->fmt.pix_mp.height * 3;
		break;
	case V4L2_PIX_FMT_GREY:
		/* keep 16 pixel alignment of 8-bit pixel data */
		f->fmt.pix_mp.plane_fmt[0].bytesperline =
			round_up(f->fmt.pix_mp.width, 16);
		f->fmt.pix_mp.plane_fmt[0].sizeimage =
			f->fmt.pix_mp.plane_fmt[0].bytesperline *
			f->fmt.pix_mp.height;
		break;
	case V4L2_PIX_FMT_JPEG:
		f->fmt.pix_mp.plane_fmt[0].bytesperline = 0;
		/*f->fmt.pix_mp.plane_fmt[0].sizeimage =
			rtk_estimate_sizeimage(ctx, f->fmt.pix_mp.plane_fmt[0].sizeimage,
					       f->fmt.pix_mp.width,
					       f->fmt.pix_mp.height);*/
		f->fmt.pix_mp.plane_fmt[0].sizeimage = f->fmt.pix_mp.width * f->fmt.pix_mp.height * 3 / 2;
		break;
	default:
		BUG();
	}

	rtk_fill_colorspace(&f->fmt.pix_mp, f->fmt.pix_mp.pixelformat);

	rtk_jcodec_dbg(2, ctx, "(%s) try format: \n", v4l2_type_names[f->type]);
	rtk_jcodec_dbg(2, ctx, "     pixelformat  : %4.4s, field : %d\n",
		       (char *)&f->fmt.pix_mp.pixelformat, f->fmt.pix_mp.field);
	rtk_jcodec_dbg(2, ctx, "     widthxheight : (%dx%d)\n",
		       f->fmt.pix_mp.width, f->fmt.pix_mp.height);
	rtk_jcodec_dbg(2, ctx, "     bytesperline : %d\n",
		       f->fmt.pix_mp.plane_fmt[0].bytesperline);
	rtk_jcodec_dbg(2, ctx, "     sizeimage    : %d\n",
		       f->fmt.pix_mp.plane_fmt[0].sizeimage);

	return 0;
}

static int rtk_jcodec_try_fmt_vid_cap(struct file *file, void *priv,
				      struct v4l2_format *f)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(priv);
	const struct rtk_q_data *q_data_src;
	const struct rtk_codec *codec;
	struct vb2_queue *src_vq;
	int hscale = 0;
	int vscale = 0;
	int ret;

	rtk_jcodec_dbg(2, ctx, "%s %d.%s.type:%s.4cc:%4.4s.w:%d.h:%d."
		"bytesperline:%d.sizeimage:%d.colorspace:%d\n",
		RTK_JCODEC_NAME, __LINE__, __func__, v4l2_type_names[f->type],
		(char *)&f->fmt.pix_mp.pixelformat, f->fmt.pix_mp.width,
		f->fmt.pix_mp.height, f->fmt.pix_mp.plane_fmt[0].bytesperline,
		f->fmt.pix_mp.plane_fmt[0].sizeimage, f->fmt.pix_mp.colorspace);

	ret = rtk_try_pixelformat(ctx, f);
	if (ret < 0) {
		v4l2_err(&ctx->dev->v4l2_dev,
			 "failed to rtk_try_pixelformat\n");
		return ret;
	}

	q_data_src = get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);

	/*
	 * If the source format is already fixed, only allow the same output
	 * resolution. When decoding JPEG images, we also have to make sure to
	 * use the same chroma subsampling.
	 */
	src_vq = v4l2_m2m_get_vq(ctx->fh.m2m_ctx,
				 V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
	if (vb2_is_streaming(src_vq)) {
		f->fmt.pix_mp.width = q_data_src->width >> hscale;
		f->fmt.pix_mp.height = q_data_src->height >> vscale;

		if (q_data_src->fourcc == V4L2_PIX_FMT_JPEG) {
			if (ctx->params.jpeg_chroma_subsampling ==
				    V4L2_JPEG_CHROMA_SUBSAMPLING_420 &&
			    f->fmt.pix_mp.pixelformat == V4L2_PIX_FMT_YUV422P) {
				f->fmt.pix_mp.pixelformat = V4L2_PIX_FMT_NV12;
			} else if (ctx->params.jpeg_chroma_subsampling ==
				   V4L2_JPEG_CHROMA_SUBSAMPLING_422) {
				f->fmt.pix_mp.pixelformat = V4L2_PIX_FMT_NV16;
			} else if (ctx->params.jpeg_chroma_subsampling ==
				   V4L2_JPEG_CHROMA_SUBSAMPLING_444) {
				f->fmt.pix_mp.pixelformat = V4L2_PIX_FMT_NV24;
			}
		}
	}

	f->fmt.pix_mp.num_planes = 1;

	q_data_src = rtk_get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
	codec = rtk_jcodec_find_codec(ctx->dev, q_data_src->fourcc,
				      f->fmt.pix_mp.pixelformat);

	if (!codec) {
		rtk_jcodec_dbg(2, ctx, "failed to rtk_jcodec_find_codec\n");
		return -EINVAL;
	}

	return rtk_try_fmt(ctx, codec, f);
}

static int rtk_s_fmt(struct rtk_jcodec_ctx *ctx, struct v4l2_format *f,
		     struct v4l2_rect *r)
{
	struct rtk_q_data *q_data;
	struct vb2_queue *vq;

	vq = v4l2_m2m_get_vq(ctx->fh.m2m_ctx, f->type);
	if (!vq)
		return -EINVAL;

	q_data = rtk_get_q_data(ctx, f->type);
	if (!q_data)
		return -EINVAL;

	if (vb2_is_busy(vq)) {
		v4l2_err(&ctx->dev->v4l2_dev, "%s: %s queue busy: %d\n",
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 8, 0)
			 __func__, v4l2_type_names[f->type], vb2_get_num_buffers(vq));
#else
			 __func__, v4l2_type_names[f->type], vq->num_buffers);
#endif
		return -EBUSY;
	}

	q_data->fourcc = f->fmt.pix_mp.pixelformat;
	q_data->ori_width = f->fmt.pix_mp.width;
	q_data->ori_height = f->fmt.pix_mp.height;
	q_data->width = f->fmt.pix_mp.width;
	q_data->height = f->fmt.pix_mp.height;
	q_data->bytesperline = f->fmt.pix_mp.plane_fmt[0].bytesperline;
	q_data->sizeimage = f->fmt.pix_mp.plane_fmt[0].sizeimage;

	if (r) {
		q_data->rect = *r;
	} else {
		q_data->rect.left = 0;
		q_data->rect.top = 0;
		q_data->rect.width = f->fmt.pix_mp.width;
		q_data->rect.height = f->fmt.pix_mp.height;
	}

	switch (f->fmt.pix_mp.pixelformat) {
	case V4L2_PIX_FMT_YUYV:
		ctx->tiled_map_type = RTK_TILED_FRAME_MB_RASTER_MAP;
		break;
	case V4L2_PIX_FMT_NV12:
		// TODO: coda upstream
		// TODO: ray modify
		// if (!disable_tiling && ctx->use_bit &&
		//     ctx->dev->devinfo->product == CODA_J10) {
		// 	ctx->tiled_map_type = RTK_TILED_FRAME_MB_RASTER_MAP;
		// 	break;
		// }
		fallthrough;
	case V4L2_PIX_FMT_YUV420:
	case V4L2_PIX_FMT_YVU420:
	case V4L2_PIX_FMT_YUV422P:
	case V4L2_PIX_FMT_NV16:
	case V4L2_PIX_FMT_YUV444M:
	case V4L2_PIX_FMT_NV24:
	case V4L2_PIX_FMT_RGB24:
	case V4L2_PIX_FMT_GREY:
		ctx->tiled_map_type = RTK_LINEAR_FRAME_MAP;
		break;
	default:
		break;
	}

	ctx->use_vdoa = false;

	rtk_jcodec_dbg(2, ctx, "(%s) set format: \n", v4l2_type_names[f->type]);
	rtk_jcodec_dbg(2, ctx, "     pixelformat  : %4.4s, field : %d\n",
		       (char *)&f->fmt.pix_mp.pixelformat, f->fmt.pix_mp.field);
	rtk_jcodec_dbg(2, ctx, "     widthxheight : (%dx%d)\n",
		       f->fmt.pix_mp.width, f->fmt.pix_mp.height);
	rtk_jcodec_dbg(2, ctx, "     bytesperline : %d\n",
		       f->fmt.pix_mp.plane_fmt[0].bytesperline);
	rtk_jcodec_dbg(2, ctx, "     sizeimage    : %d\n",
		       f->fmt.pix_mp.plane_fmt[0].sizeimage);

	rtk_jcodec_dbg(2, ctx, "(%s) set qdata: \n", v4l2_type_names[f->type]);
	rtk_jcodec_dbg(2, ctx, "     fourcc       : %4.4s\n",
		       (char *)&q_data->fourcc);
	rtk_jcodec_dbg(2, ctx, "     widthxheight : (%dx%d)\n", q_data->width,
		       q_data->height);
	rtk_jcodec_dbg(2, ctx, "     bytesperline : %d\n",
		       q_data->bytesperline);
	rtk_jcodec_dbg(2, ctx, "     sizeimage    : %d\n", q_data->sizeimage);
	rtk_jcodec_dbg(2, ctx, "     rect leftxtop     : (%dx%d)\n",
		       q_data->rect.left, q_data->rect.top);
	rtk_jcodec_dbg(2, ctx, "     rect widthxheight : (%dx%d)\n",
		       q_data->rect.width, q_data->rect.height);
	rtk_jcodec_dbg(2, ctx, "     ori  widthxheight : (%dx%d)\n",
		       q_data->ori_width, q_data->ori_height);

	rtk_jcodec_dbg(1, ctx,
		       "Setting %s format, wxh: %dx%d, fmt: %4.4s"
		       " sizeimage : %d %c\n",
		       v4l2_type_names[f->type], q_data->width, q_data->height,
		       (char *)&q_data->fourcc, q_data->sizeimage,
		       (ctx->tiled_map_type == RTK_LINEAR_FRAME_MAP) ? 'L' :
								       'T');

	return 0;
}

static int rtk_jcodec_s_fmt_vid_cap(struct file *file, void *priv,
				    struct v4l2_format *f)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(priv);
	struct rtk_q_data *q_data_src;
	const struct rtk_codec *codec;
	struct v4l2_rect r;
	int ret;

	pr_info("%s %d.%s.type:%s.4cc:%4.4s.w:%d.h:%d."
		"bytesperline:%d.sizeimage:%d.colorspace:%d\n",
		RTK_JCODEC_NAME, __LINE__, __func__, v4l2_type_names[f->type],
		(char *)&f->fmt.pix_mp.pixelformat, f->fmt.pix_mp.width,
		f->fmt.pix_mp.height, f->fmt.pix_mp.plane_fmt[0].bytesperline,
		f->fmt.pix_mp.plane_fmt[0].sizeimage, f->fmt.pix_mp.colorspace);

	ret = rtk_jcodec_try_fmt_vid_cap(file, priv, f);
	if (ret) {
		v4l2_err(&ctx->dev->v4l2_dev,
			 "failed to rtk_jcodec_try_fmt_vid_cap\n");
		return ret;
	}

	q_data_src = rtk_get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
	r.left = 0;
	r.top = 0;
	r.width = q_data_src->width;
	r.height = q_data_src->height;

	ret = rtk_s_fmt(ctx, f, &r);
	if (ret) {
		v4l2_err(&ctx->dev->v4l2_dev, "failed to rtk_s_fmt\n");
		return ret;
	}

	if (ctx->inst_type != RTK_JCODEC_CTX_ENCODER)
		return 0;

	/* Setting the coded format determines the selected codec */
	codec = rtk_jcodec_find_codec(ctx->dev, q_data_src->fourcc,
				      f->fmt.pix_mp.pixelformat);
	if (!codec) {
		rtk_jcodec_dbg(2, ctx, "%d.%s.failed to determine codec\n",
			       __LINE__, __func__);
		return -EINVAL;
	}
	ctx->codec = codec;

	ctx->colorspace = f->fmt.pix_mp.colorspace;
	ctx->xfer_func = f->fmt.pix_mp.xfer_func;
	ctx->ycbcr_enc = f->fmt.pix_mp.ycbcr_enc;
	ctx->quantization = f->fmt.pix_mp.quantization;

	return 0;
}

static int rtk_jcodec_try_fmt_vid_out(struct file *file, void *priv,
				      struct v4l2_format *f)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(priv);
	struct rtk_jcodec_dev *dev = ctx->dev;
	const struct rtk_q_data *q_data_dst;
	const struct rtk_codec *codec;
	int ret;

	rtk_jcodec_dbg(2, ctx, "%s %d.%s.type:%s.4cc:%4.4s.w:%d.h:%d."
		"bytesperline:%d.sizeimage:%d.colorspace:%d\n",
		RTK_JCODEC_NAME, __LINE__, __func__, v4l2_type_names[f->type],
		(char *)&f->fmt.pix_mp.pixelformat, f->fmt.pix_mp.width,
		f->fmt.pix_mp.height, f->fmt.pix_mp.plane_fmt[0].bytesperline,
		f->fmt.pix_mp.plane_fmt[0].sizeimage, f->fmt.pix_mp.colorspace);

	ret = rtk_try_pixelformat(ctx, f);
	if (ret < 0) {
		v4l2_err(&ctx->dev->v4l2_dev,
			 "failed to rtk_try_pixelformat\n");
		return ret;
	}

	f->fmt.pix_mp.num_planes = 1;

	q_data_dst = rtk_get_q_data(ctx, V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);
	codec = rtk_jcodec_find_codec(dev, f->fmt.pix_mp.pixelformat,
				      q_data_dst->fourcc);

	return rtk_try_fmt(ctx, codec, f);
}

static int rtk_jcodec_s_fmt_vid_out(struct file *file, void *priv,
				    struct v4l2_format *f)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(priv);
	const struct rtk_codec *codec;
	struct v4l2_format f_cap;
	struct vb2_queue *dst_vq;
	int ret;

	rtk_jcodec_dbg(2, ctx, "%s %d.%s.type:%s.4cc:%4.4s.w:%d.h:%d."
		"bytesperline:%d.sizeimage:%d.colorspace:%d\n",
		RTK_JCODEC_NAME, __LINE__, __func__, v4l2_type_names[f->type],
		(char *)&f->fmt.pix_mp.pixelformat, f->fmt.pix_mp.width,
		f->fmt.pix_mp.height, f->fmt.pix_mp.plane_fmt[0].bytesperline,
		f->fmt.pix_mp.plane_fmt[0].sizeimage, f->fmt.pix_mp.colorspace);

	ret = rtk_jcodec_try_fmt_vid_out(file, priv, f);
	if (ret) {
		v4l2_err(&ctx->dev->v4l2_dev,
			 "failed to rtk_jcodec_try_fmt_vid_out\n");
		return ret;
	}

	ret = rtk_s_fmt(ctx, f, NULL);
	if (ret) {
		v4l2_err(&ctx->dev->v4l2_dev, "failed to rtk_s_fmt\n");
		return ret;
	}

	ctx->colorspace = f->fmt.pix_mp.colorspace;
	ctx->xfer_func = f->fmt.pix_mp.xfer_func;
	ctx->ycbcr_enc = f->fmt.pix_mp.ycbcr_enc;
	ctx->quantization = f->fmt.pix_mp.quantization;

	// return 0;
	// TODO: refine later
	if (ctx->inst_type != RTK_JCODEC_CTX_DECODER)
		return 0;

	/* Setting the coded format determines the selected codec */
	codec = rtk_jcodec_find_codec(ctx->dev, f->fmt.pix_mp.pixelformat,
				      V4L2_PIX_FMT_NV12);
	if (!codec) {
		rtk_jcodec_dbg(2, ctx, "%d.%s.failed to determine codec\n",
			       __LINE__, __func__);
		return -EINVAL;
	}
	ctx->codec = codec;

	dst_vq = v4l2_m2m_get_vq(ctx->fh.m2m_ctx,
				 V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);
	if (!dst_vq)
		return -EINVAL;

	if (vb2_is_busy(dst_vq))
		return 0;

	memset(&f_cap, 0, sizeof(f_cap));
	f_cap.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	rtk_jcodec_g_fmt(file, priv, &f_cap);
	f_cap.fmt.pix_mp.width = f->fmt.pix_mp.width;
	f_cap.fmt.pix_mp.height = f->fmt.pix_mp.height;

	return rtk_jcodec_s_fmt_vid_cap(file, priv, &f_cap);
}

static int rtk_jcodec_reqbufs(struct file *file, void *priv,
			      struct v4l2_requestbuffers *rb)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(priv);
	int ret;

	ret = v4l2_m2m_reqbufs(file, ctx->fh.m2m_ctx, rb);
	if (ret)
		return ret;

	rtk_jcodec_dbg(2, ctx, "%d.%s.(%s) req %d bufs\n", __LINE__, __func__,
		       v4l2_type_names[rb->type], rb->count);

	/*
	 * Allow to allocate instance specific per-context buffers, such as
	 * bitstream ringbuffer, slice buffer, work buffer, etc. if needed.
	 */

	if (ctx->ops->reqbufs) {
		return ctx->ops->reqbufs(ctx, rb);
	}

	return 0;
}

static int rtk_jcodec_qbuf(struct file *file, void *priv,
			   struct v4l2_buffer *buf)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(priv);
	if (ctx->inst_type == RTK_JCODEC_CTX_DECODER &&
	    V4L2_TYPE_IS_OUTPUT(buf->type)) {
		buf->flags &= ~V4L2_BUF_FLAG_LAST;
	}

	rtk_jcodec_dbg(2, ctx, "%d.%s.(%s) queue buf %d\n", __LINE__, __func__,
		       v4l2_type_names[buf->type], buf->index);

	return v4l2_m2m_qbuf(file, ctx->fh.m2m_ctx, buf);
}

static int rtk_jcodec_dqbuf(struct file *file, void *priv,
			    struct v4l2_buffer *buf)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(priv);
	int ret;
	// static int fake_buf_last = 0;

	ret = v4l2_m2m_dqbuf(file, ctx->fh.m2m_ctx, buf);

	if (ctx->inst_type == RTK_JCODEC_CTX_DECODER &&
	    V4L2_TYPE_IS_OUTPUT(buf->type)) {
		buf->flags &= ~V4L2_BUF_FLAG_LAST;
	}

	rtk_jcodec_dbg(2, ctx, "(%s) dequeue buf %d%s\n",
		       v4l2_type_names[buf->type], buf->index,
		       (buf->flags & V4L2_BUF_FLAG_LAST) ? " (last)" : "");

	return ret;
}

static int rtk_jcodec_g_selection(struct file *file, void *fh,
				  struct v4l2_selection *s)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(fh);
	struct rtk_q_data *q_data;
	struct v4l2_rect r, *rsel;

	if (s->type != V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE &&
	    s->type != V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE &&
	    s->type != V4L2_BUF_TYPE_VIDEO_CAPTURE &&
	    s->type != V4L2_BUF_TYPE_VIDEO_OUTPUT)
		return -EINVAL;

	q_data = rtk_get_q_data(ctx, s->type);
	if (!q_data)
		return -EINVAL;

	r.left = 0;
	r.top = 0;
	r.width = q_data->width;
	r.height = q_data->height;
	rsel = &q_data->rect;

	rtk_jcodec_dbg(2, ctx, "rect x-y(%dx%d), rect w-h(%dx%d)\n", r.left,
		       r.top, r.width, r.height);

	rtk_jcodec_dbg(2, ctx, "rsel x-y(%dx%d), rsel w-h(%dx%d)\n", rsel->left,
		       rsel->top, rsel->width, rsel->height);

	switch (s->target) {
	case V4L2_SEL_TGT_CROP_DEFAULT:
	case V4L2_SEL_TGT_CROP_BOUNDS:
		rsel = &r;
		fallthrough;
	case V4L2_SEL_TGT_CROP:
		if (!V4L2_TYPE_IS_OUTPUT(s->type) ||
		    ctx->inst_type == RTK_JCODEC_CTX_DECODER) {
			return -EINVAL;
		}
		break;
	case V4L2_SEL_TGT_COMPOSE_BOUNDS:
	case V4L2_SEL_TGT_COMPOSE_PADDED:
		rsel = &r;
		fallthrough;
	case V4L2_SEL_TGT_COMPOSE:
	case V4L2_SEL_TGT_COMPOSE_DEFAULT:
		if (!V4L2_TYPE_IS_CAPTURE(s->type) ||
		    ctx->inst_type == RTK_JCODEC_CTX_ENCODER) {
			return -EINVAL;
		}
		break;
	default:
		return -EINVAL;
	}

	s->r = *rsel;

	return 0;
}

static int rtk_jcodec_s_selection(struct file *file, void *fh,
				  struct v4l2_selection *s)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(fh);
	struct rtk_q_data *q_data;

	if (s->type != V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE &&
	    s->type != V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE &&
	    s->type != V4L2_BUF_TYPE_VIDEO_CAPTURE &&
	    s->type != V4L2_BUF_TYPE_VIDEO_OUTPUT)
		return -EINVAL;

	switch (s->target) {
	case V4L2_SEL_TGT_CROP:
		if (ctx->inst_type == RTK_JCODEC_CTX_ENCODER &&
		    V4L2_TYPE_IS_OUTPUT(s->type)) {
			q_data = get_q_data(ctx, s->type);
			if (!q_data)
				return -EINVAL;

			s->r.left = 0;
			s->r.top = 0;
			s->r.width = clamp(s->r.width, 2U, q_data->width);
			s->r.height = clamp(s->r.height, 2U, q_data->height);

			if (s->flags & V4L2_SEL_FLAG_LE) {
				s->r.width = round_up(s->r.width, 2);
				s->r.height = round_up(s->r.height, 2);
			} else {
				s->r.width = round_down(s->r.width, 2);
				s->r.height = round_down(s->r.height, 2);
			}

			q_data->rect = s->r;

			rtk_jcodec_dbg(1, ctx,
				       "Setting crop rectangle: %dx%d\n",
				       s->r.width, s->r.height);

			return 0;
		}
		fallthrough;
	case V4L2_SEL_TGT_NATIVE_SIZE:
	case V4L2_SEL_TGT_COMPOSE:
		return rtk_jcodec_g_selection(file, fh, s);
	default:
		/* v4l2-compliance expects this to fail for read-only targets */
		return -EINVAL;
	}
}

static void rtk_jcodec_wake_up_capture_queue(struct rtk_jcodec_ctx *ctx)
{
	struct vb2_queue *dst_vq;

	rtk_jcodec_dbg(1, ctx, "waking up capture queue\n");

	dst_vq = v4l2_m2m_get_vq(ctx->fh.m2m_ctx,
				 V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);
	dst_vq->last_buffer_dequeued = true;
	wake_up(&dst_vq->done_wq);
}

static int rtk_jcodec_try_encoder_cmd(struct file *file, void *fh,
				      struct v4l2_encoder_cmd *dc)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(fh);

	if (ctx->inst_type != RTK_JCODEC_CTX_ENCODER)
		return -ENOTTY;

	return v4l2_m2m_ioctl_try_encoder_cmd(file, fh, dc);
}

static int rtk_jcodec_try_decoder_cmd(struct file *file, void *fh,
				      struct v4l2_decoder_cmd *dc)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(fh);

	if (ctx->inst_type != RTK_JCODEC_CTX_DECODER)
		return -ENOTTY;

	return v4l2_m2m_ioctl_try_decoder_cmd(file, fh, dc);
}

static bool rtk_jcodec_mark_last_meta(struct rtk_jcodec_ctx *ctx)
{
	struct rtk_meta_buffer *meta;

	spin_lock(&ctx->meta_buffer_lock);
	if (list_empty(&ctx->meta_buffer_list)) {
		spin_unlock(&ctx->meta_buffer_lock);
		rtk_jcodec_dbg(1, ctx, "meta buffer list empty\n");
		return false;
	}

	meta = list_last_entry(&ctx->meta_buffer_list, struct rtk_meta_buffer,
			       list);
	meta->last = true;

	rtk_jcodec_dbg(1, ctx, "marking last meta %d\n", meta->sequence);

	spin_unlock(&ctx->meta_buffer_lock);
	return true;
}

static bool rtk_jcodec_mark_last_dst_buf(struct rtk_jcodec_ctx *ctx)
{
	struct vb2_v4l2_buffer *buf;
	struct vb2_buffer *dst_vb;
	struct vb2_queue *dst_vq;
	unsigned long flags;

	rtk_jcodec_dbg(1, ctx, "marking last capture buffer\n");

	dst_vq = v4l2_m2m_get_vq(ctx->fh.m2m_ctx,
				 V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);
	spin_lock_irqsave(&dst_vq->done_lock, flags);
	if (list_empty(&dst_vq->done_list)) {
		spin_unlock_irqrestore(&dst_vq->done_lock, flags);
		rtk_jcodec_dbg(1, ctx, "capture buffer done list empty\n");
		return false;
	}

	dst_vb = list_last_entry(&dst_vq->done_list, struct vb2_buffer,
				 done_entry);
	buf = to_vb2_v4l2_buffer(dst_vb);
	buf->flags |= V4L2_BUF_FLAG_LAST;

	spin_unlock_irqrestore(&dst_vq->done_lock, flags);
	return true;
}

static void rtk_wake_up_capture_queue(struct rtk_jcodec_ctx *ctx)
{
	struct vb2_queue *dst_vq;

	rtk_jcodec_dbg(1, ctx, "waking up capture queue\n");

	dst_vq = v4l2_m2m_get_vq(ctx->fh.m2m_ctx,
				 V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);
	dst_vq->last_buffer_dequeued = true;
	wake_up(&dst_vq->done_wq);
}

static int rtk_jcodec_encoder_cmd(struct file *file, void *fh,
				  struct v4l2_encoder_cmd *ec)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(fh);
	struct vb2_v4l2_buffer *buf;
	int ret;

	ret = v4l2_m2m_ioctl_try_encoder_cmd(file, fh, ec);
	if (ret < 0)
		return ret;

	mutex_lock(&ctx->wakeup_mutex);
	buf = v4l2_m2m_last_src_buf(ctx->fh.m2m_ctx);
	if (buf) {
		/*
		 * If the last output buffer is still on the queue, make sure
		 * that decoder finish_run will see the last flag and report it
		 * to userspace.
		 */
		buf->flags |= V4L2_BUF_FLAG_LAST;
	} else {
		/* Set the stream-end flag on this context */
		ctx->bit_stream_param |= RTK_BIT_STREAM_END_FLAG;

		/*
		 * If the last output buffer has already been taken from the
		 * queue, wake up the capture queue and signal end of stream
		 * via the -EPIPE mechanism.
		 */
		rtk_wake_up_capture_queue(ctx);
	}
	mutex_unlock(&ctx->wakeup_mutex);

	return 0;
}

static int rtk_jcodec_decoder_cmd(struct file *file, void *fh,
				  struct v4l2_decoder_cmd *dc)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(fh);
	struct rtk_jcodec_dev *dev = ctx->dev;
	struct vb2_queue *dst_vq;
	struct vb2_v4l2_buffer *buf;
	//struct vb2_queue *dst_vq;
	bool stream_end;
	bool wakeup;
	int ret;

	rtk_jcodec_dbg(2, ctx, "decoder cmd 0x%x: \n", dc->cmd);

	ret = rtk_jcodec_try_decoder_cmd(file, fh, dc);
	if (ret < 0)
		return ret;

	switch (dc->cmd) {
	case V4L2_DEC_CMD_START:
		mutex_lock(&dev->rtk_mutex);
		mutex_lock(&ctx->bitstream_mutex);
		dst_vq = v4l2_m2m_get_vq(ctx->fh.m2m_ctx,
					 V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);
		vb2_clear_last_buffer_dequeued(dst_vq);
		ctx->bit_stream_param &= ~RTK_BIT_STREAM_END_FLAG;
		rtk_feed_bitstream(ctx, NULL);
		mutex_unlock(&ctx->bitstream_mutex);
		mutex_unlock(&dev->rtk_mutex);
		break;
	case V4L2_DEC_CMD_STOP:
		stream_end = false;
		wakeup = false;

		mutex_lock(&ctx->wakeup_mutex);

		buf = v4l2_m2m_last_src_buf(ctx->fh.m2m_ctx);
		if (buf) {
			rtk_jcodec_dbg(1, ctx,
				       "marking last pending buffer"
				       " %d\n",
				       buf->vb2_buf.index);

			/* Mark last buffer */
			buf->flags |= V4L2_BUF_FLAG_LAST;

			if (v4l2_m2m_num_src_bufs_ready(ctx->fh.m2m_ctx) == 0) {
				rtk_jcodec_dbg(1, ctx,
					       "all remaining"
					       " buffers queued\n");
				stream_end = true;
			}
		} else {
			if (ctx->use_bit) {
				if (rtk_jcodec_mark_last_meta(ctx)) {
					stream_end = true;
				} else {
					wakeup = true;
				}
			} else {
				if (!rtk_jcodec_mark_last_dst_buf(ctx)) {
					wakeup = true;
				}
			}
		}

		if (stream_end) {
			rtk_jcodec_dbg(1, ctx,
				       "all remaining buffers queued\n");
			/* Set the stream-end flag on this context */
			rtk_bitstream_end_flag(ctx);
			ctx->hold = false;
			v4l2_m2m_try_schedule(ctx->fh.m2m_ctx);
		}

		if (wakeup) {
			/* If there is no buffer in flight, wake up */
			rtk_jcodec_wake_up_capture_queue(ctx);
		}

		mutex_unlock(&ctx->wakeup_mutex);
		break;
	default:
		return -EINVAL;
	}

	return 0;
}

static int rtk_jcodec_enum_framesizes(struct file *file, void *fh,
				      struct v4l2_frmsizeenum *fsize)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(fh);
	struct rtk_q_data *q_data_src;
	struct rtk_q_data *q_data_dst;
	const struct rtk_codec *codec = NULL;

	if (fsize->index) {
		return -EINVAL;
	}

	if (ctx->cvd->type == RTK_JCODEC_CTX_DECODER) {
		pr_info("%d.%s.pixel_format:%p4cc\n", __LINE__, __func__,
			&(fsize->pixel_format));

		if (fsize->pixel_format != V4L2_PIX_FMT_JPEG) {
			q_data_src = rtk_get_q_data(
				ctx, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
			codec = rtk_jcodec_find_codec(ctx->dev,
						      q_data_src->fourcc,
						      fsize->pixel_format);
		} else {
			codec = rtk_jcodec_find_codec(ctx->dev,
						      fsize->pixel_format,
						      V4L2_PIX_FMT_NV12);
		}
	} else if (ctx->cvd->type == RTK_JCODEC_CTX_ENCODER) {
		pr_info("%d.%s.pixel_format:%p4cc\n", __LINE__, __func__,
			&(fsize->pixel_format));

		if (fsize->pixel_format != V4L2_PIX_FMT_JPEG) {
			q_data_dst = get_q_data(
				ctx, V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);
			codec = rtk_jcodec_find_codec(ctx->dev,
						      fsize->pixel_format,
						      q_data_dst->fourcc);

		} else {
			codec = rtk_jcodec_find_codec(ctx->dev,
						      V4L2_PIX_FMT_NV12,
						      fsize->pixel_format);
		}
	}

	if (!codec) {
		rtk_jcodec_dbg(2, ctx, "%d.%s.failed to determine codec\n",
			       __LINE__, __func__);
		return -ENOTTY;
	}

	fsize->type = V4L2_FRMSIZE_TYPE_CONTINUOUS;
	fsize->stepwise.min_width = MIN_WIDTH;
	fsize->stepwise.max_width = codec->max_w;
	fsize->stepwise.step_width = 1;
	fsize->stepwise.min_height = MIN_HEIGHT;
	fsize->stepwise.max_height = codec->max_h;
	fsize->stepwise.step_height = 1;

	rtk_jcodec_dbg(2, ctx, "enum framesizes: \n");
	rtk_jcodec_dbg(2, ctx, "min_width : %d, max_width : %d\n",
		       fsize->stepwise.min_width, fsize->stepwise.max_width);
	rtk_jcodec_dbg(2, ctx, "min_height : %d, max_height : %d\n",
		       fsize->stepwise.min_height, fsize->stepwise.max_height);
	rtk_jcodec_dbg(2, ctx, "step_width : %d, step_height : %d\n",
		       fsize->stepwise.step_width, fsize->stepwise.step_height);

	return 0;
}

static int rtk_jcodec_enum_frameintervals(struct file *file, void *fh,
					  struct v4l2_frmivalenum *f)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(fh);
	struct rtk_q_data *q_data_src;
	struct rtk_q_data *q_data_dst;
	const struct rtk_codec *codec = NULL;

	if (f->index)
		return -EINVAL;

	/* Disallow YUYV if the vdoa is not available */
	if (/*!ctx->vdoa && */ f->pixel_format == V4L2_PIX_FMT_YUYV)
		return -EINVAL;

	if (ctx->cvd->type == RTK_JCODEC_CTX_DECODER) {
		pr_info("%d.%s.pixel_format:%p4cc\n", __LINE__, __func__,
			&(f->pixel_format));

		if (f->pixel_format != V4L2_PIX_FMT_JPEG) {
			q_data_src = rtk_get_q_data(
				ctx, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
			codec = rtk_jcodec_find_codec(
				ctx->dev, q_data_src->fourcc, f->pixel_format);

		} else {
			codec = rtk_jcodec_find_codec(ctx->dev, f->pixel_format,
						      V4L2_PIX_FMT_NV12);
		}

	} else if (ctx->cvd->type == RTK_JCODEC_CTX_ENCODER) {
		pr_info("%d.%s.pixel_format:%p4cc\n", __LINE__, __func__,
			&(f->pixel_format));

		if (f->pixel_format != V4L2_PIX_FMT_JPEG) {
			q_data_dst = get_q_data(
				ctx, V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);
			codec = rtk_jcodec_find_codec(ctx->dev, f->pixel_format,
						      q_data_dst->fourcc);

		} else {
			codec = rtk_jcodec_find_codec(
				ctx->dev, V4L2_PIX_FMT_NV12, f->pixel_format);
		}
	}

	if (!codec) {
		rtk_jcodec_dbg(2, ctx, "%d.%s.failed to determine codec\n",
			       __LINE__, __func__);
		return -ENOTTY;
	}

	if (f->width < MIN_W || f->width > codec->max_w || f->height < MIN_H ||
	    f->height > codec->max_h)
		return -EINVAL;

	f->type = V4L2_FRMIVAL_TYPE_CONTINUOUS;
	f->stepwise.min.numerator = 1;
	f->stepwise.min.denominator = 65535;
	f->stepwise.max.numerator = 65536;
	f->stepwise.max.denominator = 1;
	f->stepwise.step.numerator = 1;
	f->stepwise.step.denominator = 1;

	return 0;
}

static int rtk_jcodec_subscribe_event(struct v4l2_fh *fh,
				      const struct v4l2_event_subscription *sub)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(fh);

	rtk_jcodec_dbg(2, ctx, "subscribe event (0x%x)\n", sub->type);

	switch (sub->type) {
	case V4L2_EVENT_EOS:
		return v4l2_event_subscribe(fh, sub, 0, NULL);
	case V4L2_EVENT_SOURCE_CHANGE:
		if (ctx->inst_type == RTK_JCODEC_CTX_DECODER)
			return v4l2_event_subscribe(fh, sub, 0, NULL);
		else
			return -EINVAL;
	default:
		return v4l2_ctrl_subscribe_event(fh, sub);
	}
}

// TODO: for debug
static int rtk_jcodec_expbuf(struct file *file, void *priv,
		      struct v4l2_exportbuffer *eb)
{
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(priv);
	int ret;

	rtk_jcodec_dbg(2, ctx, "(%s) export buf %d\n",
		       v4l2_type_names[eb->type], eb->index);

	ret = v4l2_m2m_ioctl_expbuf(file, priv, eb);

	return ret;
}

static const struct v4l2_ioctl_ops rtk_jcodec_ioctl_ops = {
	.vidioc_querycap = rtk_jcodec_querycap,

	.vidioc_enum_fmt_vid_cap = rtk_jcodec_enum_fmt,
	.vidioc_g_fmt_vid_cap_mplane = rtk_jcodec_g_fmt,
	.vidioc_try_fmt_vid_cap_mplane = rtk_jcodec_try_fmt_vid_cap,
	.vidioc_s_fmt_vid_cap_mplane = rtk_jcodec_s_fmt_vid_cap,

	.vidioc_enum_fmt_vid_out = rtk_jcodec_enum_fmt,
	.vidioc_g_fmt_vid_out_mplane = rtk_jcodec_g_fmt,
	.vidioc_try_fmt_vid_out_mplane = rtk_jcodec_try_fmt_vid_out,
	.vidioc_s_fmt_vid_out_mplane = rtk_jcodec_s_fmt_vid_out,

	.vidioc_reqbufs = rtk_jcodec_reqbufs,
	.vidioc_querybuf = v4l2_m2m_ioctl_querybuf,

	.vidioc_qbuf = rtk_jcodec_qbuf,
	.vidioc_expbuf = rtk_jcodec_expbuf,
	.vidioc_dqbuf = rtk_jcodec_dqbuf,
	.vidioc_create_bufs = v4l2_m2m_ioctl_create_bufs,
	.vidioc_prepare_buf = v4l2_m2m_ioctl_prepare_buf,

	.vidioc_streamon = v4l2_m2m_ioctl_streamon,
	.vidioc_streamoff = v4l2_m2m_ioctl_streamoff,

	.vidioc_g_selection = rtk_jcodec_g_selection,
	.vidioc_s_selection = rtk_jcodec_s_selection,

	.vidioc_try_encoder_cmd = rtk_jcodec_try_encoder_cmd,
	.vidioc_encoder_cmd = rtk_jcodec_encoder_cmd,
	.vidioc_try_decoder_cmd = rtk_jcodec_try_decoder_cmd,
	.vidioc_decoder_cmd = rtk_jcodec_decoder_cmd,

	//.vidioc_g_parm		= rtk_jcodec_g_parm,
	//.vidioc_s_parm		= rtk_jcodec_s_parm,

	.vidioc_enum_framesizes = rtk_jcodec_enum_framesizes,
	.vidioc_enum_frameintervals = rtk_jcodec_enum_frameintervals,

	.vidioc_subscribe_event = rtk_jcodec_subscribe_event,
	.vidioc_unsubscribe_event = v4l2_event_unsubscribe,
};

/*
 * RTK jcodec mem-to-mem operations.
 */

void rtk_jcodec_m2m_buf_done(struct rtk_jcodec_ctx *ctx,
			     struct vb2_v4l2_buffer *buf,
			     enum vb2_buffer_state state)
{
	const struct v4l2_event eos_event = { .type = V4L2_EVENT_EOS };

	if (buf->flags & V4L2_BUF_FLAG_LAST) {
		v4l2_event_queue_fh(&ctx->fh, &eos_event);
	}

	v4l2_m2m_buf_done(buf, state);
}

static void rtk_jcodec_device_run(void *m2m_priv)
{
	struct rtk_jcodec_ctx *ctx = m2m_priv;
	struct rtk_jcodec_dev *dev = ctx->dev;

	queue_work(dev->workqueue, &ctx->pic_run_work);
}

static void rtk_jcodec_pic_run_work(struct work_struct *work)
{
	struct rtk_jcodec_ctx *ctx =
		container_of(work, struct rtk_jcodec_ctx, pic_run_work);
	struct rtk_jcodec_dev *dev = ctx->dev;
	int ret;

	mutex_lock(&ctx->buffer_mutex);
	mutex_lock(&dev->rtk_mutex);

	ret = ctx->ops->prepare_run(ctx);
	if (ret < 0 && ctx->inst_type == RTK_JCODEC_CTX_DECODER) {
		printk(KERN_INFO
		       "[fn_name]:[\x1b[31m%s\033[0m], [line]: \x1b[33m%d\033[0m\n",
		       __func__, __LINE__);
#if 0
		mutex_unlock(&dev->rtk_mutex);
		mutex_unlock(&ctx->buffer_mutex);
		/* job_finish scheduled by prepare_decode */
		return;
#else
		goto exit;
#endif
	}

	if (!wait_for_completion_timeout(&ctx->completion,
					 msecs_to_jiffies(1000))) {
		if (ctx->use_bit) {
			dev_err(dev->dev, "RTK PIC_RUN timeout\n");

			ctx->hold = true;

			rtk_jcodec_hw_reset(dev);
		}

		if (ctx->ops->run_timeout)
			ctx->ops->run_timeout(ctx);
	} else {
		ctx->ops->finish_run(ctx);
	}

exit:
	if (ctx->parsing_hdr_err) {
		ctx->ops->finish_run(ctx);
		ctx->parsing_hdr_err = false;
	}

	mutex_unlock(&dev->rtk_mutex);
	mutex_unlock(&ctx->buffer_mutex);

	v4l2_m2m_job_finish(ctx->dev->m2m_dev, ctx->fh.m2m_ctx);
}

static int rtk_jcodec_job_ready(void *m2m_priv)
{
	struct rtk_jcodec_ctx *ctx = m2m_priv;
	int src_bufs = v4l2_m2m_num_src_bufs_ready(ctx->fh.m2m_ctx);

	/*
	 * For both 'P' and 'key' frame cases 1 picture
	 * and 1 frame are needed. In the decoder case,
	 * the compressed frame can be in the bitstream.
	 */
	if (!src_bufs && ctx->inst_type != RTK_JCODEC_CTX_DECODER) {
		rtk_jcodec_dbg(1, ctx,
			       "not ready: not enough vid-out buffers.\n");
		return 0;
	}

	if (!v4l2_m2m_num_dst_bufs_ready(ctx->fh.m2m_ctx)) {
		rtk_jcodec_dbg(1, ctx,
			       "not ready: not enough vid-cap buffers.\n");
		return 0;
	}

	if (ctx->inst_type == RTK_JCODEC_CTX_DECODER && ctx->use_bit) {
		bool stream_end =
			ctx->bit_stream_param & RTK_BIT_STREAM_END_FLAG;
		int num_metas = ctx->num_metas;
		struct rtk_meta_buffer *meta;
		unsigned int count;

		count = hweight32(ctx->frm_dis_flg);

		rtk_jcodec_dbg(2, ctx,
			       "stream_end : %d, ctx->hold : %d, count : %d\n",
			       stream_end, ctx->hold, count);

		// TODO: ray refine free fb timing
		if (/*ctx->use_vdoa && */ count >=
		    (ctx->num_frame_buffers /*- 1*/)) {
			rtk_jcodec_dbg(
				1, ctx,
				"not ready: all frame buffers in use: %d/%d (0x%x)",
				count, ctx->num_frame_buffers,
				ctx->frm_dis_flg);
			return 0;
		}

		if (ctx->hold && !src_bufs) {
			rtk_jcodec_dbg(
				1, ctx,
				"not ready: on hold for more buffers.\n");
			return 0;
		}

		if (!stream_end && (num_metas + src_bufs) < 2) {
			rtk_jcodec_dbg(1, ctx,
				       "not ready: need 2 buffers"
				       " available (queue:%d + bitstream:%d)\n",
				       num_metas, src_bufs);
			return 0;
		}

		meta = list_first_entry(&ctx->meta_buffer_list,
					struct rtk_meta_buffer, list);
		if (!rtk_bitstream_can_fetch_past(ctx, meta->end) &&
		    !stream_end) {
			rtk_jcodec_dbg(1, ctx,
				       "not ready: not enough bitstream data"
				       " to read past %u (%u)\n",
				       meta->end, ctx->bitstream_fifo.kfifo.in);
			return 0;
		}
	}

	if (ctx->aborting) {
		rtk_jcodec_dbg(1, ctx, "not ready: aborting\n");
		return 0;
	}

	rtk_jcodec_dbg(2, ctx, "job ready\n");

	return 1;
}

static void rtk_jcodec_job_abort(void *priv)
{
	struct rtk_jcodec_ctx *ctx = priv;

	ctx->aborting = 1;

	rtk_jcodec_dbg(1, ctx, "job abort\n");
}

static const struct v4l2_m2m_ops rtk_jcodec_m2m_ops = {
	.device_run = rtk_jcodec_device_run,
	.job_ready = rtk_jcodec_job_ready,
	.job_abort = rtk_jcodec_job_abort,
};

/**
 * RTK jcodec ctrls operations
 */

static int rtk_jcodec_s_ctrl(struct v4l2_ctrl *ctrl)
{
	const char *const *val_names = v4l2_ctrl_get_menu(ctrl->id);
	struct rtk_jcodec_ctx *ctx =
		container_of(ctrl->handler, struct rtk_jcodec_ctx, ctrls);

	if (val_names)
		rtk_jcodec_dbg(2, ctx,
			       "s_ctrl: id = 0x%x, name = \"%s\","
			       " val = %d (\"%s\")\n",
			       ctrl->id, ctrl->name, ctrl->val,
			       val_names[ctrl->val]);
	else
		rtk_jcodec_dbg(2, ctx,
			       "s_ctrl: id = 0x%x, name = \"%s\","
			       " val = %d\n",
			       ctrl->id, ctrl->name, ctrl->val);

	switch (ctrl->id) {
	case V4L2_CID_HFLIP:
		if (ctrl->val)
			ctx->params.rot_mode |= CODA_MIR_HOR;
		else
			ctx->params.rot_mode &= ~CODA_MIR_HOR;
		break;
	case V4L2_CID_VFLIP:
		if (ctrl->val)
			ctx->params.rot_mode |= CODA_MIR_VER;
		else
			ctx->params.rot_mode &= ~CODA_MIR_VER;
		break;
	case V4L2_CID_ROTATE:
		if (ctrl->val) {
			switch(ctrl->val / 90) {
				case 0:
					ctx->params.rot_mode |= RTK_ROT_0;
					break;
				case 1:
					ctx->params.rot_mode |= RTK_ROT_90;
					break;
				case 2:
					ctx->params.rot_mode |= RTK_ROT_180;
					break;
				case 3:
					ctx->params.rot_mode |= RTK_ROT_270;
					break;
			}
		}
		break;
	case V4L2_CID_HDSF:
		if (ctrl->val)
			ctx->params.horizontal_factor = ctrl->val;
		else
			ctx->params.horizontal_factor = 0;
		break;
	case V4L2_CID_VDSF:
		if (ctrl->val)
			ctx->params.vertical_factor = ctrl->val;
		else
			ctx->params.vertical_factor = 0;
		break;
	case V4L2_CID_MPEG_VIDEO_BITRATE:
		ctx->params.bitrate = ctrl->val / 1000;
		ctx->params.bitrate_changed = true;
		break;
	case V4L2_CID_MPEG_VIDEO_GOP_SIZE:
		ctx->params.gop_size = ctrl->val;
		break;
	case V4L2_CID_MPEG_VIDEO_H264_LOOP_FILTER_ALPHA:
		ctx->params.h264_slice_alpha_c0_offset_div2 = ctrl->val;
		break;
	case V4L2_CID_MPEG_VIDEO_H264_LOOP_FILTER_BETA:
		ctx->params.h264_slice_beta_offset_div2 = ctrl->val;
		break;
	case V4L2_CID_MPEG_VIDEO_H264_LOOP_FILTER_MODE:
		ctx->params.h264_disable_deblocking_filter_idc = ctrl->val;
		break;
	case V4L2_CID_MPEG_VIDEO_H264_CONSTRAINED_INTRA_PREDICTION:
		ctx->params.h264_constrained_intra_pred_flag = ctrl->val;
		break;
	case V4L2_CID_MPEG_VIDEO_FRAME_RC_ENABLE:
		ctx->params.frame_rc_enable = ctrl->val;
		break;
	case V4L2_CID_MPEG_VIDEO_MB_RC_ENABLE:
		ctx->params.mb_rc_enable = ctrl->val;
		break;
	case V4L2_CID_MPEG_VIDEO_H264_CHROMA_QP_INDEX_OFFSET:
		ctx->params.h264_chroma_qp_index_offset = ctrl->val;
		break;
	case V4L2_CID_MPEG_VIDEO_H264_PROFILE:
		/* TODO: switch between baseline and constrained baseline */
		if (ctx->inst_type == RTK_JCODEC_CTX_ENCODER)
			ctx->params.h264_profile_idc = 66;
		break;
	case V4L2_CID_MPEG_VIDEO_H264_LEVEL:
		/* nothing to do, this is set by the encoder */
		break;
	case V4L2_CID_MPEG_VIDEO_MPEG4_I_FRAME_QP:
		ctx->params.mpeg4_intra_qp = ctrl->val;
		break;
	case V4L2_CID_MPEG_VIDEO_MPEG4_P_FRAME_QP:
		ctx->params.mpeg4_inter_qp = ctrl->val;
		break;
	case V4L2_CID_MPEG_VIDEO_MPEG2_PROFILE:
	case V4L2_CID_MPEG_VIDEO_MPEG2_LEVEL:
	case V4L2_CID_MPEG_VIDEO_MPEG4_PROFILE:
	case V4L2_CID_MPEG_VIDEO_MPEG4_LEVEL:
		/* nothing to do, these are fixed */
		break;
	case V4L2_CID_MPEG_VIDEO_MULTI_SLICE_MODE:
		ctx->params.slice_mode = ctrl->val;
		ctx->params.slice_mode_changed = true;
		break;
	case V4L2_CID_MPEG_VIDEO_MULTI_SLICE_MAX_MB:
		ctx->params.slice_max_mb = ctrl->val;
		ctx->params.slice_mode_changed = true;
		break;
	case V4L2_CID_MPEG_VIDEO_MULTI_SLICE_MAX_BYTES:
		ctx->params.slice_max_bits = ctrl->val * 8;
		ctx->params.slice_mode_changed = true;
		break;
	case V4L2_CID_MPEG_VIDEO_HEADER_MODE:
		break;
	case V4L2_CID_MPEG_VIDEO_CYCLIC_INTRA_REFRESH_MB:
		ctx->params.intra_refresh = ctrl->val;
		ctx->params.intra_refresh_changed = true;
		break;
	case V4L2_CID_MPEG_VIDEO_FORCE_KEY_FRAME:
		ctx->params.force_ipicture = true;
		break;
	case V4L2_CID_JPEG_COMPRESSION_QUALITY:
		rtk_set_jpeg_compression_quality(ctx, ctrl->val, 0);
		break;
	case V4L2_CID_JPEG_RESTART_INTERVAL:
		ctx->params.jpeg_restart_interval = ctrl->val;
		break;
	case V4L2_CID_MPEG_VIDEO_VBV_DELAY:
		ctx->params.vbv_delay = ctrl->val;
		break;
	case V4L2_CID_MPEG_VIDEO_VBV_SIZE:
		ctx->params.vbv_size = min(ctrl->val * 8192, 0x7fffffff);
		break;
	default:
		rtk_jcodec_dbg(1, ctx, "Invalid control, id=%d, val=%d\n",
			       ctrl->id, ctrl->val);
		return -EINVAL;
	}

	return 0;
}

static int rtk_jcodec_g_v_ctrl(struct v4l2_ctrl *ctrl)
{
	const char *const *val_names = v4l2_ctrl_get_menu(ctrl->id);
	struct rtk_jcodec_ctx *ctx =
		container_of(ctrl->handler, struct rtk_jcodec_ctx, ctrls);
	int ret = 0;

	if (val_names)
		rtk_jcodec_dbg(2, ctx,
			       "%d.%s.s_ctrl: id = 0x%x, name = \"%s\","
			       "val = %d (\"%s\")\n",
			       __LINE__, __func__, ctrl->id, ctrl->name,
			       ctrl->val, val_names[ctrl->val]);
	else
		rtk_jcodec_dbg(2, ctx,
			       "%d.%s.s_ctrl: id = 0x%x, name = \"%s\","
			       " val = %d\n",
			       __LINE__, __func__, ctrl->id, ctrl->name,
			       ctrl->val);

	switch (ctrl->id) {
	case V4L2_CID_MIN_BUFFERS_FOR_CAPTURE:
		ctrl->val = 2;
		break;
	default:
		ret = -EINVAL;
	}
	return ret;
}

static const struct v4l2_ctrl_ops rtk_jcodec_ctrl_ops = {
	.s_ctrl = rtk_jcodec_s_ctrl,
	.g_volatile_ctrl = rtk_jcodec_g_v_ctrl,
};

static void rtk_jcodec_encode_ctrls(struct rtk_jcodec_ctx *ctx)
{
	/* TODO: ....? */

	v4l2_ctrl_new_std(&ctx->ctrls, &rtk_jcodec_ctrl_ops,
			  V4L2_CID_JPEG_COMPRESSION_QUALITY, 5, 100, 1, 50);
	v4l2_ctrl_new_std(&ctx->ctrls, &rtk_jcodec_ctrl_ops,
			  V4L2_CID_JPEG_RESTART_INTERVAL, 0, 100, 1, 0);
	//return;
}

static const struct v4l2_ctrl_config rtk_jcodec_ctrl_horizontal_downsample_factor = {
	.ops = &rtk_jcodec_ctrl_ops,
	.id = V4L2_CID_HDSF,
	.name = "Horizontal Downsampling Factor",
	.type = V4L2_CTRL_TYPE_INTEGER,
	.def = 0,
	.min = 0,
	.max = 3,
	.step = 1,
};

static const struct v4l2_ctrl_config rtk_jcodec_ctrl_vertical_downsample_factor = {
	.ops = &rtk_jcodec_ctrl_ops,
	.id = V4L2_CID_VDSF,
	.name = "Vertical Downsampling Factor",
	.type = V4L2_CTRL_TYPE_INTEGER,
	.def = 0,
	.min = 0,
	.max = 3,
	.step = 1,
};

static int rtk_jcodec_ctrls_setup(struct rtk_jcodec_ctx *ctx)
{
	struct v4l2_ctrl *ctrl;

	v4l2_ctrl_handler_init(&ctx->ctrls, 9);

	v4l2_ctrl_new_std(&ctx->ctrls, &rtk_jcodec_ctrl_ops, V4L2_CID_HFLIP, 0,
			  1, 1, 0);
	v4l2_ctrl_new_std(&ctx->ctrls, &rtk_jcodec_ctrl_ops, V4L2_CID_VFLIP, 0,
			  1, 1, 0);
	v4l2_ctrl_new_std(&ctx->ctrls, &rtk_jcodec_ctrl_ops, V4L2_CID_ROTATE, 0,
				270, 90, 0);
	if (ctx->inst_type == RTK_JCODEC_CTX_ENCODER) {
		if (ctx->cvd->dst_formats[0] == V4L2_PIX_FMT_JPEG)
			rtk_jcodec_encode_ctrls(ctx);
		// else
		// 	rtk_vcodec_encode_ctrls(ctx);
	} else {
		ctrl = v4l2_ctrl_new_std(&ctx->ctrls, &rtk_jcodec_ctrl_ops,
					 V4L2_CID_MIN_BUFFERS_FOR_CAPTURE,
					 RTK_MIN_FRAME_BUFFERS,
					 RTK_MAX_FRAME_BUFFERS, 1, 1);
		ctrl->flags |= V4L2_CTRL_FLAG_VOLATILE;

		// TODO: refine later
		// ctx->mb_err_cnt_ctrl = v4l2_ctrl_new_custom(&ctx->ctrls,
		// 				&coda_mb_err_cnt_ctrl_config,
		// 				NULL);
		// if (ctx->mb_err_cnt_ctrl)
		// 	ctx->mb_err_cnt_ctrl->flags |= V4L2_CTRL_FLAG_READ_ONLY;
		v4l2_ctrl_new_custom(&ctx->ctrls, &rtk_jcodec_ctrl_horizontal_downsample_factor, NULL);
		v4l2_ctrl_new_custom(&ctx->ctrls, &rtk_jcodec_ctrl_vertical_downsample_factor, NULL);
	}

	if (ctx->ctrls.error) {
		v4l2_err(&ctx->dev->v4l2_dev,
			 "control initialization error (%d)", ctx->ctrls.error);
		return -EINVAL;
	}

	return v4l2_ctrl_handler_setup(&ctx->ctrls);
}

/*
 * RTK jcodec file operations
 */

static int rtk_jcodec_open(struct file *file)
{
	struct video_device *vdev = video_devdata(file);
	struct rtk_jcodec_dev *dev = video_get_drvdata(vdev);
	struct rtk_jcodec_ctx *ctx;
	unsigned int max = ~0;
	char *name;
	int ret;
	int idx;
	unsigned int val;

	ctx = kzalloc(sizeof(*ctx), GFP_KERNEL);
	if (!ctx) {
		pr_err("%s %d.%s.return -ENOMEM\n", RTK_JCODEC_NAME, __LINE__,
		       __func__);
		return -ENOMEM;
	}

	idx = ida_alloc_max(&dev->ida, max, GFP_KERNEL);
	if (idx < 0) {
		ret = idx;
		pr_err("%s %d.%s.idx:%d.goto err_rtk_max\n", RTK_JCODEC_NAME,
		       __LINE__, __func__, idx);
		goto err_rtk_max;
	}

	name = kasprintf(GFP_KERNEL, "context%d", idx);
	if (!name) {
		ret = -ENOMEM;
		pr_err("%s %d.%s.-ENOMEM.goto err_rtk_name_init\n",
		       RTK_JCODEC_NAME, __LINE__, __func__);
		goto err_rtk_name_init;
	}
	rtk_jcodec_dbg(2, ctx, "%s %d.%s.idx:%d.name:%s\n", RTK_JCODEC_NAME, __LINE__, __func__,
		idx, name);

	ctx->debugfs_entry = debugfs_create_dir(name, dev->debugfs_root);
	kfree(name);

	ctx->cvd = to_rtk_video_device(vdev);
	ctx->inst_type = ctx->cvd->type;
	ctx->ops = ctx->cvd->ops;
	ctx->use_bit = !ctx->cvd->direct;
	init_completion(&ctx->completion);
	INIT_WORK(&ctx->pic_run_work, rtk_jcodec_pic_run_work);

	v4l2_fh_init(&ctx->fh, video_devdata(file));
	file->private_data = &ctx->fh;
	v4l2_fh_add(&ctx->fh);
	ctx->dev = dev;
	ctx->idx = idx;

	rtk_jcodec_dbg(1, ctx, "\x1b[33mopen instance (%p) (%s)\033[0m\n", ctx,
		       ctx->cvd->name);

	switch (dev->devinfo->product) {
	case CODA_J10:
		/*
		 * Enabling the BWB when decoding can hang the firmware with
		 * certain streams. The issue was tracked as ENGR00293425 by
		 * Freescale. As a workaround, disable BWB for all decoders.
		 * The enable_bwb module parameter allows to override this.
		 */
		// TODO: refine later
		// if (enable_bwb || ctx->inst_type == RTK_VCODEC_CTX_ENCODER)
		// 	ctx->frame_mem_ctrl = CODA9_FRAME_ENABLE_BWB;
		// fallthrough;
		// TODO: refine later
		// case CODA_HX4:
		// case CODA_7541:
		ctx->reg_idx = 0;
		break;
	default:
		ctx->reg_idx = idx;
	}

	ctx->use_vdoa = false;

	// TODO rtk16xxb settings
	ret = pm_runtime_get_sync(dev->dev);
	// TODO: refine later
	if (ret < 0) {
		v4l2_err(&dev->v4l2_dev, "failed to power up: %d\n", ret);
		goto err_pm_get;
	}

	reset_control_deassert(dev->rstc);
	ret = rtk_jcodec_clk_enable(dev->clk);
	if (ret)
		goto err_clk_enable;
	val = rtk_jcodec_read(dev, RTK_REG_JPEG_DBUS);
	val |= (dbus_en << 0);
	val &= ~(1 << 1); //Disable idle gating, fix it later.
	rtk_jcodec_write(dev, val, RTK_REG_JPEG_DBUS);

	rtk_jcodec_set_default_params(ctx);

	ctx->fh.m2m_ctx =
		v4l2_m2m_ctx_init(dev->m2m_dev, ctx, ctx->ops->queue_init);
	if (IS_ERR(ctx->fh.m2m_ctx)) {
		ret = PTR_ERR(ctx->fh.m2m_ctx);

		v4l2_err(&dev->v4l2_dev, "%s return error (%d)\n", __func__,
			 ret);
		goto err_ctx_init;
	}

	ret = rtk_jcodec_ctrls_setup(ctx);
	if (ret) {
		v4l2_err(&dev->v4l2_dev, "failed to setup coda controls\n");
		goto err_ctrls_setup;
	}

	ctx->fh.ctrl_handler = &ctx->ctrls;

	mutex_init(&ctx->bitstream_mutex);
	mutex_init(&ctx->buffer_mutex);
	mutex_init(&ctx->wakeup_mutex);
	INIT_LIST_HEAD(&ctx->meta_buffer_list);

	list_add_tail(&ctx->list, &dev->instances);

	spin_lock_init(&ctx->meta_buffer_lock);

	rtk_jcodec_dbg(1, ctx, "%s %d.%s.leave\n", RTK_JCODEC_NAME, __LINE__, __func__);
	return 0;

err_ctrls_setup:
	v4l2_m2m_ctx_release(ctx->fh.m2m_ctx);
err_ctx_init:
	clk_disable_unprepare(dev->clk);
err_clk_enable:
	pm_runtime_put_sync(dev->dev);
err_pm_get:
	v4l2_fh_del(&ctx->fh);
	v4l2_fh_exit(&ctx->fh);
err_rtk_name_init:
	ida_free(&dev->ida, ctx->idx);
err_rtk_max:
	kfree(ctx);
	return ret;
}

static int rtk_jcodec_release(struct file *file)
{
	struct rtk_jcodec_dev *dev = video_drvdata(file);
	struct rtk_jcodec_ctx *ctx = fh_to_ctx(file->private_data);

	rtk_jcodec_dbg(1, ctx, "\x1b[31mrelease instance (%p) (%s)\033[0m\n",
		       ctx, ctx->cvd->name);

	if (ctx->inst_type == RTK_JCODEC_CTX_DECODER && ctx->use_bit) {
		printk(KERN_INFO "[fn_name]:[\x1b[32m%s\033[0m], [line]:"
				 " \x1b[33m%d\033[0m\n",
		       __func__, __LINE__);
		// TODO: refine later
		rtk_bitstream_end_flag(ctx);
	}

	/* If this instance is running, call .job_abort and wait for it to end */
	v4l2_m2m_ctx_release(ctx->fh.m2m_ctx);
	// if (ctx->vdoa)
	// 	vdoa_context_destroy(ctx->vdoa);

	v4l2_ctrl_handler_free(&ctx->ctrls);

	clk_disable_unprepare(dev->clk);

	// TODO rtk16xxb settings
	pm_runtime_mark_last_busy(dev->dev);
	pm_runtime_put_autosuspend(dev->dev);
	// TODO: refine later
	// pm_runtime_put_sync(dev->dev);
	v4l2_fh_del(&ctx->fh);
	v4l2_fh_exit(&ctx->fh);
	ida_free(&dev->ida, ctx->idx);
	if (ctx->ops->release) {
		ctx->ops->release(ctx);
	}
	debugfs_remove_recursive(ctx->debugfs_entry);
	list_del(&ctx->list);
	kfree(ctx);

	return 0;
}

static const struct v4l2_file_operations rtk_jcodec_fops = {
	.owner = THIS_MODULE,
	.open = rtk_jcodec_open,
	.release = rtk_jcodec_release,
	.poll = v4l2_m2m_fop_poll,
	.unlocked_ioctl = video_ioctl2,
	.mmap = v4l2_m2m_fop_mmap,
};

static int rtk_jcodec_register_device(struct rtk_jcodec_dev *dev, int i)
{
	struct video_device *vfd = &dev->vfd[i];
	const char *name;
	int ret;

	if (i >= dev->devinfo->num_vdevs)
		return -EINVAL;

	name = dev->devinfo->vdevs[i]->name;
	strscpy(vfd->name, dev->devinfo->vdevs[i]->name, sizeof(vfd->name));
	vfd->fops = &rtk_jcodec_fops;
	vfd->ioctl_ops = &rtk_jcodec_ioctl_ops;
	vfd->release = video_device_release_empty;
	vfd->lock = &dev->dev_mutex;
	vfd->v4l2_dev = &dev->v4l2_dev;
	vfd->vfl_dir = VFL_DIR_M2M;
	vfd->device_caps = V4L2_CAP_VIDEO_M2M_MPLANE | V4L2_CAP_STREAMING;
	video_set_drvdata(vfd, dev);

	/* Not applicable, use the selection API instead */
	// TODO: refine later
	v4l2_disable_ioctl(vfd, VIDIOC_CROPCAP);
	v4l2_disable_ioctl(vfd, VIDIOC_G_CROP);
	v4l2_disable_ioctl(vfd, VIDIOC_S_CROP);

	if (dev->devinfo->vdevs[i]->type == RTK_JCODEC_CTX_ENCODER) {
		v4l2_disable_ioctl(vfd, VIDIOC_DECODER_CMD);
		v4l2_disable_ioctl(vfd, VIDIOC_TRY_DECODER_CMD);
		if (dev->devinfo->vdevs[i]->dst_formats[0] ==
		    V4L2_PIX_FMT_JPEG) {
			v4l2_disable_ioctl(vfd, VIDIOC_ENUM_FRAMEINTERVALS);
			v4l2_disable_ioctl(vfd, VIDIOC_G_PARM);
			v4l2_disable_ioctl(vfd, VIDIOC_S_PARM);
		}
	} else {
		v4l2_disable_ioctl(vfd, VIDIOC_ENCODER_CMD);
		v4l2_disable_ioctl(vfd, VIDIOC_TRY_ENCODER_CMD);
		v4l2_disable_ioctl(vfd, VIDIOC_ENUM_FRAMEINTERVALS);
		v4l2_disable_ioctl(vfd, VIDIOC_G_PARM);
		v4l2_disable_ioctl(vfd, VIDIOC_S_PARM);
	}

	ret = video_register_device(vfd, VFL_TYPE_VIDEO, 0);
	if (!ret) {
		v4l2_info(&dev->v4l2_dev, "%s registered as %s\n", name,
			  video_device_node_name(vfd));
	}
	pr_info("%s %d.%s.video_register_device.name:%s\n", RTK_JCODEC_NAME,
		__LINE__, __func__, name);
	return ret;
}

//coda_fw_callback
static void rtk_jcodec_set_dev(struct rtk_jcodec_dev *dev)
{
	int i, ret;

	ret = rtk_jcodec_hw_init(dev);
	if (ret < 0) {
		v4l2_err(&dev->v4l2_dev, "HW initialization failed\n");
		goto put_pm;
	}

	dev->m2m_dev = v4l2_m2m_init(&rtk_jcodec_m2m_ops);
	if (IS_ERR(dev->m2m_dev)) {
		v4l2_err(&dev->v4l2_dev, "Failed to init mem2mem device\n");
		goto put_pm;
	}

	ret = rtk_jcodec_check_firmware(dev);
	if (ret < 0) {
		goto put_pm;
	}
	for (i = 0; i < dev->devinfo->num_vdevs; i++) {
		ret = rtk_jcodec_register_device(dev, i);
		if (ret) {
			v4l2_err(&dev->v4l2_dev,
				 "Failed to register %s video device: %d\n",
				 dev->devinfo->vdevs[i]->name, ret);
			goto rel_vfd;
		}
	}

	pm_runtime_set_suspended(dev->dev);
	pm_runtime_use_autosuspend(dev->dev);
	pm_runtime_set_autosuspend_delay(dev->dev, 15000);
	pm_runtime_enable(dev->dev);
	pm_runtime_mark_last_busy(dev->dev);
	pr_info("%s %d.%s.af pm_xxx\n", RTK_JCODEC_NAME, __LINE__, __func__);

	return;

rel_vfd:
	while (--i >= 0)
		video_unregister_device(&dev->vfd[i]);
	v4l2_m2m_release(dev->m2m_dev);
put_pm:
	pm_runtime_put_sync(dev->dev);
}

static const struct of_device_id rtk_dt_ids[] = {
	{ .compatible = "realtek,rtd16xxb-jpeg",
	  .data = &rtk_devdata[RTK_STARK] },
	{ .compatible = "realtek,kent-jpeg",
	  .data = &rtk_devdata[RTK_KENT] },
	{ .compatible = "realtek,prince-jpeg",
	  .data = &rtk_devdata[RTK_PRINCE] },
	{ /* sentinel */ }
};
MODULE_DEVICE_TABLE(of, rtk_dt_ids);

static int rtk_jcodec_probe(struct platform_device *pdev)
{
	struct rtk_jcodec_dev *dev;
	int ret, irq;

	dev_info(&pdev->dev, "%s %d.%s.enter\n", RTK_JCODEC_NAME, __LINE__,
		 __func__);
	dev = devm_kzalloc(&pdev->dev, sizeof(*dev), GFP_KERNEL);
	if (!dev)
		return -ENOMEM;

#ifdef CONFIG_DMABUF_HEAPS_REALTEK
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	set_dma_ops(&pdev->dev, &rheap_dma_ops);
	rheap_setup_dma_pools(&pdev->dev, "rtk_media_heap",
			      RTK_FLAG_NONCACHED | RTK_FLAG_SCPUACC |
				      RTK_FLAG_VO_POOL,
			      __func__);
#endif
#endif

	dev->devinfo = of_device_get_match_data(&pdev->dev);

	dev->dev = &pdev->dev;

	dev->clk = devm_clk_get(&pdev->dev, "jpeg");
	//	dev->clk = clk_get(&pdev->dev, "jpeg");
	if (IS_ERR(dev->clk)) {
		dev_err(&pdev->dev, "Could not get jpeg clock\n");
		return PTR_ERR(dev->clk);
	}

	/* Get memory for physical registers */
	dev->regs_base = devm_platform_ioremap_resource(pdev, 0);
	if (IS_ERR(dev->regs_base))
		return PTR_ERR(dev->regs_base);

	/* IRQ */
	irq = platform_get_irq(pdev, 0);
	if (irq < 0) {
		dev_err(&pdev->dev, "Could not get irq\n");
		return irq;
	}

	ret = devm_request_irq(&pdev->dev, irq, rtk_jcodec_irq_handler, 0,
			       RTK_JCODEC_NAME "-jpeg", dev);
	if (ret < 0) {
		dev_err(&pdev->dev, "failed to request irq: %d\n", ret);
		return ret;
	}

	//dev->rstc = devm_reset_control_get_exclusive(&pdev->dev, "reset");
	dev->rstc = devm_reset_control_get_exclusive(&pdev->dev, NULL);
	if (IS_ERR(dev->rstc)) {
		ret = PTR_ERR(dev->rstc);
		dev_err(&pdev->dev, "failed get reset control: %d\n", ret);
		return ret;
	}

	ret = v4l2_device_register(&pdev->dev, &dev->v4l2_dev);
	if (ret)
		return ret;

	// TODO: Not sure rtk need ratelimit or not
	//ratelimit_default_init(&dev->mb_err_rs);

	mutex_init(&dev->dev_mutex);
	mutex_init(&dev->rtk_mutex);
	ida_init(&dev->ida);

	dev->debugfs_root = debugfs_create_dir("rtk-jcodec-dbg", NULL);

	dev->workqueue = alloc_ordered_workqueue("rtk-jcodec", WQ_MEM_RECLAIM);
	if (!dev->workqueue) {
		dev_err(&pdev->dev, "unable to alloc workqueue\n");
		return -ENOMEM;
	}

	platform_set_drvdata(pdev, dev);

	/*
	 * Start activated so we can directly call rtk_jcodec_hw_init in
	 * coda_fw_callback regardless of whether CONFIG_PM is
	 * enabled or whether the device is associated with a PM domain.
	 */

	// TODO: refine later
	// pm_runtime_get_noresume(&pdev->dev);
	// pm_runtime_set_active(&pdev->dev);
	// pm_runtime_enable(&pdev->dev);
	ret = device_create_file(&pdev->dev, &dev_attr_instance_info);
	if (ret < 0)
		dev_err(&pdev->dev, "failed to create jpeg v4l2 instance_info attribute\n");

	INIT_LIST_HEAD(&dev->instances);

	rtk_jcodec_set_dev(dev);
	dev_info(&pdev->dev, "%s %d.%s.leave\n", RTK_JCODEC_NAME, __LINE__,
		 __func__);
	return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 11, 0)
static void rtk_jcodec_remove(struct platform_device *pdev)
#else
static int rtk_jcodec_remove(struct platform_device *pdev)
#endif
{
	struct rtk_jcodec_dev *dev = platform_get_drvdata(pdev);
	int i;

	for (i = 0; i < ARRAY_SIZE(dev->vfd); i++) {
		if (video_get_drvdata(&dev->vfd[i]))
			video_unregister_device(&dev->vfd[i]);
	}

	device_remove_file(&pdev->dev, &dev_attr_instance_info);

	if (dev->m2m_dev)
		v4l2_m2m_release(dev->m2m_dev);
	pm_runtime_disable(&pdev->dev);
	v4l2_device_unregister(&dev->v4l2_dev);
	destroy_workqueue(dev->workqueue);

	debugfs_remove_recursive(dev->debugfs_root);
	ida_destroy(&dev->ida);
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 11, 0)
	return 0;
#endif
}

#ifdef CONFIG_PM

static int rtk_jcodec_runtime_suspend(struct device *dev)
{
	struct rtk_jcodec_dev *rdev = dev_get_drvdata(dev);
	int ret = 0;

	reset_control_deassert(rdev->rstc);
	rtk_jcodec_clk_enable(rdev->clk);
	rtk_jcodec_clk_disable(rdev->clk);
	reset_control_assert(rdev->rstc);

	return ret;
}

static int rtk_jcodec_runtime_resume(struct device *dev)
{
	struct rtk_jcodec_dev *rdev = dev_get_drvdata(dev);
	int ret = 0;

#if 0 // mark by joshua, need to refine
	if (dev->pm_domain && rdev->codebuf.vaddr) {
		dev_info(dev, "[fn_name]:[\x1b[33m%s\033[0m], [line]:"
				" \x1b[33m%d\033[0m\n", __func__, __LINE__);
		ret = rtk_jcodec_hw_init(rdev);
		if (ret)
			v4l2_err(&rdev->v4l2_dev, "HW initialization failed\n");
	}
#else
	reset_control_deassert(rdev->rstc);
	rtk_jcodec_clk_enable(rdev->clk);
	rtk_jcodec_clk_disable(rdev->clk);
	reset_control_assert(rdev->rstc);
#endif
	return ret;
}
#endif

static const struct dev_pm_ops rtk_jcodec_pm_ops = { SET_RUNTIME_PM_OPS(
	rtk_jcodec_runtime_suspend, rtk_jcodec_runtime_resume, NULL) };

static struct platform_driver rtk_jcodec_driver = {
	.probe	= rtk_jcodec_probe,
	.remove	= rtk_jcodec_remove,
	.driver	= {
		.name	= RTK_JCODEC_NAME,
		.of_match_table = rtk_dt_ids,
		.pm	= &rtk_jcodec_pm_ops,
	},
};

module_platform_driver(rtk_jcodec_driver);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("HK Chiu <hkchiu@realtek.com>");
MODULE_DESCRIPTION("Realtek jpeg codec V4L2 driver");
