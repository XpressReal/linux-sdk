/* SPDX-License-Identifier: (GPL-2.0 OR BSD-3-Clause) */
/*
 * Realtek video encoder v4l2 driver
 *
 * Copyright (c) 2024 Realtek Semiconductor Corp. All rights reserved.
 *
 * SPDX-License-Identifier: LicenseRef-Realtek-Proprietary
 *
 * This software component is confidential and proprietary to Realtek
 * Semiconductor Corp. Disclosure, reproduction, redistribution, in whole
 * or in part, of this work and its derivatives without express permission
 * is prohibited.
 */
#ifndef __RTKVE4ENC_VUI_H__
#define __RTKVE4ENC_VUI_H__

#include <linux/types.h>

struct rtkve4enc_ctx;

/**
 * rtkve4enc_h264_build_vui_rbsp - construct H.264 VUI RBSP (ITU-T H.264 Annex E)
 * @ctx: encoder context; reads colorspace, xfer_func, ycbcr_enc, quantization,
 *       enc_params.framerate_{num,denom}, enc_params.vui_sar_{idc,width,height}.
 *       Writes result into ctx->vbVuiRbsp.vaddr (must be pre-allocated).
 *
 * Returns the byte count of the generated RBSP, or 0 on error.
 */
u32 rtkve4enc_h264_build_vui_rbsp(struct rtkve4enc_ctx *ctx);

#endif /* __RTKVE4ENC_VUI_H__ */
