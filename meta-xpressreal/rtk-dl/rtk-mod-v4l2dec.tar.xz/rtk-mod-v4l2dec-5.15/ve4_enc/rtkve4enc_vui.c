// SPDX-License-Identifier: (GPL-2.0 OR BSD-3-Clause)
/*
 * Realtek video encoder v4l2 driver
 *
 * Copyright (c) 2024 Realtek Semiconductor Corp. All rights reserved.
 *
 * SPDX-License-Identifier: LicenseRef-Realtek-Proprietary
 *
 * This software component is confidential and proprietary to Realtek
 * Semiconductor Corp. Disclosure, reproduction, redistribution, in whole
 * or in part, of this work and its derivatives without express permission
 * is prohibited.
 */
#include <linux/string.h>
#include <linux/videodev2.h>

#include "rtkve4enc_common.h"
#include "rtkve4enc_vui.h"
#include "ve4_vdi.h"

/* ------------------------------------------------------------------ */
/* RBSP bitstream writer                                               */
/* ------------------------------------------------------------------ */

struct rbsp_writer {
	u8  *buf;
	u32  cap;     /* buffer capacity in bytes */
	u32  bit_pos; /* current write position (MSB-first within each byte) */
};

static void rbsp_write_bit(struct rbsp_writer *w, u8 bit)
{
	u32 byte_idx = w->bit_pos >> 3;
	u32 bit_off  = 7 - (w->bit_pos & 7);

	if (byte_idx >= w->cap)
		return;

	if (bit)
		w->buf[byte_idx] |=  (u8)(1u << bit_off);
	else
		w->buf[byte_idx] &= (u8)~(1u << bit_off);

	w->bit_pos++;
}

static void rbsp_write_bits(struct rbsp_writer *w, u32 val, int n)
{
	int i;

	for (i = n - 1; i >= 0; i--)
		rbsp_write_bit(w, (u8)((val >> i) & 1u));
}

/* rbsp_trailing_bits: stop bit followed by zero-padding to byte boundary */
static void rbsp_trailing_bits(struct rbsp_writer *w)
{
	rbsp_write_bit(w, 1);
	while (w->bit_pos & 7)
		rbsp_write_bit(w, 0);
}

static u32 rbsp_byte_count(const struct rbsp_writer *w)
{
	return (w->bit_pos + 7) >> 3;
}

/* ------------------------------------------------------------------ */
/* V4L2 colorspace -> H.264 VUI metadata mappings (ITU-T H.264 Annex E) */
/* ------------------------------------------------------------------ */

/* Table E-3: colour_primaries */
static u8 v4l2_to_h264_colour_primaries(enum v4l2_colorspace cs)
{
	switch (cs) {
	case V4L2_COLORSPACE_REC709:          return 1;  /* BT.709 */
	case V4L2_COLORSPACE_470_SYSTEM_M:    return 4;  /* BT.470M */
	case V4L2_COLORSPACE_SMPTE170M:       return 6;  /* BT.601 525*/
	case V4L2_COLORSPACE_470_SYSTEM_BG:   return 5;  /* BT.601 625 */
	case V4L2_COLORSPACE_BT2020:          return 9;  /* BT.2020 */
	default:                              return 2;  /* Unspecified */
	}
}

/* Table E-4: transfer_characteristics */
static u8 v4l2_to_h264_transfer_chars(enum v4l2_xfer_func xf,
				       enum v4l2_colorspace cs)
{
	switch (xf) {
	case V4L2_XFER_FUNC_709:        return 1;  /* BT.709 */
	case V4L2_XFER_FUNC_SRGB:       return 13; /* IEC 61966-2-1 sRGB */
	case V4L2_XFER_FUNC_NONE:       return 8;  /* Linear */
	case V4L2_XFER_FUNC_SMPTE2084:  return 16; /* SMPTE ST 2084 (PQ) */
	default:
		/* Fall back to colorspace default */
		if (cs == V4L2_COLORSPACE_SMPTE170M ||
		    cs == V4L2_COLORSPACE_470_SYSTEM_BG)
			return 6;  /* BT.601 */
		return 2;  /* Unspecified */
	}
}

/* Table E-5: matrix_coefficients */
static u8 v4l2_to_h264_matrix_coeffs(enum v4l2_ycbcr_encoding enc)
{
	switch (enc) {
	case V4L2_YCBCR_ENC_709:              return 1;  /* BT.709 */
	case V4L2_YCBCR_ENC_601:              return 6;  /* BT.601 */
	case V4L2_YCBCR_ENC_SMPTE240M:        return 7;  /* SMPTE 240M */
	case V4L2_YCBCR_ENC_BT2020:           return 9;  /* BT.2020 non-constant */
	case V4L2_YCBCR_ENC_BT2020_CONST_LUM: return 10; /* BT.2020 constant */
	default:                              return 2;  /* Unspecified */
	}
}

/* ------------------------------------------------------------------ */
/* DEFAULT colorspace resolution                                       */
/* ------------------------------------------------------------------ */

/*
 * Resolve V4L2_*_DEFAULT placeholders to concrete values.
 * colorspace: use V4L2_MAP_COLORSPACE_DEFAULT keyed on frame size
 *   (SDTV <= 720x576 -> BT.601/SMPTE170M, otherwise -> BT.709/REC709).
 * xfer_func, ycbcr_enc, quantization: follow their respective macros
 *   which chain from the resolved colorspace.
 */
static void resolve_default_colorspace(const struct rtkve4enc_ctx *ctx,
				       enum v4l2_colorspace     *cs_out,
				       enum v4l2_xfer_func      *xf_out,
				       enum v4l2_ycbcr_encoding *yc_out,
				       bool                    *full_range_out)
{
	bool is_sdtv = (ctx->src_fmt.width  <= 720 &&
			ctx->src_fmt.height <= 576);
	bool is_hdtv = !is_sdtv;
	enum v4l2_colorspace     cs;
	enum v4l2_xfer_func      xf;
	enum v4l2_ycbcr_encoding yc;
	enum v4l2_quantization   quant;

	cs = (ctx->colorspace != V4L2_COLORSPACE_DEFAULT)
	     ? ctx->colorspace
	     : V4L2_MAP_COLORSPACE_DEFAULT(is_sdtv, is_hdtv);

	xf = (ctx->xfer_func != V4L2_XFER_FUNC_DEFAULT)
	     ? ctx->xfer_func
	     : V4L2_MAP_XFER_FUNC_DEFAULT(cs);

	yc = (ctx->ycbcr_enc != V4L2_YCBCR_ENC_DEFAULT)
	     ? ctx->ycbcr_enc
	     : V4L2_MAP_YCBCR_ENC_DEFAULT(cs);

	quant = (ctx->quantization != V4L2_QUANTIZATION_DEFAULT)
		? ctx->quantization
		: V4L2_MAP_QUANTIZATION_DEFAULT(false, cs, yc);

	*cs_out         = cs;
	*xf_out         = xf;
	*yc_out         = yc;
	*full_range_out = (quant == V4L2_QUANTIZATION_FULL_RANGE);
}

/* ------------------------------------------------------------------ */
/* Public API                                                          */
/* ------------------------------------------------------------------ */

/**
 * rtkve4enc_h264_build_vui_rbsp - write H.264 VUI RBSP into ctx->vbVuiRbsp
 *
 * Generates the following syntax elements (ITU-T H.264 E.1.1):
 *   - aspect_ratio_info  (if enc_params.vui_sar_idc != 0)
 *   - video_signal_type  (always; V4L2_COLORSPACE_DEFAULT resolved from frame size)
 *   - timing_info        (if enc_params.framerate_num/denom are set)
 *
 * The buffer ctx->vbVuiRbsp must be pre-allocated by enc_alloc_custom_buffers()
 * before calling this function.
 *
 * Returns: byte count of generated data, or 0 on error.
 */
u32 rtkve4enc_h264_build_vui_rbsp(struct rtkve4enc_ctx *ctx)
{
	/*
	 * Build into a local stack buffer first, then copy to DMA memory with
	 * VDI_BIG_ENDIAN so the 128-bit LE bus byte-lane ordering matches the
	 * big-endian H.264 bitstream that non_vcl_param.vuiRbspDataSize describes.
	 * Max VUI size in our implementation: ~24 bytes; 64 is ample.
	 */
	u8 temp[64] = {};
	struct rbsp_writer w = {
		.buf     = temp,
		.cap     = sizeof(temp),
		.bit_pos = 0,
	};
	u32 size;
	enum v4l2_colorspace     cs;
	enum v4l2_xfer_func      xf;
	enum v4l2_ycbcr_encoding yc;
	bool full_range;

	bool has_sar    = (ctx->enc_params.vui_sar_enable &&
			   ctx->enc_params.vui_sar_idc != 0);
	bool has_timing = (ctx->enc_params.framerate_num > 0 &&
			   ctx->enc_params.framerate_denom > 0);

	if (!ctx->vbVuiRbsp.vaddr || !ctx->vbVuiRbsp.size)
		return 0;

	resolve_default_colorspace(ctx, &cs, &xf, &yc, &full_range);

	/* aspect_ratio_info_present_flag */
	rbsp_write_bit(&w, has_sar ? 1 : 0);
	if (has_sar) {
		rbsp_write_bits(&w, ctx->enc_params.vui_sar_idc, 8);
		/* Extended_SAR (255): explicit sar_width / sar_height follow */
		if (ctx->enc_params.vui_sar_idc == 255) {
			rbsp_write_bits(&w, ctx->enc_params.vui_sar_width,  16);
			rbsp_write_bits(&w, ctx->enc_params.vui_sar_height, 16);
		}
	}

	/* overscan_info_present_flag = 0 */
	rbsp_write_bit(&w, 0);

	/* video_signal_type_present_flag = 1 (always emit with resolved colorspace) */
	rbsp_write_bit(&w, 1);
	rbsp_write_bits(&w, 5, 3); /* video_format = Unspecified */
	rbsp_write_bit(&w, full_range ? 1 : 0);
	rbsp_write_bit(&w, 1); /* colour_description_present_flag */
	rbsp_write_bits(&w, v4l2_to_h264_colour_primaries(cs), 8);
	rbsp_write_bits(&w, v4l2_to_h264_transfer_chars(xf, cs), 8);
	rbsp_write_bits(&w, v4l2_to_h264_matrix_coeffs(yc), 8);

	/* chroma_loc_info_present_flag = 0 */
	rbsp_write_bit(&w, 0);

	/* timing_info_present_flag
	 * H.264 E.2.1: time_scale = 2 * framerate_num,
	 *               num_units_in_tick = framerate_denom
	 */
	rbsp_write_bit(&w, has_timing ? 1 : 0);
	if (has_timing) {
		rbsp_write_bits(&w, ctx->enc_params.framerate_denom,     32);
		rbsp_write_bits(&w, ctx->enc_params.framerate_num * 2u,  32);
		rbsp_write_bit(&w, 1); /* fixed_frame_rate_flag */
	}

	/* nal_hrd_parameters_present_flag = 0 */
	rbsp_write_bit(&w, 0);
	/* vcl_hrd_parameters_present_flag = 0 */
	rbsp_write_bit(&w, 0);
	/* pic_struct_present_flag = 0 */
	rbsp_write_bit(&w, 0);
	/* bitstream_restriction_flag = 0 */
	rbsp_write_bit(&w, 0);

	rbsp_trailing_bits(&w);

	size = rbsp_byte_count(&w);

	/*
	 * Copy VUI RBSP bytes to DMA buffer with no byte-lane swap.
	 * The firmware reads this buffer as a sequential byte array;
	 * both CPU and VPU share the same LE memory bus so no reordering
	 * is needed.  VDI_BIG_ENDIAN would apply all 4 swap levels and
	 * completely reverse the byte order, corrupting the VUI.
	 * (vui_rbsp_addr is written as Little Endian in gen_set_param_reg.)
	 */
	if (rtkve4_write_memory(ctx->dev, ctx->vbVuiRbsp.vaddr,
				ctx->vbVuiRbsp.size, 0,
				temp, (int)size, VDI_128BIT_LITTLE_ENDIAN) < 0)
		return 0;

	return size;
}
