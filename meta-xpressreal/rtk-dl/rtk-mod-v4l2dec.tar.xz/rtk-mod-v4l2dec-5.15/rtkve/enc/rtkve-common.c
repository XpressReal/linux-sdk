// SPDX-License-Identifier: (GPL-2.0 OR BSD-3-Clause)

#include <linux/v4l2-common.h>
#include <linux/dma-map-ops.h>
#include <linux/version.h>
#include <soc/realtek/memory.h>
#include <soc/realtek/rtk_media_heap.h>
#include "rtkve-common.h"

struct vpu_buf *rtkve_allocate_dma_memory(struct device *dev,
				 size_t size, bool limit)
{
	struct vpu_buf *buf_hdl = NULL;
	void *vaddr;
	dma_addr_t dma_addr;
#ifdef CONFIG_DMABUF_HEAPS_REALTEK
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	unsigned int flags = 0;
#endif
#endif
	if (!size) {
		dev_err(dev, "%s(): requested size==0\n", __func__);
		goto exit;
	}
#if 0
	if (size < SZ_8K)
		size = SZ_8K;
#endif
	buf_hdl = kzalloc(sizeof(*buf_hdl), GFP_KERNEL);
	if (!buf_hdl) {
		dev_err(dev, "%s allocate vpu_buf fail, No Memory\n", __func__);
		goto exit;
	}
#ifdef CONFIG_DMABUF_HEAPS_REALTEK
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	if (limit)
		flags = RTK_FLAG_NONCACHED | RTK_FLAG_SCPUACC | RTK_FLAG_VO_U_POOL;
	else
		flags = RTK_FLAG_NONCACHED | RTK_FLAG_SCPUACC | RTK_FLAG_VO_POOL;
#endif
#endif
	mutex_lock(&dev->mutex);
#ifdef CONFIG_DMABUF_HEAPS_REALTEK
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	rheap_setup_dma_pools(dev, "rtk_media_heap", flags, __func__);
#endif
#endif
	vaddr = dma_alloc_coherent(dev, size, &dma_addr, GFP_KERNEL);
	mutex_unlock(&dev->mutex);
	if (!vaddr) {
		dev_err(dev, "%s dma_alloc fail \n", __func__);
		kfree(buf_hdl);
		buf_hdl = NULL;
		goto exit;
	}

	buf_hdl->vaddr = vaddr;
	buf_hdl->daddr = dma_addr;
	buf_hdl->size = size;
	memset(buf_hdl->vaddr, 0, size);
exit:
	return buf_hdl;
}

void rtkve_free_dma_memory(struct device *dev, struct vpu_buf *vb)
{
	if (vb->size == 0)
		goto exit;

	if (!vb->vaddr)
		dev_err(dev, "%s(): requested free of unmapped buffer\n",
			__func__);
	else
		dma_free_coherent(dev, vb->size, vb->vaddr, vb->daddr);

	kfree(vb);
exit:
	return;
}
