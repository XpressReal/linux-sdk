/* GStreamer Wayland Library
 *
 * Copyright (C) 2012 Intel Corporation
 * Copyright (C) 2012 Sreerenj Balachandran <sreerenj.balachandran@intel.com>
 * Copyright (C) 2014 Collabora Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 */


#include <gst/gst.h>
#include <gst/allocators/allocators-prelude.h>
#include <gst/allocators/allocators.h>

G_BEGIN_DECLS

typedef struct _GstRtkDmaAllocator GstRtkDmaAllocator;
typedef struct _GstRtkDmaAllocatorClass GstRtkDmaAllocatorClass;
typedef struct _GstRtkDmaAllocatorPriv GstRtkDmaAllocatorPriv;

typedef enum memory_type {
  DMA_BUF_LINUX_CMA,
  DMA_BUF_SYSTEM,
  DMA_BUF_VO,
} MEMORY_TYPE;

#define GST_ALLOCATOR_RTK_DMA "rtkdma"

#define GST_TYPE_RTK_DMA_ALLOCATOR              (gst_rtk_dma_allocator_get_type())
#define GST_IS_RTK_DMA_ALLOCATOR(obj)           (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GST_TYPE_RTK_DMA_ALLOCATOR))
#define GST_IS_RTK_DMA_ALLOCATOR_CLASS(klass)   (G_TYPE_CHECK_CLASS_TYPE ((klass), GST_TYPE_RTK_DMA_ALLOCATOR))
#define GST_RTK_DMA_ALLOCATOR_GET_CLASS(obj)    (G_TYPE_INSTANCE_GET_CLASS ((obj), GST_TYPE_RTK_DMA_ALLOCATOR, GstRtkDmaAllocatorClass))
#define GST_RTK_DMA_ALLOCATOR(obj)              (G_TYPE_CHECK_INSTANCE_CAST ((obj), GST_TYPE_RTK_DMA_ALLOCATOR, GstRtkDmaAllocator))
#define GST_RTK_DMA_ALLOCATOR_CLASS(klass)      (G_TYPE_CHECK_CLASS_CAST ((klass), GST_TYPE_RTK_DMA_ALLOCATOR, GstRtkDmaAllocatorClass))
#define GST_RTK_DMA_ALLOCATOR_CAST(obj)         ((GstRtkDmaAllocator *)(obj))

struct _GstRtkDmaAllocator
{
  GstDmaBufAllocator parent_instance;
  MEMORY_TYPE type;
};

struct _GstRtkDmaAllocatorClass
{
  GstDmaBufAllocatorClass parent_class;
};

GST_ALLOCATORS_API
GstAllocator * gst_rtk_dma_allocator_new (void);

GST_ALLOCATORS_API
void gst_rtk_dma_allocator_set_heap(GstAllocator *alloc, MEMORY_TYPE type);

GST_ALLOCATORS_API
gboolean gst_is_rtk_dma_memory (GstMemory * mem);

G_END_DECLS
