#ifndef _KBASE_GPU_MEMORY_PROCFS_H
#define _KBASE_GPU_MEMORY_PROCFS_H

void kbase_gpu_memory_procfs_init(void);
void kbase_gpu_memory_procfs_term(void);

#endif
