#ifndef _KBASE_GPU_LOAD_PROCFS_H
#define _KBASE_GPU_LOAD_PROCFS_H

void kbase_gpu_load_procfs_init(void);
void kbase_gpu_load_procfs_term(void);

#endif
