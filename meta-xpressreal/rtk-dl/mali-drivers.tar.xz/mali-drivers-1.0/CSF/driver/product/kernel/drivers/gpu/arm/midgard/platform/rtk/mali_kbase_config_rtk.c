#include <linux/delay.h>
#include <linux/clk.h>
#include <linux/reset.h>
#include <linux/pm_runtime.h>
#include <linux/debugfs.h>
#include <linux/of.h>
#include <linux/of_device.h>
#include <mali_kbase.h>
#include <mali_kbase_defs.h>
#include <mali_kbase_config.h>
#include "mali_kbase_config_platform.h"
#include "mali_kbase_config_rtk.h"

static int kbase_platform_init(struct kbase_device *kbdev)
{
	struct device *dev = kbdev->dev;
	struct rtk_gpu_platform_data *pdata;

	pdata = devm_kzalloc(dev, sizeof(*pdata), GFP_KERNEL);
	if (!pdata)
		return -ENOMEM;
	kbdev->platform_context = pdata;
	pdata->dev = dev;

	return 0;
}

static void kbase_platform_term(struct kbase_device *kbdev)
{
	kbdev->platform_context = NULL;
}

struct kbase_platform_funcs_conf platform_funcs = {
	.platform_init_func = kbase_platform_init,
	.platform_term_func = kbase_platform_term,
};

static struct kbase_platform_config dummy_platform_config;

struct kbase_platform_config *kbase_get_platform_config(void)
{
	return &dummy_platform_config;
}

#ifdef MODULE_IMPORT_NS
MODULE_IMPORT_NS(ANDROID_GKI_VFS_EXPORT_ONLY);
#endif
