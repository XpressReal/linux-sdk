#ifndef __RTK_MEDIA_PLAYER__
#define __RTK_MEDIA_PLAYER__
#include <gst/gst.h>
#include <pthread.h>
#define STATE_RETRY_COUNT 10
#define MAX_VIDEO_COUNT 5
#define MAX_SUBTITLE_COUNT 30
#define MAX_AUDIO_COUNT 30

#define RTK_PLAYER_SOCKET_PATH "/tmp/rtk_player.sock"
#define RTK_PLAYER_REPLY_SOCKET_PATH "/tmp/rtk_player_reply.sock"
typedef enum rtk_subtitle_type {
	RTK_DVDSPU,
	RTK_SRT,
	RTK_ASS,
	RTK_UNKNOWN_SUBTITLE,
} RTK_SUBTITLE_TYPE;

typedef enum rtk_video_type {
	RTK_H264_VIDEO,
	RTK_H265_VIDEO,
	RTK_AV1_VIDEO,
	RTK_VP8_VIDEO,
	RTK_VP9_VIDEO,
	RTK_MPEG4_VIDEO,
	RTK_MPEG2_VIDEO,
	RTK_MPEG1_VIDEO,
	RTK_WMV_VIDEO,
	RTK_UNKNOWN_VIDEO,
} RTK_VIDEO_TYPE;

typedef enum rtk_audio_type {
	RTK_AC3_AUDIO,
	RTK_EAC3_AUDIO,
	RTK_AAC_AUDIO,
	RTK_MP1_AUDIO,
	RTK_MP2_AUDIO,
	RTK_MP3_AUDIO,
	RTK_OPUS_AUDIO,
	RTK_VORBIS_AUDIO,
	RTK_DTS_AUDIO,
	RTK_UNKNOWN_AUDIO,
} RTK_AUDIO_TYPE;

typedef enum rtk_container_type {
	RTK_MP4_CONTAINER,
	RTK_TS_CONTAINER,
	RTK_MKV_CONTAINER,
	RTK_ASF_CONTAINER,
	RTK_PS_CONTAINER,
	RTK_AVI_CONTAINER,
	RTK_FLV_CONTAINER,
	RTK_UNKNOWN_CONTAINER,
} RTK_CONTAINER_TYPE;

typedef struct rtk_video_bin {
	RTK_VIDEO_TYPE type;
	GstPad *pad;
	GstElement *queue1;
	GstElement *dec;
	GstElement *queue2;
	GstElement *vqueue;
	GstElement *squeue;
	GstElement *vsink;
	GstElement *ssink;
	GstElement *selector;
	GstElement *convert;
	GstElement *resample;
	GstElement *volume;
	GstElement *capsfilter;
	GstElement *asink;
} RTK_VIDEO_BIN;

typedef struct rtk_subtitle_bin {
	RTK_SUBTITLE_TYPE type;
	GstPad *pad;
	GstElement *queue1;
	GstElement *subtitle;
} RTK_SUBTITLE_BIN;

typedef struct rtk_audio_bin {
	RTK_AUDIO_TYPE type;
	int audio_active_id;
	GstPad *pad;
	GstElement *queue1;
	GstElement *dec;
	GstElement *queue2;
} RTK_AUDIO_BIN;

typedef enum rtk_player_cmd_type {
	PLAYER_START,
	PLAYER_STOP,
	PLAYER_PAUSE,
	PLAYER_RESUME,
	PLAYER_SEEK,
	PLAYER_RATE,
	PLAYER_DUMP_DOT,
	PLAYER_SWITCH_SUBTITLE,
	PLAYER_SWITCH_AUDIO,
	PLAYER_QUERY_POSITION,
	PLAYER_QUERY_DURATION,
	PLAYER_EXIT,
} RTK_PLAYER_CMD_TYPE;

typedef struct rtk_player_cmd {
	RTK_PLAYER_CMD_TYPE type;
	char str[256];
} RTK_PLAYER_CMD;

typedef struct rtk_media_playback {
	char player_name[128];
	char file_path[512];
	GMainLoop *loop;
	GstBus *bus;
	GstElement *pipeline;
	GstElement *src;
	GstElement *typefind;
	GstElement *demux;
	RTK_CONTAINER_TYPE container_type;
	RTK_VIDEO_BIN video_bin[MAX_VIDEO_COUNT];
	int video_count;
	int video_index;
	RTK_SUBTITLE_BIN subtitle_bin[MAX_SUBTITLE_COUNT];
	int subtitle_count;
	int subtitle_index;
	RTK_AUDIO_BIN audio_bin[MAX_AUDIO_COUNT];
	int audio_count;
	int audio_index;
	gboolean pipeline_already_quit;
	gboolean start_playing;
	double rate;
	gboolean video_first_frame;
} RTK_MEDIA_PLAYBACK;

void playback_init(RTK_MEDIA_PLAYBACK *playback);
RTK_MEDIA_PLAYBACK *playback_start(RTK_MEDIA_PLAYBACK *playback, char *file_path, const char *player_name); //block mode
void playback_stop(RTK_MEDIA_PLAYBACK *playback);
void playback_pause(RTK_MEDIA_PLAYBACK *playback);
void playback_resume(RTK_MEDIA_PLAYBACK *playback);
void playback_seek(RTK_MEDIA_PLAYBACK *playback, gint64 step);
void playback_rate(RTK_MEDIA_PLAYBACK *playback, double rate);
void playback_dump_dot(RTK_MEDIA_PLAYBACK *playback);

void playback_switch_subtitle(RTK_MEDIA_PLAYBACK *playback, int index);
void playback_switch_audio(RTK_MEDIA_PLAYBACK *playback, int index);
gint64 playback_query_duration(RTK_MEDIA_PLAYBACK *playback);
gint64 playback_query_position(RTK_MEDIA_PLAYBACK *playback);
#endif // end of __RTK_MEDIA_PLAYER__
