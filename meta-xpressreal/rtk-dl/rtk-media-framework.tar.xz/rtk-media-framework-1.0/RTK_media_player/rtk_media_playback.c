#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stddef.h>
#include "rtk_media_playback.h"
#define RELEASE_RETRY_COUNT 10

#define container_of(ptr, type, member) \
		((type *)((char *)ptr - offsetof(type, member)))

static void set_element_state(GstElement *element, GstState state)
{
	GstState gst_current, gst_pending;
	gst_element_set_state(element, state);
	for (int i = 0; i < RELEASE_RETRY_COUNT; i++)
	{
		gst_element_get_state(element, &gst_current, &gst_pending, GST_CLOCK_TIME_NONE);
		if (gst_current == state) {
			break;
		} else {
			printf("wait gst state to %s\n", gst_element_state_get_name(state));
			usleep(50000);
		}
	}
}

static void unref_element(GstElement *element)
{
	for (int i = 0; i < RELEASE_RETRY_COUNT; i++)
	{
		int ref_count = 0;
		ref_count = GST_OBJECT_REFCOUNT(element);
		if (ref_count == 0) {
			break;
		} else {
			printf("unref element:%s until 0\n", gst_element_get_name(element));
			gst_object_unref (GST_OBJECT (element));
			usleep(50000);
		}
	}
}

static GstElement *choose_subtitle_plugin(RTK_SUBTITLE_BIN *subtitle) {
	switch (subtitle->type) {
		case RTK_DVDSPU:
			subtitle->subtitle = gst_element_factory_make("rtkdvdspu", NULL);
			break;
		case RTK_SRT:
			subtitle->subtitle = gst_element_factory_make("rtksrtrender", NULL);
			break;
		case RTK_ASS:
			subtitle->subtitle = gst_element_factory_make("rtkassrender", NULL);
			break;
		default:
			printf("unknown subtitle type:%d\n", subtitle->type);
			break;
	}
	return subtitle->subtitle;
}

static void on_vdec_pad_added(GstElement *element, GstPad *new_pad, gpointer user_data)
{
	RTK_MEDIA_PLAYBACK *playback = (RTK_MEDIA_PLAYBACK *)user_data;
	RTK_VIDEO_BIN *video = &playback->video_bin[playback->video_index];
	GstPad *sinkpad = gst_element_get_static_pad (video->queue2, "sink");
	gst_pad_link(new_pad, sinkpad);
	g_object_unref(sinkpad);
// fullscreen
	GValue location = G_VALUE_INIT;
	GValue tmp = G_VALUE_INIT;
	g_value_init (&location, GST_TYPE_ARRAY);
	g_value_init (&tmp, G_TYPE_INT);
	g_value_set_int (&tmp, 0);
	gst_value_array_append_value (&location, &tmp);
	g_value_set_int (&tmp, 0);
	gst_value_array_append_value (&location, &tmp);
	g_value_set_int (&tmp, 1920);
	gst_value_array_append_value (&location, &tmp);
	g_value_set_int (&tmp, 1080);
	gst_value_array_append_value (&location, &tmp);

	if (playback->subtitle_count > 0) {
		g_object_set_property (G_OBJECT (video->vsink), "render-rectangle", &location);
		g_object_set_property (G_OBJECT (video->ssink), "render-rectangle", &location);
	} else {
		gst_element_link(video->queue2, video->vsink);
		g_object_set_property (G_OBJECT (video->vsink), "render-rectangle", &location);
	}

	if (playback->audio_count <= 0) {
		gst_element_set_state (playback->pipeline, GST_STATE_PLAYING);
		playback->start_playing = TRUE;
	}
}

static void on_adec_pad_added(GstElement *element, GstPad *new_pad, gpointer user_data)
{
	RTK_AUDIO_BIN *audio = (RTK_AUDIO_BIN *)user_data;
	RTK_MEDIA_PLAYBACK *playback = container_of(audio - (sizeof(RTK_AUDIO_BIN) * audio->audio_active_id), RTK_MEDIA_PLAYBACK, audio_bin);
	GstPad *sinkpad = gst_element_get_static_pad (audio->queue2, "sink");
	gst_pad_link(new_pad, sinkpad);
	g_object_unref(sinkpad);
	gst_element_set_state (playback->pipeline, GST_STATE_PLAYING);
	playback->start_playing = TRUE;
}

static GstPadProbeReturn on_first_subtitle_frame(GstPad *pad, GstPadProbeInfo *info, gpointer user_data)
{
	RTK_MEDIA_PLAYBACK *playback = (RTK_MEDIA_PLAYBACK *)user_data;
	if (playback->video_first_frame == TRUE)
		return GST_PAD_PROBE_REMOVE;
	else
		return GST_PAD_PROBE_DROP;
}

static GstPadProbeReturn on_first_video_frame(GstPad *pad, GstPadProbeInfo *info, gpointer user_data)
{
	RTK_MEDIA_PLAYBACK *playback = (RTK_MEDIA_PLAYBACK *)user_data;
	playback->video_first_frame = TRUE;
	return GST_PAD_PROBE_REMOVE;
}

static GstPadProbeReturn on_vdec_caps_probe(GstPad *pad, GstPadProbeInfo *info, gpointer user_data)
{
	GstCaps *caps = gst_pad_get_current_caps(pad);
	GstStructure *structure = NULL;
	int width = -1, height = -1;
	RTK_VIDEO_BIN *video = NULL;

	if (caps == NULL)
		return GST_PAD_PROBE_OK;

	structure = gst_caps_get_structure (caps, 0);
	if (structure == NULL)
		return GST_PAD_PROBE_OK;

	gst_structure_get_int(structure, "height", &height);
	gst_structure_get_int(structure, "width", &width);

	video = (RTK_VIDEO_BIN *)user_data;
	if (width * height >= 2560 * 1440) {
		g_object_set(video->queue1, "max-size-time", 0, NULL);
		g_object_set(video->queue1, "max-size-bytes", 50 * 1024 * 1024, NULL);
	}

	if (caps)
		gst_caps_unref(caps);

	return GST_PAD_PROBE_REMOVE;
}

static void on_vdec_parsebin_added(GstElement *element, GstPad *new_pad, gpointer user_data)
{
	gst_pad_add_probe(new_pad, GST_PAD_PROBE_TYPE_EVENT_DOWNSTREAM, (GstPadProbeCallback)on_vdec_caps_probe, user_data, NULL);
}

static void on_vdec_element_added(GstBin *bin, GstElement *child, gpointer user_data)
{
	const gchar *type_name = G_OBJECT_TYPE_NAME(child);
	GstElementFactory *f = gst_element_get_factory(child);
	const gchar *factory_name = f ? gst_plugin_feature_get_name(GST_PLUGIN_FEATURE(f)) : NULL;

	if ((factory_name && g_strcmp0(factory_name, "parsebin") == 0) || g_str_has_prefix(type_name, "GstParseBin"))
	{
		g_signal_connect(child, "pad-added", G_CALLBACK(on_vdec_parsebin_added), user_data);
	}
}

static void no_dmx_more_pads (GstElement *element, gpointer user_data)
{
	RTK_MEDIA_PLAYBACK *playback = (RTK_MEDIA_PLAYBACK *)user_data;
	RTK_VIDEO_BIN *video = NULL;
	RTK_AUDIO_BIN *audio = NULL;

	if (playback->video_count > 0) {
		GstPad *sinkpad = NULL;

		playback->video_index = 0;
		video = &playback->video_bin[0];
		video->queue1 = gst_element_factory_make("rtkhookqueue", NULL);
//		g_object_set(video->queue1, "max-size-time", 0, NULL);
//		g_object_set(video->queue1, "max-size-bytes", 50 * 1024 * 1024, NULL);
		video->dec = gst_element_factory_make("decodebin3", NULL);
		video->queue2 = gst_element_factory_make("rtkhookqueue", NULL);
		video->vsink = gst_element_factory_make("waylandsink", NULL);

		gst_bin_add_many(GST_BIN(playback->pipeline), video->queue1, video->dec, video->queue2, video->vsink, NULL);
		gst_bin_sync_children_states(GST_BIN(playback->pipeline));
		sinkpad = gst_element_get_static_pad (video->queue1, "sink");
		gst_pad_link(video->pad, sinkpad);
		gst_element_link(video->queue1, video->dec);
		g_signal_connect(video->dec, "element-added", G_CALLBACK(on_vdec_element_added), video);
		g_signal_connect(video->dec, "pad-added", G_CALLBACK(on_vdec_pad_added), playback);
		g_object_unref(sinkpad);

		if (playback->subtitle_count > 0)
		{
			video->vqueue = gst_element_factory_make("rtkhookqueue", NULL);
			video->squeue = gst_element_factory_make("rtkhookqueue", NULL);
			video->ssink = gst_element_factory_make("waylandsink", NULL);

			playback->subtitle_index = 0;
			RTK_SUBTITLE_BIN *subtitle = &playback->subtitle_bin[playback->subtitle_index];
			subtitle->queue1 = gst_element_factory_make("rtkhookqueue", NULL);
			subtitle->subtitle = choose_subtitle_plugin(subtitle);
			gst_bin_add_many(GST_BIN(playback->pipeline), subtitle->queue1, subtitle->subtitle, video->vqueue, video->squeue, video->ssink, NULL);
			gst_bin_sync_children_states(GST_BIN(playback->pipeline));
			sinkpad = gst_element_get_static_pad (subtitle->queue1, "sink");
			gst_pad_link(subtitle->pad, sinkpad);
			gst_element_link(video->queue2, subtitle->subtitle);
			gst_element_link(subtitle->queue1, subtitle->subtitle);
			gst_element_link(subtitle->subtitle, video->vqueue);
			gst_element_link(subtitle->subtitle, video->squeue);

			GstPad *ssink_pad = gst_element_get_static_pad(video->ssink, "sink");
			GstPad *vsink_pad = gst_element_get_static_pad(video->vsink, "sink");
			gst_pad_add_probe(ssink_pad, GST_PAD_PROBE_TYPE_BLOCK | GST_PAD_PROBE_TYPE_BUFFER, (GstPadProbeCallback)on_first_subtitle_frame, playback, NULL);
			gst_pad_add_probe(vsink_pad, GST_PAD_PROBE_TYPE_BLOCK | GST_PAD_PROBE_TYPE_BUFFER, (GstPadProbeCallback)on_first_video_frame, playback, NULL);
			g_object_unref(ssink_pad);
			g_object_unref(vsink_pad);

			gst_element_link(video->vqueue, video->vsink);
			gst_element_link(video->squeue, video->ssink);
			g_object_unref(sinkpad);
		}
	}


	if (playback->audio_count > 0) {
		playback->audio_index = 0;
		video->asink = gst_element_factory_make("alsasink", NULL);
		video->selector = gst_element_factory_make("input-selector", NULL);
		video->convert = gst_element_factory_make("audioconvert", NULL);
		video->resample = gst_element_factory_make("audioresample", NULL);
		video->capsfilter = gst_element_factory_make("capsfilter", NULL);
		GstCaps *caps = gst_caps_from_string("audio/x-raw,rate=48000,channels=2");
		g_object_set(video->capsfilter, "caps", caps, NULL);
		gst_caps_unref(caps);
		video->volume = gst_element_factory_make("volume", NULL);
		gst_bin_add_many(GST_BIN(playback->pipeline), video->selector, video->convert, video->resample, video->capsfilter, video->volume, video->asink, NULL);
		gst_bin_sync_children_states(GST_BIN(playback->pipeline));
		gst_element_link_many(video->selector, video->convert, video->resample, video->capsfilter, video->volume, video->asink, NULL);

		for (int i = 0; i < playback->audio_count; i++) {
			RTK_AUDIO_BIN *audio = &playback->audio_bin[i];
			GstPad *sinkpad;
			GstPad *srcpad;

			audio->queue1 = gst_element_factory_make("rtkhookqueue", NULL);
			g_object_set(audio->queue1, "max-size-time", 0, NULL);
			audio->dec = gst_element_factory_make("decodebin3", NULL);
			audio->queue2 = gst_element_factory_make("rtkhookqueue", NULL);
			g_object_set(audio->queue2, "max-size-time", 0, NULL);
			gst_bin_add_many(GST_BIN(playback->pipeline), audio->queue1, audio->dec, audio->queue2, NULL);
			gst_bin_sync_children_states(GST_BIN(playback->pipeline));

			sinkpad = gst_element_get_static_pad (audio->queue1, "sink");
			gst_pad_link(audio->pad, sinkpad);
			g_object_unref(sinkpad);
			gst_element_link(audio->queue1, audio->dec);
			srcpad = gst_element_get_static_pad (audio->queue2, "src");
			sinkpad = gst_element_get_request_pad (video->selector, "sink_%u");
			gst_pad_link(srcpad, sinkpad);
			g_object_unref(srcpad);
			g_object_unref(sinkpad);
			audio->audio_active_id = i;
			g_signal_connect(audio->dec, "pad-added", G_CALLBACK(on_adec_pad_added), audio);
		}
	}
}

static void on_dmx_pad_added (GstElement *element, GstPad *new_pad, gpointer user_data)
{
	RTK_MEDIA_PLAYBACK *playback = (RTK_MEDIA_PLAYBACK *)user_data;
	const gchar *mime = NULL;
	GstStructure *structure = NULL;
	GstCaps *caps = gst_pad_get_current_caps(new_pad);
	gchar *caps_str = NULL;

	structure = gst_caps_get_structure (caps, 0);
	if (structure == NULL)
		return;

	mime = gst_structure_get_name(structure);
	caps_str = gst_caps_to_string(caps);

	printf("mime:%s\n", mime);
	if (playback->video_count >= MAX_VIDEO_COUNT)
	{
		printf("exceed video count:%d mine_type:%s\n", playback->video_count, mime);
		return;
	}

	if (playback->subtitle_count >= MAX_SUBTITLE_COUNT)
	{
		printf("exceed subtitle count:%d mine_type:%s\n", playback->subtitle_count, mime);
		return;
	}

	if (playback->audio_count >= MAX_AUDIO_COUNT)
	{
		printf("exceed audio count:%d mine_type:%s\n", playback->audio_count, mime);
		return;
	}

	if (gst_structure_has_name (structure, "video/x-h264")) { // video codec start
		playback->video_bin[playback->video_count].type = RTK_H264_VIDEO;
		playback->video_bin[playback->video_count].pad = new_pad;
		playback->video_count++;
	} else if (gst_structure_has_name (structure, "video/x-h265")) {
		playback->video_bin[playback->video_count].type = RTK_H265_VIDEO;
		playback->video_bin[playback->video_count].pad = new_pad;
		playback->video_count++;
	} else if (gst_structure_has_name (structure, "video/x-av1")) {
		playback->video_bin[playback->video_count].type = RTK_AV1_VIDEO;
		playback->video_bin[playback->video_count].pad = new_pad;
		playback->video_count++;
	} else if (gst_structure_has_name (structure, "video/x-vp8")) {
		playback->video_bin[playback->video_count].type = RTK_VP8_VIDEO;
		playback->video_bin[playback->video_count].pad = new_pad;
		playback->video_count++;
	} else if (gst_structure_has_name (structure, "video/x-vp9")) {
		playback->video_bin[playback->video_count].type = RTK_VP9_VIDEO;
		playback->video_bin[playback->video_count].pad = new_pad;
		playback->video_count++;
	} else if (gst_structure_has_name (structure, "video/mpeg")) {
		int mpegversion = -1;
		gst_structure_get_int(structure, "mpegversion", &mpegversion);
		if (mpegversion == 1)
			playback->video_bin[playback->video_count].type = RTK_MPEG1_VIDEO;
		else if (mpegversion == 2)
			playback->video_bin[playback->video_count].type = RTK_MPEG2_VIDEO;
		else if (mpegversion == 4)
			playback->video_bin[playback->video_count].type = RTK_MPEG4_VIDEO;
		else
			return;

		playback->video_bin[playback->video_count].pad = new_pad;
		playback->video_count++;
	} else if (gst_structure_has_name (structure, "video/x-wmv")) {
		playback->video_bin[playback->video_count].type = RTK_WMV_VIDEO;
		playback->video_bin[playback->video_count].pad = new_pad;
		playback->video_count++;
	} else if (gst_structure_has_name (structure, "subpicture/x-pgs")) { // subtitle codec start
		playback->subtitle_bin[playback->subtitle_count].type = RTK_DVDSPU;
		playback->subtitle_bin[playback->subtitle_count].pad = new_pad;
		playback->subtitle_count++;
	} else if (gst_structure_has_name (structure, "text/x-raw")) {
		playback->subtitle_bin[playback->subtitle_count].type = RTK_SRT;
		playback->subtitle_bin[playback->subtitle_count].pad = new_pad;
		playback->subtitle_count++;
	} else if (gst_structure_has_name (structure, "application/x-ass") || gst_structure_has_name (structure, "application/x-ssa")) {
		playback->subtitle_bin[playback->subtitle_count].type = RTK_ASS;
		playback->subtitle_bin[playback->subtitle_count].pad = new_pad;
		playback->subtitle_count++;
	} else if (gst_structure_has_name (structure, "audio/x-ac3")) { // audio codec start
		playback->audio_bin[playback->audio_count].type = RTK_AC3_AUDIO;
		playback->audio_bin[playback->audio_count].pad = new_pad;
		playback->audio_count++;
	} else if (gst_structure_has_name (structure, "audio/x-eac3")) {
		playback->audio_bin[playback->audio_count].type = RTK_EAC3_AUDIO;
		playback->audio_bin[playback->audio_count].pad = new_pad;
		playback->audio_count++;
	} else if (gst_structure_has_name (structure, "audio/mpeg")) {
		int mpegversion = -1;
		gst_structure_get_int(structure, "mpegversion", &mpegversion);
		if (mpegversion == 1) {
			int layer = -1;
			gst_structure_get_int(structure, "layer", &layer);
			if (layer == 1)
				playback->audio_bin[playback->audio_count].type = RTK_MP1_AUDIO;
			else if (layer == 2)
				playback->audio_bin[playback->audio_count].type = RTK_MP2_AUDIO;
			else if (layer == 3)
				playback->audio_bin[playback->audio_count].type = RTK_MP3_AUDIO;
			else
				return;
		} else if (mpegversion == 4)
			playback->audio_bin[playback->audio_count].type = RTK_AAC_AUDIO;

		playback->audio_bin[playback->audio_count].pad = new_pad;
		playback->audio_count++;
	} else if (gst_structure_has_name (structure, "audio/x-opus")) {
		playback->audio_bin[playback->audio_count].type = RTK_OPUS_AUDIO;
		playback->audio_bin[playback->audio_count].pad = new_pad;
		playback->audio_count++;
	} else if (gst_structure_has_name (structure, "audio/x-vorbis")) {
		playback->audio_bin[playback->audio_count].type = RTK_VORBIS_AUDIO;
		playback->audio_bin[playback->audio_count].pad = new_pad;
		playback->audio_count++;
	} else if (gst_structure_has_name (structure, "audio/x-dts")) {
		playback->audio_bin[playback->audio_count].type = RTK_DTS_AUDIO;
		playback->audio_bin[playback->audio_count].pad = new_pad;
		playback->audio_count++;
	} else {
		printf("unsupported codec format:%s\n", caps_str);
	}

	if (caps)
		gst_caps_unref(caps);

	if (caps_str)
		g_free(caps_str);
}

static gboolean bus_call (GstBus *bus, GstMessage *msg, gpointer data)
{
	RTK_MEDIA_PLAYBACK *playback = (RTK_MEDIA_PLAYBACK *)data;
	switch (GST_MESSAGE_TYPE (msg)) {
		case GST_MESSAGE_EOS:
			printf ("End of stream\n");
			playback->pipeline_already_quit = TRUE;
			playback->start_playing = FALSE;
			g_main_loop_quit (playback->loop);
			break;
		case GST_MESSAGE_ERROR: {
			gchar  *debug = NULL;
			GError *error;

			gst_message_parse_error (msg, &error, &debug);

			printf ("element:%s Error: %s\n", GST_OBJECT_NAME(GST_MESSAGE_SRC(msg)), error->message);
			printf ("elmenet:%s Debug: %s\n", GST_OBJECT_NAME(GST_MESSAGE_SRC(msg)), (debug) ? debug : "none");
			g_error_free (error);
			g_free(debug);
			playback->pipeline_already_quit = TRUE;
			playback->start_playing = FALSE;
			g_main_loop_quit (playback->loop);
			break;
		}
		case GST_MESSAGE_ASYNC_DONE: {
#if 0
			GstElement *element = (GstElement*)GST_MESSAGE_SRC (msg);
			GstState current, pending;
			gst_element_get_state (element, &current, &pending, GST_CLOCK_TIME_NONE);
			if (current == GST_STATE_PAUSED)
				gst_element_set_state (element, GST_STATE_PLAYING);
#endif
			}
		default:
			break;
	}

	return TRUE;
}

static void typefound_cb(GstElement *typefind, guint probability, GstCaps *caps, gpointer user_data)
{
	RTK_MEDIA_PLAYBACK *playback = (RTK_MEDIA_PLAYBACK *)user_data;
	const gchar *mime = NULL;
	mime = gst_structure_get_name(gst_caps_get_structure(caps, 0));
	printf("container mime:%s\n", mime);
	if (g_str_has_prefix(mime, "video/quicktime") ||
		g_str_has_prefix(mime, "video/mp4") ||
		g_str_has_prefix(mime, "application/x-3gp")) {
		playback->container_type = RTK_MP4_CONTAINER;
	} else if (g_str_has_prefix(mime, "video/x-matroska") || g_str_has_prefix(mime, "video/webm")) {
		playback->container_type = RTK_MKV_CONTAINER;
	} else if (g_str_has_prefix(mime, "video/mpegts")) {
		playback->container_type = RTK_TS_CONTAINER;
	} else if (g_str_has_prefix(mime, "video/x-ms-asf")) {
		playback->container_type = RTK_ASF_CONTAINER;
	} else if (g_str_has_prefix(mime, "video/mpeg")) {
		playback->container_type = RTK_PS_CONTAINER;
	} else if (g_str_has_prefix(mime, "video/x-msvideo")) {
		playback->container_type = RTK_AVI_CONTAINER;
	} else if (g_str_has_prefix(mime, "video/x-flv")) {
		playback->container_type = RTK_FLV_CONTAINER;
	} else {
		printf("unsupported container format:%s\n", mime);
		playback->container_type = RTK_UNKNOWN_CONTAINER;
	}
#if 0
	if (playback->container_type != RTK_UNKNOWN_CONTAINER) {
		gst_bin_add(GST_BIN(playback->pipeline), playback->demux);
		gst_bin_sync_children_states(GST_BIN(playback->pipeline));
		gst_element_link(playback->typefind, playback->demux);
		g_signal_connect (playback->demux, "pad-added", G_CALLBACK (on_dmx_pad_added), playback);
		g_signal_connect (playback->demux, "no-more-pads", G_CALLBACK (no_dmx_more_pads), playback);
	}
#endif
	g_main_loop_quit (playback->loop);
}

void playback_switch_audio(RTK_MEDIA_PLAYBACK *playback, int index)
{
	gchar active_pad[32] = {0};
	GstPad *pad = NULL;
	RTK_VIDEO_BIN *video = NULL;
	if (playback->audio_count <= 0)
		return;

	if (playback->audio_index == index)
		return;

	if (index >= playback->audio_count)
		return;

	video = &playback->video_bin[playback->video_index];
	GstPad *test;
	g_object_get(video->selector, "active-pad", &test, NULL);
	gst_object_unref(test);

	sprintf(active_pad, "sink_%u", index);
	printf("audio active_pad:%s\n", active_pad);
	pad = gst_element_get_static_pad(video->selector, active_pad);
	g_object_set(video->selector, "active-pad", pad, NULL);
	gst_object_unref(pad);
	playback->audio_index = index;
	set_element_state (playback->pipeline, GST_STATE_PLAYING);
}

void playback_switch_subtitle(RTK_MEDIA_PLAYBACK *playback, int index)
{
	GstPad *sinkpad = NULL;
	RTK_VIDEO_BIN *video = &playback->video_bin[playback->video_index];
	RTK_SUBTITLE_BIN *subtitle_current = NULL;
	RTK_SUBTITLE_BIN *subtitle_new = NULL;

	if (playback->subtitle_count <= 0)
		return;

	if (playback->subtitle_index == index)
		return;

	if (index >= playback->subtitle_count)
		return;

	subtitle_current = &playback->subtitle_bin[playback->subtitle_index];
	subtitle_new = &playback->subtitle_bin[index];

	g_object_set(G_OBJECT(subtitle_current->subtitle), "silent", TRUE, NULL);
	g_object_set(G_OBJECT(video->ssink), "silent", TRUE, NULL);
	g_object_set(G_OBJECT(video->ssink), "clear", TRUE, NULL);
// flush previous subtitle frame
	gst_element_send_event(video->squeue, gst_event_new_flush_start());
	gst_element_send_event(video->squeue, gst_event_new_flush_stop(FALSE));
	gint64 current_position = 0;
	gst_element_query_position(playback->pipeline, GST_FORMAT_TIME, &current_position);
	gst_element_send_event(video->squeue, gst_event_new_gap(current_position, 0));

	set_element_state(playback->pipeline, GST_STATE_PAUSED);
	gst_element_unlink(video->queue2, subtitle_current->subtitle);

	sinkpad = gst_element_get_static_pad (subtitle_current->queue1, "sink");
	gst_pad_unlink(subtitle_current->pad, sinkpad);
	g_object_unref(sinkpad);

	gst_element_unlink(subtitle_current->subtitle, video->vqueue);
	gst_element_unlink(subtitle_current->subtitle, video->squeue);
	gst_element_unlink(subtitle_current->queue1, subtitle_current->subtitle);
	set_element_state(subtitle_current->queue1, GST_STATE_NULL);
	set_element_state(subtitle_current->subtitle, GST_STATE_NULL);
	gst_bin_remove(GST_BIN(playback->pipeline), subtitle_current->queue1);
	gst_bin_remove(GST_BIN(playback->pipeline), subtitle_current->subtitle);

	subtitle_new->queue1 = gst_element_factory_make("rtkhookqueue", NULL);
	subtitle_new->subtitle = choose_subtitle_plugin(subtitle_new);

	gst_bin_add_many(GST_BIN(playback->pipeline), subtitle_new->queue1, subtitle_new->subtitle, NULL);
	gst_bin_sync_children_states(GST_BIN(playback->pipeline));
	sinkpad = gst_element_get_static_pad (subtitle_new->queue1, "sink");
	gst_pad_link(subtitle_new->pad, sinkpad);
	g_object_unref(sinkpad);
	gst_element_link(video->queue2, subtitle_new->subtitle);
	gst_element_link(subtitle_new->queue1, subtitle_new->subtitle);
	gst_element_link(subtitle_new->subtitle, video->vqueue);
	gst_element_link(subtitle_new->subtitle, video->squeue);
	g_object_set(G_OBJECT(video->ssink), "silent", FALSE, NULL);

	playback->subtitle_index = index;
	set_element_state (playback->pipeline, GST_STATE_PLAYING);
}

void playback_dump_dot(RTK_MEDIA_PLAYBACK *playback)
{
	gst_debug_bin_to_dot_file(GST_BIN(playback->pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "pipeline_go");
}

void playback_rate(RTK_MEDIA_PLAYBACK *playback, double rate)
{
	gint64 current_position = -1;
	gst_element_query_position(playback->pipeline, GST_FORMAT_TIME, &current_position);
	if (current_position != -1) {
		gst_element_seek(playback->pipeline, rate, GST_FORMAT_TIME, GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_ACCURATE,
			GST_SEEK_TYPE_SET, current_position, GST_SEEK_TYPE_NONE, GST_CLOCK_TIME_NONE);

		playback->rate = rate;
	}
}

void playback_pause(RTK_MEDIA_PLAYBACK *playback)
{
	set_element_state(playback->pipeline, GST_STATE_PAUSED);
}

void playback_resume(RTK_MEDIA_PLAYBACK *playback)
{
	set_element_state(playback->pipeline, GST_STATE_PLAYING);
}

gint64 playback_query_duration(RTK_MEDIA_PLAYBACK *playback)
{
	gint64 duration = -1;
	gst_element_query_duration(playback->pipeline, GST_FORMAT_TIME, &duration);

	return duration;
}

gint64 playback_query_position(RTK_MEDIA_PLAYBACK *playback)
{
	gint64 current_position = -1;
	gst_element_query_position(playback->pipeline, GST_FORMAT_TIME, &current_position);

	return current_position;
}

void playback_seek(RTK_MEDIA_PLAYBACK *playback, gint64 pos)
{
	gint64 duration = -1;
	gint64 new_pos = pos * GST_SECOND;
	gint64 before_position = -1;

	if (!gst_element_query_duration(playback->pipeline, GST_FORMAT_TIME, &duration)) {
		printf("Failed to query duration.\n");
		return;
	}

	if (pos >= duration/GST_SECOND)
	{
		printf("exceed video duration pos:%lld video total time:%lld\n", pos, duration);
		return;
	}

	gst_element_query_position(playback->pipeline, GST_FORMAT_TIME, &before_position);

	new_pos = new_pos < 0 ? 0 : new_pos;

	GstSeekFlags seekFlags = GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_ACCURATE;
	if (!gst_element_seek_simple(playback->pipeline, GST_FORMAT_TIME, seekFlags, new_pos)) {
		printf("Seek failed to position %" GST_TIME_FORMAT "\n", GST_TIME_ARGS(new_pos));
		return;
	}

	for (int i = 0; i < 10; i++)
	{
		gint64 after_position = -1;
		gst_element_query_position(playback->pipeline, GST_FORMAT_TIME, &after_position);
		if (before_position != after_position)
			break;
		usleep(50000);
	}
}

RTK_MEDIA_PLAYBACK *playback_start(RTK_MEDIA_PLAYBACK *playback, char *file_path, const char *player_name)
{
	strcpy(playback->player_name, player_name);
	strcpy(playback->file_path, file_path);

	playback->video_index = -1;
	playback->subtitle_index = -1;
	playback->audio_index = -1;
	playback->pipeline_already_quit = FALSE;
	playback->start_playing = FALSE;
	playback->rate = 1.0;

	playback->loop = g_main_loop_new (NULL, FALSE);

	gst_init(NULL, NULL);
	if (strcmp(file_path, "rtk_dprx")) {
		playback->pipeline = gst_pipeline_new(player_name);
		playback->src = gst_element_factory_make("filesrc", NULL);
		playback->typefind = gst_element_factory_make("typefind", NULL);
		GstElement *fakesink = gst_element_factory_make("fakesink", NULL);

		g_object_set(G_OBJECT(playback->src), "location", file_path, NULL);
		g_object_set(G_OBJECT(fakesink), "sync", FALSE, NULL);
		gst_bin_add_many(GST_BIN(playback->pipeline), playback->src, playback->typefind, fakesink, NULL);
		gst_element_link_many(playback->src, playback->typefind, fakesink);

		playback->bus = gst_pipeline_get_bus (GST_PIPELINE (playback->pipeline));
		gst_bus_add_watch (playback->bus, bus_call, playback);

		g_signal_connect(playback->typefind, "have-type", G_CALLBACK(typefound_cb), playback);
		set_element_state(playback->pipeline, GST_STATE_PAUSED);
		// g_main_loop_run(playback->loop);
	// already found container format
		set_element_state(playback->pipeline, GST_STATE_NULL);
		unref_element(playback->pipeline);

		if (playback->bus)
			gst_object_unref(playback->bus);

		if (playback->loop)
			g_main_loop_unref(playback->loop);

		switch (playback->container_type)
		{
			case RTK_MP4_CONTAINER:
				playback->demux = gst_element_factory_make("qtdemux", NULL);
				break;
			case RTK_MKV_CONTAINER:
				playback->demux = gst_element_factory_make("matroskademux", NULL);
				break;
			case RTK_TS_CONTAINER:
				playback->demux = gst_element_factory_make("tsdemux", NULL);
				break;
			case RTK_ASF_CONTAINER:
				playback->demux = gst_element_factory_make("asfdemux", NULL);
				break;
			case RTK_PS_CONTAINER:
				playback->demux = gst_element_factory_make("mpegpsdemux", NULL);
				break;
			case RTK_AVI_CONTAINER:
				playback->demux = gst_element_factory_make("avidemux", NULL);
				break;
			default:
				return NULL;
		}

		playback->loop = g_main_loop_new (NULL, FALSE);
		playback->pipeline = gst_pipeline_new(player_name);
		playback->src = gst_element_factory_make("filesrc", NULL);
		g_object_set(G_OBJECT(playback->src), "location", file_path, NULL);

		gst_bin_add_many(GST_BIN(playback->pipeline), playback->src, playback->demux, NULL);
		gst_element_link(playback->src, playback->demux);

		playback->bus = gst_pipeline_get_bus (GST_PIPELINE (playback->pipeline));
		gst_bus_add_watch (playback->bus, bus_call, playback);

		g_signal_connect (playback->demux, "pad-added", G_CALLBACK (on_dmx_pad_added), playback);
		g_signal_connect (playback->demux, "no-more-pads", G_CALLBACK (no_dmx_more_pads), playback);

		set_element_state(playback->pipeline, GST_STATE_PAUSED);
	} else {
		gchar *pipeline_str;
		GError *error = NULL;
		pipeline_str = g_strdup_printf("v4l2src device=/dev/video60 extra-buffers=10 ! queue ! waylandsink render-rectangle=\"<0,0,1920,1080>\"");
		playback->pipeline = gst_parse_launch (pipeline_str, &error);
		playback->bus = gst_pipeline_get_bus (GST_PIPELINE (playback->pipeline));
		gst_bus_add_watch (playback->bus, bus_call, playback);
		printf("dprx running\n");
		set_element_state(playback->pipeline, GST_STATE_PLAYING);
	}
	g_main_loop_run(playback->loop);

	return playback;
}

void playback_stop(RTK_MEDIA_PLAYBACK* playback)
{
	if (playback->loop && playback->pipeline_already_quit == FALSE) {
		playback->start_playing = FALSE;
		g_main_loop_quit(playback->loop);
	}

	if (playback->pipeline) {
		set_element_state (playback->pipeline, GST_STATE_NULL);
		unref_element(playback->pipeline);
	}

	if (playback->bus)
		gst_object_unref(playback->bus);

	if (playback->loop)
		g_main_loop_unref(playback->loop);
}

void playback_init(RTK_MEDIA_PLAYBACK *playback)
{
	if (playback == NULL)
		return;
	memset(playback, 0, sizeof(RTK_MEDIA_PLAYBACK));
	for (int i=0; i<MAX_VIDEO_COUNT; i++)
	{
		playback->video_bin[i].type = RTK_UNKNOWN_VIDEO;
	}
	playback->video_count = 0;
	playback->video_index = -1;
	for (int i=0; i<MAX_SUBTITLE_COUNT; i++)
	{
		playback->subtitle_bin[i].type = RTK_UNKNOWN_SUBTITLE;
	}
	playback->subtitle_count = 0;
	playback->subtitle_index = -1;
	for (int i=0; i<MAX_AUDIO_COUNT; i++)
	{
		playback->audio_bin[i].type = RTK_UNKNOWN_AUDIO;
	}
	playback->audio_count = 0;
	playback->audio_index = -1;
}
