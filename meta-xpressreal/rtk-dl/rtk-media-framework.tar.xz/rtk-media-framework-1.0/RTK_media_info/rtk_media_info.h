#ifndef __RTK_MEDIA_INFO__
#define __RTK_MEDIA_INFO__

#include <stdbool.h>

#define MAX_STR_LEN 64
#define STREAM_INFO_LEN 128

enum rtk_stream_type {
	RTK_UNKNOWN_TYPE,
	RTK_CONTAINER_TYPE,
	RTK_VIDEO_TYPE,
	RTK_AUDIO_TYPE,
	RTK_SUBTITLE_TYPE,
};

struct video_info {
	int width;
	int height;
	int mpegversion;
	int wmvversion;
	float frame_rate;
	int par_d;
	int par_n;
	bool interlace;
	unsigned int bitrate;
	unsigned int max_bitrate;
	unsigned int bit_depth;
	char profile[MAX_STR_LEN];
	char level[MAX_STR_LEN];
};

struct audio_info {
	int channel;
	int sample_rate;
	unsigned int bitrate;
	unsigned int max_bitrate;
};

struct subtitle_info {
	char format[MAX_STR_LEN];
};

struct rtk_stream_info {
	char stream_type_name[MAX_STR_LEN];
	enum rtk_stream_type stream_type;
	int stream_type_id;
	char mime_type[MAX_STR_LEN];
	char language[MAX_STR_LEN];
	char title[MAX_STR_LEN];
	struct video_info v_info;
	struct audio_info a_info;
	struct subtitle_info s_info;
};

struct rtk_media_info {
	int info_count;
	struct rtk_stream_info stream_info[STREAM_INFO_LEN];
};

#ifdef __cplusplus
extern "C" {
#endif
void get_media_info(char *filename, struct rtk_media_info *info, bool only_once);
void list_media_info(struct rtk_media_info *info);
#ifdef __cplusplus
}
#endif

#endif // __RTK_MEDIA_INFO
