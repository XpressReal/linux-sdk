#include <stdio.h>
#include <stdlib.h>
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <stdlib.h>
#include <glib.h>
#include <gst/gst.h>
#include <gst/pbutils/pbutils.h>
#include <gst/audio/audio.h>
#include "rtk_media_info.h"
#include <string.h>
#ifdef DEBUG
# define DEBUG_PRINT(format, args...) printf(format, ##args)
#else
# define DEBUG_PRINT(format, args...) do {} while (0)
#endif

static void fill_stream_type_info(const char *name, int id, struct rtk_stream_info *stream_info)
{
	stream_info->stream_type_id = id;
	strncpy(stream_info->stream_type_name, name, MAX_STR_LEN - 1);

	if (strncmp(stream_info->stream_type_name, "container", strlen("container")) == 0)
		stream_info->stream_type = RTK_CONTAINER_TYPE;
	else if (strncmp(stream_info->stream_type_name, "video", strlen("video")) == 0)
		stream_info->stream_type = RTK_VIDEO_TYPE;
	else if (strncmp(stream_info->stream_type_name, "audio", strlen("audio")) == 0)
		stream_info->stream_type = RTK_AUDIO_TYPE;
	else if (strncmp(stream_info->stream_type_name, "subtitles", strlen("subtitles")) == 0)
		stream_info->stream_type = RTK_SUBTITLE_TYPE;
	else
		stream_info->stream_type = RTK_UNKNOWN_TYPE;

	DEBUG_PRINT("%s#%d\n", stream_info->stream_type_name, stream_info->stream_type_id);
}

static void fill_tag_foreach(const GstTagList *tags, const gchar *tag, gpointer user_data)
{
	GValue val = { 0, };
	gchar *str;
	struct rtk_stream_info *stream_info = (struct rtk_stream_info *)user_data;

	if (!gst_tag_list_copy_value (&val, tags, tag))
		return;

	if (G_VALUE_HOLDS_STRING (&val)) {
		str = g_value_dup_string (&val);
	} else if (G_VALUE_TYPE (&val) == GST_TYPE_SAMPLE) {
		GstSample *sample = gst_value_get_sample (&val);
		GstBuffer *img = gst_sample_get_buffer (sample);
		GstCaps *caps = gst_sample_get_caps (sample);

		if (img) {
			if (caps) {
				gchar *caps_str;

				caps_str = gst_caps_to_string (caps);
				str = g_strdup_printf ("buffer of %" G_GSIZE_FORMAT " bytes, "
						"type: %s", gst_buffer_get_size (img), caps_str);
				g_free (caps_str);
			} else {
				str = g_strdup_printf ("buffer of %" G_GSIZE_FORMAT " bytes",
				gst_buffer_get_size (img));
			}
		} else {
			str = g_strdup ("NULL buffer");
		}
	} else {
		str = gst_value_serialize (&val);
	}

	if (strncmp(gst_tag_get_nick (tag), "language code", strlen("language code")) == 0)
		strncpy(stream_info->language, str, MAX_STR_LEN - 1);
	else if (strncmp(gst_tag_get_nick (tag), "title", strlen("title")) == 0)
		strncpy(stream_info->title, str, MAX_STR_LEN - 1);
}

static void fill_tag_info(GstDiscovererStreamInfo * info, struct rtk_stream_info *stream_info)
{
	const GstTagList *tags;
	tags = gst_discoverer_stream_info_get_tags (info);

	if (tags) {
		gst_tag_list_foreach (tags, fill_tag_foreach, stream_info);
	}
}

static void fill_video_info(GstDiscovererStreamInfo * info, GstStructure *structure, struct rtk_stream_info *stream_info)
{
	struct video_info *v_info = &stream_info->v_info;
	gint fps_n = 0, fps_d = 0;
	const gchar *s;

	if (structure) {
		strncpy(stream_info->mime_type, gst_structure_get_name(structure), strlen(gst_structure_get_name(structure)));
		gst_structure_get_int(structure, "width", &v_info->width);
		gst_structure_get_int(structure, "height", &v_info->height);
		gst_structure_get_int(structure, "mpegversion", &v_info->mpegversion);
		gst_structure_get_int(structure, "wmvversion", &v_info->wmvversion);
		gst_structure_get_uint(structure, "bit-depth-chroma", &v_info->bit_depth);

		gst_structure_get_fraction (structure, "framerate", &fps_n, &fps_d);
		if (fps_d != 0)
			v_info->frame_rate = fps_n/fps_d;

		gst_structure_get_fraction (structure, "pixel-aspect-ratio", &v_info->par_n, &v_info->par_d);

		if ((s = gst_structure_get_string (structure, "interlace-mode")))
		{
			if (strncmp(s, "progressive", strlen("progressive")) == 0)
				v_info->interlace = false;
			else
				v_info->interlace = true;
		}

		if ((s = gst_structure_get_string (structure, "profile")))
		{
			strncpy(v_info->profile, s, MAX_STR_LEN - 1);
		}

		if ((s = gst_structure_get_string (structure, "level")))
		{
			strncpy(v_info->level, s, MAX_STR_LEN - 1);
		}
	}

	fill_tag_info(info, stream_info);
	DEBUG_PRINT("\tmime type:%s\n", stream_info->mime_type);
	DEBUG_PRINT("\tlanguage:%s\n", stream_info->language);
	DEBUG_PRINT("\ttitle:%s\n", stream_info->title);
	DEBUG_PRINT("\twidth:%d height:%d\n", v_info->width, v_info->height);
	DEBUG_PRINT("\tframerate:%f\n", v_info->frame_rate);
	DEBUG_PRINT("\taspect_ratio:%d/%d\n", v_info->par_n, v_info->par_d);
	DEBUG_PRINT("\tbit_depth:%d\n", v_info->bit_depth);
	DEBUG_PRINT("\tinterlace:%d\n", v_info->interlace);
	DEBUG_PRINT("\tmpegversion:%d\n", v_info->mpegversion);
	DEBUG_PRINT("\twmvversion:%d\n", v_info->wmvversion);
	DEBUG_PRINT("\tprofile:%s level:%s\n", v_info->profile, v_info->level);
}

static void fill_container_info(GstDiscovererStreamInfo * info, GstStructure *structure, struct rtk_stream_info *stream_info)
{
	if (structure) {
		strncpy(stream_info->mime_type, gst_structure_get_name(structure), strlen(gst_structure_get_name(structure)));
	}

	DEBUG_PRINT("\tmime type:%s\n", stream_info->mime_type);
}

static void fill_subtitle_info(GstDiscovererStreamInfo * info, GstStructure *structure, struct rtk_stream_info *stream_info)
{
	struct subtitle_info *s_info = &stream_info->s_info;
	const gchar *s;
	if (structure) {
		strncpy(stream_info->mime_type, gst_structure_get_name(structure), strlen(gst_structure_get_name(structure)));
		if ((s = gst_structure_get_string (structure, "format")))
		{
			strncpy(s_info->format, s, MAX_STR_LEN - 1);
		} else {
			strncpy(s_info->format, "none", MAX_STR_LEN - 1);
		}
	}

	fill_tag_info(info, stream_info);
	DEBUG_PRINT("\tmime type:%s\n", stream_info->mime_type);
	DEBUG_PRINT("\tlanguage:%s\n", stream_info->language);
	DEBUG_PRINT("\ttitle:%s\n", stream_info->title);
	DEBUG_PRINT("\tformat:%s\n", s_info->format);
}

static void fill_audio_info(GstDiscovererStreamInfo * info, GstStructure *structure, struct rtk_stream_info *stream_info)
{
	struct audio_info *a_info = &stream_info->a_info;
	if (structure) {
		strncpy(stream_info->mime_type, gst_structure_get_name(structure), strlen(gst_structure_get_name(structure)));
		gst_structure_get_int(structure, "rate", &a_info->sample_rate);
		gst_structure_get_int(structure, "channels", &a_info->channel);
	}

	fill_tag_info(info, stream_info);
	DEBUG_PRINT("\tmime type:%s\n", stream_info->mime_type);
	DEBUG_PRINT("\tlanguage:%s\n", stream_info->language);
	DEBUG_PRINT("\ttitle:%s\n", stream_info->title);
	DEBUG_PRINT("\tsample_rate:%d\n", a_info->sample_rate);
	DEBUG_PRINT("\tchannels:%d\n", a_info->channel);
}

static void collect_stream_info(GstDiscovererStreamInfo * info, struct rtk_stream_info *stream_info)
{
	GstCaps *caps;
	GstStructure *structure = NULL;
	caps = gst_discoverer_stream_info_get_caps (info);

	if (caps) {
		structure = gst_caps_get_structure (caps, 0);
	}

	fill_stream_type_info(gst_discoverer_stream_info_get_stream_type_nick (info), gst_discoverer_stream_info_get_stream_number (info), stream_info);
	if (stream_info->stream_type == RTK_CONTAINER_TYPE)	{
		fill_container_info(info, structure, stream_info);
	} else if (stream_info->stream_type == RTK_VIDEO_TYPE) {
		fill_video_info(info, structure, stream_info);
	} else if (stream_info->stream_type == RTK_SUBTITLE_TYPE) {
		fill_subtitle_info(info, structure, stream_info);
	} else if (stream_info->stream_type == RTK_AUDIO_TYPE) {
		fill_audio_info(info, structure, stream_info);
	}

	if (caps)
		gst_caps_unref(caps);
}

static void collect_info(GstDiscovererInfo * info, struct rtk_media_info *media_info, GError * err)
{
	GstDiscovererResult result;
	GstDiscovererStreamInfo *sinfo;	
	media_info->info_count = 0;

	result = gst_discoverer_info_get_result (info);
	switch (result) {
		case GST_DISCOVERER_OK:
			break;
		case GST_DISCOVERER_URI_INVALID:
			printf("uri is not vaild\n");
			break;
		case GST_DISCOVERER_ERROR:
			printf("discover error\n");
			printf(" %s\n", err->message);
			break;
		case GST_DISCOVERER_TIMEOUT:
			printf("discover timeout\n");
			break;
		case GST_DISCOVERER_BUSY:
			printf("discover busy\n");
			break;
/*
		case GST_DISCOVERER_MISSING_PLUGINS:
		{
			gint i = 0;
			const gchar **installer_details = gst_discoverer_info_get_missing_elements_installer_details (info);

			printf ("Missing plugins\n");

			while (installer_details[i]) {
				printf (" (%s)\n", installer_details[i]);
				i++;
			}
			break;
		}
*/
		default:
			break;
	}

	if ((sinfo = gst_discoverer_info_get_stream_info (info))) {
		struct rtk_stream_info *stream_info_data = &media_info->stream_info[media_info->info_count];

		collect_stream_info(sinfo, stream_info_data);
		media_info->info_count++;
		if (media_info->info_count >= STREAM_INFO_LEN) {
			printf("stream_info more than array size\n");
			goto release;
		}

		if (GST_IS_DISCOVERER_CONTAINER_INFO (sinfo)) {
			GList *tmp, *streams;

			streams = gst_discoverer_container_info_get_streams (GST_DISCOVERER_CONTAINER_INFO(sinfo));
			for (tmp = streams; tmp; tmp = tmp->next) {
				GstDiscovererStreamInfo *tmpinf = (GstDiscovererStreamInfo *) tmp->data;
				
				stream_info_data = &media_info->stream_info[media_info->info_count];
				collect_stream_info(tmpinf, stream_info_data);
				media_info->info_count++;
				if (media_info->info_count >= STREAM_INFO_LEN) {
					printf("stream_info more than array size\n");
					break;
				}
			}
			gst_discoverer_stream_info_list_free (streams);
		}
	}

release:
	if (sinfo)
		gst_discoverer_stream_info_unref (sinfo);
}

static void process_file(GstDiscoverer *dc, char *filename, struct rtk_media_info *media_info)
{
	GError *err = NULL;
	GDir *dir;
	gchar *uri, *path;
	GstDiscovererInfo *info;

	if (!gst_uri_is_valid (filename)) {
		if ((dir = g_dir_open (filename, 0, NULL))) {
			const gchar *entry;

			while ((entry = g_dir_read_name (dir))) {
				gchar *path;
				path = g_strconcat (filename, G_DIR_SEPARATOR_S, entry, NULL);
				process_file (dc, path, media_info);
				g_free (path);
			}

			g_dir_close (dir);
			return;
		}

		if (!g_path_is_absolute (filename)) {
			gchar *cur_dir;

			cur_dir = g_get_current_dir ();
			path = g_build_filename (cur_dir, filename, NULL);
			g_free (cur_dir);
		} else {
			path = g_strdup (filename);
		}

		uri = g_filename_to_uri (path, NULL, &err);
		g_free (path);
		path = NULL;

		if (err) {
			printf ("Couldn't convert filename to URI: %s\n", err->message);
			g_clear_error (&err);
			return;
		}
	} else {
		uri = g_strdup (filename);
	}

	info = gst_discoverer_discover_uri (dc, uri, &err);

	if (!info)
	{
		printf("Could not Discover URI\n");
		printf(" %s\n", err->message);
		return;
	}

	collect_info(info, media_info, err);

	if (info)
		gst_discoverer_info_unref (info);

	g_clear_error (&err);
	g_free (uri);
}

void get_media_info(char *filename, struct rtk_media_info *info, bool only_once)
{
	GError *err = NULL;
	GstDiscoverer *dc;
	gint timeout = 10;

	if (filename == NULL || info == NULL)
		return;

	gst_init(NULL, NULL);
	memset(info, 0, sizeof(struct rtk_media_info));
	dc = gst_discoverer_new (timeout * GST_SECOND, &err);
	if (G_UNLIKELY (dc == NULL)) {
		g_print ("Error initializing: %s\n", err->message);
		g_clear_error (&err);
		exit (1);
	}

	process_file(dc, filename, info);
	g_object_unref(dc);
	if (only_once) {
		gst_deinit();
	}
}

void list_media_info(struct rtk_media_info *info)
{
	if (info == NULL)
		return;

	for (int i = 0; i < info->info_count; i++) {
		struct rtk_stream_info *stream_info = &info->stream_info[i];
		printf("%s#%d\n", stream_info->stream_type_name, stream_info->stream_type_id);
		printf("\tmime type:%s\n", stream_info->mime_type);
		switch(stream_info->stream_type) {
			case RTK_SUBTITLE_TYPE:
				printf("\tlanguage:%s\n", stream_info->language);
				printf("\ttitle:%s\n", stream_info->title);
				printf("\tformat:%s\n", stream_info->s_info.format);
				break;
			case RTK_VIDEO_TYPE:
				printf("\tlanguage:%s\n", stream_info->language);
				printf("\ttitle:%s\n", stream_info->title);
				printf("\twidth:%d height:%d\n", stream_info->v_info.width, stream_info->v_info.height);
				printf("\tframerate:%f\n", stream_info->v_info.frame_rate);
				printf("\taspect_ratio:%d/%d\n", stream_info->v_info.par_n, stream_info->v_info.par_d);
				printf("\tbit_depth:%d\n", stream_info->v_info.bit_depth);
				printf("\tinterlace:%d\n", stream_info->v_info.interlace);
				printf("\tmpegversion:%d\n", stream_info->v_info.mpegversion);
				printf("\twmvversion:%d\n", stream_info->v_info.wmvversion);
				printf("\tprofile:%s level:%s\n", stream_info->v_info.profile, stream_info->v_info.level);
				break;
			case RTK_AUDIO_TYPE:
				printf("\tlanguage:%s\n", stream_info->language);
				printf("\ttitle:%s\n", stream_info->title);
				printf("\tsample_rate:%d\n", stream_info->a_info.sample_rate);
				printf("\tchannls:%d\n", stream_info->a_info.channel);
				break;
			default:
				break;
		}
	}
}