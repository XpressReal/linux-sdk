#include "rtk_media_cap.h"
#include <string.h>
#include <ctype.h>

#ifdef DEBUG
# define DEBUG_PRINT(format, args...) printf(format, ##args)
#else
# define DEBUG_PRINT(format, args...) do {} while (0)
#endif


static int rtk_subtitle_cap_getinfo(struct rtk_cap_instance *instance)
{
	struct json_object *soc = NULL, *type = NULL, *codec = NULL;
	int ret = 0;

	soc = json_object_object_get(instance->cap, "soc");
	if (soc)
		strncpy(instance->soc, json_object_get_string(soc), strlen(json_object_get_string(soc)));

	type = json_object_object_get(instance->cap, "type");
	if (type) {
		if (strncmp("subtitle", json_object_get_string(type), strlen("subtitle")) == 0) {
			instance->type = RTK_SUBTITLE_CAP;
		} else {
			ret = -1;
			goto finish;
		}
	}

	codec = json_object_object_get(instance->cap, "codec");
	if (codec) {
		struct rtk_subtitle_cap *subtitle_cap_ptr;
		instance->cap_count = json_object_array_length(codec);
		instance->cap_data = malloc(sizeof(struct rtk_subtitle_cap) * instance->cap_count);
		subtitle_cap_ptr = (struct rtk_subtitle_cap *)instance->cap_data;

		for (int i = 0; i < instance->cap_count; i++) {
			struct json_object *index = NULL, *value = NULL;
			struct rtk_subtitle_cap *subtitle_cap = &subtitle_cap_ptr[i];

			index = json_object_array_get_idx(codec, i);
			if (index) {
				value = json_object_object_get(index, "mime_type");
				if (value) {
					strncpy(subtitle_cap->mime_type, json_object_get_string(value), strlen(json_object_get_string(value)));
				}
			}
		}
	}

finish:
	return ret;
}

static int rtk_video_cap_getinfo(struct rtk_cap_instance *instance)
{
	struct json_object *soc = NULL, *type = NULL, *codec = NULL;
	int ret = 0;

	soc = json_object_object_get(instance->cap, "soc");
	if (soc)
		strncpy(instance->soc, json_object_get_string(soc), strlen(json_object_get_string(soc)));

	type = json_object_object_get(instance->cap, "type");

	if (type) {
		if (strncmp("video", json_object_get_string(type), strlen("video")) == 0) {
			instance->type = RTK_VIDEO_CAP;
		} else {
			ret = -1;
			goto finish;
		}
	}

	codec = json_object_object_get(instance->cap, "codec");

	if (codec) {
		struct rtk_video_cap *video_cap_ptr;
		instance->cap_count = json_object_array_length(codec);
		instance->cap_data = malloc(sizeof(struct rtk_video_cap) * instance->cap_count);
		video_cap_ptr = (struct rtk_video_cap *)instance->cap_data;

		for (int i = 0; i < instance->cap_count; i++) {
			struct json_object *index = NULL, *value = NULL;
			struct rtk_video_cap *video_cap = &video_cap_ptr[i];

			index = json_object_array_get_idx(codec, i);
			if (index) {
				value = json_object_object_get(index, "mime_type");
				if (value) {
					strncpy(video_cap->mime_type, json_object_get_string(value), strlen(json_object_get_string(value)));
				}
				value = json_object_object_get(index, "max_width");
				if (value)
					video_cap->max_width = json_object_get_int(value);

				value = json_object_object_get(index, "max_height");
				if (value)
					video_cap->max_height = json_object_get_int(value);

				value = json_object_object_get(index, "mpegversion");
				if (value)
					video_cap->mpegversion = json_object_get_int(value);

				value = json_object_object_get(index, "profile");
				if (value) {
					struct json_object *profile_index;
					video_cap->profile_count = json_object_array_length(value);
					for (int i = 0; i < video_cap->profile_count; i++) {
						profile_index = json_object_array_get_idx(value, i);
						strncpy(video_cap->profile[i], json_object_get_string(profile_index), strlen(json_object_get_string(profile_index)));
					}
				}

				value = json_object_object_get(index, "level");
				if (value) {
					struct json_object *level_index;
					video_cap->level_count = json_object_array_length(value);
					for (int i = 0; i < video_cap->level_count; i++) {
						level_index = json_object_array_get_idx(value, i);
						strncpy(video_cap->level[i], json_object_get_string(level_index), strlen(json_object_get_string(level_index)));
					}
				}

				value = json_object_object_get(index, "wmvversion");
				if (value)
					video_cap->wmvversion = json_object_get_int(value);

				value = json_object_object_get(index, "max_bit_depth");
				if (value)
					video_cap->max_bit_depth = json_object_get_int(value);

				value = json_object_object_get(index, "input_format");
				if (value)
					strncpy(video_cap->input_format, json_object_get_string(value), strlen(json_object_get_string(value)));

				value = json_object_object_get(index, "output_format");
				if (value)
					strncpy(video_cap->output_format, json_object_get_string(value), strlen(json_object_get_string(value)));
			}
		}
	}
finish:
	return ret;
}

int rtk_subtitle_cap_check(struct rtk_cap_instance *instance, struct rtk_subtitle_cap *subtitle_cap)
{
	struct rtk_subtitle_cap *subtitle_cap_ptr = NULL, *tmp_cap = NULL;

	if (instance == NULL) {
		printf("no instance\n");
		return -1;
	}

	if (strlen(subtitle_cap->mime_type) == 0) {
		printf("mime_type should be set\n");
		return -1;
	}

	subtitle_cap_ptr = (struct rtk_subtitle_cap *)instance->cap_data;
	for (int i = 0; i < instance->cap_count; i++)
	{
		tmp_cap = &subtitle_cap_ptr[i];
		if (strcmp(subtitle_cap->mime_type, tmp_cap->mime_type) == 0)
			break;

		tmp_cap = NULL;
	}

	if (tmp_cap == NULL) {
		printf("mime_type:%s isn't supported\n", subtitle_cap->mime_type);
		return -1;
	}

	return 0;
}

static int mpeg_codec_check(struct rtk_cap_instance *instance, struct rtk_video_cap *video_cap)
{
	struct rtk_video_cap *video_cap_ptr = NULL, *tmp_cap = NULL;
	video_cap_ptr = (struct rtk_video_cap *)instance->cap_data;

	if (video_cap->mpegversion == 0) {
		printf("mime_type:%s need to indicate mpegversion [1, 2, 4]\n", video_cap->mime_type);
		return -1;
	}

	for (int i = 0 ; i < instance->cap_count; i++) {
		tmp_cap = &video_cap_ptr[i];
		if (strcmp(video_cap->mime_type, tmp_cap->mime_type) == 0 && video_cap->mpegversion == tmp_cap->mpegversion)
				break;

		tmp_cap = NULL;
	}

	if (tmp_cap == NULL) {
		printf("mime_type:%s mpegversion:%d isn't supported\n", video_cap->mime_type, video_cap->mpegversion);
		return -1;
	}

	if (video_cap->max_width != 0 && video_cap->max_height != 0) {
		if (video_cap->max_width * video_cap->max_height > tmp_cap->max_width * tmp_cap->max_height) {
			printf("mime_type:%s max resolution over spec:%dx%d\n", video_cap->mime_type, video_cap->max_width, video_cap->max_height);
			return -1;
		}
	} else if (video_cap->max_width != 0) {
		if (video_cap->max_width > tmp_cap->max_width) {
			printf("mime_type:%s max width over spec:%d\n", video_cap->mime_type, video_cap->max_width);
			return -1;
		}
	} else if (video_cap->max_height != 0) {
		if (video_cap->max_height > tmp_cap->max_height) {
			printf("mime_type:%s max height over spec:%d\n", video_cap->mime_type, video_cap->max_height);
			return -1;
		}
	}

	if (strlen(video_cap->profile[0]) != 0) {
		if (tmp_cap->profile_count != 0) {
			int profile_support = 0;

			for (int i = 0; i < tmp_cap->profile_count; i++) {
				if (strcmp(video_cap->profile[0], tmp_cap->profile[i]) == 0) {
					profile_support = 1;
					break;
				}
			}

			if (profile_support == 0) {
				printf("mime_type:%s profile over spec:%s\n", video_cap->mime_type, video_cap->profile[0]);
				return -1;
			}
		}
	}

	if (strlen(video_cap->level[0]) != 0) {
		if (tmp_cap->level_count != 0) {
			int level_support = 0;

			for (int i = 0; i < tmp_cap->level_count; i++) {
				if (strcmp(video_cap->level[0], tmp_cap->level[i]) == 0) {
					level_support = 1;
					break;
				}
			}

			if (level_support == 0) {
				printf("mime_type:%s level over spec:%s\n", video_cap->mime_type, video_cap->level[0]);
				return -1;
			}
		}
	}

	if (video_cap->max_bit_depth != 0) {
		if (video_cap->max_bit_depth > tmp_cap->max_bit_depth) {
			printf("mime_type:%s max_bit_depth over spec:%d\n", video_cap->mime_type, video_cap->max_bit_depth);
			return -1;
		}
	}

	if (strlen(video_cap->input_format) != 0) {
		if (strcmp(video_cap->input_format, tmp_cap->input_format) != 0) {
			printf("mime_type:%s input_format over spec:%s\n", video_cap->mime_type, video_cap->input_format);
			return -1;
		}
	}

	if (strlen(video_cap->output_format) != 0) {
		if (strcmp(video_cap->output_format, tmp_cap->output_format) != 0) {
			printf("mime_type:%s output_format over spec:%s\n", video_cap->mime_type, video_cap->output_format);
			return -1;
		}
	}

	return 0;

}

static int wmv_codec_check(struct rtk_video_cap *video_cap, struct rtk_video_cap *tmp_cap)
{
	if (video_cap->max_width != 0 && video_cap->max_height != 0) {
		if (video_cap->max_width * video_cap->max_height > tmp_cap->max_width * tmp_cap->max_height) {
			printf("mime_type:%s max resolution over spec:%dx%d\n", video_cap->mime_type, video_cap->max_width, video_cap->max_height);
			return -1;
		}
	} else if (video_cap->max_width != 0) {
		if (video_cap->max_width > tmp_cap->max_width) {
			printf("mime_type:%s max width over spec:%d\n", video_cap->mime_type, video_cap->max_width);
			return -1;
		}
	} else if (video_cap->max_height != 0) {
		if (video_cap->max_height > tmp_cap->max_height) {
			printf("mime_type:%s max height over spec:%d\n", video_cap->mime_type, video_cap->max_height);
			return -1;
		}
	}

	if (video_cap->wmvversion != 0) {
		if (video_cap->wmvversion > tmp_cap->wmvversion) {
			printf("mime_type:%s wmvversion over spec:%d\n", video_cap->mime_type, video_cap->wmvversion);
			return -1;
		}
	}

	if (video_cap->max_bit_depth != 0) {
		if (video_cap->max_bit_depth > tmp_cap->max_bit_depth) {
			printf("mime_type:%s max_bit_depth over spec:%d\n", video_cap->mime_type, video_cap->max_bit_depth);
			return -1;
		}
	}

	if (strlen(video_cap->input_format) != 0) {
		if (strcmp(video_cap->input_format, tmp_cap->input_format) != 0) {
			printf("mime_type:%s input_format over spec:%s\n", video_cap->mime_type, video_cap->input_format);
			return -1;
		}
	}

	if (strlen(video_cap->output_format) != 0) {
		if (strcmp(video_cap->output_format, tmp_cap->output_format) != 0) {
			printf("mime_type:%s output_format over spec:%s\n", video_cap->mime_type, video_cap->output_format);
			return -1;
		}
	}
	return 0;
}

static int normal_codec_check(struct rtk_video_cap *video_cap, struct rtk_video_cap *tmp_cap)
{
	if (video_cap->max_width != 0 && video_cap->max_height != 0) {
		if (video_cap->max_width * video_cap->max_height > tmp_cap->max_width * tmp_cap->max_height) {
			printf("mime_type:%s max resolution over spec:%dx%d\n", video_cap->mime_type, video_cap->max_width, video_cap->max_height);
			return -1;
		}
	} else if (video_cap->max_width != 0) {
		if (video_cap->max_width > tmp_cap->max_width) {
			printf("mime_type:%s max width over spec:%d\n", video_cap->mime_type, video_cap->max_width);
			return -1;
		}
	} else if (video_cap->max_height != 0) {
		if (video_cap->max_height > tmp_cap->max_height) {
			printf("mime_type:%s max height over spec:%d\n", video_cap->mime_type, video_cap->max_height);
			return -1;
		}
	}

	if (strlen(video_cap->profile[0]) != 0) {
		if (tmp_cap->profile_count != 0) {
			int profile_support = 0;

			for (int i = 0; i < tmp_cap->profile_count; i++) {
				if (strcmp(video_cap->profile[0], tmp_cap->profile[i]) == 0) {
					profile_support = 1;
					break;
				}
			}

			if (profile_support == 0) {
				printf("mime_type:%s profile over spec:%s\n", video_cap->mime_type, video_cap->profile[0]);
				return -1;
			}
		}
	}

	if (strlen(video_cap->level[0]) != 0) {
		if (tmp_cap->level_count != 0) {
			int level_support = 0;

			for (int i = 0; i < tmp_cap->level_count; i++) {
				if (strcmp(video_cap->level[0], tmp_cap->level[i]) == 0) {
					level_support = 1;
					break;
				}
			}

			if (level_support == 0) {
				printf("mime_type:%s level over spec:%s\n", video_cap->mime_type, video_cap->level[0]);
				return -1;
			}
		}
	}

	if (video_cap->max_bit_depth != 0) {
		if (video_cap->max_bit_depth > tmp_cap->max_bit_depth) {
			printf("mime_type:%s max_bit_depth over spec:%d\n", video_cap->mime_type, video_cap->max_bit_depth);
			return -1;
		}
	}

	if (strlen(video_cap->input_format) != 0) {
		if (strcmp(video_cap->input_format, tmp_cap->input_format) != 0) {
			printf("mime_type:%s input_format over spec:%s\n", video_cap->mime_type, video_cap->input_format);
			return -1;
		}
	}

	if (strlen(video_cap->output_format) != 0) {
		if (strcmp(video_cap->output_format, tmp_cap->output_format) != 0) {
			printf("mime_type:%s output_format over spec:%s\n", video_cap->mime_type, video_cap->output_format);
			return -1;
		}
	}

	return 0;
}


int rtk_video_cap_check(struct rtk_cap_instance *instance, struct rtk_video_cap *video_cap)
{
	int ret = -1;
	struct rtk_video_cap *video_cap_ptr = NULL, *tmp_cap = NULL;
	if (instance == NULL) {
		printf("no instance\n");
		return -1;
	}

	if (strlen(video_cap->mime_type) == 0) {
		printf("mime_type should be set\n");
		return -1;
	}

	video_cap_ptr = (struct rtk_video_cap *)instance->cap_data;

	for (int i = 0 ; i < instance->cap_count; i++) {
		tmp_cap = &video_cap_ptr[i];
		if (strcmp(video_cap->mime_type, tmp_cap->mime_type) == 0)
				break;

		tmp_cap = NULL;
	}

	if (tmp_cap == NULL) {
		printf("mime_type:%s isn't supported\n", video_cap->mime_type);
		return -1;
	}

	if (strcmp(video_cap->mime_type, "video/mpeg") == 0)
		ret = mpeg_codec_check(instance, video_cap);
	else if (strcmp(video_cap->mime_type, "video/x-wmv") == 0)
		ret = wmv_codec_check(video_cap, tmp_cap);
	else
		ret = normal_codec_check(video_cap, tmp_cap);


	return ret;
}

void rtk_media_cap_init(struct rtk_cap_instance *instance, enum rtk_cap_query_type type)
{
	int ret = 0;
	char *conf = NULL;

	if (instance == NULL) {
		printf("%s instance is null\n", __func__);
		return;
	}

	switch (type) {
		case RTK_VIDEO_CAP:
			instance->cap = json_object_from_file(VIDEO_CAP_CONF);
			if (instance->cap)
				ret = rtk_video_cap_getinfo(instance);
			conf = VIDEO_CAP_CONF;
			break;
		case RTK_AUDIO_CAP:
			instance->cap = json_object_from_file(AUDIO_CAP_CONF);
			conf = AUDIO_CAP_CONF;
			printf("audio cap is not supported now\n");
			ret = -1;
			break;
		case RTK_SUBTITLE_CAP:
			instance->cap = json_object_from_file(SUBTITLE_CAP_CONF);
			if (instance->cap)
				ret = rtk_subtitle_cap_getinfo(instance);
			conf = SUBTITLE_CAP_CONF;
			break;
		default:
			printf("unknow query cap type:%d\n", type);
			return;
	}

	if (instance->cap == NULL) {
		printf("can't get config file:%s\n", conf);
		return;
	}

	if (ret != 0) {
		printf("fail to get media cap with type:%d\n", type);
	}
}

void rtk_media_cap_uninit(struct rtk_cap_instance *instance)
{
	if (instance) {
		if (instance->cap)
			json_object_put(instance->cap);

		if (instance->cap_data)
			free(instance->cap_data);
	}
}

void list_subtitle_cap_info(struct rtk_subtitle_cap *subtitle_cap)
{
	if (subtitle_cap == NULL)
		return;
	printf("\tmime_type: %s\n", subtitle_cap->mime_type);
	printf("\n");
}

void list_video_cap_info(struct rtk_video_cap *video_cap)
{
	if (video_cap == NULL)
		return;

	printf("\tmime_type: %s\n", video_cap->mime_type);
	printf("\t\t--max_width: %d\n", video_cap->max_width);
	printf("\t\t--max_height: %d\n", video_cap->max_height);
	if (video_cap->mpegversion != 0)
		printf("\t\t--mpegversion: %d\n", video_cap->mpegversion);

	if (video_cap->profile_count != 0) {
		printf("\t\t--profile: ");
		for (int k = 0; k < video_cap->profile_count; k++) {
			if (k == video_cap->profile_count - 1)
				printf("%s\n", video_cap->profile[k]);
			else
				printf("%s, ", video_cap->profile[k]);

		}
	}

	if (video_cap->level_count != 0) {
		printf("\t\t--level: ");
		for (int k = 0; k < video_cap->level_count; k++) {
		if (k == video_cap->level_count - 1)
			printf("%s\n", video_cap->level[k]);
		else
			printf("%s, ", video_cap->level[k]);
		}
		printf("\n");
	}

	if (video_cap->wmvversion != 0)
		printf("\t\t--wmvversion: %d\n", video_cap->wmvversion);

	if (video_cap->max_bit_depth != 0)
		printf("\t\t--max_bit_depth: %d\n", video_cap->max_bit_depth);
	if (strlen(video_cap->input_format) != 0)
		printf("\t\t--input_format: %s\n", video_cap->input_format);
	if (strlen(video_cap->output_format) != 0)
		printf("\t\t--output_format: %s\n", video_cap->output_format);

	printf("\n");
}

void list_cap_instance_info(struct rtk_cap_instance *instance)
{
	if (instance == NULL)
		return;

	if (instance->type == RTK_VIDEO_CAP) {
		printf("type: video\n");
		printf("soc: %s\n", instance->soc);
		struct rtk_video_cap *video_cap_ptr = (struct rtk_video_cap *)instance->cap_data;
		for (int i = 0; i < instance->cap_count; i++)
		{
			list_video_cap_info(&video_cap_ptr[i]);
		}
	}
	else if (instance->type == RTK_AUDIO_CAP) {
		printf("type: audio\n");
		printf("soc: %s\n", instance->soc);
	}
	else if (instance->type == RTK_SUBTITLE_CAP) {
		printf("type: subtitle\n");
		printf("soc: %s\n", instance->soc);
		struct rtk_subtitle_cap *subtitle_cap_ptr = (struct rtk_subtitle_cap *)instance->cap_data;
		for (int i = 0; i < instance->cap_count; i++)
		{
			list_subtitle_cap_info(&subtitle_cap_ptr[i]);
		}
	}
	else if (instance->type == RTK_UNKNOW_CAP) {
		printf("type: unknown\n");
		printf("soc: %s\n", instance->soc);
	}
	else {
		printf("type: undefined %d\n", instance->type);
		printf("soc: %s\n", instance->soc);
	}
}
