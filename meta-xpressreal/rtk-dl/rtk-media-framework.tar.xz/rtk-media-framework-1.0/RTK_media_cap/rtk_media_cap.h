#ifndef __RTK_MEDIA_CAP__
#define __RTK_MEDIA_CAP__
#include <stdio.h>
#include <stdlib.h>
#include <json-c/json.h>
#define VIDEO_CAP_CONF "/etc/rtk_video_cap.json"
#define AUDIO_CAP_CONF "/etc/rtk_audio_cap.json"
#define SUBTITLE_CAP_CONF "/etc/rtk_subtitle_cap.json"
#define STR_LEN 128
#define MAX_PROFILE_COUNT 10
#define MAX_LEVEL_COUNT 32

enum rtk_cap_query_type {
	RTK_UNKNOW_CAP,
	RTK_VIDEO_CAP,
	RTK_AUDIO_CAP,
	RTK_SUBTITLE_CAP,
};

struct rtk_video_cap {
	char mime_type[STR_LEN];
	int max_width;
	int max_height;
	int mpegversion;
	int profile_count;
	char profile[MAX_PROFILE_COUNT][STR_LEN];
	int level_count;
	char level[MAX_LEVEL_COUNT][STR_LEN];
	int wmvversion;
	int max_bit_depth;
	char input_format[STR_LEN];
	char output_format[STR_LEN];
};

struct rtk_subtitle_cap {
	char mime_type[STR_LEN];
};

struct rtk_cap_instance {
	json_object *cap;
	enum rtk_cap_query_type type;
	char soc[STR_LEN];
	int cap_count;
    void *cap_data;
};

#ifdef __cplusplus
extern "C" {
#endif
void rtk_media_cap_init(struct rtk_cap_instance *instance, enum rtk_cap_query_type type);
void rtk_media_cap_uninit(struct rtk_cap_instance *instance);
int rtk_video_cap_check(struct rtk_cap_instance *instance, struct rtk_video_cap *video_cap);
int rtk_subtitle_cap_check(struct rtk_cap_instance *instance, struct rtk_subtitle_cap *subtitle_cap);
void list_video_cap_info(struct rtk_video_cap *video_cap);
void list_subtitle_cap_info(struct rtk_subtitle_cap *subtitle_cap);
void list_cap_instance_info(struct rtk_cap_instance *instance);
#ifdef __cplusplus
}
#endif

#endif // end of __RTK_MEDIA_CAP__
