#include <stdio.h>
#include <stdlib.h>
#include "rtk_media_cap.h"
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <getopt.h>

void usage() {
	printf("--list [video | subtitle]: to list video or subtitle capability table\n");
	printf("--video_check : to check video capability\n");
	printf("--subtitle_check : to check subtitle capability\n");
	printf("--mime_type #type : to check mime_type\n");
	printf("--max_width #width : to check max_width\n");
	printf("--max_height #height : to check max_height\n");
	printf("--mpegversion #version : to check mpegversion\n");
	printf("--profile #profile : to check profile\n");
	printf("--level #level: to check level\n");
	printf("--wmvversion #version: to check wmvversion\n");
	printf("--max_bit_depth #bit_depth: to check max_bit_depth\n");
	printf("--input_format #format : to check input format\n");
	printf("--output_format #format : to check output format\n");
}

static char optstr[] = "a:b:c:d:e:f:g:h:i:jkl:m:";
static struct option opts[] = {
	{"list", 1, NULL, 'l'},
	{"video_check", 0, NULL, 'j'},
	{"subtitle_check", 0, NULL, 'k'},
	{"mime_type", 1, NULL, 'a'},
	{"max_width", 1, NULL, 'b'},
	{"max_height", 1, NULL, 'c'},
	{"mpegversion", 1, NULL, 'd'},
	{"profile", 1, NULL, 'e'},
	{"level", 1, NULL, 'f'},
	{"max_bit_depth", 1, NULL, 'g'},
	{"input_format", 1, NULL, 'h'},
    {"output_format", 1, NULL, 'i'},
	{"wmvversion", 1, NULL, 'm'}
};

int main(int argc, char **argv)
{
	int c;
	unsigned int args = 0;
	int list = 0;
	int video_check = 0;
	int subtitle_check = 0;
	int ret = 0;
	opterr = 0;
	char mime_type[STR_LEN] = {0};
	int max_width = 0;
	int max_height = 0;
	int mpegversion = 0;
	char profile[STR_LEN] = {0};
	char level[STR_LEN] = {0};
	int max_bit_depth = 0;
	char input_format[STR_LEN] = {0};
	char output_format[STR_LEN] = {0};
	char list_type[STR_LEN] = {0};
	int wmvversion = 0;

	while((c = getopt_long(argc, argv, optstr, opts, NULL)) != -1) {
		args++;
		switch (c) {
		case 'l':
			list = 1;
			strcpy(list_type, optarg);
			break;
		case 'j':
			video_check = 1;
			break;
		case 'k':
			subtitle_check = 1;
			break;
		case 'a':
			strcpy(mime_type, optarg);
			break;
		case 'b':
			max_width = atoi(optarg);
			break;
		case 'c':
			max_height = atoi(optarg);
			break;
		case 'd':
			mpegversion = atoi(optarg);
			break;
		case 'e':
			strcpy(profile, optarg);
			break;
		case 'f':
			strcpy(level, optarg);
			break;
		case 'g':
			max_bit_depth = atoi(optarg);
			break;
		case 'h':
			strcpy(input_format, optarg);
			break;
		case 'i':
			strcpy(output_format, optarg);
			break;
		case 'm':
			wmvversion = atoi(optarg);
			break;
		default:
			usage();
			return 0;
		}
	}

    if (args == 0) {
        usage();
    }

	struct rtk_cap_instance instance = {0};

	if (list) {
		if (strcmp(list_type, "video") == 0) {
			rtk_media_cap_init(&instance, RTK_VIDEO_CAP);
			list_cap_instance_info(&instance);
		} else if (strcmp(list_type, "subtitle") == 0) {
			rtk_media_cap_init(&instance, RTK_SUBTITLE_CAP);
			list_cap_instance_info(&instance);
		}
		goto uninit;
	}

	if (video_check) {
		struct rtk_video_cap video_cap = {0};
		strcpy(video_cap.mime_type, mime_type);
		video_cap.max_width = max_width;
		video_cap.max_height = max_height;
		video_cap.mpegversion = mpegversion;
		strcpy(video_cap.profile[0], profile);
		if(strlen(video_cap.profile[0]) != 0)
			video_cap.profile_count = 1;
		strcpy(video_cap.level[0], level);
		if(strlen(video_cap.level[0]) != 0)
			video_cap.level_count = 1;
		video_cap.max_bit_depth = max_bit_depth;
		strcpy(video_cap.input_format, input_format);
		strcpy(video_cap.output_format, output_format);
		video_cap.wmvversion = wmvversion;

		rtk_media_cap_init(&instance, RTK_VIDEO_CAP);

		ret = rtk_video_cap_check(&instance, &video_cap);
		if (ret == -1)
			printf("result : check fail\n");
		else
			printf("result : check success\n");

		goto uninit;
	}

	if (subtitle_check) {
		struct rtk_subtitle_cap subtitle_cap = {0};
		strcpy(subtitle_cap.mime_type, mime_type);
		rtk_media_cap_init(&instance, RTK_SUBTITLE_CAP);
		ret = rtk_subtitle_cap_check(&instance, &subtitle_cap);
		if (ret == -1)
			printf("result : check fail\n");
		else
			printf("result : check success\n");

		goto uninit;
	}
uninit:
	if (video_check || subtitle_check || list)
		rtk_media_cap_uninit(&instance);
	return 0;
}
