#ifndef _RTK_EDID_H_
#define _RTK_EDID_H_
#include <xf86drm.h>
#include <xf86drmMode.h>

#define EDID_BLOCK_LEN  128

/* CTA Data Block Tag Codes */
#define AUDIO_DATA_BLOCK                1
#define VIDEO_DATA_BLOCK                2
#define VENDOR_SPECIFIC_DATA_BLOCK      3
#define SPEAKER_ALLOCATION_DATA_BLOCK	4
#define VESA_DTC_DATA_BLOCK	            5
#define USE_EXTENDED_TAG	            7

/* Extended Tag Codes */
#define VIDEO_CAPABILITY_DATA_BLOCK			 0
#define VENDOR_SPECIFIC_VIDEO_DATA_BLOCK	 1
#define VESA_DISPLAY_DEVICE_DATA_BLOCK		 2
#define VESA_VIDEO_TIMING_BLOCK_EXTENSION	 3
#define COLORIMETRY_DATA_BLOCK				 5
#define HDR_STATIC_METADATA_DATA_BLOCK		 6
#define HDR_DYNAMIC_METADATA_DATA_BLOCK		 7
#define VIDEO_FORMAT_PERFERENCE_DATA_BLOCK	13
#define YCBCR420_VIDEO_DATA_BLOCK			14
#define YCBCR420_CAPABILITY_MAP_DATA_BLOCK	15
#define VENDOR_SPECIFIC_AUDIO_DATA_BLOCK	17
#define ROOM_CONFIGURATION_DATA_BLOCK		19
#define SPEAKER_LOCATION_DATA_BLOCK			20
#define INFOFRAME_DATA_BLOCK				32
#define HF_EDID_EXT_OVERRIDE_DATA_BLOCK    120
#define HF_SINK_CAPABILITY_DATA_BLOCK      121
#define HF_SBTM_DATA_BLOCK                 122

#define HDMI_1PX_ID 0x000C03
#define HDMI_2P0_ID 0xC45DD8
#define HDMI_2P1_ID 0x000079

#define BIT0    0x00000001
#define BIT1    0x00000002
#define BIT2    0x00000004
#define BIT3    0x00000008
#define BIT4    0x00000010
#define BIT5    0x00000020
#define BIT6    0x00000040
#define BIT7    0x00000080
#define BIT8    0x00000100
#define BIT9    0x00000200
#define BIT10   0x00000400
#define BIT11   0x00000800
#define BIT12   0x00001000
#define BIT13   0x00002000
#define BIT14   0x00004000
#define BIT15   0x00008000
#define BIT16   0x00010000
#define BIT17   0x00020000
#define BIT18   0x00040000
#define BIT19   0x00080000
#define BIT20   0x00100000
#define BIT21   0x00200000
#define BIT22   0x00400000
#define BIT23   0x00800000
#define BIT24   0x01000000
#define BIT25   0x02000000
#define BIT26   0x04000000
#define BIT27   0x08000000
#define BIT28   0x10000000
#define BIT29   0x20000000
#define BIT30   0x40000000
#define BIT31   0x80000000

/* VIDEO_CAPABILITY_DATA_BLOCK */
#define QY     BIT7
#define QS     BIT6
#define S_PT1  BIT5
#define S_PT0  BIT4
#define S_IT1  BIT3
#define S_IT0  BIT2
#define S_CE1  BIT1
#define S_CE0  BIT0

/* COLORIMETRY_DATA_BLOCK */
#define BT2020_RGB   BIT7
#define BT2020_YCC   BIT6
#define BT2020_cYCC  BIT5
#define AdobeRGB     BIT4
#define AdobeYCC601  BIT3
#define sYCC601      BIT2
#define xvYCC709     BIT1
#define xvYCC601     BIT0

/* HDMI1.4-VSDB Content Type */
#define CNC0_GRAPHICS  BIT0
#define CNC1_PHOTO     BIT1
#define CNC2_CINEMA    BIT2
#define CNC3_GAME      BIT3

/* HDMI2.1 SCDS PB5 */
#define SCDS5_QMS   BIT6
#define SCDS5_ALLM  BIT1

/* HDMI2.1 SCDS PB8 */
#define SCDS8_QMS_TFR_MAX  BIT5
#define SCDS8_QMS_TFR_MIN  BIT4

/* HDR_STATIC_METADATA_DATA_BLOCK EOTF */
#define EOTF_TRAD_SDR BIT0
#define EOTF_TRAD_HDR BIT1
#define EOTF_ST2084   BIT2
#define EOTF_HLG      BIT3

enum VIDEO_ID_CODE {
	VIC_640_480p_60Hz_4_3 = 1,
	VIC_720_480p_60Hz_4_3 = 2,
	VIC_720_480p_60Hz_16_9 = 3,
	VIC_1280_720p_60Hz_16_9 = 4,
	VIC_1920_1080i_60Hz_16_9 = 5,
	VIC_720_480i_60Hz_4_3 = 6,
	VIC_720_480i_60Hz_16_9 = 7,
	VIC_720_240p_60Hz_4_3 = 8,
	VIC_720_240p_60Hz_16_9 = 9,
	VIC_2880_480i_60Hz_4_3 = 10,
	VIC_2880_480i_60Hz_16_9 = 11,
	VIC_2880_240p_60Hz_4_3 = 12,
	VIC_2880_240p_60Hz_16_9 = 13,
	VIC_1440_480p_60Hz_4_3 = 14,
	VIC_1440_480p_60Hz_16_9 = 15,
	VIC_1920_1080p_60Hz_16_9 = 16,
	VIC_720_576p_50Hz_4_3 = 17,
	VIC_720_576p_50Hz_16_9 = 18,
	VIC_1280_720p_50Hz_16_9 = 19,
	VIC_1920_1080i_50Hz_16_9 = 20,
	VIC_720_576i_50Hz_4_3 = 21,
	VIC_720_576i_50Hz_16_9 = 22,
	VIC_720_288p_50Hz_4_3 = 23,
	VIC_720_288p_50Hz_16_9 = 24,
	VIC_2880_576i_50Hz_4_3 = 25,
	VIC_2880_576i_50Hz_16_9 = 26,
	VIC_2880_288p_50Hz_4_3 = 27,
	VIC_2880_288p_50Hz_16_9 = 28,
	VIC_1440_576p_50Hz_4_3 = 29,
	VIC_1440_576p_50Hz_16_9 = 30,
	VIC_1920_1080p_50Hz_16_9 = 31,
	VIC_1920_1080p_24Hz_16_9 = 32,
	VIC_1920_1080p_25Hz_16_9 = 33,
	VIC_1920_1080p_30Hz_16_9 = 34,
	VIC_2880_480p_60Hz_4_3 = 35,
	VIC_2880_480p_60Hz_16_9 = 36,
	VIC_2880_576p_50Hz_4_3 = 37,
	VIC_2880_576p_50Hz_16_9 = 38,
	VIC_1920_1080i_t_50Hz_16_9 = 39,
	VIC_1920_1080i_100Hz_16_9 = 40,
	VIC_1280_720p_100Hz_16_9 = 41,
	VIC_720_576p_100Hz_4_3 = 42,
	VIC_720_576p_100Hz_16_9 = 43,
	VIC_720_576i_100Hz_4_3 = 44,
	VIC_720_576i_100Hz_16_9 = 45,
	VIC_1920_1080i_120Hz_16_9 = 46,
	VIC_1280_720p_120Hz_16_9 = 47,
	VIC_720_480p_120Hz_4_3 = 48,
	VIC_720_480p_120Hz_16_9 = 49,
	VIC_720_480i_120Hz_4_3 = 50,
	VIC_720_480i_120Hz_16_9 = 51,
	VIC_720_576p_200Hz_4_3 = 52,
	VIC_720_576p_200Hz_16_9 = 53,
	VIC_720_576i_200Hz_4_3 = 54,
	VIC_720_576i_200Hz_16_9 = 55,
	VIC_720_480p_240Hz_4_3 = 56,
	VIC_720_480p_240Hz_16_9 = 57,
	VIC_720_480i_240Hz_4_3 = 58,
	VIC_720_480i_240Hz_16_9 = 59,
	VIC_1280_720p_24Hz_16_9 = 60,
	VIC_1280_720p_25Hz_16_9 = 61,
	VIC_1280_720p_30Hz_16_9 = 62,
	VIC_1920_1080p_120Hz_16_9 = 63,
	VIC_1920_1080p_100Hz_16_9 = 64,
	VIC_1280_720p_24Hz_64_276 = 65,
	VIC_1280_720p_25Hz_64_276 = 66,
	VIC_1280_720p_30Hz_64_276 = 67,
	VIC_1280_720p_50Hz_64_276 = 68,
	VIC_1280_720p_60Hz_64_276 = 69,
	VIC_1280_720p_100Hz_64_276 = 70,
	VIC_1280_720p_120Hz_64_276 = 71,
	VIC_1920_1080p_24Hz_64_276 = 72,
	VIC_1920_1080p_25Hz_64_276 = 73,
	VIC_1920_1080p_30Hz_64_276 = 74,
	VIC_1920_1080p_50Hz_64_276 = 75,
	VIC_1920_1080p_60Hz_64_276 = 76,
	VIC_1920_1080p_100Hz_64_276 = 77,
	VIC_1920_1080p_120Hz_64_276 = 78,
	VIC_1680_720p_24Hz_64_276 = 79,
	VIC_1680_720p_25Hz_64_276 = 80,
	VIC_1680_720p_30Hz_64_276 = 81,
	VIC_1680_720p_50Hz_64_276 = 82,
	VIC_1680_720p_60Hz_64_276 = 83,
	VIC_1680_720p_100Hz_64_276 = 84,
	VIC_1680_720p_120Hz_64_276 = 85,
	VIC_2560_1080p_24Hz_64_276 = 86,
	VIC_2560_1080p_25Hz_64_276 = 87,
	VIC_2560_1080p_30Hz_64_276 = 88,
	VIC_2560_1080p_50Hz_64_276 = 89,
	VIC_2560_1080p_60Hz_64_276 = 90,
	VIC_2560_1080p_100Hz_64_276 = 91,
	VIC_2560_1080p_120Hz_64_276 = 92,
	VIC_3840_2160p_24Hz_16_9 = 93,
	VIC_3840_2160p_25Hz_16_9 = 94,
	VIC_3840_2160p_30Hz_16_9 = 95,
	VIC_3840_2160p_50Hz_16_9 = 96,
	VIC_3840_2160p_60Hz_16_9 = 97,
	VIC_4096_2160p_24Hz_256_135 = 98,
	VIC_4096_2160p_25Hz_256_135 = 99,
	VIC_4096_2160p_30Hz_256_135 = 100,
	VIC_4096_2160p_50Hz_256_135 = 101,
	VIC_4096_2160p_60Hz_256_135 = 102,
	VIC_3840_2160p_24Hz_64_276 = 103,
	VIC_3840_2160p_25Hz_64_276 = 104,
	VIC_3840_2160p_30Hz_64_276 = 105,
	VIC_3840_2160p_50Hz_64_276 = 106,
	VIC_3840_2160p_60Hz_64_276 = 107,
	VIC_ERROR = 108,
};

enum rtk_color_mode {
	RTK_COLOR_MODE_RGB = 0,
	RTK_COLOR_MODE_Y422,
	RTK_COLOR_MODE_Y444,
	RTK_COLOR_MODE_Y420,
};

enum rtk_hdr_mode {
	RTK_HDR_MODE_NO_APP = 0,
	RTK_HDR_MODE_DV_ON,
	RTK_HDR_MODE_SDR,
	RTK_HDR_MODE_HDR_GAMMA,
	RTK_HDR_MODE_HDR10,
	RTK_HDR_MODE_HLG,
	RTK_HDR_MODE_INPUT,
	RTK_HDR_MODE_DV_LL_12b_Y422,
	RTK_HDR_MODE_DV_LL_10b_Y444,
	RTK_HDR_MODE_DV_LL_10b_RGB,
	RTK_HDR_MODE_DV_LL_12b_Y444,
	RTK_HDR_MODE_DV_LL_12b_RGB,
	RTK_HDR_MODE_DV_ON_INPUT,
	RTK_HDR_MODE_DV_LL_12b422_INPUT,
	RTK_HDR_MODE_INPUT_BT2020,
	RTK_HDR_MODE_DV_ON_HDR10_VS10,
	RTK_HDR_MODE_DV_ON_SDR_VS10,
};

enum rtk_color_support {
	COLOR_SUPPORT = 1,
	BIT_8 = 1 << 1,
	BIT_10 = 1 << 2,
	BIT_12 = 1 << 3,
};

struct monitor_descriptor {
	unsigned char flag[2];
	unsigned char flag_res1;
	unsigned char data_type;
	unsigned char flag_res2;
	unsigned char name[13];
} __attribute__((packed));

/**
 * struct base_block -  block zero
 */
struct base_block {
	/* vendor/product identification 0x08 */
	unsigned char manf_name_str[3];
	unsigned char product_code[2];
	unsigned char serial_number[4];
	unsigned char manf_week;
	unsigned char manf_year;
	/* EDID Version */
	unsigned char version;
	unsigned char revision;
	/* Basic display parameters and features 0x14*/
	unsigned char video_input_def;
	unsigned char hor_size_cm;
	unsigned char ver_size_cm;
	unsigned char gamma;
	unsigned char feature;
	/* Color Characteristics 0x19 */
	unsigned char red_green_low;
	unsigned char blue_white_low;
	unsigned char red_x;
	unsigned char red_y;
	unsigned char green_x;
	unsigned char green_y;
	unsigned char blue_x;
	unsigned char blue_y;
	unsigned char white_x;
	unsigned char white_y;
	/* Descriptor */
	unsigned char monitor_name[16];
	/* Extension 0x7e */
	unsigned char ext_flag;
};

/**
 * struct short_audio_desc - Short Audio Descriptor for audio format
 * @coding_type: Audio format code
 * @max_channels: Max number of channels
 * @frequency: Bit6[192KHz]/[176.4KHz]/[96KHz]/[88.2KHz]/[48KHz]/[44.1KHz]/Bit0[32KHz]
 * @byte3: Byte#3, depends on coding_type
 */
struct short_audio_desc {
	unsigned char format_code;
	unsigned char max_channels;
	unsigned char frequency;
	unsigned char byte3;
};

/**
 * struct audio_data - Audio Data Block
 * @desc_len: number of descriptors
 * @descriptors: struct short_audio_desc
 */
struct audio_data {
	unsigned char desc_len;
	struct short_audio_desc descriptors[20];
};

/**
 * struct video_formats - Color format and 3D support for specific VIC
 * @vic: Video ID Code
 * @rgb444: b'0-Support RGB444, b'1-RGB444/8bit, b'2-RGB444/10bit, b'3-RGB444/12bit
 * @yuv422: b'0-Support YUV422, b'1-YUV422/8bit, b'2-YUV422/10bit, b'3-YUV422/12bit
 * @yuv444: b'0-Support YUV444, b'1-YUV444/8bit, b'2-YUV444/10bit, b'3-YUV444/12bit
 * @yuv420: b'0-Support YUV420, b'1-YUV420/8bit, b'2-YUV420/10bit, b'3-YUV420/12bit
 * @_3d: b'0-Support 3D, b'1-FramePacking, b'2-TopAndBottom, b'3-SideBySideHalf
 * @fract_fps: b'0-Support fractional fps, b'1-Support 3D fractional fps
 */
struct video_formats {
	unsigned char vic;
	unsigned char rgb444;
	unsigned char yuv422;
	unsigned char yuv444;
	unsigned char yuv420;
	unsigned char _3d;
	unsigned char fract_fps;
	unsigned char reserved;
};

/**
 * struct video_data
 * @vic_sp1: Bit mapping of vic 1 to 64 support, b'0=VIC1
 * @vic_sp2: Bit mapping of vic 65 to 128 support, b'0=VIC65
 * @vic_sp3: Bit mapping of vic 193 to 256 support, b'0=VIC193
 * @vic_sp2_420: Bit mapping of YCbCr420 vic 65 to 128 support, b'0=VIC65
 * @vic_sp3_420: Bit mapping of YCbCr420 vic 193 to 256 support, b'0=VIC193
 * @tx_support: struct video_formats
 * @tx_support_size:  Number of items in tx_support array
 */
#define TXSUPPORT_MAX 30
struct video_data {
	__u64 vic_sp1;
	__u64 vic_sp2;
	__u64 vic_sp3;
	__u64 vic_sp2_420;
	__u64 vic_sp3_420;
	struct video_formats tx_support[TXSUPPORT_MAX];
	unsigned int tx_support_size;
};

/**
 * struct colorimetry_data - colorimetry data block
 * @flags: colorimetry support flags
 * @md: metadata support flags
 */
struct colorimetry_data {
	unsigned char flags;
	unsigned char md;
};


/* struct sink_cap_data - sink capability data structure */
struct sink_cap_data {
	/* HDMI 1.4 */
	unsigned char support_audio;
	unsigned char support_y444;
	unsigned char support_y422;
	unsigned char phy_addr[2];
	unsigned char supports_ai;
	unsigned char dc_10bit;
	unsigned char dc_12bit;
	unsigned char dc_y444;
	unsigned char cn_type;
	unsigned char video_latency[2]; /* [0]: progressive, [1]: interlaced */
	unsigned char audio_latency[2];
	/* HDMI 2.x */
	unsigned int max_tmds;
	unsigned char scdc_present;
	unsigned char rr_capable;
	unsigned char _340m_scramble;
	unsigned char max_frl_rate;
	unsigned char dc_420;
	unsigned char scds_pb5;
	unsigned char vrr_min;
	__u16 vrr_max;
	unsigned char scds_pb8;
	unsigned char scds_pb9;
	unsigned char scds_pb10;
};

/**
 * struct hdr_static_metadata - HDR static metadata data block
 * @length: length of dat, 2 to 5
 * @eotf: supported electro optical transfer function
 * @sm: supported static metadata descriptor
 * @max_luminace: content max luminace
 * @max_frame_avg: content max frame-average luminance
 * @min_luminace: content min luminance
 */
struct hdr_static_metadata {
	unsigned char length;
	unsigned char eotf;
	unsigned char sm;
	unsigned char max_luminace;
	unsigned char max_frame_avg;
	unsigned char min_luminace;
};

#define MAX_VSVDB 22
/**
 * struct dolby_vsvdb - Dolby Vendor Specific Video Data Block
 * @length: Dolby VSVDB payload length
 * @data: Dolby VSVDB payload data
 */
struct dolby_vsvdb {
	unsigned char length;
	unsigned char data[MAX_VSVDB];
};

#define MAX_VSADB 27
/**
 * struct dolby_vsadb - Dolby Vendor Specific Audio Data Block
 * @length: Dolby VSADB payload length
 * @data: Dolby VSADB payload data
 */
struct dolby_vsadb {
	unsigned char length;
	unsigned char data[MAX_VSADB];
};

#define MAX_SBTM 30
/**
 * struct sbtm_db - SBTM Data Block
 * @length: SBTM data length
 * @data: SBTM data
 */
struct sbtm_db {
	unsigned char length;
	unsigned char data[MAX_SBTM];
};

struct edid_info {
	struct base_block basic;
	struct audio_data audio;
	struct video_data video;
	unsigned int hdmi_id;
	/* VIDEO_CAPABILITY_DATA_BLOCK */
	unsigned char video_cap_desc;
	/* COLORIMETRY_DATA_BLOCK */
	struct colorimetry_data colorimetry;
	/* HDMI1.4-VSDB, HF-VSDB, HF-SCDB */
	struct sink_cap_data sink_cap;
	/* HDR_STATIC_METADATA_DATA_BLOCK */
	struct hdr_static_metadata hdr;
	/* Dolby Vision VSVDB additional payload */
	struct dolby_vsvdb dolby_video;
	/* VENDOR_SPECIFIC_AUDIO_DATA_BLOCK */
	struct dolby_vsadb dolby_audio;
	/* HDR10+ VSVDB */
	unsigned char hdr10_plus;
	/* HDMI Forum SBTM Data Block */
	struct sbtm_db sbtm;
};

struct color_mode_setting {
	int valid;
	int score;
	enum rtk_color_mode color_mode;
	enum rtk_hdr_mode hdr_mode;
	uint64_t max_bpc;
};

#define ERR_NO_EDID       (-1)
#define ERR_INVALID_SIZE  (-2)
#define ERR_NULL_PTR      (-3)
#define ERR_INVALID_HEADER  (-5)
#define ERR_INVALID_CSUM    (-6)

#ifdef __cplusplus
extern "C" {
#endif

int rtk_parse_edid(unsigned char *raw_edid,
		unsigned int edid_size, struct edid_info *info);

int rtk_read_edid_sysfs(unsigned char *edid, unsigned int len);

char *rtk_vic_convert(unsigned char vic, int fract_fps);
void rtk_color_depth_convert(unsigned char color_depth, char *buf);
int rtk_drm_mode_to_vic(drmModeModeInfo info);
int rtk_choose_best_setting(struct video_formats *format, enum rtk_color_mode *color_mode, enum rtk_hdr_mode *hdr_mode, uint64_t *max_bpc);
#ifdef __cplusplus
}
#endif

#endif
