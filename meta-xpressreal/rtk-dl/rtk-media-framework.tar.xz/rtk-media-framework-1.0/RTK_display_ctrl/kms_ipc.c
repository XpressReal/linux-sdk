#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <inttypes.h>
#include "rtk_display_ctrl.h"

static void process_display_cmd(struct kms_device *dev, char *display_cmd)
{
	int enable = 1;
	int conn_id = 0;
	char mode[64] = {0};
	sscanf(display_cmd, "%[^:]:%d:%d", mode, &conn_id, &enable);

	if (strcmp(mode, "vo") == 0) {
		set_vo_enable(dev, conn_id, enable);
	} else if (strcmp(mode, "display") == 0) {
		set_display_enable(dev, conn_id, enable);
	} else {
		printf("no this mode:%s\n", mode);
	}
}

static void process_plane_mode(struct kms_device *dev, char *plane_mode) {
	char plane[256] = {0};
	char mode[256] = {0};
	sscanf(plane_mode, "%[^:]:%s", plane, mode);
	set_plane_mode(dev, plane, mode);
}

static void process_pqmode(struct kms_device *dev, char *pqmode)
{
	char cmd[256] = {0};
	char pq_ctrl[256] = {0};
	int value = 0;
	int ret = -1;
	sscanf(pqmode, "%[^:]:%[^:]:%d", cmd, pq_ctrl, &value);
	if (strcmp(cmd, "set") == 0) {
		ret = set_pqmode(dev, pq_ctrl, value);
		if (ret < 0)
			printf("pq mode:%s fail\n", pq_ctrl);

	} else if (strcmp(cmd, "get") == 0) {
		if (strcmp(pq_ctrl, "all") == 0) {
			int count = pq_ctrl_get_query_count();
			for (int i = 0; i < count; i++) {
				char *pq_cap = pq_ctrl_get_query_cap(i);
				ret = get_pqmode(dev, pq_cap, &value);
				if (ret < 0)
					printf("pq mode:%s value:invalid\n", pq_cap);
				else
					printf("pq mode:%s value:%d\n", pq_cap, value);
			}
		} else {
			ret = get_pqmode(dev, pq_ctrl, &value);
			if (ret < 0)
				printf("pq mode:%s value:invalid\n", pq_ctrl);
			else
				printf("pq mode:%s value:%d\n", pq_ctrl, value);
		}
	}
}

static void process_edid_cmd (struct kms_device *dev, char *edid_cmd)
{
	char cmd[256] = {0};
	char tv_mode[256] = {0};
	int conn_id = 0;
	struct tv_mode_info mode_info = {0};

	if (strncmp(edid_cmd, "list", strlen("list")) == 0) {
		sscanf(edid_cmd, "%[^:]:%d", cmd, &conn_id);
		get_connector_tv_mode_info(dev, conn_id, &mode_info);
		list_all_tv_mode_info(&mode_info);
	} else if (strncmp(edid_cmd, "get", strlen("get")) == 0) {
		sscanf(edid_cmd, "%[^:]:%d:%s", cmd, &conn_id, tv_mode);
		get_connector_tv_mode_info(dev, conn_id, &mode_info);
		list_specific_tv_mode_bitmap(&mode_info, tv_mode);
	}
}

static void process_tv_mode_cmd(struct kms_device *dev, char *tv_mode)
{
	int conn_id = -1;
	char tv_mode_info[256] = {0};

	sscanf(tv_mode, "%d:%s", &conn_id, tv_mode_info);
	set_tv_mode(dev, conn_id, tv_mode_info);
}

static void usage(void)
{
	printf("\nQuery options:\n\n");
	printf("  %-30s %s\n", "--version",            "show version");
	printf("  %-30s %s\n", "--connectors",         "list connectors info");
	printf("  %-30s %s\n", "--edid <arg>",         "get edid info");
	printf("  %-30s %s\n", "",
	       "list all connector id: list:<connector_id>");
	printf("  %-30s %s\n", "",
	       "list tv mode support: get:<connector_id>:<tv_mode>");

	printf("\nControl options:\n\n");
	printf("  %-30s %s\n", "--set-tv-mode <arg>",
	       "change tv mode: <connector_id>:widthxheight@<refresh>");
	printf("  %-30s %s\n", "--property <arg>",
	       "property control: <obj_id>:<prop_name>:<value>");
	printf("  %-30s %s\n", "--display <arg>",
	       "enable/disable: <vo|display>:<connector_id>:<0|1>");
	printf("  %-30s %s\n", "--plane <arg>",
	       "set plane mode: <V1|V2>:<low_delay_off|low_delay_decoder|low_delay_display|");
	printf("  %-30s %s\n", "",
	       "low_delay_decoder_display|low_delay_avsync|low_delay_decoder_avsync|");
	printf("  %-30s %s\n", "",
	       "low_delay_display_order>");
	printf("  %-30s %s\n", "--pqmode <arg>",      "set pq mode: <set|get>:<pq control>:<0|1>");
	printf("  %-30s %s\n", "--offline",           "offline open (no Weston DRM master)");
	printf("\n");
}

#define KMS_IPC_VERSION "KMS_IPC 3.0.7"

int main(int argc, char **argv)
{
	int ret = -1;
	struct kms_device dev = {0};
	char *edid_cmd = NULL;
	int list_connectors = 0;
	char *tv_mode = NULL;
	int c = 0;
	struct property_info prop_info = {0};
	int show_version = 0;
	char *display_cmd = NULL;
	char *plane_mode = NULL;
	int offline_open = 0;
	char *pqmode = NULL;
	int option_index = 0;

	static struct option long_options[] = {
		{ "version",     no_argument,       NULL, 'v' },
		{ "connectors",  no_argument,       NULL, 'c' },
		{ "edid",        required_argument, NULL, 'e' },
		{ "set-tv-mode", required_argument, NULL, 's' },
		{ "display",     required_argument, NULL, 'd' },
		{ "property",    required_argument, NULL, 'w' },
		{ "plane",       required_argument, NULL, 'p' },
		{ "pqmode",      required_argument, NULL, 'a' },
		{ "offline",     no_argument,       NULL, 'F' },
		{ 0, 0, 0, 0 }
	};

	opterr = 0;
	while ((c = getopt_long(argc, argv, "s:w:e:cvd:p:Fa:", long_options, &option_index)) != -1) {
		switch(c) {
		case 'v':
			show_version = 1;
			break;
		case 'e':
			edid_cmd = strdup(optarg);
			break;
		case 's':
			tv_mode = strdup(optarg);
			break;
		case 'd':
			display_cmd = strdup(optarg);
			break;
		case 'c':
			list_connectors = 1;
			break;
		case 'w': {
			struct property_param *param;

			prop_info.param = realloc(prop_info.param,
				(prop_info.prop_count + 1) * sizeof(struct property_param));
			if (!prop_info.param) {
				printf("memory allocation failed\n");
				return -1;
			}

			param = &prop_info.param[prop_info.prop_count];
			memset(param, 0, sizeof(*param));

			if (sscanf(optarg, "%d:%32[^:]:%" SCNu64,
				   &param->obj_id, param->name, &param->value) != 3) {
				printf("wrong property format\n");
				return -1;
			}
			prop_info.prop_count++;
			break;
		}
		case 'p':
			plane_mode = strdup(optarg);
			break;
		case 'a':
			pqmode = strdup(optarg);
			break;
		case 'F':
			offline_open = 1;
			break;
		default:
			usage();
			return 0;
		}
	}

	if (show_version)
		printf("Version: %s\n", KMS_IPC_VERSION);

	/* Init device */
	if (offline_open)
		ret = kms_device_offline_init(&dev);
	else
		ret = kms_device_init(&dev);

	if (ret < 0) {
		printf("kms_device_init fail\n");
		goto out;
	}

	/* No action specified → dump all DRM info and exit */
	if (!list_connectors && !edid_cmd && !tv_mode &&
			!display_cmd && !plane_mode && !pqmode &&
			!show_version && !prop_info.prop_count) {
		dump_drm_info(&dev);
		return 0;
	}

	/* Offline mode only supports --connectors and --version */
	if (offline_open && (display_cmd || prop_info.prop_count || tv_mode ||
			    edid_cmd || plane_mode || pqmode)) {
		printf("The command isn't supported by offline setting\n");
		goto out;
	}

	/* Mutually exclusive commands (first match wins) */
	if (list_connectors) {
		struct connector_info conn_info = {0};
		get_connectors_info(&dev, &conn_info);
		printf("Connector list:\n");
		for (int i = 0; i < conn_info.conn_count; i++)
			printf("ID:%d name:%s\n", conn_info.conn_id[i], conn_info.name[i]);
		printf("\n");
	} else if (edid_cmd) {
		process_edid_cmd(&dev, edid_cmd);
	} else if (plane_mode) {
		process_plane_mode(&dev, plane_mode);
	} else if (pqmode) {
		process_pqmode(&dev, pqmode);
	} else if (display_cmd) {
		process_display_cmd(&dev, display_cmd);
	}

	/* --property and --set-tv-mode can be combined */
	if (prop_info.prop_count > 0) {
		struct connector_info conn_info = {0};
		get_connectors_info(&dev, &conn_info);

		/* if set connector property, need to reset output */
		for (int i = 0; i < conn_info.conn_count; i++) {
			for (int j = 0; j < prop_info.prop_count; j++) {
				struct property_param *param = &prop_info.param[j];
				if (param->obj_id == conn_info.conn_id[i]) {
					prop_info.conn_id = param->obj_id;
					prop_info.output_reset = 1;
				}
			}
		}

		set_tv_property(&dev, &prop_info);
	}

	if (tv_mode)
		process_tv_mode_cmd(&dev, tv_mode);

out:
	free(edid_cmd);
	free(display_cmd);
	free(plane_mode);
	free(tv_mode);
	free(prop_info.param);
	free(pqmode);
	kms_device_uninit(&dev);
	return 0;
}
