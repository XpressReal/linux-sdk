//#define LOG_NDEBUG 0
#define LOG_TAG "librtkdrm"

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/mman.h>

#include <xf86drm.h>
#include "rtk_edid.h"

#define DEBUG 0
#define debug_printf(fmt, args...) \
            do { if (DEBUG) printf(fmt, ##args); } while (0)

#define PATH_LEN    (512)

#define DRM_SYSFS   "/sys/devices/platform/display-subsystem/drm/card0/card0-HDMI-A-1"
#define EDID        "edid"

static const unsigned char block0_header[] = {
	0x00, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00
};

static const unsigned char pnpid[] = {
	' ', 'A', 'B', 'C', 'D', 'E', 'F', 'G',
	'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O',
	'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W',
	'X', 'Y', 'Z', ' ', ' ', ' ', ' ', ' '
};

const unsigned char support_vic[] = {
    VIC_720_480p_60Hz_4_3,
    VIC_1280_720p_60Hz_16_9,
    VIC_1920_1080i_60Hz_16_9,
    VIC_720_480i_60Hz_4_3,
    VIC_1920_1080p_60Hz_16_9,
    VIC_720_576p_50Hz_4_3,
    VIC_1280_720p_50Hz_16_9,
    VIC_1920_1080i_50Hz_16_9,
    VIC_720_576i_50Hz_4_3,
    VIC_1920_1080p_50Hz_16_9,
    VIC_1920_1080p_24Hz_16_9,
    VIC_1920_1080p_25Hz_16_9,
    VIC_1920_1080p_30Hz_16_9,
    VIC_1280_720p_24Hz_16_9,
    VIC_1280_720p_25Hz_16_9,
    VIC_1280_720p_30Hz_16_9,
    VIC_1920_1080p_120Hz_16_9,
    VIC_3840_2160p_24Hz_16_9,
    VIC_3840_2160p_25Hz_16_9,
    VIC_3840_2160p_30Hz_16_9,
    VIC_3840_2160p_50Hz_16_9,
    VIC_3840_2160p_60Hz_16_9,
    VIC_4096_2160p_24Hz_256_135,
    VIC_4096_2160p_25Hz_256_135,
    VIC_4096_2160p_30Hz_256_135,
    VIC_4096_2160p_50Hz_256_135,
    VIC_4096_2160p_60Hz_256_135,
};

#define MAX_SVDS_LEN 32
static unsigned char svds[MAX_SVDS_LEN];
static unsigned char svds_index;

#ifdef __cplusplus
extern "C" {
#endif

static int check_edid_valid(unsigned char *raw_edid,
			unsigned int edid_size)
{
	unsigned int i;
	unsigned char check_sum;

	for (i = 0; i < sizeof(block0_header); i++)
		if (raw_edid[i] != block0_header[i])
			return ERR_INVALID_HEADER;

	check_sum = 0;
	for (i = 0; i < EDID_BLOCK_LEN; i++)
		check_sum += raw_edid[i];

	if (check_sum)
		return ERR_INVALID_CSUM;

	return 0;
}

static unsigned char get_tag_code(unsigned char *data_block)
{
	return data_block[0] >> 5;
}

static unsigned char get_payload_len(unsigned char *data_block)
{
	return data_block[0] & 0x1F;
}

static void parse_base_block(unsigned char *raw_edid,
		unsigned int edid_size, struct base_block *basic)
{
	unsigned int i;
	unsigned char index;
	struct monitor_descriptor *desc;

	/* vendor/product identification 0x08 */
	index = (raw_edid[0x08] >> 2) & 0x1F;
	basic->manf_name_str[0] = pnpid[index];
	index = ((raw_edid[0x08]&0x3) << 3) | ((raw_edid[0x09] >> 5) & 0x7);
	basic->manf_name_str[1] = pnpid[index];
	index = raw_edid[0x09] & 0x1F;
	basic->manf_name_str[2] = pnpid[index];

	basic->product_code[0] = raw_edid[0x0A];
	basic->product_code[1] = raw_edid[0x0B];

	basic->serial_number[0] = raw_edid[0x0C];
	basic->serial_number[1] = raw_edid[0x0D];
	basic->serial_number[2] = raw_edid[0x0E];
	basic->serial_number[3] = raw_edid[0x0F];

	basic->manf_week = raw_edid[0x10];
	basic->manf_year = raw_edid[0x11];

	/* EDID Version */
	basic->version = raw_edid[0x12];
	basic->revision = raw_edid[0x13];

	/* Basic display parameters and features 0x14*/
	basic->video_input_def = raw_edid[0x14];
	basic->hor_size_cm = raw_edid[0x15];
	basic->ver_size_cm = raw_edid[0x16];
	basic->gamma = raw_edid[0x17];
	basic->feature = raw_edid[0x18];

	/* Color Characteristics 0x19 */
	basic->red_green_low = raw_edid[0x19];
	basic->blue_white_low = raw_edid[0x1A];
	basic->red_x = raw_edid[0x1B];
	basic->red_y = raw_edid[0x1C];
	basic->green_x = raw_edid[0x1D];
	basic->green_y = raw_edid[0x1E];
	basic->blue_x = raw_edid[0x1F];
	basic->blue_y = raw_edid[0x20];
	basic->white_x = raw_edid[0x21];
	basic->white_y = raw_edid[0x22];

	/* Descriptor */
	desc = (struct monitor_descriptor *)&raw_edid[0x36];
	for (i = 0; i < 4; i++) {
		if ((desc[i].flag[0] != 0x0) || (desc[i].flag[1] != 0x0))
			continue;

		if (desc[i].data_type != 0xFC)
			continue;

		for (index = 0; index < 13; index++) {
			if (desc[i].name[index] == 0xA)
				break;

			basic->monitor_name[index] = desc[i].name[index];
		}
		break;
	}

	/* Extension 0x7e */
	basic->ext_flag = raw_edid[0x7E];

}

static void parse_audio_block(unsigned char *data_block, struct edid_info *info)
{
	unsigned char data_len;
	unsigned char desc_len;
	unsigned char max_desc_len;
	unsigned char i;
	unsigned char *sad;
	struct audio_data *audio;
	struct short_audio_desc *desc;

	data_len = get_payload_len(data_block);
	if ((data_len % 3) != 0) {
		debug_printf("Invalid length in audio data block, skip parse\n");
		return;
	}

	audio = &info->audio;
	max_desc_len = sizeof(audio->descriptors)/sizeof(audio->descriptors[0]);

	desc_len = data_len/3;
	debug_printf("max_desc_len=%u, desc_len=%u\n", max_desc_len, desc_len);

	for (i = 0; i < desc_len; i++) {
		if ((audio->desc_len + i) >= max_desc_len)
			break;

		sad = &data_block[i*3 + 1];
		desc = &audio->descriptors[audio->desc_len + i];

		desc->format_code = ((sad[0] & 0x78)>>3);
		desc->max_channels = (sad[0] & 0x7) + 1;
		if (desc->max_channels < 2)
			desc->max_channels = 2;

		desc->frequency = sad[1];
		desc->byte3 = sad[2];
	}

	audio->desc_len += i;
}

static void parse_video_block(unsigned char *data_block, struct edid_info *info)
{
	unsigned char data_len;
	unsigned char i;
	unsigned char svd;
	unsigned char vic;
	struct video_data *video;

	data_len = get_payload_len(data_block);
	video = &info->video;

	memset(svds, 0, MAX_SVDS_LEN);
	for (i = 1; i <= data_len; i++) {
		svd = data_block[i];
		if ((svd >= 128) && (svd <= 192))
			vic = svd & 0x7F;
		else
			vic = svd;

		/* Save svds for y420 bitmap */
		if (svds_index < MAX_SVDS_LEN)
			svds[svds_index++] = vic;

		if (vic == 0)
			continue;

		if (vic <= 64)
			video->vic_sp1 |= 1ULL << (vic - 1);
		else if (vic <= 128)
			video->vic_sp2 |= 1ULL << (vic - 65);
		else if (vic >= 193)
			video->vic_sp3 |= 1ULL << (vic - 193);
	}
}

static void parse_hdmi14_vsdb(unsigned char *data_block, struct edid_info *info)
{
	unsigned char data_len;
	unsigned char offset;
	unsigned char latency_present;
	unsigned char i_latency_present;
	unsigned char video_present;
	unsigned char _3d_present;
	unsigned char vic_len;
	unsigned char i;

	offset = 0;
	data_len = get_payload_len(data_block);

	if (data_len < 5)
		return;

	info->sink_cap.phy_addr[0] = data_block[4];
	info->sink_cap.phy_addr[1] = data_block[5];

	if (data_len < 6)
		return;

	info->sink_cap.supports_ai = (data_block[6] >> 7) & BIT0;
	info->sink_cap.dc_12bit = (data_block[6] >> 5) & BIT0;
	info->sink_cap.dc_10bit = (data_block[6] >> 4) & BIT0;
	info->sink_cap.dc_y444 = (data_block[6] >> 3) & BIT0;

	if (data_len < 7)
		return;

	if (info->sink_cap.max_tmds < data_block[7])
		info->sink_cap.max_tmds = data_block[7];

	if (data_len < 8)
		return;

	info->sink_cap.cn_type = data_block[8] & 0xF;
	latency_present = data_block[8] & BIT7;
	i_latency_present = data_block[8] & BIT6;
	video_present = data_block[8] & BIT5;

	if (latency_present && (data_len >= 10)) {
		info->sink_cap.video_latency[0] = data_block[9];
		info->sink_cap.audio_latency[0] = data_block[10];
		offset += 2;
	}

	if (i_latency_present && (data_len >= 12)) {
		info->sink_cap.video_latency[1] = data_block[11];
		info->sink_cap.audio_latency[1] = data_block[12];
		offset += 2;
	}

	if (video_present) {
		offset++;
		if (data_len >= (8 + offset)) {
			_3d_present = (data_block[8+offset] >> 7) & BIT0;
		}

		offset++;
		if (data_len >= (8 + offset))
			vic_len = data_block[8+offset] >> 5;
		else
			vic_len = 0;

		for (i = 1; i <= vic_len; i++) {
			switch (data_block[8 + offset + i]) {
			case 1:
				info->video.vic_sp2 |= BIT30;
				break;
			case 2:
				info->video.vic_sp2 |= BIT29;
				break;
			case 3:
				info->video.vic_sp2 |= BIT28;
				break;
			case 4:
				info->video.vic_sp2 |= (1ULL << 33);
				break;
			default:
				break;
			}
		}
	}

}

/**
 * parse_scds - parse Sink Capability  Data Structure(SCDS)
 *   The minimun length of the SCDS is 4, and the maximum length is 28
 *   SCDS might be contained in HF-VSDB or HF-SCDB
 */
static void parse_scds(unsigned char *data_block, struct edid_info *info)
{
	unsigned char data_len;

	data_len = get_payload_len(data_block);

	if (data_len < 7)
		return;

	info->sink_cap.max_tmds = data_block[5] * 5;
	info->sink_cap.scdc_present = (data_block[6] >> 7) & BIT0;
	info->sink_cap.rr_capable = (data_block[6] >> 6) & BIT0;
	info->sink_cap._340m_scramble = (data_block[6] >> 3) & BIT0;
	info->sink_cap.max_frl_rate = (data_block[7] >> 4) & 0xF;
	info->sink_cap.dc_420 = data_block[7] & 0x7;

	if (data_len < 8)
		return;

	info->sink_cap.scds_pb5 = data_block[8];

	if (data_len < 9)
		return;
	info->sink_cap.vrr_min = data_block[9] & 0x3F;

	if (data_len < 10)
		return;
	info->sink_cap.vrr_max = (__u16) ((data_block[9]&0xC0)<<2) | data_block[10];

	if (data_len < 11)
		return;
	info->sink_cap.scds_pb8 = data_block[11];

	if (data_len < 12)
		return;
	info->sink_cap.scds_pb9 = data_block[12];

	if (data_len < 13)
		return;
	info->sink_cap.scds_pb10 = data_block[13];
}

static void parse_vendor_block(unsigned char *data_block, struct edid_info *info)
{
	unsigned char data_len;
	unsigned int ieee_oui;

	data_len = get_payload_len(data_block);
	if (data_len < 5)
		return;

	ieee_oui = (data_block[3] << 16) | (data_block[2] << 8) | data_block[1];

	if ((ieee_oui == HDMI_1PX_ID) &&
		(info->hdmi_id != HDMI_2P1_ID) && (info->hdmi_id != HDMI_2P0_ID))
		info->hdmi_id = HDMI_1PX_ID;
	else if ((ieee_oui == HDMI_2P0_ID) && (info->hdmi_id != HDMI_2P1_ID))
		info->hdmi_id = HDMI_2P0_ID;

	if (ieee_oui == HDMI_1PX_ID)
		parse_hdmi14_vsdb(data_block, info);
	else if (ieee_oui == HDMI_2P0_ID)
		parse_scds(data_block, info);

}

static void parse_vendor_specific_video_db(unsigned char *ext_block,
	struct edid_info *info)
{
	unsigned char data_len;
	unsigned char oui[3];
	unsigned char i;

	data_len = get_payload_len(ext_block);
	if (data_len < 5)
		return;

	oui[0] = ext_block[2];
	oui[1] = ext_block[3];
	oui[2] = ext_block[4];

	if ((oui[0] == 0x46) && (oui[1] == 0xD0) && (oui[2] == 0x00)) {
		/* Get Dolby Vision VSVDB payload */
		if (data_len > 25) {
			debug_printf("Unknow Dolby Vision version");
			return;
		}
		info->dolby_video.length = data_len - 4;

		for (i = 5; i <= data_len; i++)
			info->dolby_video.data[i-5] = ext_block[i];

	} else if ((oui[0] == 0x8B) && (oui[1] == 0x84) && (oui[2] == 0x90)) {
		/* Get HDR10+ */
		info->hdr10_plus = ext_block[5];
		debug_printf("Found HDR10+ in EDID\n");
	}

}

static void parse_colorimetry_db(unsigned char *ext_block,
	struct edid_info *info)
{
	unsigned char data_len;

	data_len = get_payload_len(ext_block);
	if (data_len < 3)
		return;

	info->colorimetry.flags = ext_block[2];
	info->colorimetry.md = ext_block[3];
}

static void parse_static_metadata_db(unsigned char *ext_block,
	struct edid_info *info)
{
	unsigned char data_len;
	struct hdr_static_metadata *hdr;

	data_len = get_payload_len(ext_block);
	if (data_len < 2)
		return;

	hdr = &info->hdr;

	hdr->length = data_len - 1;

	hdr->eotf = ext_block[2];

	if (data_len < 3)
		return;

	hdr->sm = ext_block[3];

	if (data_len < 4)
		return;

	hdr->max_luminace = ext_block[4];

	if (data_len < 5)
		return;

	hdr->max_frame_avg = ext_block[5];

	if (data_len < 6)
		return;

	hdr->min_luminace = ext_block[6];
}

static void parse_y420_video_db(unsigned char *ext_block, struct edid_info *info)
{
	unsigned char data_len;
	unsigned char i;
	unsigned char svd;
	unsigned char vic;
	struct video_data *video;

	data_len = get_payload_len(ext_block);
	video = &info->video;

	if (data_len <= 2)
		return;

	for (i = 2; i <= data_len; i++) {
		svd = ext_block[i];
		if ((svd >= 128) && (svd <= 192))
			vic = svd & 0x7F;
		else
			vic = svd;

		if (vic == 0)
			continue;

		if ((vic > 64) && (vic <= 128))
			video->vic_sp2_420 |= 1ULL << (vic - 65);
		else if (vic >= 193)
			video->vic_sp3_420 |= 1ULL << (vic - 193);
	}
}

static void parse_y420_cap_map_db(unsigned char *ext_block, struct edid_info *info)
{
	unsigned char data_len;
	unsigned char map_size;
	unsigned char byte_count;
	unsigned char bit_count;
	unsigned char vic;
	unsigned char *bit_map;
	struct video_data *video;

	data_len = get_payload_len(ext_block);
	video = &info->video;

	/* Empty bit map, support all svds */
	if (data_len <= 2) {
		video->vic_sp2_420 = video->vic_sp2;
		video->vic_sp3_420 = video->vic_sp3;
		return;
	}

	bit_map = &ext_block[2];
	map_size = data_len - 1;
	for (byte_count = 0; byte_count < map_size; byte_count++) {
		for (bit_count = 0; bit_count < 8; bit_count++) {
			if (*bit_map & (0x1 << bit_count)) {
				vic = svds[byte_count*8 + bit_count];
				if ((vic >= 65) && (vic <= 128))
					video->vic_sp2_420 |= 1ULL << (vic - 65);
				else if (vic >= 193)
					video->vic_sp3_420 |= 1ULL << (vic - 193);
			}
		}
		/* next bit map */
		bit_map++;
	}

}

static void parse_vendor_specific_audio_db(unsigned char *ext_block,
	struct edid_info *info)
{
	unsigned char data_len;
	unsigned char i;
	unsigned char oui[3];
	struct dolby_vsadb *dolby_audio;

	data_len = get_payload_len(ext_block);
	dolby_audio = &info->dolby_audio;

	if (data_len < 5)
		return;

	oui[0] = ext_block[2];
	oui[1] = ext_block[3];
	oui[2] = ext_block[4];

	if ((oui[0] != 0x46) || (oui[1] != 0xD0) || (oui[2] != 0x00))
		return;

	dolby_audio->length = data_len - 4;

	if (dolby_audio->length > MAX_VSADB) {
		debug_printf("Error: dolby_audio->length(%u) > MAX_VSADB(%u)\n",
			dolby_audio->length, MAX_VSADB);
		dolby_audio->length = MAX_VSADB;
	}

	for (i = 0; i < dolby_audio->length; i++)
		dolby_audio->data[i] = ext_block[i+5];


}

static void parse_sbtm_db(unsigned char *ext_block, struct edid_info *info)
{
	unsigned char data_len;
	unsigned char i;
	struct sbtm_db *sbtm;

	data_len = get_payload_len(ext_block);
	sbtm = &info->sbtm;

	if (data_len < 2)
		return;

	sbtm->length = data_len - 1;

	if (sbtm->length > MAX_SBTM) {
		debug_printf("Error: sbtm->length(%u) > MAX_SBTM(%u)\n", sbtm->length, MAX_SBTM);
		sbtm->length = MAX_SBTM;
	}

	for (i = 0; i < sbtm->length; i++)
		sbtm->data[i] = ext_block[i+2];

}

static void parse_extended_block(unsigned char *ext_block, struct edid_info *info)
{
	unsigned char data_len;

	data_len = get_payload_len(ext_block);
	if (data_len < 1)
		return;

	switch (ext_block[1]) {
	case VIDEO_CAPABILITY_DATA_BLOCK:
		debug_printf("VIDEO_CAPABILITY_DATA_BLOCK\n");
		info->video_cap_desc = ext_block[2];
		break;
	case VENDOR_SPECIFIC_VIDEO_DATA_BLOCK:
		debug_printf("VENDOR_SPECIFIC_VIDEO_DATA_BLOCK\n");
		parse_vendor_specific_video_db(ext_block, info);
		break;
	case VESA_DISPLAY_DEVICE_DATA_BLOCK:
		break;
	case VESA_VIDEO_TIMING_BLOCK_EXTENSION:
		break;
	case COLORIMETRY_DATA_BLOCK:
		debug_printf("COLORIMETRY_DATA_BLOCK\n");
		parse_colorimetry_db(ext_block, info);
		break;
	case HDR_STATIC_METADATA_DATA_BLOCK:
		debug_printf("HDR_STATIC_METADATA_DATA_BLOCK\n");
		parse_static_metadata_db(ext_block, info);
		break;
	case HDR_DYNAMIC_METADATA_DATA_BLOCK:
		break;
	case VIDEO_FORMAT_PERFERENCE_DATA_BLOCK:
		break;
	case YCBCR420_VIDEO_DATA_BLOCK:
		debug_printf("YCBCR420_VIDEO_DATA_BLOCK\n");
		parse_y420_video_db(ext_block, info);
		break;
	case YCBCR420_CAPABILITY_MAP_DATA_BLOCK:
		debug_printf("YCBCR420_CAPABILITY_MAP_DATA_BLOCK\n");
		parse_y420_cap_map_db(ext_block, info);
		break;
	case VENDOR_SPECIFIC_AUDIO_DATA_BLOCK:
		debug_printf("VENDOR_SPECIFIC_AUDIO_DATA_BLOCK\n");
		parse_vendor_specific_audio_db(ext_block, info);
		break;
	case ROOM_CONFIGURATION_DATA_BLOCK:
		break;
	case SPEAKER_LOCATION_DATA_BLOCK:
		break;
	case INFOFRAME_DATA_BLOCK:
		break;
	case HF_EDID_EXT_OVERRIDE_DATA_BLOCK:
		break;
	case HF_SINK_CAPABILITY_DATA_BLOCK:
		debug_printf("HF_SINK_CAPABILITY_DATA_BLOCK\n");
		parse_scds(ext_block, info);
		break;
	case HF_SBTM_DATA_BLOCK:
		debug_printf("HF_SBTM_DATA_BLOCK\n");
		parse_sbtm_db(ext_block, info);
		break;
	default:
		debug_printf("extended tag=%u\n", ext_block[1]);
		break;
	}
}

static unsigned char get_rgb444_support(unsigned char vic,
	struct edid_info *info)
{
	unsigned char rgb444_support;
	unsigned char need_check_tmds;

	rgb444_support = BIT1 | BIT0;

	if ((vic == VIC_3840_2160p_50Hz_16_9) || (vic == VIC_3840_2160p_60Hz_16_9) ||
		(vic == VIC_4096_2160p_50Hz_256_135) || (vic == VIC_4096_2160p_60Hz_256_135))
		goto exit;

	if ((vic == VIC_3840_2160p_24Hz_16_9) || (vic == VIC_3840_2160p_25Hz_16_9) ||
		(vic == VIC_3840_2160p_30Hz_16_9) || (vic == VIC_4096_2160p_24Hz_256_135) ||
		(vic == VIC_4096_2160p_25Hz_256_135) || (vic == VIC_4096_2160p_30Hz_256_135) ||
		(vic == VIC_1920_1080p_120Hz_16_9))
		need_check_tmds = 1;
	else
		need_check_tmds = 0;

	/* Check deep color */
	if (info->sink_cap.dc_10bit &&
		(!need_check_tmds || (info->sink_cap.max_tmds > 371)))
		rgb444_support |= BIT2;

	if (info->sink_cap.dc_12bit &&
		(!need_check_tmds || (info->sink_cap.max_tmds > 445)))
		rgb444_support |= BIT3;

exit:
	return rgb444_support;
}

static unsigned char get_yuv422_support(unsigned char vic,
	struct edid_info *info)
{
	unsigned char yuv422_support;

	yuv422_support = 0;

	if (!info->sink_cap.support_y422)
		return yuv422_support;

	yuv422_support |= (BIT1 | BIT0);

	/* Check deep color */
	if ((vic != VIC_4096_2160p_50Hz_256_135) && (vic != VIC_4096_2160p_60Hz_256_135)) {
			yuv422_support |= BIT2;
			yuv422_support |= BIT3;
	}

	return yuv422_support;
}

static unsigned char get_yuv444_support(unsigned char vic,
	struct edid_info *info)
{
	unsigned char yuv444_support;
	unsigned char need_check_tmds;

	yuv444_support = 0;

	if (!info->sink_cap.support_y444)
		goto exit;

	yuv444_support |= (BIT1 | BIT0);

	if ((vic == VIC_3840_2160p_50Hz_16_9) || (vic == VIC_3840_2160p_60Hz_16_9) ||
		(vic == VIC_4096_2160p_50Hz_256_135) || (vic == VIC_4096_2160p_60Hz_256_135) ||
		(info->sink_cap.dc_y444== 0))
		goto exit;

	if ((vic == VIC_3840_2160p_24Hz_16_9) || (vic == VIC_3840_2160p_25Hz_16_9) ||
		(vic == VIC_3840_2160p_30Hz_16_9) || (vic == VIC_4096_2160p_24Hz_256_135) ||
		(vic == VIC_4096_2160p_25Hz_256_135) || (vic == VIC_4096_2160p_30Hz_256_135) ||
		(vic == VIC_1920_1080p_120Hz_16_9))
		need_check_tmds = 1;
	else
		need_check_tmds = 0;

	/* Check deep color */
	if (info->sink_cap.dc_10bit &&
		(!need_check_tmds || (info->sink_cap.max_tmds > 371)))
		yuv444_support |= BIT2;

	if (info->sink_cap.dc_12bit &&
		(!need_check_tmds || (info->sink_cap.max_tmds > 445)))
		yuv444_support |= BIT3;

exit:
	return yuv444_support;
}

static unsigned char get_yuv420_support(unsigned char vic,
	struct edid_info *info)
{
	unsigned char yuv420_support;

	yuv420_support = 0;

	if ((vic != VIC_3840_2160p_50Hz_16_9) && (vic != VIC_3840_2160p_60Hz_16_9) &&
		(vic != VIC_4096_2160p_50Hz_256_135) && (vic != VIC_4096_2160p_60Hz_256_135))
		goto exit;

	yuv420_support = BIT1 | BIT0;

	/* Check deep color */
	if ((info->sink_cap.dc_420 & BIT0) && (info->sink_cap.max_tmds > 371))
		yuv420_support |= BIT2;

	if ((info->sink_cap.dc_420 & BIT1) && (info->sink_cap.max_tmds > 445))
		yuv420_support |= BIT3;

exit:
	return yuv420_support;
}

static unsigned char get_fract_fps_support(unsigned char vic)
{
	unsigned char fract_fps;

	switch (vic) {
	case VIC_1280_720p_24Hz_16_9:
	case VIC_1280_720p_30Hz_16_9:
	case VIC_1280_720p_60Hz_16_9:
	case VIC_1920_1080i_60Hz_16_9:
	case VIC_1920_1080p_24Hz_16_9:
	case VIC_1920_1080p_30Hz_16_9:
	case VIC_1920_1080p_60Hz_16_9:
	case VIC_3840_2160p_24Hz_16_9:
	case VIC_3840_2160p_30Hz_16_9:
	case VIC_3840_2160p_60Hz_16_9:
	case VIC_4096_2160p_24Hz_256_135:
	case VIC_4096_2160p_30Hz_256_135:
	case VIC_4096_2160p_60Hz_256_135:
		fract_fps = BIT0;
		break;
	default:
		fract_fps = 0;
		break;
	}

	return fract_fps;
}

static void add_vformat_to_list(unsigned char offset,
	unsigned char vic, struct edid_info *info, unsigned char only_420)
{
	info->video.tx_support[offset].vic = vic;
	info->video.tx_support[offset].yuv420 = get_yuv420_support(vic, info);
	info->video.tx_support[offset].fract_fps = get_fract_fps_support(vic);

	if (only_420)
		return;

	info->video.tx_support[offset].rgb444 = get_rgb444_support(vic, info);
	info->video.tx_support[offset].yuv422 = get_yuv422_support(vic, info);
	info->video.tx_support[offset].yuv444 = get_yuv444_support(vic, info);

}

static void gen_video_support_list(struct edid_info *info)
{
	__u64 vic_sp1;
	__u64 vic_sp2;
	__u64 vic_sp2_420;
	unsigned char vic;
	unsigned char i;
	unsigned char offset;

	vic_sp1 = info->video.vic_sp1;
	vic_sp2 = info->video.vic_sp2;
	vic_sp2_420 = info->video.vic_sp2_420;

	/* SD 16:9->4:3 */
	if (vic_sp1 & BIT2)
		vic_sp1 |= BIT1;
	if (vic_sp1 & BIT6)
		vic_sp1 |= BIT5;
	if (vic_sp1 & BIT17)
		vic_sp1 |= BIT16;
	if (vic_sp1 & BIT21)
		vic_sp1 |= BIT20;

	offset = 0;
    unsigned char sz = sizeof(support_vic)/sizeof(unsigned char);
	for (i = 0; i < sz; i++) {
		vic = support_vic[i];

		if (vic <= 64) {
			/* VIC 1 to 64 */
			if (vic_sp1 & (1ULL << (vic - 1))) {
				add_vformat_to_list(offset, vic, info, 0);
				offset++;
			}
		} else {
			/* VIC 65 to 128 */
			if (vic_sp2 & (1ULL << (vic - 65))) {
				add_vformat_to_list(offset, vic, info, 0);
				offset++;
			} else if (vic_sp2_420 & (1ULL << (vic - 65))) {
				/* Only support 420*/
				add_vformat_to_list(offset, vic, info, 1);
				offset++;
			}
		}
	}

	info->video.tx_support_size = offset;
}

static void parse_ext_block(unsigned char *ext_block, struct edid_info *info)
{
	unsigned char *data_block;
	unsigned char tag_code;
	unsigned char data_len;
	unsigned int i;
	unsigned int byte_offset;

	/* Check tag and revision */
	if ((ext_block[0] != 0x02)|| (ext_block[1] != 0x03))
		return;

	byte_offset = ext_block[2];
	if ((byte_offset < 4) || (byte_offset > 127))
		return;

	debug_printf("byte_offset=%u\n", byte_offset);

	if (byte_offset == 0)
		byte_offset = 127;

	if (ext_block[3] & BIT6)
		info->sink_cap.support_audio = 1;

	if (ext_block[3] & BIT5)
		info->sink_cap.support_y444 = 1;

	if (ext_block[3] & BIT4)
		info->sink_cap.support_y422 = 1;

	i = 4;
	while ((i < byte_offset) && (i < 127)) {
		data_block = &ext_block[i];
		tag_code = get_tag_code(data_block);
		data_len = get_payload_len(data_block);

		switch (tag_code) {
		case AUDIO_DATA_BLOCK:
			debug_printf("AUDIO_DATA_BLOCK size=%u\n", data_len);
			parse_audio_block(data_block, info);
			break;
		case VIDEO_DATA_BLOCK:
			debug_printf("VIDEO_DATA_BLOCK size=%u\n", data_len);
			parse_video_block(data_block, info);
			break;
		case VENDOR_SPECIFIC_DATA_BLOCK:
			debug_printf("VENDOR_SPECIFIC_DATA_BLOCK size=%u\n", data_len);
			parse_vendor_block(data_block, info);
			break;
		case SPEAKER_ALLOCATION_DATA_BLOCK:
			debug_printf("SPEAKER_ALLOCATION_DATA_BLOCK size=%u\n", data_len);
			break;
		case VESA_DTC_DATA_BLOCK:
			debug_printf("VESA_DTC_DATA_BLOCK size=%u\n", data_len);
			break;
		case USE_EXTENDED_TAG:
			debug_printf("USE_EXTENDED_TAG size=%u\n", data_len);
			parse_extended_block(data_block, info);
			break;
		default:
			debug_printf("Unknown tag_code=%u size=%u\n", tag_code, data_len);
		}

		i += data_len + 1;
	}


}

static void parse_ext_blocks(unsigned char *raw_edid,
		unsigned int edid_size, struct edid_info *info)
{
	unsigned int i;

	if (edid_size < EDID_BLOCK_LEN*2)
		return;

	for (i = 1; i < edid_size/EDID_BLOCK_LEN; i++)
		parse_ext_block(raw_edid + EDID_BLOCK_LEN*i, info);
}

int rtk_parse_edid(unsigned char *raw_edid,
		unsigned int edid_size, struct edid_info *info)
{
	int ret;

	if ((edid_size < EDID_BLOCK_LEN) || (edid_size % EDID_BLOCK_LEN != 0))
		return ERR_INVALID_SIZE;

	if (raw_edid == NULL)
		return ERR_NO_EDID;

	if (info == NULL)
		return ERR_NULL_PTR;

	ret = check_edid_valid(raw_edid, edid_size);
	if (ret)
		return ret;

	memset(info, 0, sizeof(struct edid_info));
	memset(svds, 0, MAX_SVDS_LEN);
	svds_index = 0;

	parse_base_block(raw_edid, edid_size, &info->basic);

	parse_ext_blocks(raw_edid, edid_size, info);

	gen_video_support_list(info);

	return 0;
}

int rtk_read_edid_sysfs(unsigned char *edid, unsigned int len)
{
    char path[PATH_LEN] = {};
    snprintf(path,PATH_LEN,"%s/%s",DRM_SYSFS,EDID);

    FILE *fd = fopen(path,"r");
    if(fd != NULL) {
        int rlen = fread(edid,1,len,fd);
        debug_printf("[%s] fd:%p rlen:%d",__FUNCTION__,fd,rlen);

        char str[1024*10] = {};
        for(int i=0;i<rlen;i++) {
            char tok[8] = {};
            snprintf(tok,8,"%.2x ",edid[i]);
            strcat(str,tok);
            if((i+1)%16==0) strcat(str,"\n");
        }

        debug_printf("EDID:");
        debug_printf("%s",str);
        fclose(fd);
    }
    return 0;
}

char buf[128] = {0};

char *rtk_vic_convert(unsigned char vic, int fract_fps) {
	memset(buf, 0, 128);
	switch (vic) {
		case VIC_720_480p_60Hz_4_3:
			sprintf(buf, "720x480@%s", fract_fps? "59.94" : "60.00");
			return buf;
		case VIC_1280_720p_60Hz_16_9:
			sprintf(buf, "1280x720@%s", fract_fps? "59.94" : "60.00");
			return buf;
		case VIC_1920_1080i_60Hz_16_9:
			sprintf(buf, "1920x1080i@%s", fract_fps? "59.94" : "60.00");
			return buf;
		case VIC_720_480i_60Hz_4_3:
			sprintf(buf, "720x480i@%s", fract_fps? "59.94" : "60.00");
			return buf;
		case VIC_1920_1080p_60Hz_16_9:
			sprintf(buf, "1920x1080@%s", fract_fps? "59.94" : "60.00");
			return buf;
		case VIC_720_576p_50Hz_4_3:
			return "720x576@50.00";
		case VIC_1280_720p_50Hz_16_9:
			return "1280x720@50.00";
		case VIC_1920_1080i_50Hz_16_9:
			return "1920x1080i@50.00";
		case VIC_720_576i_50Hz_4_3:
			return "720x576i@50.00";
		case VIC_1920_1080p_50Hz_16_9:
			return "1920x1080@50.00";
		case VIC_1920_1080p_24Hz_16_9:
			sprintf(buf, "1920x1080@%s", fract_fps? "23.98" : "24.00");
			return buf;
		case VIC_1920_1080p_25Hz_16_9:
			return "1920x1080@25.00";
		case VIC_1920_1080p_30Hz_16_9:
			sprintf(buf, "1920x1080@%s", fract_fps? "29.97" : "30.00");
			return buf;
		case VIC_1280_720p_24Hz_16_9:
			sprintf(buf, "120x720@%s", fract_fps? "23.98" : "24.00");
			return buf;
		case VIC_1280_720p_25Hz_16_9:
			return "1280x720@25.00";
		case VIC_1280_720p_30Hz_16_9:
			sprintf(buf, "1280x720@%s", fract_fps? "29.97" : "30.00");
			return buf;
		case VIC_1920_1080p_120Hz_16_9:
			return "1920x1080@120.00";
		case VIC_3840_2160p_24Hz_16_9:
			sprintf(buf, "3840x2160@%s", fract_fps? "23.98" : "24.00");
			return buf;
		case VIC_3840_2160p_25Hz_16_9:
			return "3840x2160@25.00";
		case VIC_3840_2160p_30Hz_16_9:
			sprintf(buf, "3840x2160@%s", fract_fps? "29.97" : "30.00");
			return buf;
		case VIC_3840_2160p_50Hz_16_9:
			return "3840x2160@50.00";
		case VIC_3840_2160p_60Hz_16_9:
			sprintf(buf, "3840x2160@%s", fract_fps? "59.94" : "60.00");
			return buf;
		case VIC_4096_2160p_24Hz_256_135:
			sprintf(buf, "4096x2160@%s", fract_fps? "23.98" : "24.00");
			return buf;
		case VIC_4096_2160p_25Hz_256_135:
			return "4096x2160@25.00";
		case VIC_4096_2160p_30Hz_256_135:
			sprintf(buf, "4096x2160@%s", fract_fps? "29.97" : "30.00");
			return buf;
		case VIC_4096_2160p_50Hz_256_135:
			return "4096x2160@50.00";
		case VIC_4096_2160p_60Hz_256_135:
			sprintf(buf, "4096x2160@%s", fract_fps? "59.94" : "60.00");
			return buf;
		default:
			return "Unsupport_vic";
	}
}

void rtk_color_depth_convert(unsigned char color_depth, char *buf)
{
	int support_8 = 0, support_10 = 0, support_12 = 0;
	if (color_depth & 0x2)
		support_8 = 1;

	if (color_depth & 0x4)
		support_10 = 1;

	if (color_depth & 0x8)
		support_12 = 1;

	sprintf(buf, "%s/%s/%s", (support_8 == 1)?"8":"-", (support_10 == 1)?"10":"--", (support_12 == 1)?"12":"--");
}

int rtk_drm_mode_to_vic(drmModeModeInfo info)
{
	char buf[64] = {0};
	sprintf(buf, "%dx%d@%d%s", info.hdisplay, info.vdisplay, info.vrefresh, info.flags & DRM_MODE_FLAG_INTERLACE ? "i" : "");
	for (int i = 0; i < sizeof(support_vic); i++)
	{
		if (!strncmp(buf, rtk_vic_convert(support_vic[i], 0), strlen(buf))) {
			return support_vic[i];
		}
	}
	return -1;
}

int rtk_choose_best_setting(struct video_formats *format, enum rtk_color_mode *color_mode, enum rtk_hdr_mode *hdr_mode, uint64_t *max_bpc)
{
	struct color_mode_setting mode[4] = {0};
	unsigned char color_support[4] = {0};
	int ret = -1;

	color_support[RTK_COLOR_MODE_RGB] = format->rgb444;
	color_support[RTK_COLOR_MODE_Y422] = format->yuv422;
	color_support[RTK_COLOR_MODE_Y444] = format->yuv444;
	color_support[RTK_COLOR_MODE_Y420] = format->yuv420;

	for (int i = 0; i < 4; i++) {
		if (color_support[i] & COLOR_SUPPORT) {
			mode[i].valid = 1;
			mode[i].color_mode = i;
			mode[i].max_bpc = (color_support[i] & BIT_10) ? 10 : (color_support[i] & BIT_8) ? 8 : 12;
			if (mode[i].max_bpc == 10)
				mode[i].hdr_mode = RTK_HDR_MODE_INPUT;
			else
				mode[i].hdr_mode = RTK_HDR_MODE_SDR;

//add weighting by max_bpc
			if (mode[i].max_bpc == 10)
				mode[i].score += 100;
			else if (mode[i].max_bpc == 8)
				mode[i].score += 50;
			else
				mode[i].score += 0;

//add weighting by color
			if (mode[i].color_mode == RTK_COLOR_MODE_RGB)
				mode[i].score += 5;
			else if (mode[i].color_mode == RTK_COLOR_MODE_Y422)
				mode[i].score += 20;
			else if (mode[i].color_mode == RTK_COLOR_MODE_Y420)
				mode[i].score += 15;
			else
				mode[i].score += 10;
		}
	}

	struct color_mode_setting best_mode = {0};

	for (int i = 0; i < 4; i++) {
		if (mode[i].valid == 0)
			continue;
		if (mode[i].score > best_mode.score) {
			best_mode = mode[i];
			ret = 0;
		}
	}

	*color_mode = best_mode.color_mode;
	*hdr_mode = best_mode.hdr_mode;
	*max_bpc = best_mode.max_bpc;

	return ret;
}

#ifdef __cplusplus
}
#endif
