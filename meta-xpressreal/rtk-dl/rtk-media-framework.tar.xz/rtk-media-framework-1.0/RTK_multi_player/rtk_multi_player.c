#include <stdio.h>
#include <stdlib.h>
#include <xf86drm.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#include "rtk_multi_playback.h"

GList *player_list = NULL;
int drm_fd = -1;
int control_socket = -1;

pthread_t control_thread;
int enable_control_thread = 0;
pthread_mutex_t control_lock;
pthread_cond_t control_cond;

void *player_start_thread(void *data)
{
	RTK_MULTI_PLAYBACK *playback = (RTK_MULTI_PLAYBACK *)data;
	playback_start(playback);
	pthread_exit(NULL);
}

void *player_control_thread(void *data)
{
	struct sockaddr_un addr;
	struct sockaddr_un clientaddr;
	socklen_t addrlen = sizeof(clientaddr);
	int ret = -1;

	unlink(RTK_PLAYER_SOCKET_PATH);
	control_socket = socket(AF_UNIX,SOCK_DGRAM, 0);

	if (control_socket < 0) {
		printf("open socket fail\n");
		goto finish;
	}

	memset(&addr,0,sizeof(addr));
	addr.sun_family = AF_UNIX;
	strcpy(addr.sun_path, RTK_PLAYER_SOCKET_PATH);

	if (bind(control_socket ,(struct sockaddr*)&addr, sizeof(addr)) < 0) {
		printf("bind socket fail\n");
		goto finish;
	}

	while (enable_control_thread) {
		RTK_PLAYER_CMD player_cmd = {0};
		ret = recvfrom(control_socket, &player_cmd, sizeof(RTK_PLAYER_CMD), 0, (struct sockaddr*)&clientaddr, &addrlen);

		if (ret < 0) {
			printf("recvfrom ret:%d\n", ret);
			continue;
		}

		switch (player_cmd.cmd_type)
		{
			case CMD_START:
			{
				printf("player start chid:%d\n", player_cmd.channel_id);
				RTK_MULTI_PLAYBACK *playback = playback_init();
				playback->source_type = player_cmd.source_type;
				playback->codec_type = player_cmd.codec_type;
				playback->render_type = player_cmd.render_type;
				playback->dec_type = player_cmd.dec_type;
				strcpy(playback->file_path, player_cmd.file_path);
				playback->drm_fd = drm_fd;
				playback->channel_id = player_cmd.channel_id;
				playback->x = player_cmd.x;
				playback->y = player_cmd.y;
				playback->w = player_cmd.w;
				playback->h = player_cmd.h;
				pthread_create(&playback->thread, NULL, player_start_thread, playback);
				player_list = g_list_append(player_list, playback);
				break;
			}
			case CMD_STOP:
			{
				printf("player stop chid:%d\n", player_cmd.channel_id);
				for (GList *l = player_list; l != NULL; l = l->next) {
					RTK_MULTI_PLAYBACK *playback = (RTK_MULTI_PLAYBACK *)l->data;
					if (playback->channel_id == player_cmd.channel_id) {
						playback_stop(playback);
						playback_uninit(playback);
						player_list = g_list_delete_link(player_list, l);
						break;
					}
				}
				break;
			}
			default:
				break;
		}	
	}

finish:
	if (control_socket >= 0) {
		shutdown(control_socket, SHUT_RDWR);
		control_socket = -1;
	}

	pthread_exit(NULL);
}

int main(void)
{
	drm_fd = drmOpen("realtek", NULL);
	pthread_mutex_init(&control_lock, NULL);
	pthread_cond_init(&control_cond, NULL);

	enable_control_thread = 1;
	pthread_create(&control_thread, NULL, player_control_thread, NULL);

	pthread_mutex_lock(&control_lock);
	pthread_cond_wait(&control_cond, &control_lock);
	pthread_mutex_unlock(&control_lock);

	enable_control_thread = 0;
	if (control_socket >= 0)
	{
		shutdown(control_socket, SHUT_RDWR);
		control_socket = -1;
	}

	pthread_join(control_thread, NULL);

	close(drm_fd);
	g_list_free(player_list);
	pthread_mutex_destroy(&control_lock);
	pthread_cond_destroy(&control_cond);
	return 0;
}
