/*****************************************************************************
#                                                                            #
#    KVMD - The main PiKVM daemon.                                           #
#                                                                            #
#    Copyright (C) 2018-2024  Maxim Devaev <mdevaev@gmail.com>               #
#                                                                            #
#    This program is free software: you can redistribute it and/or modify    #
#    it under the terms of the GNU General Public License as published by    #
#    the Free Software Foundation, either version 3 of the License, or       #
#    (at your option) any later version.                                     #
#                                                                            #
#    This program is distributed in the hope that it will be useful,         #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of          #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
#    GNU General Public License for more details.                            #
#                                                                            #
#    You should have received a copy of the GNU General Public License       #
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.  #
#                                                                            #
*****************************************************************************/

"use strict";

import {tools, $} from "../tools.js";

export function JanusStreamer(__setActive, __setInactive, __setInfo, __organizeHook, __orient, __allow_audio, __allow_mic) {
	var self = this;

	/************************************************************************/

	__allow_mic = (__allow_audio && __allow_mic); // XXX: Mic only with audio

	var __stop = false;
	var __ensuring = false;
	var __janus = null;
	var __streaming = null;
	var __retry_ensure_timeout = null;
	var __retry_emsg_timeout = null;
	var __info_interval = null;
	var __state = null;
	var __frames = 0;
	var __res = {"width": -1, "height": -1};
	var __resize_listener_installed = false;
	var __ice = null;
	var __mediaStream = new MediaStream(); // Video
	var __audioStream = new MediaStream(); // Audio

	// Setup janus server
	const server = `https://${window.location.hostname}/janus`;

	/************************************************************************/

	self.getOrientation = () => __orient;
	self.isAudioAllowed = () => __allow_audio;
	self.isMicAllowed = () => __allow_mic;

	self.getName = function() {
		let name = "WebRTC H.264";
		if (__allow_audio) {
			name += " + Audio";
			if (__allow_mic) {
				name += " + Mic";
			}
		}
		return name;
	};

	self.getMode = () => "janus";

	self.getResolution = function() {
		let el = $("stream-video");
		return {
			"real_width": (el.videoWidth || el.offsetWidth),
			"real_height": (el.videoHeight || el.offsetHeight),
			"view_width": el.offsetWidth,
			"view_height": el.offsetHeight,
		};
	};

	self.ensureStream = function(state) {
		__state = state;
		__stop = false;
		// Ensure Janus modules
		JanusStreamer.ensure_janus((success) => {
			if (success) {
				__ensureJanus(false);
				if (!__resize_listener_installed) {
					$("stream-video").addEventListener("resize", __videoResizeHandler);
					__resize_listener_installed = true;
				}
			} else {
				tools.error("Stream [Janus]: Can not init Janus");
				__setInfo(false, false, "Can not init Janus");
			}
		});
	};

	self.stopStream = function() {
		__stop = true;
		__destroyJanus();
		if (__resize_listener_installed) {
			$("stream-video").removeEventListener("resize", __videoResizeHandler);
			__resize_listener_installed = false;
		}
	};

	var __videoResizeHandler = function(ev) {
		let el = ev.target;
		if (__res.width !== el.videoWidth || __res.height !== el.videoHeight) {
			__res.width = el.videoWidth;
			__res.height = el.videoHeight;
			__organizeHook();
		}
	};

	var __ensureJanus = function(internal) {
		if (__janus === null && !__stop && (!__ensuring || internal)) {
			__ensuring = true;
			__setInactive();
			__setInfo(false, false, "");
			tools.info("Stream [Janus]: Starting Janus ...");

			if (typeof window.Janus === "undefined") {
				tools.error("Stream [Janus]: Janus undefined");
				__setInfo(false, false, "Janus undefined");
				__finishJanus();
				return;
			}

			if (!Janus.isWebrtcSupported()) {
				tools.error("Stream [Janus]: Browser does not support WebRTC");
				__setInfo(false, false, "Browser does not support WebRTC");
				__finishJanus();
				return;
			}

			__janus = new Janus({
				server: server,
				iceServers: __getIceServers(),
				success: function() {
					tools.info("Stream [Janus]: Janus created successfully");
					__attachJanus();
				},
				error: function(error) {
					tools.error("Stream [Janus]: Janus failed:", error);
					__setInfo(false, false, error);
					__finishJanus();
				}
			});
		}
	};

	var __getIceServers = function() {
		if (__ice !== null && __ice.url) {
			tools.info("Stream [Janus]: Using the custom ICE Server obtained from uStreamer:", __ice);
			return [{ urls: __ice.url }];
		}
		return [{ urls: "stun:stun.l.google.com:19302" }];
	};

	var __finishJanus = function() {
		if (__stop) {
			if (__retry_ensure_timeout !== null) {
				clearTimeout(__retry_ensure_timeout);
				__retry_ensure_timeout = null;
			}
			__ensuring = false;
		} else {
			if (__retry_ensure_timeout === null) {
				__retry_ensure_timeout = setTimeout(function() {
					__retry_ensure_timeout = null;
					__ensureJanus(true);
				}, 5000);
			}
		}
		__stopRetryEmsgInterval();
		__stopInfoInterval();
		if (__streaming) {
			tools.info("Stream [Janus]: Detaching streaming ...:", __streaming.getPlugin(), __streaming.getId());
			__streaming.detach();
			__streaming = null;
		}
		__janus = null;
		__setInactive();
		if (__stop) {
			__setInfo(false, false, "");
		}
	};

	var __destroyJanus = function() {
		if (__janus !== null) {
			__janus.destroy();
		}
		__finishJanus();
		let stream = $("stream-video").srcObject;
		if (stream) {
			for (let track of stream.getTracks()) {
				__removeTrack(track);
			}
		}
		let audio = $("stream-audio").srcObject;
		if (audio) {
			for (let track of audio.getTracks()) {
				__removeTrack(track, "audio");
			}
		}
	};

	var __addTrack = function(track, kind = "video") {
		let el = kind === "video" ? $("stream-video") : $("stream-audio");
		if (el.srcObject) {
			for (let tr of el.srcObject.getTracks()) {
				if (tr.kind === track.kind && tr.id !== track.id) {
					__removeTrack(tr, kind);
				}
			}
		}
		if (!el.srcObject) {
			el.srcObject = kind === "video" ? __mediaStream : __audioStream;
		}
		el.srcObject.addTrack(track);
	};

	var __removeTrack = function(track, kind = "video") {
		let el = kind === "video" ? $("stream-video") : $("stream-audio");
		if (!el.srcObject) {
			return;
		}
		track.stop();
		el.srcObject.removeTrack(track);
		if (el.srcObject.getTracks().length === 0) {
			el.srcObject = null;
		}
	};

	var __attachJanus = function() {
		if (__janus === null) {
			return;
		}
		__janus.attach({
			plugin: "janus.plugin.streaming", // Changed to standard streaming plugin
			opaqueId: "streamtest-" + Janus.randomString(12),
			success: function(pluginHandle) {
				__streaming = pluginHandle;
				tools.info("Stream [Janus]: Streaming attached:", __streaming.getPlugin(), __streaming.getId());
				tools.info("Stream [Janus]: Sending LIST ...");
				__streaming.send({
					message: { request: "list" },
					success: function(result) {
						tools.info("Stream [Janus]: Received stream list:", result);
						if (result && result.list && result.list.length > 0) {
							let streamId = result.list[0].id;
							tools.info("Stream [Janus]: Watching stream ID:", streamId);
							__sendWatch(streamId);
						} else {
							tools.error("Stream [Janus]: No available streams");
							__setInfo(false, false, "No available streams");
						}
					}
				});
			},
			error: function(error) {
				tools.error("Stream [Janus]: Failed to attach Streaming plugin:", error);
				__setInfo(false, false, error);
				__destroyJanus();
			},
			iceState: function(state) {
				tools.info("Stream [Janus]: ICE state:", state);
			},
			webrtcState: function(on) {
				tools.info("Stream [Janus]: WebRTC state:", on ? "Connected" : "Disconnected");
			},
			onmessage: function(msg, jsep) {
				__stopRetryEmsgInterval();
				tools.info("Stream [Janus]: Received message:", msg);

				if (msg.error) {
					tools.error("Stream [Janus]: Received error message:", msg.error);
					__setInfo(false, false, msg.error);
					if (__retry_emsg_timeout === null) {
						__retry_emsg_timeout = setTimeout(function() {
							if (!__stop) {
								__sendStop();
								if (msg.result && msg.result.id) {
									__sendWatch(msg.result.id);
								}
							}
							__retry_emsg_timeout = null;
						}, 2000);
					}
					return;
				}

				if (msg.result && msg.result.status) {
					tools.info("Stream [Janus]: Streaming state:", msg.result.status);
					if (msg.result.status === "started") {
						__setActive();
						__setInfo(false, false, "");
					} else if (msg.result.status === "stopped") {
						__setInactive();
						__setInfo(false, false, "");
					}
				}

				if (jsep) {
					tools.info("Stream [Janus]: Received JSEP:", jsep);
					let tracks = [{ type: "video", recv: true, send: false }];
					//if (__allow_audio) {
						tracks.push({ type: "audio", recv: true, send: __allow_mic });
					//}
					__streaming.createAnswer({
						jsep: jsep,
						tracks: tracks,
						customizeSdp: function(jsep) {
							jsep.sdp = jsep.sdp.replace("useinbandfec=1", "useinbandfec=1;stereo=1");
						},
						success: function(jsep) {
							tools.info("Stream [Janus]: Created answer JSEP:", jsep);
							__sendStart(jsep);
						},
						error: function(error) {
							tools.error("Stream [Janus]: Failed to create answer:", error);
							__setInfo(false, false, error);
						}
					});
				}
			},
			onremotetrack: function(track, mid, on, metadata) {
				tools.info("Stream [Janus]: Remote track event:", { track, mid, on, metadata });
				if (on && metadata?.reason === "created") {
					if (track.kind === "video") {
						__addTrack(track, "video");
						__startInfoInterval();
					} else if (track.kind === "audio") {
						__audioStream.addTrack(track);
				   		document.getElementById("stream-audio").srcObject = __audioStream;
					}
					//track.onmute = () => tools.info(`Stream [Janus]: ${track.kind} muted`);
					//track.onunmute = () => tools.info(`Stream [Janus]: ${track.kind} unmuted`);
					track.onended = () => tools.info(`Stream [Janus]: ${track.kind} ended`);
				} else if (!on && metadata?.reason === "ended") {
					__removeTrack(track, track.kind);
				}
			},
			oncleanup: function() {
				tools.info("Stream [Janus]: Received cleanup notification");
				__stopInfoInterval();
			}
		});
	};

	var __startInfoInterval = function() {
		__stopInfoInterval();
		__setActive();
		__updateInfo();
		__info_interval = setInterval(__updateInfo, 1000);
	};

	var __stopInfoInterval = function() {
		if (__info_interval !== null) {
			clearInterval(__info_interval);
			__info_interval = null;
		}
	};

	var __stopRetryEmsgInterval = function() {
		if (__retry_emsg_timeout !== null) {
			clearTimeout(__retry_emsg_timeout);
			__retry_emsg_timeout = null;
		}
	};

	var __updateInfo = function() {
		if (__streaming !== null) {
			let info = "";
			let el = $("stream-video");
			let frames = el.webkitDecodedFrameCount || el.mozPaintedFrames || null;
			info = `${__streaming.getBitrate()}`.replace("kbits/sec", "kbps");
			if (frames !== null) {
				info += ` / ${Math.max(0, frames - __frames)} fps dynamic`;
				__frames = frames;
			}
			__setInfo(true, __isOnline(), info);
		}
	};

	var __isOnline = function() {
		return !!(__state && __state.source.online);
	};

	var __sendWatch = function(streamId) {
		if (__streaming) {
			tools.info(`Stream [Janus]: Sending WATCH(id=${streamId}, orient=${__orient}, audio=${__allow_audio}, mic=${__allow_mic}) ...`);
			__streaming.send({
				message: {
					request: "watch",
					id: streamId,
					params: {
						orientation: __orient,
						audio: __allow_audio,
						mic: __allow_mic
					}
				}
			});
		}
	};

	var __sendStart = function(jsep) {
		if (__streaming) {
			tools.info("Stream [Janus]: Sending START ...");
			__streaming.send({ message: { request: "start" }, jsep: jsep });
		}
	};

	var __sendStop = function() {
		__stopInfoInterval();
		if (__streaming) {
			tools.info("Stream [Janus]: Sending STOP ...");
			__streaming.send({ message: { request: "stop" } });
			__streaming.hangup();
		}
	};
}

JanusStreamer.ensure_janus = function(callback) {
	// Check if adapter.js and janus.js have been loaded via <script> tags
	if (typeof window.adapter === "undefined") {
		tools.info("Stream [Janus]: window.adapter is undefined, attempting to dynamically load adapter.js...");
		const adapterScript = document.createElement("script");
		adapterScript.src = "/share/js/kvm/adapter.js";
		adapterScript.onload = function() {
			tools.info("Stream [Janus]: adapter.js loaded successfully, continuing to check janus.js...");
			loadJanusScript(callback);
		};
		adapterScript.onerror = function() {
			tools.error("Stream [Janus]: Failed to load adapter.js, check network or CDN availability");
			callback(false);
		};
		document.head.appendChild(adapterScript);
	} else {
		tools.info("Stream [Janus]: window.adapter is defined, continuing to check janus.js...");
		loadJanusScript(callback);
	}
};

function loadJanusScript(callback) {
	if (window.Janus && typeof window.Janus.init === "function") {
		tools.info("Stream [Janus]: Detected window.Janus, already initialized or initializing...");
		window.Janus.init({
			debug: "all",
			callback: function() {
				tools.info("Stream [Janus]: Janus initialization completed");
				callback(true);
			}
		});
	} else {
		tools.info("Stream [Janus]: window.Janus is undefined, attempting to dynamically load janus.js...");
		const janusScript = document.createElement("script");
		janusScript.src = "/share/js/kvm/janus.js"; // Ensure the path is correct
		janusScript.onload = function() {
			if (window.Janus && typeof window.Janus.init === "function") {
				tools.info("Stream [Janus]: janus.js loaded successfully, starting initialization...");
				window.Janus.init({
					debug: "all",
					callback: function() {
						tools.info("Stream [Janus]: Janus initialization completed");
						callback(true);
					}
				});
			} else {
				tools.error("Stream [Janus]: window.Janus.init is still undefined after loading janus.js");
				callback(false);
			}
		};
		janusScript.onerror = function() {
			tools.error("Stream [Janus]: Failed to load janus.js, check file path or server configuration");
			callback(false);
		};
		document.head.appendChild(janusScript);
	}
}

JanusStreamer.is_webrtc_available = function() {
	return !!window.RTCPeerConnection;
};