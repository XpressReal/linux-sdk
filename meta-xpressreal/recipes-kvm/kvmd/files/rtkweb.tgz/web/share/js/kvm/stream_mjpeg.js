/*****************************************************************************
#                                                                            #
#    KVMD - The main PiKVM daemon.                                           #
#                                                                            #
#    Copyright (C) 2018-2024  Maxim Devaev <mdevaev@gmail.com>               #
#                                                                            #
#    This program is free software: you can redistribute it and/or modify    #
#    it under the terms of the GNU General Public License as published by    #
#    the Free Software Foundation, either version 3 of the License, or       #
#    (at your option) any later version.                                     #
#                                                                            #
#    This program is distributed in the hope that it will be useful,         #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of          #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
#    GNU General Public License for more details.                            #
#                                                                            #
#    You should have received a copy of the GNU General Public License       #
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.  #
#                                                                            #
*****************************************************************************/


"use strict";


import {ROOT_PREFIX} from "../vars.js";
import {tools, $} from "../tools.js";

// Dynamically load Janus library
function loadJanusScript() {
	return new Promise((resolve, reject) => {
		if (typeof Janus !== 'undefined') {
			resolve();
			return;
		}

		// Load adapter.js (WebRTC adapter)
		const adapterScript = document.createElement('script');
		adapterScript.src = '/share/js/kvm/adapter.js';
		adapterScript.onload = () => {
			// Load janus.js
			const janusScript = document.createElement('script');
			janusScript.src = "/share/js/kvm/janus.js"; // Ensure the path is correct
			janusScript.onload = () => resolve();
			janusScript.onerror = () => reject(new Error('Failed to load janus.js'));
			document.head.appendChild(janusScript);
		};
		adapterScript.onerror = () => reject(new Error('Failed to load adapter.js'));
		document.head.appendChild(adapterScript);
	});
}

function setupJanus() {
	// Janus audio streaming setup will be initialized here
	let janus = null;
	let streaming = null;
	const server = `https://${window.location.hostname}/janus`;
	let audioStream = new MediaStream();

	// First load the Janus library
	return loadJanusScript().then(() => {
		return new Promise((resolve, reject) => {
			if (!Janus.isWebrtcSupported()) {
				console.error("WebRTC not supported by this browser");
				reject(new Error("WebRTC not supported"));
				return;
			}
			Janus.init({
				debug: "all",
				callback: function() {
					if (!Janus.isWebrtcSupported()) {
						console.error("WebRTC not supported by this browser");
						reject(new Error("WebRTC not supported"));
						return;
					}

					janus = new Janus({
						server: server,
						iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
						success: function() {
							console.log("Janus instance created");
							janus.attach({
								plugin: "janus.plugin.streaming",
								opaqueId: "streamtest-" + Janus.randomString(12),
								success: function(pluginHandle) {
									streaming = pluginHandle;
									console.log("Plugin attached: " + streaming.getPlugin() + ", id=" + streaming.getId());
									
									streaming.send({
										message: { request: "list" },
										success: function(result) {
											console.log("Available streams:", result);
											if (result && result.list && result.list.length > 0) {
												let streamId = result.list[0].id;
												console.log("Watching stream ID:", streamId);
												streaming.send({ message: { request: "watch", id: streamId } });
											} else {
												console.error("No streams available");
											}
										}
									});

									resolve({ janus, streaming, audioStream });
								},
								error: function(error) {
									console.error("Plugin attach error:", error);
									reject(error);
								},
								onmessage: function(msg, jsep) {
									console.log("Message received:", msg);
									if (msg.error) {
										console.error("Message error:", msg.error);
										return;
									}
									if (jsep) {
										console.log("Received JSEP:", jsep);
										streaming.createAnswer({
											jsep: jsep,
											tracks: [
												{ type: 'audio', recv: true, send: false }  // Only receive audio
											],
											success: function(jsep) {
												console.log("Answer JSEP:", jsep);
												streaming.send({ message: { request: "start" }, jsep: jsep });
											},
											error: function(error) {
												console.error("Create answer error:", error);
											}
										});
									}
								},
								onremotetrack: function(track, mid, on, metadata) {
									console.log("Remote track event:", { track, mid, on, metadata });
									if (on && metadata?.reason === "created") {
										if (track.kind === "audio") {
											audioStream.addTrack(track);
											document.getElementById("stream-audio").srcObject = audioStream;
										}
										track.onmute = () => tools.info(`Stream [Janus]: ${track.kind} muted`);
										track.onunmute = () => tools.info(`Stream [Janus]: ${track.kind} unmuted`);
										track.onended = () => tools.info(`Stream [Janus]: ${track.kind} ended`);
									} else if (!on && metadata?.reason === "ended") {
										__removeTrack(track, track.kind);
									}
								},
								iceState: function(state) {
									console.log("ICE state:", state);
								},
								webrtcState: function(on) {
									console.log("WebRTC state:", on ? "up" : "down");
								},
								error: function(error) {
									console.error("Plugin error:", error);
								}
							});
						},
						error: function(error) {
							console.error("Janus error:", error);
							reject(error);
						}
					});
				}
			});
		});
	});
}

export function MjpegStreamer(__setActive, __setInactive, __setInfo, __organizeHook) {
	var self = this;

	/************************************************************************/

	var __key = tools.makeRandomId();
	var __id = "";
	var __fps = -1;
	var __state = null;

	var __timer = null;
	var __timer_retries = 0;

	// Janus audio-related variables
	var __janusPromise = null;
	var __janusInstances = null;
	var __audioEnabled = false;

	/************************************************************************/

	self.getName = () => "HTTP MJPEG + Audio";
	self.getMode = () => "mjpeg";

	self.getResolution = function() {
		let el = $("stream-image");
		return {
			"real_width": el.naturalWidth,
			"real_height": el.naturalHeight,
			"view_width": el.offsetWidth,
			"view_height": el.offsetHeight,
		};
	};

	self.enableAudio = function(enable = true) {
		__audioEnabled = enable;
		if (enable && !__janusPromise) {
			__initializeJanus();
		} else if (!enable && __janusInstances) {
			__destroyJanus();
		}
	};

	self.ensureStream = function(state) {
		if (state) {
			__state = state;
			__findId();
			if (__id.length > 0 && __id in __state.stream.clients_stat) {
				__setStreamActive();
				__stopChecking();
				__organizeHook();
				
			} else {
				__ensureChecking();
				__initializeJanus();
			}
		} else {
			__stopChecking();
			__setStreamInactive();
			if (__janusInstances) {
				__destroyJanus();
			}
		}
	};

	self.stopStream = function() {
		self.ensureStream(null);
		let blank = `${ROOT_PREFIX}share/png/blank-stream.png`;
		if (!String.prototype.endsWith.call($("stream-image").src, blank)) {
			$("stream-image").src = blank;
		}
		
		// Stop audio
		if (__janusInstances) {
			__destroyJanus();
		}
	};

	var __initializeJanus = function() {
		if (__janusPromise) {
			return __janusPromise;
		}

		__janusPromise = setupJanus()
			.then((instances) => {
				__janusInstances = instances;
				__logInfo("Janus audio streaming initialized");
			})
			.catch((error) => {
				__logInfo("Failed to initialize Janus audio:", error);
				__janusPromise = null;
			});

		return __janusPromise;
	};

	var __destroyJanus = function() {
		if (__janusInstances) {
			try {
				if (__janusInstances.streaming) {
					__janusInstances.streaming.detach();
				}
				if (__janusInstances.janus) {
					__janusInstances.janus.destroy();
				}
				
				__logInfo("Janus audio streaming destroyed");
			} catch (error) {
				__logInfo("Error destroying Janus:", error);
			}
		}
		__janusInstances = null;
		__janusPromise = null;
	};

	var __setStreamActive = function() {
		let old_fps = __fps;
		__fps = __state.stream.clients_stat[__id].fps;
		if (old_fps < 0) {
			__logInfo("Active");
			__setActive();
		}
		__setInfo(true, __state.source.online, `${__fps} fps dynamic`);

	};

	var __setStreamInactive = function() {
		let old_fps = __fps;
		__key = tools.makeRandomId();
		__id = "";
		__fps = -1;
		__state = null;
		if (old_fps >= 0) {
			__logInfo("Inactive");
			__setInactive();
			__setInfo(false, false, "");
		}
	};

	var __ensureChecking = function() {
		if (!__timer) {
			__timer_retries = 10;
			__timer = setInterval(__checkStream, 100);
		}
	};

	var __stopChecking = function() {
		if (__timer) {
			clearInterval(__timer);
		}
		__timer = null;
		__timer_retries = 0;
	};

	var __findId = function() {
		let sc = tools.cookies.get("stream_client");
		if (__id.length === 0 && sc && sc.startsWith(__key + "/")) {
			__logInfo("Found acceptable stream_client cookie:", sc);
			__id = sc.slice(sc.indexOf("/") + 1);
		}
	};

	var __checkStream = function() {
		__findId();

		if (__id.length > 0 && __id in __state.stream.clients_stat) {
			__setStreamActive();
			__stopChecking();

		} else if (__id.length > 0 && __timer_retries >= 0) {
			__timer_retries -= 1;

		} else {
			__setStreamInactive();
			__stopChecking();

			let path = `${ROOT_PREFIX}streamer/stream?key=${encodeURIComponent(__key)}`;
			if (tools.browser.is_safari || tools.browser.is_ios) {
				// uStreamer fix for WebKit
				__logInfo("Using dual_final_frames=1 to fix WebKit bugs");
				path += "&dual_final_frames=1";
			} else if (tools.browser.is_chrome || tools.browser.is_blink) {
				// uStreamer fix for Blink https://bugs.chromium.org/p/chromium/issues/detail?id=527446
				__logInfo("Using advance_headers=1 to fix Blink bugs");
				path += "&advance_headers=1";
			}

			__logInfo("Refreshing ...");
			$("stream-image").src = path;
		}
	};

	var __logInfo = (...args) => tools.info("Stream [MJPEG]:", ...args);
}